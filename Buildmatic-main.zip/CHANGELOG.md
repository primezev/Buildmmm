# Changelog

## 0.1.0

First release. Eleven jars, one per build target, covering Minecraft 1.19 through 26.2.

### Swapping

- Variant picker on the block under the crosshair (**V**), applying each selection live so the ghost
  changes while the list is still open
- Swap by material (every other stair) or by shape (every other oak thing), scoped to one block, to
  every identical block, to a whole material, or to the connected volume of a flood fill
- Properties carry across the swap: a north-facing bottom oak stair becomes a north-facing bottom
  spruce stair
- Whole-material swaps are expressed material to material, so every shape follows instead of
  collapsing into one block
- Swaps are non-destructive layers: reorder, toggle, remove, undo, redo. The file on disk is never
  touched until you export
- Seven build themes (medieval, futuristic, asian, ancient, modern, desert, mesa), each with several
  combinations, applied as one more layer
- Schematic-wide and region-scoped rules fold into an effective palette, so converting a
  ten-million-block build costs a few hundred evaluations rather than ten million

### Schematics

- Reads and writes `.litematic` (v4–v7, multi-region, entities and metadata), Sponge `.schem`
  (v1/v2/v3) and vanilla structure `.nbt`
- Format detected by content, so a file with the wrong extension still loads
- Capture an area from the world and save it out, with several named sub-regions under one origin so
  a sparse build does not store the empty space between its parts
- Unloaded chunks are reported on save rather than quietly written as air

### In the world

- Ghost preview with per-slice meshing, so a one-block swap re-meshes one 16³ cube
- Layer slices on any axis, error highlighting, and hiding blocks already placed
- Ten tool modes on a stick: area selection, placement, rotate, variant swap, schematic edit, plus
  fill, replace, paste, move and delete, which are hidden entirely in survival
- World edits run layer by layer, confirm before overwriting, and the last sixteen jobs can be undone
- Easy place: right click a ghost block to place what the schematic wants, found anywhere in the
  inventory, already facing the right way
- Placements and their swap layers are remembered per world and per dimension, autosaved every 30 s
  and on disconnect

### Menu

One window, seven tabs (Schematics, Placements, Swaps, Areas, Materials, Verify, Settings) over a
running game, so a change shows in the preview around the panel straight away. No chat commands.

- Material list driven by the effective palette, not the original one: double slabs cost two, door
  upper halves cost nothing, wall torches cost torches, flowing water costs nothing
- Verifier reporting correct, missing, extra, wrong block and wrong state, with unloaded chunks
  counted separately rather than as missing
- English and Italian

### Known limitations

- The ghost opacity slider has no effect on 1.19 – 1.20.4. The preview is still see-through, it just
  does not respond to the setting: the older draw call has no alpha channel.
- The menu panels and the renderer have not been driven through every feature on every one of the
  eleven targets. The engine underneath is covered by 196 unit tests that pass on all of them.
- No printer mode.
- Legacy MCEdit `.schematic` files are not read; convert with WorldEdit first.
- Weighted swaps exist in the engine and are saved and restored, but nothing in the interface
  creates one yet.
- `.buildmatic` files are currently written as plain Litematica files; swap layers live in the
  per-world placement store instead.
