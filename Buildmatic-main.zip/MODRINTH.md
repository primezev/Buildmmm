# Buildmatic

A schematic mod in the spirit of Litematica, built around one idea it does not have: **live variant
swapping**. Point at any block in a loaded schematic, press a key, and pick a different material or
a different shape for it. The schematic, the ghost preview and the material list all update at once,
and nothing is destroyed: every swap is a layer you can reorder, switch off or delete.

Client-side. Fabric. One source tree from Minecraft 1.19 through 26.2.

## Swapping

Litematica makes you commit to the palette the schematic shipped with. If a build was made in oak
and you want it in dark oak, you export it, edit it elsewhere and re-import. Buildmatic treats the
palette as something you edit in place.

Look at a block, press **V**, and a list opens with everything that could stand in for it. Arrow up
and down and **each selection is applied straight away**, so the ghost behind the panel changes
while the list is still open, and choosing is a matter of looking rather than guessing. Three
buttons across the top decide what you get:

- **Other materials / Other shapes**: every other stair, or every other oak thing
- **This block / All identical / Whole material / Connected**: how far the swap reaches, from one
  clicked block to a flood fill of everything touching it
- **Family only / Everything**: lead with the wood set, or show all two hundred stairs

Enter keeps the selection, Escape closes; either way it is a normal layer, so you can switch it off,
remove it, or undo it.

Properties survive the swap: a north-facing bottom oak stair becomes a north-facing bottom spruce
stair, not a default-state spruce stair. Picking a whole material swaps material to material, so
every shape follows along instead of collapsing into the one block you looked at.

You can also start from the shopping list: the Materials tab's **Swap this** opens the same picker
on the selected row. That is the shortest path from "I am 320 spruce stairs short" to "make them oak
instead", without going to find one of those blocks in the world to look at.

## The rest of it

Everything lives behind one menu with seven tabs, so nothing is more than a keypress away.

- **Schematics**: browse the folder with each file's real size, block count and author read from
  the file, load with a double click, open the folder in your file manager
- **Placements**: rotate and mirror in place rather than orbiting the build, nudge it, lock it,
  slice it by layer on any axis
- **Swaps**: the layer stack. Move a layer up or down, switch one off, remove it, undo, clear the
  lot, or open the theme picker
- **Areas**: draw a box around something you built and save it out, with several named sub-regions
  under one origin so a sparse build does not store the empty space between its parts
- **Materials**: a live list driven by the swaps, not the original palette. Double slabs cost two,
  door upper halves cost nothing, wall torches cost torches, flowing water costs nothing. Counts
  your inventory and multiplies for building the same thing several times
- **Verify**: correct, missing, extra, wrong block, wrong state, with unloaded chunks reported
  separately instead of counted as missing
- **Settings**: ghost opacity, error highlighting, hiding blocks already placed, the scroll step,
  easy place, and a shortcut to rebind the keys

No chat commands: a stick in your hand and one window.

## The tool

Hold a **stick** and right click once to switch it on; the first click only arms it, so picking a
stick up never moves anything by accident. Clicks do nothing while it is put away, so ordinary play
comes straight back.

Hold **R** for the mode ring, or walk the modes with `[` and `]`. There are ten: area selection,
placement, rotate, variant swap and schematic edit, plus the five that write to the world (fill,
replace, paste, move and delete). Those five are **hidden entirely in survival** rather than failing
when used. World edits run layer by layer, ask before overwriting anything, and the last sixteen
jobs can be undone.

## Keys

Defaults, all rebindable under Controls → Miscellaneous.

| Key | Does |
|---|---|
| **M** | Opens the menu, on whichever tab you left it |
| **N** / **J** / **K** / **H** | Straight to Schematics / Materials / Swaps / Areas |
| **V** | Variant picker for the block under the crosshair |
| **R** *(hold)* | The tool mode ring; releasing picks whatever is highlighted |
| **`[`** / **`]`** | Previous / next tool mode |
| **Enter** | Runs the current mode |
| **G** | Picks the targeted block as the fill block (Ctrl: as the block to replace) |
| **=** / **-** | Nudge a corner, a box or the placement one block |
| **B** | Toggle the preview |
| **PageUp** / **PageDown** | Move the layer slice |
| **Ctrl+Z** / **Ctrl+Y** | Undo / redo |

Scrolling with the tool armed moves the placement along the way you are facing; Ctrl+scroll moves it
up and down.

## Easy place

With the tool **not** in hand, right clicking a ghost block places the block the schematic wants,
found anywhere in your inventory, already facing the right way. In creative singleplayer the state
is written directly, so the orientation is exact; anywhere else the item is selected and vanilla
does the placing, which gets the block right but not always its rotation, the same limit Litematica
hits without a server-side helper mod. On by default.

## Themes

Re-dress a whole build at once. Seven palettes (medieval, futuristic, asian, ancient, modern,
desert, mesa), each with several combinations, because "medieval" is not one palette: a cobblestone
keep, an oak-framed village house and a mossy ruin share none of their blocks.

A theme fills the same handful of roles every time, so clicking through the list shows you the same
build seven ways without touching its shape. It arrives as one more swap layer, so you can switch it
off or undo it like anything else. Blocks a theme wants that your Minecraft version does not have
fall back to older ones, and a combination whose materials do not exist yet is hidden rather than
offered and silently doing nothing.

## Formats

| Format | Read | Write | Notes |
|---|---|---|---|
| `.litematic` | yes | yes | v4 to v7. Keeps every region separately, plus entities and metadata |
| `.schem` | yes | yes | Sponge v1/v2/v3, for WorldEdit and FAWE. Flattened into one box |
| `.nbt` | yes | yes | Vanilla structure. One box; structure blocks refuse over 48 per side |
| `.schematic` | no | no | Legacy MCEdit. Reports a clear error, convert with WorldEdit first |

Put your files in `<game folder>/schematics` and press **M**.

Where you left each build is remembered per world and per dimension, swap layers included, so
stepping through a nether portal or rejoining a server does not cost you an afternoon of lining a
build up against an existing structure.

## Requirements

- **Fabric Loader** 0.16 or newer
- **Fabric API**
- Client-side only. Installing it on a server does nothing; it will not complain, but it will not
  do anything either.

## Status

This is an early release and it behaves like one. The engine underneath is covered by 196 unit
tests that run on every supported Minecraft version: formats, block-state rotation and mirroring,
the swap engine, placement maths, the material list, the verifier, the ghost geometry. What has had
far less exposure is the part you actually see: the panels and the renderer have not been driven
through every feature on every one of the eleven targets.

Two things to know going in:

- On 1.19 to 1.20.4 the ghost opacity slider has no effect. The preview is still see-through, it
  just does not respond to the setting; the older rendering call has no alpha channel to give it.
- There is no printer mode yet.

Bug reports with the Minecraft version and what you were doing are genuinely useful right now.

## Licence

MIT. Source on [GitHub](https://github.com/JK-jackk99/Buildmatic), and there is a
[Discord](https://discord.gg/jkstudios) if you would rather report something there than open an
issue.
