# Buildmatic

A client-side schematic mod for Fabric, in the spirit of Litematica, built around one idea it does
not have: **live variant swapping**. Point at any block of a loaded schematic, press a key, and pick
a different material or a different shape for it. The schematic, the ghost preview and the material
list all update at once, and nothing is destroyed: every swap is a layer you can reorder, switch
off, or delete.

One source tree, eleven build targets, Minecraft **1.19 through 26.2**.

---

## Swapping

Litematica makes you commit to the palette the schematic shipped with. If a build was made in oak
and you want it in dark oak, you export it, edit it elsewhere and re-import. Buildmatic treats the
palette as something you edit in place.

Look at a block, press **V**, and a list opens with everything that could stand in for it. Walking
the list with the arrow keys applies each choice immediately, so the ghost behind the panel changes
while the list is still open. Three buttons across the top decide what you get:

| Button | Choices |
|---|---|
| Axis | **Other materials** (every other stair) or **Other shapes** (every other oak thing) |
| Scope | **This block** · **All identical** · **Whole material** · **Connected** (flood fill) |
| Breadth | **Family only** (lead with the wood set) or **Everything** (all two hundred stairs) |

Enter keeps the selection, Escape closes; either way it lands as a normal swap layer, so the Swaps
tab can switch it off or remove it and **Ctrl+Z** undoes it.

Properties survive the swap: a north-facing bottom oak stair becomes a north-facing bottom spruce
stair, not a default-state spruce stair. Picking a whole material swaps material to material, so
every shape follows along instead of collapsing into the one block you clicked.

You can also start from the shopping list. The Materials tab's **Swap this** opens the same picker
on the selected row, which is the shortest path from "I am 320 spruce stairs short" to "make them
oak instead" without going to find one of those blocks to look at.

### Why it is fast

Rules scoped to a region or the whole schematic are folded into an **effective palette**: one
resolved state per palette slot, computed once. Converting every oak block in a ten-million-block
build costs a few hundred evaluations, not ten million. Only rules bound to specific positions (one
block, a box, a flood fill) fall back to a per-position map, and those are bounded by their own
scope. Dirty tracking follows the same split, so a one-block swap re-meshes one 16³ slice rather
than the whole build.

---

## Requirements

- **Fabric Loader** 0.16 or newer
- **Fabric API**
- Client-side. It will load on a server without complaining, but it registers no server behaviour.

Drop the jar in `mods/` and put your schematics in `<game folder>/schematics`.

---

## Using it

No chat commands: a stick in your hand and one menu.

### The menu

Press **M**. One window, seven tabs: **Schematics**, **Placements**, **Swaps**, **Areas**,
**Materials**, **Verify**, **Settings**. The game keeps running underneath, so a change made on the
Swaps tab shows up in the preview around the panel straight away.

- **Schematics**: the folder, with each file's real size, block count and author read from the
  file, so picking the right build out of thirty is a matter of looking rather than loading them one
  at a time. Double click loads; **Open folder** hands the folder to your file manager.
- **Placements**: move the build to you, rotate, mirror, lock, show/hide, close, paste or clear it,
  and slice it by layer on any axis.
- **Swaps**: the layer stack. Toggle a layer, remove it, move it up or down, undo, clear the lot,
  or open the theme picker.
- **Areas**: draw a box around something you built and save it out. **Add region** gives the
  selection another named box, so a build with a gap in it is captured without storing the empty
  space; each box becomes a region of the file. **Save as schematic** warns before replacing an
  existing file and reports how many sample positions sat in unloaded chunks rather than quietly
  saving them as air.
- **Materials**: a live list driven by the effective palette, not the original one. Double slabs
  cost two, door upper halves cost nothing, wall torches cost torches, flowing water costs nothing.
  Counts your inventory, filters to what is missing, and multiplies for building the same thing
  several times.
- **Verify**: correct / missing / extra / wrong block / wrong state, with unloaded chunks reported
  separately instead of counted as missing.
- **Settings**: ghost opacity, error highlighting, hiding blocks already placed, the scroll step,
  easy place, and a shortcut to rebind the keys.

### The tool

Hold a **stick** and right click once to switch it on; the first click only arms it, so picking a
stick up never moves anything by accident. Clicks do nothing while it is put away, and putting it
away disarms it again, so ordinary play comes straight back.

Hold **R** for the mode ring, or walk the modes with **`[`** and **`]`**. The current mode is
announced above the hotbar with a line explaining what its buttons do.

| Mode | What it does |
|---|---|
| Area selection | Left click corner 1, right click corner 2, or expand in the other sub-mode |
| Placement | Right click drops the build on that block, left click on top of it; Enter pastes |
| Rotate | Right click turns the build, left click turns it back |
| Variant swap | Right click a ghost block for its variants |
| Schematic edit | Left click deletes a ghost block, right click places the off-hand block |
| Fill | Fills the selection with the picked block |
| Replace | Swaps one block for another inside the selection |
| Paste | Writes the build into the world |
| Move | Enter cuts the selection out and hands it to the placement tools so you can carry it |
| Delete | Clears the selection |

The first five read or edit the schematic. The last five write to the world, so they are **hidden
entirely in survival** rather than failing when used. World edits run layer by layer with progress
above the hotbar, ask for confirmation when they would overwrite something, and the last sixteen
jobs can be undone.

Schematic edits are applied as position-scoped swap layers rather than by rewriting the schematic,
so every edit stays listed, individually switchable and undoable, and the file on disk is untouched
until you deliberately export.

### Keys

Defaults. All of them are rebindable under Controls, in the Miscellaneous category.

| Key | Does |
|---|---|
| **M** | Opens the menu, on whichever tab you left it |
| **N** / **J** / **K** / **H** | Straight to Schematics / Materials / Swaps / Areas |
| **V** | Variant picker for the block under the crosshair |
| **R** *(hold)* | The tool mode ring; releasing picks whatever is highlighted |
| **`[`** / **`]`** | Previous / next tool mode, without opening the ring |
| **Enter** | Runs the current mode |
| **G** | Picks the targeted block as the fill block (Ctrl: as the block to replace) |
| **=** / **-** | Nudge the held corner, box or placement one block the way you face |
| **B** | Toggle the preview |
| **PageUp** / **PageDown** | Move the layer slice |
| **Ctrl+Z** / **Ctrl+Y** | Undo / redo; world edits first, then swap layers |

Scrolling with the tool armed moves the placement along the direction you are facing; Ctrl+scroll
moves it up and down. The step size is on the Settings tab.

### Easy place

With the tool **not** in hand, right clicking a ghost block places the block the schematic wants,
found anywhere in the inventory, already facing the right way. In creative singleplayer the state is
written directly, so the orientation is exact; anywhere else the item is selected and vanilla does
the placing, which gets the block right but not always its rotation, the same limit Litematica
hits without a server-side helper. On by default, switchable on the Settings tab.

### Themes

**Swaps** or **Materials** tab → **Themes** re-dresses the whole build at once. Seven palettes
(medieval, futuristic, asian, ancient, modern, desert, mesa), each with several combinations, since
"medieval" is not one palette: a cobblestone keep, an oak-framed village house and a mossy ruin
share none of their blocks. Every theme fills the same roles, so clicking down the list shows the
same build seven ways without touching its shape, and the result is one more layer to switch off or
undo.

The tables are data and meant to be edited: a combination is a handful of `.role(...)` lines over
its theme's default, in `BuildThemes`. Blocks added after 1.19 carry a fallback so a theme never
leaves half a build untouched, and a combination whose materials do not exist on the running version
is hidden by the picker rather than offered.

---

## Formats

| Format | Read | Write | Notes |
|---|---|---|---|
| `.litematic` | yes | yes | Litematica v4–v7, including negative region sizes. Keeps every region separately, plus entities and metadata |
| `.schem` | yes | yes | Sponge v1/v2/v3, for WorldEdit and FAWE. Multi-region builds are flattened into one box on export |
| `.nbt` | yes | yes | Vanilla structure. One box; structure blocks themselves refuse over 48 per side |
| `.buildmatic` | yes | yes | Recognised, but currently read and written as a plain Litematica file; swap layers are not carried in it yet |
| `.schematic` | no | no | Legacy MCEdit. Reports a clear error rather than guessing; convert with WorldEdit first |

Files with a wrong or missing extension are identified by content.

### Where things are kept

| Path | What |
|---|---|
| `<game folder>/schematics/` | the folder the Schematics tab lists and the Areas tab saves into |
| `<config>/buildmatic/buildmatic.properties` | settings, a plain properties file you can edit by hand |
| `<config>/buildmatic/placements/<world>.nbt` | placements and swap layers, per world and per dimension, autosaved every 30 s and on disconnect |

Placements store only the reference (the file name and the transform), never the blocks, so a
schematic edited or deleted on disk is skipped rather than resurrected from a stale copy.

---

## Supported versions

Eleven build targets from one source tree:

| Target | Minecraft | Java |
|---|---|---|
| `1.19.2` | 1.19 – 1.19.2 | 17 |
| `1.19.4` | 1.19.3 – 1.19.4 | 17 |
| `1.20.1` | 1.20 – 1.20.1 | 17 |
| `1.20.4` | 1.20.2 – 1.20.4 | 17 |
| `1.20.6` | 1.20.5 – 1.20.6 | 21 |
| `1.21.1` | 1.21 – 1.21.1 | 21 |
| `1.21.4` | 1.21.2 – 1.21.4 | 21 |
| `1.21.8` | 1.21.5 – 1.21.8 | 21 |
| `1.21.11` | 1.21.9 – 1.21.11 | 21 |
| `26.1.x` | 26.1 – 26.1.2 | 25 |
| `26.2.x` | 26.2 | 25 |

---

## Building

[Stonecutter](https://stonecutter.kikugie.dev/) 0.9.7 drives the version splits;
`dev.kikugie.loom-back-compat` picks the right Loom variant per target: plain `fabric-loom` on
26.1+, where Minecraft ships unobfuscated, and `fabric-loom-remap` below it. Mojang mappings are
used throughout so the source reads the same on every target. Per-version settings live in
`stonecutter.properties.toml`, the target list in `settings.gradle.kts`.

Requires a **JDK 25** as the Gradle JVM, since 26.1+ mandates it; the 17 and 21 toolchains are
downloaded on demand.

```bash
./gradlew build
```

That covers the active target only: `26.2.x`, set at the top of `stonecutter.gradle.kts`. To run
the game on it:

```bash
./gradlew ":26.2.x:runClient"
```

To build every target:

```bash
./gradlew ":1.19.2:build" ":1.19.4:build" ":1.20.1:build" ":1.20.4:build" ":1.20.6:build" ":1.21.1:build" ":1.21.4:build" ":1.21.8:build" ":1.21.11:build" ":26.1.x:build" ":26.2.x:build"
```

Each writes its jar to `versions/<target>/build/libs/`.

---

## Layout

The design decision everything else follows from: **the core never imports `net.minecraft`.**

```
dev.buildmatic
├── core/              pure Java, no Minecraft, unit-testable, identical on every version
│   ├── nbt/           own NBT implementation (tags, gzip framing, SNBT)
│   ├── util/          Vec3i, BlockBox, Direction, Rotation, Mirror, BitStorage
│   ├── block/         BlockStateRef, BlockPalette, PropertyTransforms, PropertyTranslator
│   ├── schematic/     Schematic, SchematicRegion, the container formats, SchematicIo
│   ├── area/          selections and world capture
│   ├── placement/     transforms and layer slices
│   ├── variant/       BlockShape, MaterialFamilies, ColorIndex, VariantIndex
│   ├── swap/          SwapRule, SwapLayer, SwapEngine, SwapCodec
│   ├── theme/         the build themes and their roles
│   ├── render/        ghost slicing, face culling, voxel raycast
│   ├── material/      the shopping list
│   └── verify/        schematic against world
├── platform/          GamePlatform, the only version-specific seam
├── mixin/             click, scroll and block-change hooks
└── client/            session, rendering, UI
```

`BlockShape` classifies a block id into `(material, shape)` from the id itself, so that
`dark_oak_stairs` becomes `(dark_oak, STAIRS)` and `stripped_birch_log` becomes
`(birch, STRIPPED_LOG)`. It uses a longest-suffix table rather than registry tags, which differ
between versions and which mods often forget to apply. The index is then built from whatever blocks the running game reports, so modded
blocks and blocks from future versions are covered with no table to maintain. `MaterialFamilies`
adds the curation on top: click an oak stair and the other woods come first, click a deepslate stair
and the stone set does.

---

Bug reports with the Minecraft version and what you were doing are genuinely useful right now.

## Licence

MIT.
