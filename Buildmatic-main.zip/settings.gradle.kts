pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
        maven("https://maven.fabricmc.net/") { name = "Fabric" }
        maven("https://maven.kikugie.dev/releases") { name = "KikuGie Releases" }
        maven("https://maven.kikugie.dev/snapshots") { name = "KikuGie Snapshots" }
    }
}

plugins {
    id("dev.kikugie.stonecutter") version "0.9.7"
    // Applies the right Loom variant per version: `fabric-loom` on 26.1+ (unobfuscated),
    // `fabric-loom-remap` on 1.21.11 and below.
    id("dev.kikugie.loom-back-compat") version "0.4.2"
    // Lets Gradle download the JDK 17 / 21 / 25 toolchains on demand.
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}

stonecutter {
    create(rootProject) {
        // Java 25 era - unobfuscated Minecraft. Both build today.
        version("26.1.x", "26.1.2")
        version("26.2.x", "26.2")

        // All eleven build. The `core` package compiles unchanged on every one of them - it never
        // imports net.minecraft - and the client turned out to need no per-era implementations,
        // only four facades and about thirty conditionals:
        //
        //   Canvas          GUI drawing. GuiGraphicsExtractor (26.1), GuiGraphics (1.20) and the
        //                   static GuiComponent calls (1.19) behind eight methods.
        //   Buttons         one factory, because 1.19.3 replaced the constructor with a builder.
        //   Registries      BuiltInRegistries (1.19.3) against the Registry statics before it.
        //   BuildmaticScreen  clicks, keys and scrolling, which changed shape three times.
        //
        // GhostRenderer holds the rest: the submit collector exists from 1.21.9, immediate-mode
        // drawing before that, and BakedQuad changed shape twice on the way down.
        //
        // The eras below are what actually differs, for whoever adds a version next:
        //
        //   1.21.9 - 1.21.11   Identifier rename, pre-submit-node rendering
        //   1.21.5 - 1.21.8    RenderPipeline era, KeyBindingHelper, ClientCommandManager
        //   1.20.5 - 1.21.4    Java 21, BufferBuilder rendering
        //   1.19.3 - 1.20.4    Java 17, BuiltInRegistries
        //   1.19   - 1.19.2    Java 17, Registry.BLOCK statics
        //
        version("1.21.11", "1.21.11")
        version("1.21.8", "1.21.8")
        versions("1.20.6", "1.21.1", "1.21.4")
        versions("1.19.2", "1.19.4", "1.20.1", "1.20.4")

        vcsVersion = "26.2.x"
    }
}

rootProject.name = "Buildmatic"
