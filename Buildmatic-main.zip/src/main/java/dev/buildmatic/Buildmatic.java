package dev.buildmatic;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common entry point.
 *
 * <p>Buildmatic is a client-side building tool, so almost nothing happens here - the interesting
 * work is in {@code dev.buildmatic.client}. This entry point exists so the mod loads on a server
 * without complaint when a pack ships it on both sides.
 */
public final class Buildmatic implements ModInitializer {

    public static final String MOD_ID = "buildmatic";
    public static final String MOD_NAME = "Buildmatic";

    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    @Override
    public void onInitialize() {
        LOGGER.info("{} loaded (client-side; no server behaviour is registered)", MOD_NAME);
    }
}
