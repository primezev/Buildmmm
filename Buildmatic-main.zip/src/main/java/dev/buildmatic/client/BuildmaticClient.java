package dev.buildmatic.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.buildmatic.Buildmatic;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.VariantPickerScreen;
import dev.buildmatic.client.gui.tabs.AreasTab;
import dev.buildmatic.client.gui.tabs.MaterialsTab;
import dev.buildmatic.client.gui.tabs.SchematicsTab;
import dev.buildmatic.client.gui.tabs.SwapsTab;
import dev.buildmatic.client.render.GhostRenderer;
import dev.buildmatic.core.render.GhostRaycast;
import dev.buildmatic.core.tool.SchematicTool;
import dev.buildmatic.core.tool.ToolMode;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.platform.MinecraftPlatform;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

/**
 * Client entry point: the tool, the hotkeys and the menu.
 *
 * <p>Everything is reachable without typing: the tool item drives selection and swapping in the
 * world, and one menu key opens every panel. There are no chat commands.
 */
public final class BuildmaticClient implements ClientModInitializer {

    /** How far to look for a ghost block, in blocks. */
    private static final double TARGET_RANGE = 64.0;

    private static MinecraftPlatform platform;
    private static BuildmaticSession session;
    private static GhostRenderer renderer;

    /** Cleared on disconnect so the next world gets its own placements restored. */
    private static boolean restored;
    private static long lastSave;

    @Override
    public void onInitializeClient() {
        BuildmaticKeys.init();
        ClientTickEvents.END_CLIENT_TICK.register(BuildmaticClient::tick);
        // Both mouse buttons are taken over by mixins rather than Fabric's interaction callbacks:
        // those only fire when a real block is targeted, and schematic work is aimed at empty air.

        // Leaving a world has to write the placements out, or an afternoon of lining a build up
        // against an existing structure is gone the moment you step through a portal.
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT
                .register((handler, client) -> {
                    // The tick-by-tick world check handles switching between worlds; this covers
                    // quitting to the menu, where there is no next tick to notice anything.
                    if (session != null && currentWorldKey != null) {
                        SessionStore.saveAs(session, currentWorldKey);
                    }
                    closeAll();
                    currentWorldKey = null;
                });

        Buildmatic.LOGGER.info("Buildmatic client ready");
    }

    /** Drops everything: the next world's placements are a different set. */
    private static void closeAll() {
        if (session == null) return;
        for (BuildmaticSession.OpenSchematic open : session.open()) {
            session.close(open);
        }
        if (renderer != null) renderer.invalidate();
    }

    /** The world the open placements belong to, or null when none are loaded. */
    private static String currentWorldKey;

    /**
     * Swaps the open placements over whenever the world underfoot changes.
     *
     * <p>Driven by comparing the world each tick rather than by the disconnect event. That event
     * does not fire for every way of leaving a world, and it says nothing at all about walking
     * through a nether portal - which is why a build kept hanging in the air after switching.
     */
    private static void syncWorld(Minecraft client) {
        String key = SessionStore.worldKey();
        if (key == null || key.equals(currentWorldKey)) return;

        // Save under the key the placements actually belong to, not the one just arrived in.
        if (currentWorldKey != null) {
            SessionStore.saveAs(session, currentWorldKey);
        }
        closeAll();
        currentWorldKey = key;

        int count = SessionStore.restore(session);
        if (count > 0) {
            if (renderer != null) renderer.invalidate();
            actionBar(client, "Buildmatic restored " + count + " placement(s)");
        }
    }

    public static BuildmaticSession session() { return session; }

    public static MinecraftPlatform platform() { return platform; }

    public static GhostRenderer renderer() { return renderer; }

    // --- lifecycle ---------------------------------------------------------------------------------

    private static void ensureStarted() {
        if (session != null) return;
        platform = new MinecraftPlatform();
        session = new BuildmaticSession(platform);
        renderer = new GhostRenderer(session, platform.schema());
        renderer.register();
        Buildmatic.LOGGER.info("Buildmatic indexed {} blocks", session.variants().size());
    }

    /** Rebuilds the variant index; call after a resource or datapack reload. */
    public static void reload() {
        if (session == null) return;
        platform.invalidate();
        session.reloadVariants();
        if (renderer != null) renderer.invalidate();
    }

    // --- the tool ----------------------------------------------------------------------------------

    /** Set by the first right click after picking the stick up; cleared when it is put away. */
    private static boolean toolArmed;

    /**
     * True when the player is holding the tool item.
     *
     * <p>Gating on the held item is what keeps the tool from hijacking ordinary play: put the stick
     * away and every click behaves normally again.
     */
    public static boolean holdingTool(Minecraft client) {
        return client.player != null
                && client.player.getMainHandItem().is(Items.STICK);
    }

    /** True when the stick is in hand <em>and</em> has been armed by a right click. */
    public static boolean toolActive(Minecraft client) {
        return toolArmed && holdingTool(client);
    }

    /**
     * Handles a right click before the game does.
     *
     * <p>Order matters. A stick that has not been armed yet swallows the first click to arm itself,
     * so picking one up never moves anything by accident. After that the click drives the current
     * tool mode. With no stick in hand, easy place gets its turn.
     *
     * @return true when Buildmatic used the click and the game should not
     */
    public static boolean handleUseItem() {
        Minecraft client = Minecraft.getInstance();
        if (session == null || client.player == null || client.level == null) return false;
        if (currentScreen(client) != null) return false;

        if (holdingTool(client)) {
            if (!toolArmed) {
                toolArmed = true;
                actionBar(client, "Buildmatic tool on - " + session.tool().mode().displayName()
                        + " (right click again to use it)");
                return true;
            }
            return handleToolUse(client);
        }

        if (session.config().easyPlace()) {
            EasyPlace.Result result = EasyPlace.tryPlace(client, platform.schema());
            switch (result.outcome()) {
                case PLACED, ALREADY_CORRECT -> {
                    return true;
                }
                case MISSING_ITEM -> {
                    actionBar(client, result.message());
                    return true;
                }
                default -> {
                    // The right item is selected now; let vanilla place it.
                    return false;
                }
            }
        }
        return false;
    }

    /** The right-click action for the current tool mode, aimed at the ghost when there is one. */
    private static boolean handleToolUse(Minecraft client) {
        SchematicTool tool = session.tool();

        if (tool.mode() == ToolMode.VARIANT_SWAP) {
            openVariantPicker(client);
            return true;
        }

        Vec3i pos = usePosition(client);
        if (pos == null) return true;
        handleClick(client, pos, false);
        return true;
    }

    /**
     * Where a tool click lands.
     *
     * <p>The ghost wins over the world: when a preview block is under the crosshair that is what
     * the builder means, even if a real block sits behind it.
     */
    private static Vec3i usePosition(Minecraft client) {
        GhostRaycast.Hit hit = target(client);
        if (hit != null) return hit.worldPos();

        if (client.hitResult instanceof net.minecraft.world.phys.BlockHitResult block) {
            var pos = block.getBlockPos();
            return new Vec3i(pos.getX(), pos.getY(), pos.getZ());
        }
        return null;
    }

    /**
     * Handles a left click before the game turns it into mining.
     *
     * <p>An armed tool must never break a block: in creative that is instant and irreversible, and
     * reaching for a corner should not cost you a wall. Put the stick away and mining works again.
     *
     * @return true when Buildmatic used the click and the game should not
     */
    public static boolean handleAttack() {
        Minecraft client = Minecraft.getInstance();
        if (session == null || client.player == null || client.level == null) return false;
        if (currentScreen(client) != null) return false;
        if (!toolActive(client)) return false;

        Vec3i pos = usePosition(client);
        if (pos != null) handleClick(client, pos, true);
        return true;
    }

    private static InteractionResult handleClick(Minecraft client, Vec3i pos, boolean leftClick) {
        ensureStarted();
        SchematicTool tool = session.tool();

        // Variant swapping targets the ghost, not the world block behind it.
        if (tool.mode() == ToolMode.VARIANT_SWAP) {
            if (leftClick) return InteractionResult.PASS;
            openVariantPicker(client);
            return InteractionResult.SUCCESS;
        }

        if (tool.mode() == ToolMode.SCHEMATIC_EDIT) {
            return editSchematic(client, pos, leftClick);
        }

        if (tool.mode() == ToolMode.ROTATE) {
            var placement = session.activePlacement();
            if (placement == null) {
                actionBar(client, "Nothing loaded - press M and pick a schematic");
                return InteractionResult.SUCCESS;
            }
            if (placement.isLocked()) {
                actionBar(client, placement.name() + " is locked");
                return InteractionResult.SUCCESS;
            }
            // Right turns it one way, left the other, so overshooting is one click back.
            placement.rotateBy(leftClick
                    ? dev.buildmatic.core.util.Rotation.COUNTERCLOCKWISE_90
                    : dev.buildmatic.core.util.Rotation.CLOCKWISE_90);
            if (renderer != null) renderer.invalidate();
            actionBar(client, placement.name() + ": " + placement.rotation().degrees() + " degrees");
            return InteractionResult.SUCCESS;
        }

        if (tool.mode() == ToolMode.PLACEMENT) {
            var placement = session.activePlacement();
            if (placement == null) {
                actionBar(client, "Nothing loaded - press M and pick a schematic");
                return InteractionResult.SUCCESS;
            }
            if (placement.isLocked()) {
                actionBar(client, placement.name() + " is locked - unlock it on the Placements tab");
                return InteractionResult.SUCCESS;
            }
            // Right click drops the build's minimum corner on the clicked block; left click puts it
            // on top of that block, which is what you want when standing on a floor.
            placement.setOrigin(leftClick ? pos.add(0, 1, 0) : pos);
            if (renderer != null) renderer.invalidate();
            actionBar(client, placement.name() + " moved to " + placement.origin());
            return InteractionResult.SUCCESS;
        }

        SchematicTool.Feedback feedback = leftClick ? tool.onLeftClick(pos) : tool.onRightClick(pos);
        if (!feedback.handled()) return InteractionResult.PASS;
        actionBar(client, feedback.message());
        return InteractionResult.SUCCESS;
    }

    // --- mouse wheel -------------------------------------------------------------------------------

    /**
     * Moves the placement with the mouse wheel.
     *
     * <p>Plain scroll pushes it away or pulls it closer along the way you are looking; with Ctrl it
     * goes straight up and down. Returns true only when the scroll was used, so the hotbar keeps
     * working whenever the tool is not in hand.
     */
    public static boolean handleScroll(double amount) {
        if (amount == 0 || session == null) return false;

        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return false;
        if (currentScreen(client) != null) return false;
        if (!toolActive(client)) return false;

        var placement = session.activePlacement();
        if (placement == null) return false;
        if (placement.isLocked()) {
            actionBar(client, placement.name() + " is locked");
            return true;
        }

        boolean forward = amount > 0;
        Direction direction;
        if (isControlDown(client)) {
            direction = forward ? Direction.UP : Direction.DOWN;
        } else {
            Direction facing = horizontalFacing(client);
            direction = forward ? facing : facing.opposite();
        }

        placement.setOrigin(placement.origin().offset(direction, session.config().scrollStep()));
        if (renderer != null) renderer.invalidate();
        actionBar(client, placement.name() + " at " + placement.origin());
        return true;
    }

    /** The compass direction the player is facing, ignoring pitch. */
    private static Direction horizontalFacing(Minecraft client) {
        int index = Math.floorMod(Math.round(client.player.getYRot() / 90f), 4);
        return Direction.byHorizontalIndex(index);
    }

    private static net.minecraft.client.gui.screens.Screen currentScreen(Minecraft client) {
        //? if >=26.2 {
        return client.gui == null ? null : client.gui.screen();
        //?} else {
        /*return client.screen;
        *///?}
    }

    // --- hotkeys -----------------------------------------------------------------------------------

    private static void tick(Minecraft client) {
        if (client.level == null || client.player == null) return;
        ensureStarted();

        syncWorld(client);
        advanceJob(client);

        // A crash or a kill should not cost the last placement either.
        long now = System.currentTimeMillis();
        if (now - lastSave > 30_000) {
            lastSave = now;
            SessionStore.save(session);
        }

        // Putting the stick away disarms it, so picking it back up needs a deliberate click again.
        if (toolArmed && !holdingTool(client)) {
            toolArmed = false;
            actionBar(client, "Buildmatic tool off");
        }

        while (BuildmaticKeys.MENU.consumeClick()) {
            openScreen(client, new BuildmaticMenuScreen());
        }
        while (BuildmaticKeys.OPEN_BROWSER.consumeClick()) {
            openScreen(client, BuildmaticMenuScreen.on(SchematicsTab.class));
        }
        while (BuildmaticKeys.OPEN_MATERIALS.consumeClick()) {
            openScreen(client, BuildmaticMenuScreen.on(MaterialsTab.class));
        }
        while (BuildmaticKeys.OPEN_LAYERS.consumeClick()) {
            openScreen(client, BuildmaticMenuScreen.on(SwapsTab.class));
        }
        while (BuildmaticKeys.OPEN_AREAS.consumeClick()) {
            openScreen(client, BuildmaticMenuScreen.on(AreasTab.class));
        }
        while (BuildmaticKeys.VARIANT_WHEEL.consumeClick()) openVariantPicker(client);
        while (BuildmaticKeys.TOOL_MODE_NEXT.consumeClick()) cycleMode(client, true);
        while (BuildmaticKeys.TOOL_MODE_PREV.consumeClick()) cycleMode(client, false);

        updateToolWheel(client);
        while (BuildmaticKeys.TOGGLE_RENDERING.consumeClick()) toggleRendering(client);
        while (BuildmaticKeys.LAYER_UP.consumeClick()) shiftLayer(client, 1);
        while (BuildmaticKeys.LAYER_DOWN.consumeClick()) shiftLayer(client, -1);
        while (BuildmaticKeys.NUDGE_FORWARD.consumeClick()) nudge(client, 1);
        while (BuildmaticKeys.NUDGE_BACK.consumeClick()) nudge(client, -1);
        while (BuildmaticKeys.UNDO.consumeClick()) undo(client);
        while (BuildmaticKeys.REDO.consumeClick()) redo(client);
        while (BuildmaticKeys.EXECUTE.consumeClick()) execute(client);
        while (BuildmaticKeys.PICK_BLOCK.consumeClick()) pickBlock(client);

        showToolHint(client);
    }

    /**
     * Holds the mode ring open while its key is physically down.
     *
     * <p>Read straight from the window rather than through the key mapping. Minecraft releases every
     * binding the moment a screen opens, so {@code isDown()} goes false on the frame the ring
     * appears - the ring closed itself instantly and reopened on the next press, which looked like
     * flickering and made it impossible to pick anything.
     */
    private static void updateToolWheel(Minecraft client) {
        boolean held = isKeyPhysicallyDown(client, BuildmaticKeys.TOOL_WHEEL);
        boolean open = currentScreen(client) instanceof dev.buildmatic.client.gui.ToolWheelScreen;

        if (held && !open && currentScreen(client) == null) {
            openScreen(client, dev.buildmatic.client.gui.ToolWheelScreen.create());
        } else if (!held && open
                && currentScreen(client) instanceof dev.buildmatic.client.gui.ToolWheelScreen wheel) {
            wheel.confirm();
        }

        // The queued presses are never acted on; draining them stops them firing later.
        while (BuildmaticKeys.TOOL_WHEEL.consumeClick()) {
            // no-op
        }
    }

    /** The physical state of a bound key, which survives a screen being open. */
    private static boolean isKeyPhysicallyDown(Minecraft client, net.minecraft.client.KeyMapping key) {
        //? if >=26.1 {
        var bound = net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper.getBoundKeyOf(key);
        //?} else {
        /*var bound = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.getBoundKeyOf(key);
        *///?}
        if (bound == null || bound.getType() != InputConstants.Type.KEYSYM) return key.isDown();
        //? if >=1.21.9 {
        return InputConstants.isKeyDown(client.getWindow(), bound.getValue());
        //?} else {
        /*return InputConstants.isKeyDown(client.getWindow().getWindow(), bound.getValue());
        *///?}
    }

    /**
     * Edits the schematic itself rather than the world.
     *
     * <p>Applied as a swap layer scoped to the one position, not by rewriting the schematic in
     * memory. That keeps every edit listed, individually switchable and undoable, and means the
     * file on disk is never touched until it is deliberately exported.
     */
    private static InteractionResult editSchematic(Minecraft client, Vec3i worldPos,
                                                   boolean leftClick) {
        BuildmaticSession.OpenSchematic open = session.active();
        if (open == null) {
            actionBar(client, "Nothing loaded - press M and pick a schematic");
            return InteractionResult.SUCCESS;
        }

        Vec3i local = open.placement().toSchematic(worldPos);
        dev.buildmatic.core.schematic.SchematicRegion region = null;
        Vec3i inRegion = null;

        for (var candidate : open.schematic().regions()) {
            Vec3i offset = local.subtract(candidate.origin());
            if (candidate.contains(offset.x(), offset.y(), offset.z())) {
                region = candidate;
                inRegion = offset;
                break;
            }
        }
        if (region == null) {
            actionBar(client, "That position is outside the schematic");
            return InteractionResult.SUCCESS;
        }

        dev.buildmatic.core.block.BlockStateRef target;
        String label;
        if (leftClick) {
            target = dev.buildmatic.core.block.BlockStateRef.AIR;
            label = "Removed a block";
        } else {
            // The tool occupies the main hand, so the block to place comes from the off hand.
            var stack = client.player.getOffhandItem();
            if (stack.isEmpty()
                    || !(stack.getItem() instanceof net.minecraft.world.item.BlockItem blockItem)) {
                actionBar(client, "Hold the block to place in your off hand");
                return InteractionResult.SUCCESS;
            }
            target = platform.schema().toRef(blockItem.getBlock().defaultBlockState());
            label = "Placed " + platform.schema().displayName(target.blockId()).getString();
        }

        session.applySwap(label, new dev.buildmatic.core.swap.SwapRule(
                new dev.buildmatic.core.swap.SwapRule.Matcher.Any(),
                new dev.buildmatic.core.swap.SwapRule.Target.State(target),
                new dev.buildmatic.core.swap.SwapRule.Scope.Positions(
                        region.name(), java.util.Set.of(inRegion))));

        if (renderer != null) renderer.invalidate();
        actionBar(client, label + "  |  Ctrl+Z to undo");
        return InteractionResult.SUCCESS;
    }

    /**
     * Runs whatever the current mode does to the world.
     *
     * <p>Bound to a key rather than to a click on purpose: fill, delete and move rewrite a whole
     * region, and those should not be one stray click away while you are still adjusting corners.
     */
    private static void execute(Minecraft client) {
        SchematicTool tool = session.tool();
        var selection = tool.currentSelectionOrNull();

        if (tool.mode() == ToolMode.MOVE) {
            actionBar(client, pickUpSelection(client, selection).message());
            return;
        }

        WorldEditJob.Plan plan = switch (tool.mode()) {
            case FILL -> WorldEditJob.fill(selection, heldBlockState(client));
            // With a selection drawn, Delete means that box; without one it means the ghost's volume.
            case DELETE -> selection != null && selection.hasCompleteBox()
                    ? WorldEditJob.deleteSelection(selection)
                    : WorldEditJob.deletePlacement(session.activePlacement(), platform.schema());
            case REPLACE -> replaceInSelection(client, tool, selection);
            // Placement and paste both mean "put it down", which is the only thing Enter can
            // sensibly do once something is being carried.
            case PASTE, PLACEMENT, ROTATE ->
                    WorldEditJob.paste(session.activePlacement(), platform.schema());
            default -> null;
        };

        if (plan == null) {
            actionBar(client, tool.mode().displayName() + " has nothing to run");
            return;
        }
        actionBar(client, startJob(plan, null));
        if (renderer != null) renderer.invalidate();
    }

    /**
     * Lifts the selected region out of the world and hands it to the placement machinery.
     *
     * <p>Moving a region by a fixed step was close to useless: you cannot see where it will land
     * and every nudge is another destructive rewrite. Cutting it into a schematic instead means the
     * usual tools apply - the stick moves it, the wheel rotates it, the ghost shows exactly where
     * it will go - and nothing is written until Enter puts it down.
     */
    private static dev.buildmatic.platform.SelectionOperations.Result pickUpSelection(
            Minecraft client, dev.buildmatic.core.area.AreaSelection selection) {

        if (client.level == null || client.player == null || !client.player.isCreative()) {
            return new dev.buildmatic.platform.SelectionOperations.Result(false, 0,
                    "Creative mode only");
        }
        if (selection == null || !selection.hasCompleteBox()) {
            return new dev.buildmatic.platform.SelectionOperations.Result(false, 0,
                    "Draw a selection first: click two corners with the tool");
        }

        var source = new dev.buildmatic.platform.LevelCaptureSource(
                client.level, platform.schema());
        var captured = dev.buildmatic.core.area.WorldCapture.capture(
                selection, source, "Moved region", "");

        // Read first, then clear: the capture is still reading the blocks being deleted.
        var cleared = dev.buildmatic.platform.SelectionOperations.delete(selection);
        if (!cleared.success()) return cleared;

        session.adopt(captured.schematic(), selection.origin());
        session.tool().setMode(ToolMode.PLACEMENT);
        if (renderer != null) renderer.invalidate();

        return new dev.buildmatic.platform.SelectionOperations.Result(true,
                captured.capturedBlocks(),
                "Picked up " + captured.capturedBlocks()
                        + " block(s) - carry it, then Enter to put it down");
    }

    private static WorldEditJob.Plan replaceInSelection(
            Minecraft client, SchematicTool tool, dev.buildmatic.core.area.AreaSelection selection) {
        if (tool.secondaryBlock() == null) {
            return new WorldEditJob.Plan(null,
                    "Look at the block to replace and press the pick key first");
        }
        var from = platform.schema().toBlockState(
                dev.buildmatic.core.block.BlockStateRef.of(tool.secondaryBlock()));
        return WorldEditJob.replace(selection, from, heldBlockState(client));
    }

    /** The job currently running, or null. Only one at a time: two would fight over the world. */
    private static WorldEditJob activeJob;

    /** Finished jobs, newest last, each holding what it overwrote. */
    private static final java.util.Deque<WorldEditJob> undoStack = new java.util.ArrayDeque<>();

    /** Deep enough to walk back a session's worth of edits without hoarding every block ever. */
    private static final int MAX_UNDO_JOBS = 16;

    public static boolean isRunningJob() {
        return activeJob != null && !activeJob.isFinished();
    }

    /**
     * Starts a job, asking first when it would destroy something.
     *
     * <p>The confirmation is only for operations that overwrite blocks the player did not choose to
     * lose. Building into empty air needs no prompt; clearing a volume does.
     */
    public static String startJob(WorldEditJob.Plan plan,
                                  net.minecraft.client.gui.screens.Screen parent) {
        Minecraft client = Minecraft.getInstance();

        if (isRunningJob()) {
            activeJob.cancel();
            return "Stopped";
        }
        if (plan.job() == null) return plan.message();

        WorldEditJob job = plan.job();
        if (!job.kind().isDestructive()) {
            begin(client, job, parent);
            return plan.message();
        }

        openScreen(client, new dev.buildmatic.client.gui.ConfirmScreen(
                "Buildmatic - " + job.kind().verb(),
                job.kind().verb() + " " + job.name() + "?",
                job.total() + " block(s) in the world will be overwritten.",
                parent,
                () -> begin(client, job, null)));
        return "Waiting for confirmation";
    }

    private static void begin(Minecraft client, WorldEditJob job,
                              net.minecraft.client.gui.screens.Screen parent) {
        activeJob = job;
        // The build is the point; a menu in front of it is not.
        openScreen(client, parent);
    }

    private static void advanceJob(Minecraft client) {
        if (activeJob == null) return;

        activeJob.tick();
        if (!activeJob.isFinished()) {
            actionBar(client, activeJob.kind().verb() + " " + activeJob.name()
                    + ": layer " + activeJob.currentLayer()
                    + ", " + activeJob.remaining() + " left");
            return;
        }

        // An undo job's own history would just redo the thing being undone, so it is not kept.
        if (activeJob.kind() != WorldEditJob.Kind.UNDO && activeJob.hasHistory()) {
            undoStack.addLast(activeJob);
            while (undoStack.size() > MAX_UNDO_JOBS) undoStack.pollFirst();
        }
        actionBar(client, activeJob.name() + " done"
                + (undoStack.isEmpty() ? "" : "  |  Ctrl+Z to undo"));
        activeJob = null;
        if (renderer != null) renderer.invalidate();
    }

    /** Puts the world back the way the last finished job found it. */
    private static void undoWorldEdit(Minecraft client) {
        WorldEditJob last = undoStack.pollLast();
        if (last == null) {
            actionBar(client, "Nothing to undo in the world");
            return;
        }
        var plan = WorldEditJob.undoOf(last);
        if (plan.job() == null) {
            actionBar(client, plan.message());
            return;
        }
        activeJob = plan.job();
        actionBar(client, "Undoing " + last.name());
    }

    /** The block the fill and replace modes will write: whatever is in the off hand slot order. */
    private static net.minecraft.world.level.block.state.BlockState heldBlockState(Minecraft client) {
        SchematicTool tool = session.tool();
        if (tool.primaryBlock() != null) {
            return platform.schema().toBlockState(
                    dev.buildmatic.core.block.BlockStateRef.of(tool.primaryBlock()));
        }
        return net.minecraft.world.level.block.Blocks.STONE.defaultBlockState();
    }

    /**
     * Stores the targeted block for fill and replace.
     *
     * <p>Fill and replace need two blocks - what to write and what to overwrite - and neither can
     * come from the hand, which is holding the tool. The key picks into the primary slot, or the
     * secondary when Ctrl is held.
     */
    private static void pickBlock(Minecraft client) {
        if (client.level == null
                || !(client.hitResult instanceof net.minecraft.world.phys.BlockHitResult block)) {
            actionBar(client, "Look at a block first");
            return;
        }
        var state = client.level.getBlockState(block.getBlockPos());
        String id = platform.schema().toRef(state).blockId();

        if (isControlDown(client)) {
            session.tool().setSecondaryBlock(id);
            actionBar(client, "Replace: " + platform.schema().displayName(id).getString());
        } else {
            session.tool().setPrimaryBlock(id);
            actionBar(client, "Fill with: " + platform.schema().displayName(id).getString());
        }
    }

    /** Repeats how to use the tool, rarely enough not to nag. */
    private static void showToolHint(Minecraft client) {
        if (!holdingTool(client) || currentScreen(client) != null) return;

        long now = System.currentTimeMillis();
        if (now - lastHint < 8_000) return;
        lastHint = now;

        if (!toolArmed) {
            actionBar(client, "Right click to switch the Buildmatic tool on");
            return;
        }
        ToolMode mode = session.tool().mode();
        String keys = mode.isCreativeOnly()
                ? "  |  " + keyName(BuildmaticKeys.EXECUTE) + " run, "
                + keyName(BuildmaticKeys.PICK_BLOCK) + " pick block"
                : "";
        actionBar(client, mode.displayName() + ": " + mode.hint()
                + "  |  " + keyName(BuildmaticKeys.TOOL_WHEEL) + " modes" + keys);
    }

    private static long lastHint;

    private static String keyName(net.minecraft.client.KeyMapping key) {
        return key.getTranslatedKeyMessage().getString();
    }

    private static void cycleMode(Minecraft client, boolean forward) {
        boolean creative = client.player != null && client.player.isCreative();
        session.tool().cycleMode(forward, creative);
        ToolMode mode = session.tool().mode();
        actionBar(client, mode.displayName() + "   -   " + mode.hint());
    }

    /**
     * Moves whatever the tool is holding one block along the direction the player faces.
     *
     * <p>In placement mode that is the placement itself, which is how a build gets lined up with an
     * existing structure without opening a menu.
     */
    private static void nudge(Minecraft client, int amount) {
        if (client.player == null) return;
        Direction facing = facingOf(client);

        if (session.tool().mode() == ToolMode.PLACEMENT) {
            var placement = session.activePlacement();
            if (placement == null) return;
            placement.setOrigin(placement.origin().offset(facing, amount));
            if (renderer != null) renderer.invalidate();
            actionBar(client, placement.name() + " at " + placement.origin());
            return;
        }

        SchematicTool.Feedback feedback = session.tool().onNudge(facing, amount);
        if (feedback.handled()) actionBar(client, feedback.message());
    }

    private static Direction facingOf(Minecraft client) {
        float pitch = client.player.getXRot();
        if (pitch < -60) return Direction.UP;
        if (pitch > 60) return Direction.DOWN;
        int index = Math.floorMod(Math.round(client.player.getYRot() / 90f), 4);
        return Direction.byHorizontalIndex(index);
    }

    private static void openVariantPicker(Minecraft client) {
        if (session.active() == null) {
            actionBar(client, "Buildmatic: nothing loaded - open the menu and pick a schematic");
            return;
        }
        VariantPickerScreen screen = VariantPickerScreen.forTargetedBlock();
        if (screen == null) {
            actionBar(client, "Buildmatic: look at a block of the schematic first");
            return;
        }
        openScreen(client, screen);
    }

    private static void toggleRendering(Minecraft client) {
        var placement = session.activePlacement();
        if (placement == null) {
            actionBar(client, "Buildmatic: nothing loaded");
            return;
        }
        placement.setEnabled(!placement.isEnabled());
        actionBar(client, "Buildmatic: preview " + (placement.isEnabled() ? "on" : "off"));
    }

    private static void shiftLayer(Minecraft client, int delta) {
        var placement = session.activePlacement();
        if (placement == null) return;
        placement.setLayerRange(placement.layerRange().shift(delta));
        if (renderer != null) renderer.invalidate();
        actionBar(client, "Buildmatic: " + placement.layerRange().describe());
    }

    /**
     * Undoes the most recent thing.
     *
     * <p>World edits come first: they are the ones that overwrote something real, so they are what
     * a panicked Ctrl+Z is reaching for. Swap layers only change the preview and can wait.
     */
    private static void undo(Minecraft client) {
        if (!isControlDown(client)) return;

        if (!undoStack.isEmpty()) {
            undoWorldEdit(client);
            return;
        }
        String undone = session.undo();
        if (renderer != null) renderer.invalidate();
        actionBar(client, undone == null ? "Buildmatic: nothing to undo" : "Undid " + undone);
    }

    private static void redo(Minecraft client) {
        if (!isControlDown(client)) return;
        String redone = session.redo();
        if (renderer != null) renderer.invalidate();
        actionBar(client, redone == null ? "Buildmatic: nothing to redo" : "Redid " + redone);
    }

    // --- helpers -----------------------------------------------------------------------------------

    /**
     * The ghost block under the crosshair, out to the menu-targeting range.
     *
     * <p>Deliberately generous: picking a block to inspect or swap has nothing to do with how far
     * you can reach to build.
     */
    public static GhostRaycast.Hit target(Minecraft client) {
        return targetWithin(client, TARGET_RANGE);
    }

    /** Routed from the client level mixin so only the affected slice is re-meshed. */
    public static void onWorldBlockChanged(int x, int y, int z) {
        if (renderer != null) renderer.onWorldBlockChanged(x, y, z);
    }

    /** The ghost block under the crosshair within {@code range} blocks, or null. */
    public static GhostRaycast.Hit targetWithin(Minecraft client, double range) {
        BuildmaticSession.OpenSchematic open = session == null ? null : session.active();
        if (open == null || client.player == null) return null;

        var eye = client.player.getEyePosition(1.0f);
        var look = client.player.getViewVector(1.0f);
        return GhostRaycast.trace(open.placement(), open.swaps(),
                eye.x, eye.y, eye.z, look.x, look.y, look.z, range);
    }

    /**
     * Opens a screen.
     *
     * <p>The one place that knows 26.2 moved screen management off {@code Minecraft} and onto
     * {@code Gui}; every caller goes through here so the preprocessor branch exists once.
     */
    public static void openScreen(Minecraft client, net.minecraft.client.gui.screens.Screen screen) {
        //? if >=26.2 {
        if (client.gui != null) client.gui.setScreen(screen);
        //?} else {
        /*client.setScreen(screen);
        *///?}
    }

    /** Shows a message above the hotbar rather than in chat, so feedback stays quiet. */
    public static void actionBar(Minecraft client, String message) {
        if (client.player != null) {
            //? if >=26.1 {
            client.player.sendOverlayMessage(Component.literal(message));
            //?} else {
            /*client.player.displayClientMessage(Component.literal(message), true);
            *///?}
        }
    }

    private static boolean isControlDown(Minecraft client) {
        // InputConstants took the window handle rather than the Window itself before 26.1.
        //? if >=1.21.9 {
        var window = client.getWindow();
        //?} else {
        /*var window = client.getWindow().getWindow();
        *///?}
        return InputConstants.isKeyDown(window, GLFW.GLFW_KEY_LEFT_CONTROL)
                || InputConstants.isKeyDown(window, GLFW.GLFW_KEY_RIGHT_CONTROL);
    }
}
