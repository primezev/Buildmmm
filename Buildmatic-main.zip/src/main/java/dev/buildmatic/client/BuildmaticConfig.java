package dev.buildmatic.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Settings that survive a restart.
 *
 * <p>A plain properties file rather than a JSON schema: there are a handful of values, they are all
 * scalars, and a builder who wants to change one by hand should be able to open the file and see
 * what it says.
 */
public final class BuildmaticConfig {

    /** How solid the ghost looks, 0.1 (barely there) to 1.0 (indistinguishable from a real block). */
    private float previewAlpha = 0.55f;

    /** Tint blocks that do not match what is already built. */
    private boolean highlightErrors = true;

    /**
     * Hide blocks that are already correctly placed, so only the work left shows.
     *
     * <p>On by default: a ghost drawn over blocks you have already built is noise, and it hides the
     * one thing you are looking for.
     */
    private boolean hidePlaced = true;

    /** How far the mouse wheel pushes the placement per notch. */
    private int scrollStep = 1;

    /**
     * Right click puts down the block the schematic wants, taken from anywhere in the inventory.
     *
     * <p>On by default: it is the reason to load a schematic in survival at all, and leaving it off
     * meant the feature looked broken to anyone who did not go looking for the switch.
     */
    private boolean easyPlace = true;

    private Path file;

    public float previewAlpha() { return previewAlpha; }

    public void setPreviewAlpha(float alpha) {
        this.previewAlpha = Math.max(0.1f, Math.min(1.0f, alpha));
    }

    public boolean highlightErrors() { return highlightErrors; }

    public void setHighlightErrors(boolean value) { this.highlightErrors = value; }

    public boolean hidePlaced() { return hidePlaced; }

    public void setHidePlaced(boolean value) { this.hidePlaced = value; }

    public int scrollStep() { return scrollStep; }

    public void setScrollStep(int step) { this.scrollStep = Math.max(1, Math.min(16, step)); }

    public boolean easyPlace() { return easyPlace; }

    public void setEasyPlace(boolean value) { this.easyPlace = value; }

    /** Alpha packed into the high byte of an 0xRRGGBB tint. */
    public int alphaMask() {
        return ((int) (previewAlpha * 255f) & 0xFF) << 24;
    }

    // --- persistence ---------------------------------------------------------------------------

    public static BuildmaticConfig load(Path directory) {
        BuildmaticConfig config = new BuildmaticConfig();
        config.file = directory.resolve("buildmatic.properties");
        if (!Files.isRegularFile(config.file)) return config;

        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(config.file)) {
            properties.load(in);
        } catch (IOException e) {
            dev.buildmatic.Buildmatic.LOGGER.warn("could not read {}", config.file, e);
            return config;
        }

        config.setPreviewAlpha(parseFloat(properties.getProperty("previewAlpha"), 0.55f));
        config.highlightErrors = parseBoolean(properties.getProperty("highlightErrors"), true);
        config.hidePlaced = parseBoolean(properties.getProperty("hidePlaced"), true);
        config.setScrollStep(parseInt(properties.getProperty("scrollStep"), 1));
        config.easyPlace = parseBoolean(properties.getProperty("easyPlace"), true);
        return config;
    }

    public void save() {
        if (file == null) return;
        Properties properties = new Properties();
        properties.setProperty("previewAlpha", Float.toString(previewAlpha));
        properties.setProperty("highlightErrors", Boolean.toString(highlightErrors));
        properties.setProperty("hidePlaced", Boolean.toString(hidePlaced));
        properties.setProperty("scrollStep", Integer.toString(scrollStep));
        properties.setProperty("easyPlace", Boolean.toString(easyPlace));
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) {
                properties.store(out, "Buildmatic settings");
            }
        } catch (IOException e) {
            dev.buildmatic.Buildmatic.LOGGER.warn("could not write {}", file, e);
        }
    }

    private static float parseFloat(String value, float fallback) {
        try {
            return value == null ? fallback : Float.parseFloat(value);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static int parseInt(String value, int fallback) {
        try {
            return value == null ? fallback : Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static boolean parseBoolean(String value, boolean fallback) {
        return value == null ? fallback : Boolean.parseBoolean(value);
    }
}
