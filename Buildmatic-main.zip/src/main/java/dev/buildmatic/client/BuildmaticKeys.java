package dev.buildmatic.client;

import com.mojang.blaze3d.platform.InputConstants;
//? if >=26.1 {
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
//?} else {
/*import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
*///?}
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/**
 * Buildmatic's key bindings.
 *
 * <p>They register under the vanilla "Miscellaneous" category rather than a custom one: a custom
 * category has to be registered with an {@code Identifier}, and that type was renamed in 1.21.11,
 * which would force a preprocessor branch here for no user-visible gain.
 */
public final class BuildmaticKeys {

    /** Opens the menu, on whichever tab was last used. */
    public static final KeyMapping MENU = register("menu", GLFW.GLFW_KEY_M);

    /** Straight to a tab. */
    public static final KeyMapping OPEN_BROWSER = register("open_browser", GLFW.GLFW_KEY_N);
    public static final KeyMapping OPEN_MATERIALS = register("open_materials", GLFW.GLFW_KEY_J);
    public static final KeyMapping OPEN_LAYERS = register("open_layers", GLFW.GLFW_KEY_K);
    public static final KeyMapping OPEN_AREAS = register("open_areas", GLFW.GLFW_KEY_H);

    /** Opens the variant picker on whatever the crosshair is over. */
    public static final KeyMapping VARIANT_WHEEL = register("variant_wheel", GLFW.GLFW_KEY_V);

    /** Held to open the mode ring; releasing picks whatever is highlighted. */
    public static final KeyMapping TOOL_WHEEL = register("tool_wheel", GLFW.GLFW_KEY_R);

    /** Runs the current mode's operation: fill, replace, delete, paste, move. */
    public static final KeyMapping EXECUTE = register("execute", GLFW.GLFW_KEY_ENTER);

    /** Picks the block being looked at into the tool's fill or replace slot. */
    public static final KeyMapping PICK_BLOCK = register("pick_block", GLFW.GLFW_KEY_G);

    /** Walks the tool through its modes without opening the ring. */
    public static final KeyMapping TOOL_MODE_NEXT = register("tool_mode_next", GLFW.GLFW_KEY_RIGHT_BRACKET);
    public static final KeyMapping TOOL_MODE_PREV = register("tool_mode_prev", GLFW.GLFW_KEY_LEFT_BRACKET);

    /** Moves the grabbed corner, box or origin one block along the way the player faces. */
    public static final KeyMapping NUDGE_FORWARD = register("nudge_forward", GLFW.GLFW_KEY_EQUAL);
    public static final KeyMapping NUDGE_BACK = register("nudge_back", GLFW.GLFW_KEY_MINUS);

    /** Toggles the schematic preview. */
    public static final KeyMapping TOGGLE_RENDERING = register("toggle_rendering", GLFW.GLFW_KEY_B);

    /** Steps the layer slice. */
    public static final KeyMapping LAYER_UP = register("layer_up", GLFW.GLFW_KEY_PAGE_UP);
    public static final KeyMapping LAYER_DOWN = register("layer_down", GLFW.GLFW_KEY_PAGE_DOWN);

    /** Undo and redo the swap stack; both need Ctrl held. */
    public static final KeyMapping UNDO = register("undo", GLFW.GLFW_KEY_Z);
    public static final KeyMapping REDO = register("redo", GLFW.GLFW_KEY_Y);

    private BuildmaticKeys() {}

    private static KeyMapping register(String name, int keyCode) {
        // Two independent splits meeting in one call. Fabric renamed the helper in 26.1, when
        // Minecraft renamed key bindings to key mappings; the category became an enum a release
        // earlier, in 1.21.9. Hence three branches rather than two.
        //? if >=26.1 {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.buildmatic." + name,
                InputConstants.Type.KEYSYM,
                keyCode,
                KeyMapping.Category.MISC));
        //?} elif >=1.21.9 {
        /*return KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.buildmatic." + name,
                InputConstants.Type.KEYSYM,
                keyCode,
                KeyMapping.Category.MISC));
        *///?} else {
        /*return KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.buildmatic." + name,
                InputConstants.Type.KEYSYM,
                keyCode,
                "key.categories.misc"));
        *///?}
    }

    /** Touching the class is enough to run the static initialisers. */
    public static void init() {}
}
