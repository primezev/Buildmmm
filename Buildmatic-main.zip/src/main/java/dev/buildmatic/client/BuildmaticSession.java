package dev.buildmatic.client;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicIo;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.swap.SwapLayer;
import dev.buildmatic.core.swap.SwapRule;
import dev.buildmatic.core.variant.VariantIndex;
import dev.buildmatic.platform.GamePlatform;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * The mutable state of one editing session: which schematics are open and what has been swapped.
 *
 * <p>Deliberately free of Minecraft types so the whole edit/undo/redo flow can be driven from a
 * test. The client layer wires input and rendering onto it.
 */
public final class BuildmaticSession {

    /** One open schematic together with its swap stack and where it sits in the world. */
    public static final class OpenSchematic {
        private final Schematic schematic;
        private final SwapEngine swaps;
        private final SchematicPlacement placement;

        OpenSchematic(Schematic schematic, SwapEngine swaps, SchematicPlacement placement) {
            this.schematic = schematic;
            this.swaps = swaps;
            this.placement = placement;
        }

        public Schematic schematic() { return schematic; }

        public SwapEngine swaps() { return swaps; }

        public SchematicPlacement placement() { return placement; }

        public String name() { return schematic.metadata().name(); }
    }

    /** An undoable operation on the swap stack. */
    private interface Edit {
        void undo();
        void redo();
        String describe();
    }

    private final GamePlatform platform;
    private VariantIndex variants;

    /** The schematic tool's state: current mode and the area selections. */
    private final dev.buildmatic.core.tool.SchematicTool tool =
            new dev.buildmatic.core.tool.SchematicTool();

    private final BuildmaticConfig config;

    private final List<OpenSchematic> open = new ArrayList<>();
    private OpenSchematic active;

    private final Deque<Edit> undoStack = new ArrayDeque<>();
    private final Deque<Edit> redoStack = new ArrayDeque<>();

    /** Matches vanilla's own undo depth for structure edits; deep enough in practice. */
    private static final int MAX_UNDO = 128;

    public BuildmaticSession(GamePlatform platform) {
        this.platform = platform;
        this.variants = platform.buildVariantIndex();
        this.config = BuildmaticConfig.load(platform.configDirectory());
    }

    public GamePlatform platform() { return platform; }

    public dev.buildmatic.core.tool.SchematicTool tool() { return tool; }

    public BuildmaticConfig config() { return config; }

    public VariantIndex variants() { return variants; }

    /** Rebuilds the variant index; call after a resource reload changes the block list or atlas. */
    public void reloadVariants() {
        this.variants = platform.buildVariantIndex();
    }

    // --- open schematics -----------------------------------------------------------------------

    public List<OpenSchematic> open() { return List.copyOf(open); }

    public OpenSchematic active() { return active; }

    public void setActive(OpenSchematic schematic) {
        if (schematic == null || open.contains(schematic)) active = schematic;
    }

    public OpenSchematic load(Path file) throws IOException {
        Schematic schematic = SchematicIo.load(file);
        return adopt(schematic, Vec3i.ZERO);
    }

    public OpenSchematic adopt(Schematic schematic) {
        return adopt(schematic, Vec3i.ZERO);
    }

    public OpenSchematic adopt(Schematic schematic, Vec3i origin) {
        SwapEngine swaps = new SwapEngine(schematic, variants, platform.stateSchema());
        OpenSchematic entry = new OpenSchematic(
                schematic, swaps, new SchematicPlacement(schematic, swaps, origin));
        open.add(entry);
        active = entry;
        return entry;
    }

    /** The active schematic's placement, or null when nothing is open. */
    public SchematicPlacement activePlacement() {
        return active == null ? null : active.placement();
    }

    public void close(OpenSchematic entry) {
        open.remove(entry);
        if (active == entry) active = open.isEmpty() ? null : open.get(open.size() - 1);
        undoStack.removeIf(edit -> edit instanceof LayerEdit layerEdit && layerEdit.owner == entry);
        redoStack.removeIf(edit -> edit instanceof LayerEdit layerEdit && layerEdit.owner == entry);
    }

    /** Writes the active schematic with every swap baked in, so other tools can read it. */
    public void exportActive(Path file, dev.buildmatic.core.schematic.SchematicFormat format)
            throws IOException {
        if (active == null) throw new IOException("no schematic is open");
        Schematic baked = active.swaps().hasLayers()
                ? active.swaps().bake()
                : active.schematic();
        SchematicIo.save(baked, SchematicIo.withExtension(file, format), format,
                platform.dataVersion());
    }

    // --- swapping ------------------------------------------------------------------------------

    /**
     * Applies a swap to the active schematic and pushes it onto the undo stack.
     *
     * <p>Every path in the UI - the variant wheel, the batch dialog, a preset - ends up here, so
     * undo behaves the same way regardless of how the swap was made.
     */
    public SwapLayer applySwap(String label, SwapRule rule) {
        if (active == null) return null;
        SwapLayer layer = SwapLayer.of(label, rule);
        pushEdit(new LayerEdit(active, layer));
        active.swaps().addLayer(layer);
        return layer;
    }

    /**
     * Replaces a preview layer with a new one, in place of stacking the two.
     *
     * <p>The pickers apply every selection immediately, which is what makes them worth using - the
     * ghost answers the question instead of a description of it. Without this, arrowing through ten
     * variants would leave ten entries on the undo stack and ten presses of Ctrl+Z between the
     * player and where they started. Swapping the layer <em>and</em> its undo entry keeps browsing
     * free: what lands on the stack is the one choice that was kept.
     *
     * @param previous the layer being replaced, or null to add the first one
     */
    public SwapLayer replaceSwap(SwapLayer previous, String label, SwapRule rule) {
        if (active == null) return null;

        // Put the replacement back where the old one was. A layer applied before a hand-made swap
        // must not jump above it just because it was re-picked: later layers win, so moving it
        // would quietly override edits the player made on top of it.
        int index = previous == null ? -1 : active.swaps().layers().indexOf(previous);
        discardSwap(previous);

        SwapLayer layer = SwapLayer.of(label, rule);
        pushEdit(new LayerEdit(active, layer));
        if (index >= 0) {
            active.swaps().insertLayer(index, layer);
        } else {
            active.swaps().addLayer(layer);
        }
        return layer;
    }

    /**
     * Removes a layer along with any undo entry that refers to it.
     *
     * <p>Both stacks are swept, not just the top: an entry left pointing at a layer that no longer
     * exists would resurrect it on redo, which is how a discarded preview comes back from the dead
     * three edits later.
     */
    public boolean discardSwap(SwapLayer layer) {
        if (active == null || layer == null) return false;
        boolean removed = active.swaps().removeLayer(layer);
        undoStack.removeIf(edit -> edit instanceof LayerEdit e && e.layer == layer);
        redoStack.removeIf(edit -> edit instanceof LayerEdit e && e.layer == layer);
        return removed;
    }

    /** Convenience for the common case: swap one clicked block's material across the whole build. */
    public SwapLayer swapMaterialEverywhere(BlockStateRef source, String targetMaterial) {
        VariantIndex.BlockKind kind = variants.kindOf(source.blockId());
        if (kind == null) return null;
        return applySwap(
                kind.materialDisplayName() + " -> " + VariantIndex.prettify(targetMaterial),
                SwapRule.of(new SwapRule.Matcher.Material(kind.material()),
                        new SwapRule.Target.Material(targetMaterial)));
    }

    public boolean canUndo() { return !undoStack.isEmpty(); }

    public boolean canRedo() { return !redoStack.isEmpty(); }

    public String undo() {
        Edit edit = undoStack.pollLast();
        if (edit == null) return null;
        edit.undo();
        redoStack.addLast(edit);
        return edit.describe();
    }

    public String redo() {
        Edit edit = redoStack.pollLast();
        if (edit == null) return null;
        edit.redo();
        undoStack.addLast(edit);
        return edit.describe();
    }

    private void pushEdit(Edit edit) {
        undoStack.addLast(edit);
        redoStack.clear();
        while (undoStack.size() > MAX_UNDO) undoStack.pollFirst();
    }

    /** Adding and removing a swap layer are exact inverses, which makes undo trivial. */
    private static final class LayerEdit implements Edit {
        private final OpenSchematic owner;
        private final SwapLayer layer;
        private int index;

        LayerEdit(OpenSchematic owner, SwapLayer layer) {
            this.owner = owner;
            this.layer = layer;
        }

        @Override
        public void undo() {
            index = owner.swaps().layers().indexOf(layer);
            owner.swaps().removeLayer(layer);
        }

        @Override
        public void redo() {
            owner.swaps().insertLayer(index < 0 ? owner.swaps().layers().size() : index, layer);
        }

        @Override
        public String describe() { return layer.describe(); }
    }
}
