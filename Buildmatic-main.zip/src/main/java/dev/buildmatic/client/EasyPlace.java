package dev.buildmatic.client;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.material.ItemMapper;
import dev.buildmatic.core.render.GhostRaycast;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.platform.MinecraftStateSchema;
import dev.buildmatic.platform.Registries;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Places the block the schematic wants, instead of the one in your hand.
 *
 * <p>Right clicking a ghost block finds the right item anywhere in the inventory, switches the
 * hotbar to it and puts the block down already facing the right way. Without it, half of building
 * from a schematic is spotting that the stair you just placed is mirrored.
 *
 * <p>In creative singleplayer the block is written directly, so the orientation is exact. Anywhere
 * else the item is selected and vanilla does the placing, which gets the block right but not always
 * its rotation - the same limit Litematica hits without a server-side helper mod.
 */
public final class EasyPlace {

    private EasyPlace() {}

    /** What a right click achieved. */
    public enum Outcome {
        /** Not applicable: no schematic, nothing targeted, or the mode is off. */
        SKIP,
        /** The block was placed. */
        PLACED,
        /** Already correct; nothing to do. */
        ALREADY_CORRECT,
        /** The item is not in the inventory. */
        MISSING_ITEM
    }

    public record Result(Outcome outcome, String message) {
        static final Result SKIP = new Result(Outcome.SKIP, "");
    }

    /**
     * Tries to place whatever the schematic wants at the position under the crosshair.
     *
     * @return what happened, so the caller can decide whether to swallow the click
     */
    /** Positions already sent, so a server round trip does not get the same block placed twice. */
    private static final java.util.Map<Vec3i, Long> RECENT = new java.util.HashMap<>();
    /** Litematica rate-limits to roughly this; without it a held button floods the server. */
    private static final long COOLDOWN_MS = 50;
    private static final long RETRY_MS = 400;

    private static long lastPlacement;

    public static Result tryPlace(Minecraft client, MinecraftStateSchema schema) {
        BuildmaticSession session = BuildmaticClient.session();
        if (session == null || client.player == null || client.level == null) return Result.SKIP;

        // Only look as far as the player could actually build. Targeting the ghost across the whole
        // render distance meant every click past arm's length was sent, rejected by the server for
        // being out of reach, and - in survival - counted as a used item by the client's own
        // prediction before the rejection arrived. Blocks vanished from the hotbar and nothing
        // appeared in the world.
        //? if >=1.20.5 {
        double reach = client.player.blockInteractionRange();
        //?} else {
        /*double reach = client.gameMode == null ? 4.5 : client.gameMode.getPickRange();
        *///?}
        GhostRaycast.Hit hit = BuildmaticClient.targetWithin(client, reach);
        if (hit == null) return Result.SKIP;

        var placement = session.activePlacement();
        if (placement == null) return Result.SKIP;

        // The state has to be read in world orientation: the placement may be rotated or mirrored.
        BlockStateRef wanted = placement.expectedAt(hit.worldPos());
        if (wanted == null || wanted.isEmpty()) return Result.SKIP;

        Vec3i aimed = hit.worldPos();
        BlockPos aimedAt = new BlockPos(aimed.x(), aimed.y(), aimed.z());

        if (client.level.getBlockState(aimedAt).equals(schema.toBlockState(wanted))) {
            RECENT.remove(aimed);
            return new Result(Outcome.ALREADY_CORRECT, "");
        }

        boolean creative = client.player.isCreative();
        Level serverLevel = serverLevel(client);
        boolean direct = creative && serverLevel != null;

        BlockPos target = aimedAt;
        Vec3i pos = aimed;
        BlockState desired = schema.toBlockState(wanted);

        // Writing straight to the integrated server skips these; anything that leaves as a packet
        // has to pass the same tests the server will apply, or the client's prediction consumes an
        // item for a placement that never happens.
        if (!direct && !canPlace(client, target, desired)) {
            return Result.SKIP;
        }

        // A placement sent to a server does not show up in the client's own level until the change
        // comes back. Without this the same block is sent again every tick while the button is held.
        long now = System.currentTimeMillis();
        Long sent = RECENT.get(pos);
        if (sent != null && now - sent < RETRY_MS) {
            return new Result(Outcome.ALREADY_CORRECT, "");
        }
        if (now - lastPlacement < COOLDOWN_MS) {
            return new Result(Outcome.ALREADY_CORRECT, "");
        }
        lastPlacement = now;
        RECENT.put(pos, now);
        RECENT.values().removeIf(stamp -> now - stamp > RETRY_MS * 4);

        ItemMapper.Cost cost = ItemMapper.VANILLA.costOf(wanted);
        if (cost.isFree()) return Result.SKIP;

        int slot = findSlot(client, cost.itemId());
        if (slot < 0 && !creative) {
            // The block's own name, not its registry id: "Missing Dirt" reads, "minecraft:dirt" does not.
            return new Result(Outcome.MISSING_ITEM,
                    "Put " + schema.displayName(wanted.blockId()).getString() + " in the hotbar");
        }
        if (slot >= 0) {
            selectSlot(client, slot);
        }

        // Creative singleplayer can write the exact state, rotation included.
        if (direct) {
            serverLevel.setBlock(target, desired, 3);
            return new Result(Outcome.PLACED, "");
        }

        return placeAt(client, target, faceFor(wanted, hit));
    }

    /**
     * The checks the server is going to run anyway.
     *
     * <p>Better to decline here than to send a packet the server will reject: the client has
     * already predicted the item leaving the stack by then, and putting it back needs a resync the
     * player experiences as blocks quietly disappearing.
     */
    private static boolean canPlace(Minecraft client, BlockPos target, BlockState desired) {
        // Reach is measured to the block, not along the ray, so a corner at the edge of range still
        // has to be rejected even though the ray reached it.
        //? if >=1.21.9 {
        if (!client.player.isWithinBlockInteractionRange(target, 0.0)) return false;
        //?} elif >=1.20.5 {
        /*if (!client.player.canInteractWithBlock(target, 0.0)) return false;
        *///?} else {
        /*// No interaction-range attribute before 1.20.5: the pick range stands in for it, measured
        // from the eye to the middle of the block.
        double limit = client.gameMode == null ? 4.5 : client.gameMode.getPickRange();
        if (client.player.getEyePosition().distanceToSqr(
                target.getX() + 0.5, target.getY() + 0.5, target.getZ() + 0.5)
                > limit * limit) {
            return false;
        }
        *///?}

        // Only air and things like grass or water can be built into.
        BlockState existing = client.level.getBlockState(target);
        // Replaceability moved off the material and onto the state in 1.19.3.
        //? if >=1.19.3 {
        if (!existing.canBeReplaced()) return false;
        //?} else {
        /*if (!existing.getMaterial().isReplaceable()) return false;
        *///?}

        // A block cannot be placed inside a mob or the player.
        return client.level.isUnobstructed(desired, target,
                net.minecraft.world.phys.shapes.CollisionContext.empty());
    }

    /**
     * Sends a placement aimed straight at the empty position the schematic wants filled.
     *
     * <p>This is the whole trick, and it is not obvious. The server does not require a block to
     * build against: {@code BlockPlaceContext} places into the clicked position itself whenever the
     * state there can be replaced, and air can be replaced. Vanilla's client never exercises that
     * path because its own ray trace only ever returns solid blocks, so a normal player has to
     * build a pillar from the bottom up. Aiming the packet at the empty cell removes that limit
     * without any server-side help.
     *
     * <p>Reach is still enforced server-side, and the block must not intersect an entity - those
     * are real rules, not artefacts of how the client aims.
     */
    private static Result placeAt(Minecraft client, BlockPos target,
                                  net.minecraft.core.Direction side) {
        if (client.gameMode == null || client.level == null || client.player == null) {
            return Result.SKIP;
        }

        // A point on the clicked face of the target cell. Which face matters: several blocks take
        // their orientation from it, so it is chosen from the schematic rather than left at random.
        net.minecraft.world.phys.Vec3 hitPoint = new net.minecraft.world.phys.Vec3(
                target.getX() + 0.5 + side.getStepX() * 0.5,
                target.getY() + 0.5 + side.getStepY() * 0.5,
                target.getZ() + 0.5 + side.getStepZ() * 0.5);

        var hit = new net.minecraft.world.phys.BlockHitResult(hitPoint, side, target, false);
        client.gameMode.useItemOn(client.player,
                net.minecraft.world.InteractionHand.MAIN_HAND, hit);
        client.player.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        return new Result(Outcome.PLACED, "");
    }

    /**
     * Which face to claim was clicked.
     *
     * <p>Blocks that record a facing take it from here, so a stair or a log lands the right way up
     * far more often than if the face were arbitrary.
     */
    private static net.minecraft.core.Direction faceFor(BlockStateRef wanted,
                                                        GhostRaycast.Hit hit) {
        String facing = wanted.property("facing");
        if (facing != null) {
            var direction = dev.buildmatic.core.util.Direction.byName(facing);
            if (direction != null) {
                // Clicking the face a block points away from is what makes it point back at you.
                return toMinecraft(direction.opposite());
            }
        }
        if (wanted.is("half", "top") || wanted.is("type", "top")) {
            return net.minecraft.core.Direction.DOWN;
        }
        if (hit.face() != null) return toMinecraft(hit.face());
        return net.minecraft.core.Direction.UP;
    }

    private static net.minecraft.core.Direction toMinecraft(
            dev.buildmatic.core.util.Direction direction) {
        return switch (direction) {
            case DOWN -> net.minecraft.core.Direction.DOWN;
            case UP -> net.minecraft.core.Direction.UP;
            case NORTH -> net.minecraft.core.Direction.NORTH;
            case SOUTH -> net.minecraft.core.Direction.SOUTH;
            case WEST -> net.minecraft.core.Direction.WEST;
            case EAST -> net.minecraft.core.Direction.EAST;
        };
    }

    /**
     * Finds the item in the hotbar.
     *
     * <p>Deliberately only the hotbar. Reaching into the backpack means rearranging the inventory,
     * and doing that client-side - which is what {@code Inventory.pickSlot} does - leaves the server
     * holding a different inventory to the one on screen. That desync is a bug on its own, it makes
     * items appear to vanish, and it is the kind of thing an anti-cheat is built to notice.
     * Changing the selected hotbar slot is something a player does by scrolling, so it is safe.
     *
     * @return the hotbar slot to select, or -1 when the item is not to hand
     */
    private static int findSlot(Minecraft client, String itemId) {
        Inventory inventory = client.player.getInventory();
        Item item = itemById(itemId);
        if (item == null) return -1;

        for (int i = 0; i < Inventory.getSelectionSize(); i++) {
            if (inventory.getItem(i).is(item)) return i;
        }
        return -1;
    }

    /**
     * Item lookup by namespaced id, cached.
     *
     * <p>Built by walking the registry rather than parsing an identifier, because that type was
     * renamed between versions and naming it here would force a preprocessor branch.
     */
    private static Item itemById(String itemId) {
        if (ITEMS.isEmpty()) {
            for (var key : Registries.ITEM.keySet()) {
                //? if >=1.21.2 {
                Item value = Registries.ITEM.getValue(key);
                //?} else {
                /*Item value = Registries.ITEM.get(key);
                *///?}
                if (value != null) ITEMS.put(key.getNamespace() + ":" + key.getPath(), value);
            }
        }
        return ITEMS.get(itemId);
    }

    private static final java.util.Map<String, Item> ITEMS = new java.util.HashMap<>();

    /** Drops the item cache; call on a resource reload. */
    public static void invalidate() { ITEMS.clear(); }

    private static void selectSlot(Minecraft client, int slot) {
        Inventory inventory = client.player.getInventory();
        //? if >=1.21.5 {
        if (inventory.getSelectedSlot() == slot) return;
        inventory.setSelectedSlot(slot);
        //?} else {
        /*if (inventory.selected == slot) return;
        inventory.selected = slot;
        *///?}
    }

    private static Level serverLevel(Minecraft client) {
        var server = client.getSingleplayerServer();
        if (server == null || client.level == null) return null;
        return server.getLevel(client.level.dimension());
    }
}
