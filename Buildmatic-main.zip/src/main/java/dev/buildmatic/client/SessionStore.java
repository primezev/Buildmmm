package dev.buildmatic.client;

import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtIo;
import dev.buildmatic.core.nbt.NbtList;
import dev.buildmatic.core.nbt.NbtTag;
import dev.buildmatic.core.placement.LayerRange;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicIo;
import dev.buildmatic.core.swap.SwapCodec;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;
import dev.buildmatic.core.util.Vec3i;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Remembers where each schematic was left, per world and per server.
 *
 * <p>Placements are worth more than the few seconds it takes to make them: lining a build up with
 * an existing structure is fiddly, and losing that alignment every time you step through a nether
 * portal or the server restarts makes the mod hostile to actually building anything.
 *
 * <p>Only the reference is stored - the file name and the transform - never the blocks. A schematic
 * that has been edited or deleted on disk since is skipped rather than resurrected from a stale
 * copy.
 */
public final class SessionStore {

    /** What was last written where, so an unchanged session is not rewritten every autosave. */
    private static Path lastFile;
    private static NbtCompound lastWritten;

    private SessionStore() {}

    /** Where the placements for the world currently being played are kept. */
    private static Path fileFor(BuildmaticSession session) {
        return fileFor(session, worldKey());
    }

    private static Path fileFor(BuildmaticSession session, String key) {
        if (key == null) return null;
        return session.platform().configDirectory().resolve("placements")
                .resolve(key + ".nbt");
    }

    /**
     * Saves under a key captured earlier.
     *
     * <p>Needed when leaving a world: by the time the change is noticed the player is already
     * somewhere else, and asking for the key again would file the old placements under the new
     * world.
     */
    public static void saveAs(BuildmaticSession session, String key) {
        write(session, fileFor(session, key));
    }

    /**
     * A stable, filesystem-safe name for the world you are currently standing in.
     *
     * <p>Singleplayer uses the level folder, multiplayer the address, and both carry the dimension:
     * a build placed in the overworld has no business reappearing at the same coordinates in the
     * Nether. Everything else about the key is stable across a rejoin, which is the point.
     */
    public static String worldKey() {
        Minecraft client = Minecraft.getInstance();
        if (client.level == null) return null;

        //? if >=1.21.9 {
        String dimension = client.level.dimension().identifier().getPath();
        //?} else {
        /*String dimension = client.level.dimension().location().getPath();
        *///?}

        var server = client.getSingleplayerServer();
        if (server != null) {
            return sanitise("sp-" + server.getWorldData().getLevelName() + "-" + dimension);
        }

        var connection = client.getCurrentServer();
        if (connection != null && connection.ip != null) {
            return sanitise("mp-" + connection.ip + "-" + dimension);
        }
        return null;
    }

    private static String sanitise(String raw) {
        StringBuilder out = new StringBuilder(raw.length());
        for (char c : raw.toLowerCase(Locale.ROOT).toCharArray()) {
            out.append(Character.isLetterOrDigit(c) || c == '-' || c == '_' ? c : '_');
        }
        // Keep the name short enough for every filesystem, and unique via the original's hash.
        String cleaned = out.toString();
        return cleaned.length() <= 60
                ? cleaned
                : cleaned.substring(0, 60) + "-" + Integer.toHexString(raw.hashCode());
    }

    // --- saving --------------------------------------------------------------------------------

    public static void save(BuildmaticSession session) {
        write(session, fileFor(session));
    }

    private static void write(BuildmaticSession session, Path file) {
        if (file == null) return;

        NbtList placements = new NbtList(NbtTag.TAG_COMPOUND);
        for (BuildmaticSession.OpenSchematic open : session.open()) {
            Path source = open.schematic().sourceFile();
            // Anything not backed by a file - a fresh world capture, say - has nothing to point at.
            if (source == null) continue;
            placements.add(write(open, source));
        }

        try {
            if (placements.isEmpty()) {
                Files.deleteIfExists(file);
                lastFile = null;
                lastWritten = null;
                return;
            }
            NbtCompound root = new NbtCompound();
            root.putInt("Version", 1);
            root.put("Placements", placements);

            // The autosave runs every thirty seconds whether anything moved or not, and a swap
            // layer can carry a flood fill's worth of positions. Comparing before writing keeps the
            // idle case free: no gzip, no disk.
            if (file.equals(lastFile) && root.equals(lastWritten)) return;

            NbtIo.write("Buildmatic", root, file, true);
            lastFile = file;
            lastWritten = root;
        } catch (IOException e) {
            dev.buildmatic.Buildmatic.LOGGER.warn("could not save placements to {}", file, e);
        }
    }

    private static NbtCompound write(BuildmaticSession.OpenSchematic open, Path source) {
        SchematicPlacement placement = open.placement();
        NbtCompound tag = new NbtCompound();

        tag.putString("File", source.toAbsolutePath().toString());
        tag.putString("Name", placement.name());
        tag.putInt("X", placement.origin().x());
        tag.putInt("Y", placement.origin().y());
        tag.putInt("Z", placement.origin().z());
        tag.putInt("Rotation", placement.rotation().quarterTurns());
        tag.putString("Mirror", placement.mirror().name());
        tag.putBoolean("Enabled", placement.isEnabled());
        tag.putBoolean("Locked", placement.isLocked());

        LayerRange layers = placement.layerRange();
        NbtCompound layerTag = new NbtCompound();
        layerTag.putString("Mode", layers.mode().name());
        layerTag.putString("Axis", layers.axis().name());
        layerTag.putInt("Min", layers.min());
        layerTag.putInt("Max", layers.max());
        tag.put("Layers", layerTag);

        if (!placement.hiddenRegions().isEmpty()) {
            tag.put("Hidden", NbtList.ofStrings(new java.util.ArrayList<>(placement.hiddenRegions())));
        }

        // Swaps live only in memory - the schematic on disk is never edited - so without this a
        // restyled build comes back in its original palette.
        NbtList swaps = SwapCodec.writeAll(open.swaps().layers());
        if (!swaps.isEmpty()) tag.put("Swaps", swaps);
        return tag;
    }

    // --- loading -------------------------------------------------------------------------------

    /** Reopens whatever was left in this world. Returns how many placements came back. */
    public static int restore(BuildmaticSession session) {
        Path file = fileFor(session);
        if (file == null || !Files.isRegularFile(file)) return 0;

        NbtCompound root;
        try {
            root = NbtIo.read(file);
        } catch (IOException e) {
            dev.buildmatic.Buildmatic.LOGGER.warn("could not read placements from {}", file, e);
            return 0;
        }

        NbtList placements = root.getList("Placements");
        if (placements == null) return 0;

        int restored = 0;
        for (int i = 0; i < placements.size(); i++) {
            NbtCompound tag = placements.getCompound(i);
            if (tag != null && read(session, tag)) restored++;
        }
        return restored;
    }

    private static boolean read(BuildmaticSession session, NbtCompound tag) {
        Path source = Path.of(tag.getString("File", ""));
        if (!Files.isRegularFile(source)) {
            // The file was moved or deleted; silently drop it rather than failing the whole restore.
            return false;
        }

        Schematic schematic;
        try {
            schematic = SchematicIo.load(source);
        } catch (IOException | RuntimeException e) {
            dev.buildmatic.Buildmatic.LOGGER.warn("could not reopen {}", source, e);
            return false;
        }

        var origin = new Vec3i(tag.getInt("X", 0), tag.getInt("Y", 0), tag.getInt("Z", 0));
        BuildmaticSession.OpenSchematic open = session.adopt(schematic, origin);
        SchematicPlacement placement = open.placement();

        placement.setName(tag.getString("Name", schematic.metadata().name()));
        placement.setRotation(Rotation.byQuarterTurns(tag.getInt("Rotation", 0)));
        placement.setMirror(parseMirror(tag.getString("Mirror", "NONE")));
        placement.setEnabled(tag.getBoolean("Enabled", true));
        placement.setLocked(tag.getBoolean("Locked", false));

        NbtCompound layers = tag.getCompound("Layers");
        if (layers != null) {
            placement.setLayerRange(new LayerRange(
                    parseLayerMode(layers.getString("Mode", "ALL")),
                    parseAxis(layers.getString("Axis", "Y")),
                    layers.getInt("Min", 0),
                    layers.getInt("Max", 0)));
        }

        NbtList hidden = tag.getList("Hidden");
        if (hidden != null) {
            for (int i = 0; i < hidden.size(); i++) {
                placement.setRegionVisible(hidden.getString(i), false);
            }
        }

        NbtList swaps = tag.getList("Swaps");
        if (swaps != null) {
            int skipped = SwapCodec.readInto(open.swaps(), swaps);
            if (skipped > 0) {
                dev.buildmatic.Buildmatic.LOGGER.warn(
                        "dropped {} unreadable swap layer(s) for {}", skipped, source);
            }
        }
        return true;
    }

    private static Mirror parseMirror(String name) {
        try {
            return Mirror.valueOf(name);
        } catch (IllegalArgumentException e) {
            return Mirror.NONE;
        }
    }

    private static LayerRange.Mode parseLayerMode(String name) {
        try {
            return LayerRange.Mode.valueOf(name);
        } catch (IllegalArgumentException e) {
            return LayerRange.Mode.ALL;
        }
    }

    private static Direction.Axis parseAxis(String name) {
        try {
            return Direction.Axis.valueOf(name);
        } catch (IllegalArgumentException e) {
            return Direction.Axis.Y;
        }
    }
}
