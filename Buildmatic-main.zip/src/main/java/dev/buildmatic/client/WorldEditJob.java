package dev.buildmatic.client;

import dev.buildmatic.core.area.AreaSelection;
import dev.buildmatic.core.area.SelectionBox;
import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.platform.MinecraftStateSchema;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Any bulk change to the world, applied gradually and recorded so it can be taken back.
 *
 * <p>Doing this in one tick is what made pasting misbehave: every block appears at once, so anything
 * that depends on its surroundings - redstone, rails, doors, falling blocks - lands next to
 * neighbours that do not exist yet and settles wrong. Spreading the work over ticks and choosing the
 * order fixes that: a build rises from the bottom so nothing is ever placed before its support, and
 * a demolition comes down from the top so nothing is left unsupported halfway.
 *
 * <p>Recording the previous state of every position as it goes costs one block state per block and
 * gives undo for free - which matters most for exactly the operations that are worth confirming.
 */
public final class WorldEditJob {

    /** One block to write. */
    private record Step(BlockPos pos, BlockState state) {}

    /** What the job is doing, for the message and for the confirmation text. */
    public enum Kind {
        PASTE("Building", false),
        DELETE("Clearing", true),
        FILL("Filling", true),
        REPLACE("Replacing", true),
        UNDO("Undoing", false);

        private final String verb;
        private final boolean destructive;

        Kind(String verb, boolean destructive) {
            this.verb = verb;
            this.destructive = destructive;
        }

        public String verb() { return verb; }

        /** True when the operation overwrites blocks the player did not ask to lose. */
        public boolean isDestructive() { return destructive; }
    }

    /** Blocks per tick. Twenty ticks a second, so this is visible but brisk. */
    private static final int DEFAULT_RATE = 48;
    private static final int MAX_BLOCKS = 500_000;

    private final List<Step> steps;
    private final Level level;
    private final Kind kind;
    private final String name;

    /** Positions already changed, with what they held before. Reversed, this is the undo. */
    private final List<Step> history;

    private int cursor;
    private int rate = DEFAULT_RATE;

    private WorldEditJob(List<Step> steps, Level level, Kind kind, String name) {
        this.steps = steps;
        this.level = level;
        this.kind = kind;
        this.name = name;
        this.history = new ArrayList<>(Math.min(steps.size(), MAX_BLOCKS));
    }

    /** A planned job, or the reason it will not run. */
    public record Plan(WorldEditJob job, String message) {
        static Plan refused(String why) { return new Plan(null, why); }
    }

    // --- planning ------------------------------------------------------------------------------

    /** Builds the placement into the world, rising from the bottom. */
    public static Plan paste(SchematicPlacement placement, MinecraftStateSchema schema) {
        Level level = writableLevel();
        if (level == null) return Plan.refused(refusal());
        if (placement == null) return Plan.refused("Nothing loaded");

        List<Step> steps = new ArrayList<>();
        for (SchematicRegion region : placement.schematic().regions()) {
            if (!placement.isRegionVisible(region)) continue;

            for (int y = 0; y < region.sizeY(); y++) {
                for (int z = 0; z < region.sizeZ(); z++) {
                    for (int x = 0; x < region.sizeX(); x++) {
                        Vec3i schematicPos = region.origin().add(x, y, z);
                        if (!placement.layerRange().contains(schematicPos)) continue;

                        Vec3i world = placement.toWorld(schematicPos);
                        BlockStateRef wanted = placement.expectedAt(world);
                        if (wanted == null || wanted.isEmpty()) continue;

                        steps.add(new Step(new BlockPos(world.x(), world.y(), world.z()),
                                schema.toBlockState(wanted)));
                    }
                }
            }
        }
        // Sorted by world height rather than by the order the regions were walked in: a
        // multi-region build must rise as one, or one tower finishes before another starts.
        steps.sort(Comparator.comparingInt(step -> step.pos().getY()));
        return finish(steps, level, Kind.PASTE, placement.name());
    }

    /** Clears the placement's volume, coming down from the top. */
    public static Plan deletePlacement(SchematicPlacement placement, MinecraftStateSchema schema) {
        Level level = writableLevel();
        if (level == null) return Plan.refused(refusal());
        if (placement == null) return Plan.refused("Nothing loaded");

        BlockState air = Blocks.AIR.defaultBlockState();
        List<Step> steps = new ArrayList<>();
        for (SchematicRegion region : placement.schematic().regions()) {
            if (!placement.isRegionVisible(region)) continue;

            for (int y = 0; y < region.sizeY(); y++) {
                for (int z = 0; z < region.sizeZ(); z++) {
                    for (int x = 0; x < region.sizeX(); x++) {
                        Vec3i schematicPos = region.origin().add(x, y, z);
                        if (!placement.layerRange().contains(schematicPos)) continue;

                        BlockStateRef wanted = placement.expectedAt(placement.toWorld(schematicPos));
                        if (wanted == null || wanted.isEmpty()) continue;

                        Vec3i world = placement.toWorld(schematicPos);
                        steps.add(new Step(new BlockPos(world.x(), world.y(), world.z()), air));
                    }
                }
            }
        }
        return topDown(steps, level, Kind.DELETE, placement.name());
    }

    /** Clears the selection, coming down from the top. */
    public static Plan deleteSelection(AreaSelection selection) {
        return overSelection(selection, Kind.DELETE, Blocks.AIR.defaultBlockState(), null);
    }

    public static Plan fill(AreaSelection selection, BlockState block) {
        return overSelection(selection, Kind.FILL, block, null);
    }

    /** Swaps one block type for another; everything else in the selection is left alone. */
    public static Plan replace(AreaSelection selection, BlockState from, BlockState to) {
        return overSelection(selection, Kind.REPLACE, to, from);
    }

    private static Plan overSelection(AreaSelection selection, Kind kind, BlockState write,
                                      BlockState only) {
        Level level = writableLevel();
        if (level == null) return Plan.refused(refusal());
        if (selection == null || !selection.hasCompleteBox()) {
            return Plan.refused("Draw a selection first: click two corners with the tool");
        }

        List<Step> steps = new ArrayList<>();
        for (SelectionBox box : selection.boxes()) {
            if (!box.isEnabled() || !box.isComplete()) continue;
            for (Vec3i pos : box.box()) {
                BlockPos at = new BlockPos(pos.x(), pos.y(), pos.z());
                if (only != null && level.getBlockState(at).getBlock() != only.getBlock()) continue;
                steps.add(new Step(at, write));
            }
        }
        return kind == Kind.DELETE
                ? topDown(steps, level, kind, selection.name())
                : finish(steps, level, kind, selection.name());
    }

    /** Undoes a finished job by replaying what it recorded, newest change first. */
    public static Plan undoOf(WorldEditJob done) {
        Level level = writableLevel();
        if (level == null) return Plan.refused(refusal());
        if (done == null || done.history.isEmpty()) return Plan.refused("Nothing to undo");

        List<Step> steps = new ArrayList<>(done.history);
        java.util.Collections.reverse(steps);
        return finish(steps, level, Kind.UNDO, done.name);
    }

    private static Plan topDown(List<Step> steps, Level level, Kind kind, String name) {
        // Taking a structure apart from underneath drops everything that was resting on it.
        steps.sort(Comparator.comparingInt((Step step) -> step.pos().getY()).reversed());
        return finish(steps, level, kind, name);
    }

    private static Plan finish(List<Step> steps, Level level, Kind kind, String name) {
        if (steps.isEmpty()) return Plan.refused("Nothing to change");
        if (steps.size() > MAX_BLOCKS) {
            return Plan.refused(steps.size() + " blocks is over the " + MAX_BLOCKS + " limit");
        }
        return new Plan(new WorldEditJob(steps, level, kind, name),
                kind.verb() + " " + name + " - " + steps.size() + " blocks");
    }

    private static Level writableLevel() {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null || !client.player.isCreative()) return null;
        var server = client.getSingleplayerServer();
        return server == null ? null : server.getLevel(client.level.dimension());
    }

    private static String refusal() {
        Minecraft client = Minecraft.getInstance();
        if (client.player != null && !client.player.isCreative()) return "Creative mode only";
        return "Singleplayer only - a server would need operator commands";
    }

    // --- running -------------------------------------------------------------------------------

    public Kind kind() { return kind; }

    public String name() { return name; }

    public int total() { return steps.size(); }

    public int remaining() { return steps.size() - cursor; }

    public boolean isFinished() { return cursor >= steps.size(); }

    public boolean hasHistory() { return !history.isEmpty(); }

    /** Y of the layer currently being worked on, for the progress line. */
    public int currentLayer() {
        return isFinished() ? 0 : steps.get(cursor).pos().getY();
    }

    public void setRate(int blocksPerTick) {
        this.rate = Math.max(1, Math.min(4096, blocksPerTick));
    }

    /**
     * Writes the next batch.
     *
     * <p>Flag 2 sends the change to clients without running neighbour updates, so a redstone
     * contraption does not fire itself apart while it is still being assembled.
     */
    public void tick() {
        int budget = rate;
        while (budget-- > 0 && !isFinished()) {
            Step step = steps.get(cursor++);
            BlockState before = level.getBlockState(step.pos());
            if (before.equals(step.state())) continue;

            history.add(new Step(step.pos(), before));
            level.setBlock(step.pos(), step.state(), 2);
        }
    }

    /** Stops here. What has already been written stays, and stays undoable. */
    public void cancel() {
        cursor = steps.size();
    }
}
