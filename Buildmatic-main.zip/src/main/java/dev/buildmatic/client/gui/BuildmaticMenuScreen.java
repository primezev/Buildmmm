package dev.buildmatic.client.gui;

import dev.buildmatic.client.BuildmaticClient;
import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.tabs.AreasTab;
import dev.buildmatic.client.gui.tabs.MaterialsTab;
import dev.buildmatic.client.gui.tabs.PlacementsTab;
import dev.buildmatic.client.gui.tabs.SchematicsTab;
import dev.buildmatic.client.gui.tabs.SwapsTab;
import dev.buildmatic.client.gui.tabs.VerifyTab;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Buildmatic's single menu.
 *
 * <p>Everything lives here behind a tab bar rather than being scattered across eight separate
 * windows: loading a schematic, positioning it, swapping its blocks, drawing an area, saving one,
 * checking materials and verifying progress are all one keypress apart.
 *
 * <p>The game keeps running underneath, so a swap made on the Swaps tab is visible in the preview
 * around the panel immediately.
 */
public final class BuildmaticMenuScreen extends BuildmaticScreen {

    private static final int TAB_HEIGHT = 18;

    private final List<MenuTab> tabs = new ArrayList<>();
    /** Remembered between openings so the menu comes back where it was left. */
    private static int lastTab = 0;
    private int current;

    public BuildmaticMenuScreen() {
        this(lastTab);
    }

    public BuildmaticMenuScreen(int tabIndex) {
        super(Component.literal("Buildmatic"));
        tabs.add(new SchematicsTab());
        tabs.add(new PlacementsTab());
        tabs.add(new SwapsTab());
        tabs.add(new AreasTab());
        tabs.add(new MaterialsTab());
        tabs.add(new VerifyTab());
        tabs.add(new dev.buildmatic.client.gui.tabs.SettingsTab());
        current = Math.max(0, Math.min(tabIndex, tabs.size() - 1));
    }

    /** Opens the menu straight onto a named tab, for the dedicated hotkeys. */
    public static BuildmaticMenuScreen on(Class<? extends MenuTab> tabType) {
        BuildmaticMenuScreen screen = new BuildmaticMenuScreen();
        for (int i = 0; i < screen.tabs.size(); i++) {
            if (tabType.isInstance(screen.tabs.get(i))) {
                screen.current = i;
                break;
            }
        }
        return screen;
    }

    @Override
    protected void init() {
        // Wider than the other panels: the tables here have several columns.
        panelWidth = Math.min(width - MARGIN * 2, 520);
        panelHeight = Math.min(height - MARGIN * 2, 340);
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
        initContents();
    }

    @Override
    protected void initContents() {
        clearWidgets();
        lastTab = current;

        int contentX = panelX + 8;
        int contentY = contentTop() + TAB_HEIGHT + 4;
        int contentW = panelWidth - 16;
        int contentH = contentBottom() - contentY - 4;

        activeTab().init(this, contentX, contentY, contentW, contentH, this::addRenderableWidget);
    }

    public MenuTab activeTab() {
        return tabs.get(current);
    }

    public BuildmaticSession sessionOrNull() {
        return session();
    }

    /** Rebuilds the current tab, e.g. after loading a schematic from inside it. */
    public void reinit() {
        init();
    }

    /** Drops the ghost geometry cache; call after anything that changes what is drawn. */
    public void invalidatePreview() {
        if (BuildmaticClient.renderer() != null) BuildmaticClient.renderer().invalidate();
    }

    private void selectTab(int index) {
        if (index == current || index < 0 || index >= tabs.size()) return;
        current = index;
        init();
    }

    // --- rendering --------------------------------------------------------------------------------

    @Override
    protected void renderContents(Canvas gfx, int mouseX, int mouseY) {
        renderTabBar(gfx, mouseX, mouseY);
        activeTab().render(gfx, mouseX, mouseY);
    }

    private void renderTabBar(Canvas gfx, int mouseX, int mouseY) {
        int x = panelX + 8;
        int y = contentTop();
        for (int i = 0; i < tabs.size(); i++) {
            MenuTab tab = tabs.get(i);
            int tabWidth = font.width(tab.title()) + 16;
            boolean active = i == current;
            boolean hovered = mouseX >= x && mouseX < x + tabWidth
                    && mouseY >= y && mouseY < y + TAB_HEIGHT;

            gfx.fill(x, y, x + tabWidth, y + TAB_HEIGHT,
                    active ? 0x40FFFFFF : (hovered ? 0x28FFFFFF : 0x14FFFFFF));
            if (active) {
                // Underline rather than a full outline: it reads as "you are here" at a glance.
                gfx.fill(x, y + TAB_HEIGHT - 2, x + tabWidth, y + TAB_HEIGHT, ACCENT);
            }
            gfx.text(font, tab.title(), x + 8, y + 5, active ? TEXT : TEXT_DIM);
            x += tabWidth + 2;
        }
        gfx.fill(panelX + 8, y + TAB_HEIGHT, panelX + panelWidth - 8, y + TAB_HEIGHT + 1, PANEL_BORDER);
    }

    @Override
    protected String footerText() {
        return activeTab().status();
    }

    // --- input ------------------------------------------------------------------------------------

    private int tabAt(double mouseX, double mouseY) {
        int y = contentTop();
        if (mouseY < y || mouseY >= y + TAB_HEIGHT) return -1;
        int x = panelX + 8;
        for (int i = 0; i < tabs.size(); i++) {
            int tabWidth = font.width(tabs.get(i).title()) + 16;
            if (mouseX >= x && mouseX < x + tabWidth) return i;
            x += tabWidth + 2;
        }
        return -1;
    }

    @Override
    protected boolean onClick(double x, double y, int button, boolean doubled) {
        int tab = tabAt(x, y);
        if (tab >= 0) {
            selectTab(tab);
            return true;
        }
        if (activeTab().mouseClicked(x, y, doubled)) return true;
        return false;
    }

    @Override
    protected boolean onScroll(double x, double y, double amount) {
        return activeTab().mouseScrolled(x, y, amount);
    }

    @Override
    protected boolean onKey(int key, int modifiers) {
        // Tab and Shift+Tab walk the tab bar, which is what every tabbed interface does.
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_TAB) {
            boolean back = (modifiers & org.lwjgl.glfw.GLFW.GLFW_MOD_SHIFT) != 0;
            selectTab(Math.floorMod(current + (back ? -1 : 1), tabs.size()));
            return true;
        }
        if (activeTab().keyPressed(key, modifiers)) return true;
        return false;
    }
}
