package dev.buildmatic.client.gui;

import dev.buildmatic.client.BuildmaticClient;
import dev.buildmatic.client.BuildmaticSession;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Shared chrome for Buildmatic's panels.
 *
 * <p>26.1 turned GUI drawing into an extract-render-state pass, so every screen here overrides
 * {@link #extractRenderState} rather than a {@code render} method. The panel, header and footer are
 * drawn once in this base class so the four panels stay consistent and short.
 */
public abstract class BuildmaticScreen extends Screen {

    // Public because the menu tabs live in their own package and draw with the same palette.
    public static final int PANEL_BACKGROUND = 0xF0121216;
    public static final int PANEL_BORDER = 0xFF3A3A45;
    public static final int ROW_ODD = 0x18FFFFFF;
    public static final int ROW_HOVER = 0x30FFFFFF;
    public static final int ROW_SELECTED = 0x504FC3F7;

    public static final int TEXT = 0xFFE6E6E6;
    public static final int TEXT_DIM = 0xFF9A9AA5;
    public static final int ACCENT = 0xFF4FC3F7;
    public static final int GOOD = 0xFF7BD88F;
    public static final int BAD = 0xFFFF6B6B;

    protected static final int MARGIN = 16;
    protected static final int HEADER_HEIGHT = 40;
    protected static final int FOOTER_HEIGHT = 30;
    protected static final int ROW_HEIGHT = 18;

    protected int panelX;
    protected int panelY;
    protected int panelWidth;
    protected int panelHeight;

    protected BuildmaticScreen(Component title) {
        super(title);
    }

    protected BuildmaticSession session() {
        return BuildmaticClient.session();
    }

    /** How big this panel would like to be; capped by the window either way. */
    protected int preferredWidth() { return 460; }

    protected int preferredHeight() { return 300; }

    @Override
    protected void init() {
        // Fill most of the window but stay readable on very wide monitors.
        panelWidth = Math.min(width - MARGIN * 2, preferredWidth());
        panelHeight = Math.min(height - MARGIN * 2, preferredHeight());
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;

        addRenderableWidget(Buttons.of(Component.literal("Close"), b -> onClose(), panelX + panelWidth - 66, panelY + panelHeight - 24, 56, 18));

        initContents();
    }

    /** Add widgets here; the panel geometry is already computed. */
    protected abstract void initContents();

    /** Draw the panel body between the header and the footer. */
    protected abstract void renderContents(Canvas gfx, int mouseX, int mouseY);

    /** Shown in the footer, on the left. */
    protected String footerText() {
        return "";
    }

    // The one method whose signature the game changed: 26.1 collects render state, everything
    // before it draws straight away. Both hand off to the same painting code below.
    //? if >=26.1 {
    @Override
    public void extractRenderState(net.minecraft.client.gui.GuiGraphicsExtractor gfx, int mouseX,
                                   int mouseY, float partialTick) {
        paint(new Canvas(gfx), mouseX, mouseY);
        super.extractRenderState(gfx, mouseX, mouseY, partialTick);
    }
    //?} elif >=1.20 {
    /*@Override
    public void render(net.minecraft.client.gui.GuiGraphics gfx, int mouseX, int mouseY,
                       float partialTick) {
        paint(new Canvas(gfx), mouseX, mouseY);
        super.render(gfx, mouseX, mouseY, partialTick);
    }
    *///?} else {
    /*@Override
    public void render(com.mojang.blaze3d.vertex.PoseStack pose, int mouseX, int mouseY,
                       float partialTick) {
        paint(new Canvas(pose), mouseX, mouseY);
        super.render(pose, mouseX, mouseY, partialTick);
    }
    *///?}

    /** Panel, header, body and footer, in the order they stack. */
    private void paint(Canvas gfx, int mouseX, int mouseY) {
        gfx.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, PANEL_BACKGROUND);
        gfx.outline(panelX, panelY, panelWidth, panelHeight, PANEL_BORDER);

        gfx.text(font, title, panelX + 10, panelY + 12, TEXT);
        gfx.fill(panelX + 1, panelY + HEADER_HEIGHT - 8,
                panelX + panelWidth - 1, panelY + HEADER_HEIGHT - 7, PANEL_BORDER);

        renderContents(gfx, mouseX, mouseY);

        int footerY = panelY + panelHeight - FOOTER_HEIGHT;
        gfx.fill(panelX + 1, footerY, panelX + panelWidth - 1, footerY + 1, PANEL_BORDER);
        String footer = footerText();
        if (!footer.isEmpty()) {
            // Truncated to the panel, or a long status runs off the right edge and out of the
            // window. Tabs build this line by joining several counts, so its length is not
            // something any one of them can be sure of.
            gfx.text(font, fit(footer, panelWidth - 20), panelX + 10, footerY + 11, TEXT_DIM);
        }
        // Buttons and other widgets draw on top of the panel; the caller runs super afterwards.
    }

    // --- input ------------------------------------------------------------------------------------

    /**
     * Clicks and keys, in terms that do not change between versions.
     *
     * <p>26.1 wrapped both in records - {@code MouseButtonEvent}, {@code KeyEvent} - where every
     * earlier version passes loose parameters. The panels override these two instead, and the
     * bridge below is the only place that has to know the difference. Returning false lets the
     * click or key fall through to the widgets, which is what the superclass call used to do.
     *
     * <p>{@code doubled} is always false before 26.1: double-click detection is the game's, and
     * older versions do not offer it. Every panel treats a double click as a shortcut for something
     * reachable another way, so the loss is a convenience rather than a feature.
     */
    protected boolean onClick(double x, double y, int button, boolean doubled) { return false; }

    protected boolean onKey(int key, int modifiers) { return false; }

    /** Vertical scroll only; the horizontal axis arrived in 1.20.2 and nothing here uses it. */
    protected boolean onScroll(double x, double y, double amount) { return false; }

    //? if >=1.20.2 {
    @Override
    public boolean mouseScrolled(double x, double y, double scrollX, double scrollY) {
        if (onScroll(x, y, scrollY)) return true;
        return super.mouseScrolled(x, y, scrollX, scrollY);
    }
    //?} else {
    /*@Override
    public boolean mouseScrolled(double x, double y, double amount) {
        if (onScroll(x, y, amount)) return true;
        return super.mouseScrolled(x, y, amount);
    }
    *///?}

    //? if >=1.21.9 {
    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
        if (onClick(event.x(), event.y(), event.button(), doubled)) return true;
        return super.mouseClicked(event, doubled);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (onKey(event.key(), event.modifiers())) return true;
        return super.keyPressed(event);
    }
    //?} else {
    /*@Override
    public boolean mouseClicked(double x, double y, int button) {
        if (onClick(x, y, button, false)) return true;
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (onKey(key, modifiers)) return true;
        return super.keyPressed(key, scanCode, modifiers);
    }
    *///?}

    /** Y of the first content row. */
    protected int contentTop() {
        return panelY + HEADER_HEIGHT;
    }

    /** Y just past the last content row. */
    protected int contentBottom() {
        return panelY + panelHeight - FOOTER_HEIGHT;
    }

    protected int contentHeight() {
        return contentBottom() - contentTop();
    }

    /** Truncates to fit a column, appending an ellipsis when it does not. */
    protected String fit(String text, int maxWidth) {
        if (font.width(text) <= maxWidth) return text;
        String trimmed = font.plainSubstrByWidth(text, maxWidth - font.width("..."));
        return trimmed + "...";
    }

    @Override
    public boolean isPauseScreen() {
        // Keeping the world live matters: the preview behind the panel updates as swaps are made.
        return false;
    }
}
