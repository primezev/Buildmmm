package dev.buildmatic.client.gui;

import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;

import java.util.function.Consumer;

/**
 * Packs a row of buttons into the width there actually is.
 *
 * <p>The tabs used to place their buttons at hand-counted offsets - 0, 56, 116, 154, 200 - which
 * works until the panel is narrower than the numbers assume. Fullscreen is exactly that case: the
 * game raises the GUI scale, the virtual screen shrinks to a few hundred pixels, the panel shrinks
 * with it, and the right-hand buttons walk off the edge.
 *
 * <p>So the buttons are laid out rather than positioned. They keep their preferred width while it
 * fits and wrap onto another line when it does not. Lines stack <em>upwards</em> from the bottom of
 * the tab, so the first line stays where the eye expects it and {@link #height()} tells the list
 * above exactly how much room to give up.
 */
public final class ButtonRow {

    private static final int GAP = 4;
    private static final int SPACING = 22;

    private final int left;
    private final int width;
    private final int bottom;
    private final int buttonHeight;
    private final Consumer<AbstractWidget> sink;

    private int x;
    private int line;

    /**
     * @param bottom y of the top edge of the bottom line of buttons
     */
    public ButtonRow(int left, int bottom, int width, int buttonHeight,
                     Consumer<AbstractWidget> sink) {
        this.left = left;
        this.bottom = bottom;
        this.width = width;
        this.buttonHeight = buttonHeight;
        this.sink = sink;
    }

    public ButtonRow add(String text, int preferredWidth, Button.OnPress onPress) {
        return add(text, preferredWidth, onPress, null);
    }

    /**
     * Adds a button, wrapping first and shrinking only as a last resort.
     *
     * @param made receives the button, for the tabs that relabel theirs later
     */
    public ButtonRow add(String text, int preferredWidth, Button.OnPress onPress,
                         Consumer<Button> made) {
        if (x > 0 && x + preferredWidth > width) {
            line++;
            x = 0;
        }
        int buttonWidth = Math.min(preferredWidth, Math.max(GAP, width - x));

        // Held rather than placed: the y of a line is only known once it is clear how many lines
        // there are, and the first button added has to end up on the top one.
        planned.add(new Planned(text, buttonWidth, onPress, made, line, x));
        x += buttonWidth + GAP;
        return this;
    }

    /**
     * Places every button and reports how much vertical room they took.
     *
     * <p>Call once, after the last {@code add}; the caller sizes its list with what comes back.
     */
    public int finish() {
        int lines = line + 1;
        int top = bottom - (lines - 1) * SPACING;
        for (Planned p : planned) {
            Button button = Buttons.of(p.text, p.onPress,
                    left + p.x, top + p.line * SPACING, p.width, buttonHeight);
            sink.accept(button);
            if (p.made != null) p.made.accept(button);
        }
        planned.clear();
        return (lines - 1) * SPACING + buttonHeight;
    }

    private final java.util.List<Planned> planned = new java.util.ArrayList<>();

    private record Planned(String text, int width, Button.OnPress onPress, Consumer<Button> made,
                           int line, int x) {}
}
