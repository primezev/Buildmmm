package dev.buildmatic.client.gui;

import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/**
 * One way to make a button, whichever version is compiling.
 *
 * <p>1.19.3 replaced the constructor with a builder. Buildmatic makes forty-nine buttons, so the
 * difference is either forty-nine version branches or this: the panels ask for a button with its
 * text, its action and its bounds, and the one file that knows how buttons are built lives here.
 *
 * <p>Same idea as {@link Canvas} for drawing and the input bridge on {@link BuildmaticScreen}: the
 * version-specific surface is pushed to the edge, where it can be read in one sitting.
 */
public final class Buttons {

    private Buttons() {}

    public static Button of(String text, Button.OnPress onPress,
                            int x, int y, int width, int height) {
        return of(Component.literal(text), onPress, x, y, width, height);
    }

    /** Text and action first, then where it goes - the order the builder reads in. */
    public static Button of(Component text, Button.OnPress onPress,
                            int x, int y, int width, int height) {
        //? if >=1.19.3 {
        return Button.builder(text, onPress).bounds(x, y, width, height).build();
        //?} else {
        /*return new Button(x, y, width, height, text, onPress);
        *///?}
    }
}
