package dev.buildmatic.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

//? if >=26.1 {
import net.minecraft.client.gui.GuiGraphicsExtractor;
//?} elif >=1.20 {
/*import net.minecraft.client.gui.GuiGraphics;
*///?} elif >=1.19.3 {
/*import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
*///?} else {
/*import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
*///?}

/**
 * Everything Buildmatic knows how to draw, in one place.
 *
 * <p>26.1 split GUI drawing into an extract-then-render pass and named the collector
 * {@code GuiGraphicsExtractor}; every version before it draws immediately through
 * {@code GuiGraphics}. The two have the same shape but neither the same type nor the same method
 * names, and Buildmatic's panels mention that type forty-seven times - which is why compiling
 * against 1.21.11 reported eighty-three errors, forty-seven of them this one class.
 *
 * <p>So the panels talk to this instead. It is eight methods wide, which is the whole vocabulary a
 * schematic mod's interface needs, and it is the only file in the client that has to know which era
 * of Minecraft it is being compiled for.
 */
public final class Canvas {

    //? if >=26.1 {
    private final GuiGraphicsExtractor gfx;

    public Canvas(GuiGraphicsExtractor gfx) {
        this.gfx = gfx;
    }

    /** The underlying collector, for the few places that need the real thing. */
    public GuiGraphicsExtractor raw() { return gfx; }

    public void text(Font font, String text, int x, int y, int colour) {
        gfx.text(font, text, x, y, colour);
    }

    public void text(Font font, Component text, int x, int y, int colour) {
        gfx.text(font, text, x, y, colour);
    }

    public void centeredText(Font font, String text, int centreX, int y, int colour) {
        gfx.centeredText(font, text, centreX, y, colour);
    }

    public void textWithWordWrap(Font font, Component text, int x, int y, int width, int colour) {
        gfx.textWithWordWrap(font, text, x, y, width, colour);
    }

    public void fill(int x1, int y1, int x2, int y2, int colour) {
        gfx.fill(x1, y1, x2, y2, colour);
    }

    public void outline(int x, int y, int width, int height, int colour) {
        gfx.outline(x, y, width, height, colour);
    }

    public void item(ItemStack stack, int x, int y) {
        gfx.item(stack, x, y);
    }

    public void enableScissor(int x1, int y1, int x2, int y2) {
        gfx.enableScissor(x1, y1, x2, y2);
    }

    public void disableScissor() {
        gfx.disableScissor();
    }
    //?} elif >=1.20 {
    /*private final GuiGraphics gfx;

    public Canvas(GuiGraphics gfx) {
        this.gfx = gfx;
    }

    public GuiGraphics raw() { return gfx; }

    public void text(Font font, String text, int x, int y, int colour) {
        gfx.drawString(font, text, x, y, colour);
    }

    public void text(Font font, Component text, int x, int y, int colour) {
        gfx.drawString(font, text, x, y, colour);
    }

    public void centeredText(Font font, String text, int centreX, int y, int colour) {
        gfx.drawCenteredString(font, text, centreX, y, colour);
    }

    public void textWithWordWrap(Font font, Component text, int x, int y, int width, int colour) {
        gfx.drawWordWrap(font, text, x, y, width, colour);
    }

    public void fill(int x1, int y1, int x2, int y2, int colour) {
        gfx.fill(x1, y1, x2, y2, colour);
    }

    public void outline(int x, int y, int width, int height, int colour) {
        gfx.renderOutline(x, y, width, height, colour);
    }

    public void item(ItemStack stack, int x, int y) {
        gfx.renderItem(stack, x, y);
    }

    public void enableScissor(int x1, int y1, int x2, int y2) {
        gfx.enableScissor(x1, y1, x2, y2);
    }

    public void disableScissor() {
        gfx.disableScissor();
    }
    *///?} elif >=1.19.3 {
    /*// Before 1.20 there is no graphics object at all: drawing is static methods on GuiComponent
    // taking the pose stack, and items go through the item renderer directly.
    private final PoseStack pose;

    public Canvas(PoseStack pose) {
        this.pose = pose;
    }

    public PoseStack raw() { return pose; }

    public void text(Font font, String text, int x, int y, int colour) {
        GuiComponent.drawString(pose, font, text, x, y, colour);
    }

    public void text(Font font, Component text, int x, int y, int colour) {
        GuiComponent.drawString(pose, font, text, x, y, colour);
    }

    public void centeredText(Font font, String text, int centreX, int y, int colour) {
        GuiComponent.drawCenteredString(pose, font, text, centreX, y, colour);
    }

    public void textWithWordWrap(Font font, Component text, int x, int y, int width, int colour) {
        // No wrapping draw call here, so the text is split and the lines are drawn one by one.
        int line = 0;
        for (var row : font.split(text, width)) {
            GuiComponent.drawString(pose, font, row, x, y + line * font.lineHeight, colour);
            line++;
        }
    }

    public void fill(int x1, int y1, int x2, int y2, int colour) {
        GuiComponent.fill(pose, x1, y1, x2, y2, colour);
    }

    public void outline(int x, int y, int width, int height, int colour) {
        // GuiComponent has no outline of its own; four one-pixel fills make the same rectangle.
        GuiComponent.fill(pose, x, y, x + width, y + 1, colour);
        GuiComponent.fill(pose, x, y + height - 1, x + width, y + height, colour);
        GuiComponent.fill(pose, x, y + 1, x + 1, y + height - 1, colour);
        GuiComponent.fill(pose, x + width - 1, y + 1, x + width, y + height - 1, colour);
    }

    public void item(ItemStack stack, int x, int y) {
        Minecraft.getInstance().getItemRenderer().renderGuiItem(pose, stack, x, y);
    }

    public void enableScissor(int x1, int y1, int x2, int y2) {
        GuiComponent.enableScissor(x1, y1, x2, y2);
    }

    public void disableScissor() {
        GuiComponent.disableScissor();
    }
    *///?} else {
    /*// Identical to the branch above except for the item call: the renderer only started taking
    // the pose stack in 1.19.3, and one differing line inside an inactive branch cannot be
    // expressed any other way.
    private final PoseStack pose;

    public Canvas(PoseStack pose) {
        this.pose = pose;
    }

    public PoseStack raw() { return pose; }

    public void text(Font font, String text, int x, int y, int colour) {
        GuiComponent.drawString(pose, font, text, x, y, colour);
    }

    public void text(Font font, Component text, int x, int y, int colour) {
        GuiComponent.drawString(pose, font, text, x, y, colour);
    }

    public void centeredText(Font font, String text, int centreX, int y, int colour) {
        GuiComponent.drawCenteredString(pose, font, text, centreX, y, colour);
    }

    public void textWithWordWrap(Font font, Component text, int x, int y, int width, int colour) {
        int line = 0;
        for (var row : font.split(text, width)) {
            GuiComponent.drawString(pose, font, row, x, y + line * font.lineHeight, colour);
            line++;
        }
    }

    public void fill(int x1, int y1, int x2, int y2, int colour) {
        GuiComponent.fill(pose, x1, y1, x2, y2, colour);
    }

    public void outline(int x, int y, int width, int height, int colour) {
        GuiComponent.fill(pose, x, y, x + width, y + 1, colour);
        GuiComponent.fill(pose, x, y + height - 1, x + width, y + height, colour);
        GuiComponent.fill(pose, x, y + 1, x + 1, y + height - 1, colour);
        GuiComponent.fill(pose, x + width - 1, y + 1, x + width, y + height - 1, colour);
    }

    public void item(ItemStack stack, int x, int y) {
        Minecraft.getInstance().getItemRenderer().renderGuiItem(stack, x, y);
    }

    public void enableScissor(int x1, int y1, int x2, int y2) {
        GuiComponent.enableScissor(x1, y1, x2, y2);
    }

    public void disableScissor() {
        GuiComponent.disableScissor();
    }
    *///?}
}
