package dev.buildmatic.client.gui;

import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/**
 * Asks before something irreversible.
 *
 * <p>Only for operations that overwrite blocks the player did not ask to lose. Building a schematic
 * into empty air does not need a prompt; clearing a volume does, and so does filling over whatever
 * happened to be there.
 */
public final class ConfirmScreen extends BuildmaticScreen {

    private final String question;
    private final String detail;
    private final Runnable onConfirm;
    private final net.minecraft.client.gui.screens.Screen parent;

    public ConfirmScreen(String title, String question, String detail,
                         net.minecraft.client.gui.screens.Screen parent, Runnable onConfirm) {
        super(Component.literal(title));
        this.question = question;
        this.detail = detail;
        this.parent = parent;
        this.onConfirm = onConfirm;
    }

    @Override
    protected void init() {
        panelWidth = Math.min(width - MARGIN * 2, 320);
        panelHeight = Math.min(height - MARGIN * 2, 130);
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
        initContents();
    }

    @Override
    protected void initContents() {
        int y = panelY + panelHeight - 28;

        // Cancel sits first and is what Escape does: the safe answer should be the easy one.
        addRenderableWidget(Buttons.of(Component.literal("Cancel"), b -> onClose(), panelX + 10, y, 90, 20));
        addRenderableWidget(Buttons.of(Component.literal("Do it"), b -> {
            onConfirm.run();
            onClose();
        }, panelX + panelWidth - 100, y, 90, 20));
    }

    @Override
    protected void renderContents(Canvas gfx, int mouseX, int mouseY) {
        gfx.textWithWordWrap(font, Component.literal(question),
                panelX + 12, contentTop(), panelWidth - 24, TEXT);
        if (!detail.isEmpty()) {
            gfx.textWithWordWrap(font, Component.literal(detail),
                    panelX + 12, contentTop() + 24, panelWidth - 24, BAD);
        }
    }

    @Override
    protected String footerText() {
        return "This can be undone";
    }

    @Override
    public void onClose() {
        dev.buildmatic.client.BuildmaticClient.openScreen(
                net.minecraft.client.Minecraft.getInstance(), parent);
    }
}
