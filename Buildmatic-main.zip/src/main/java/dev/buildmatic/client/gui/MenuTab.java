package dev.buildmatic.client.gui;

import net.minecraft.client.gui.components.AbstractWidget;

import java.util.function.Consumer;

/**
 * One page of the main menu.
 *
 * <p>Tabs are plain objects rather than screens so switching between them costs nothing and the
 * world keeps rendering behind: changing a swap on the Swaps tab updates the preview that is
 * visible around the panel, which is the whole reason the menu does not pause the game.
 */
public interface MenuTab {

    /** Short label on the tab bar. */
    String title();

    /**
     * Called when the tab becomes visible.
     *
     * @param addWidget registers a button with the host screen; widgets are cleared on tab change
     */
    void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
              Consumer<AbstractWidget> addWidget);

    void render(Canvas gfx, int mouseX, int mouseY);

    /** One line for the footer: what is loaded, how many blocks, what is missing. */
    default String status() { return ""; }

    default boolean mouseClicked(double mouseX, double mouseY, boolean doubleClick) { return false; }

    default boolean mouseScrolled(double mouseX, double mouseY, double amount) { return false; }

    default boolean keyPressed(int key, int modifiers) { return false; }

    /** Called when something outside the tab changed what it displays. */
    default void refresh() {}
}
