package dev.buildmatic.client.gui;

import dev.buildmatic.core.schematic.SchematicFormat;
import dev.buildmatic.core.schematic.SchematicIo;
import dev.buildmatic.core.schematic.format.VanillaStructureFormat;
import dev.buildmatic.core.util.Vec3i;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;

/**
 * Asks what to call a capture and which container to write it into.
 *
 * <p>Saving used to take the selection's name and write a {@code .litematic} without asking, which
 * meant a second capture of the same area silently replaced the first. The name is editable here,
 * the target path is spelled out in the footer, and an existing file turns the button into
 * "Overwrite" rather than being discovered afterwards.
 *
 * <p>The format matters more than it looks. Litematica keeps every sub-region separately; the other
 * two describe one cuboid, so a sparse selection is flattened into its enclosing box and the gaps
 * become air. The notes under the picker say so for the selection actually being saved.
 */
public final class SaveSchematicScreen extends BuildmaticScreen {

    /** What to do once a name and a format have been chosen. */
    public interface Handler {
        void save(String name, SchematicFormat format);
    }

    /** Offered in this order: the one that keeps the most, then the two that travel best. */
    private static final SchematicFormat[] FORMATS = {
            SchematicFormat.LITEMATICA,
            SchematicFormat.SPONGE,
            SchematicFormat.VANILLA_STRUCTURE,
    };

    private static final String ILLEGAL = "\\/:*?\"<>|";

    /** Remembered between saves, like the menu remembers its tab: exports come in batches. */
    private static int lastFormat;

    private final Screen parent;
    private final Path directory;
    private final String initialName;
    /** Enabled sub-regions in the capture; more than one is what the flattening note is about. */
    private final int regions;
    private final Vec3i size;
    private final Handler handler;

    private EditBox nameBox;
    private Button formatButton;
    private Button saveButton;
    private int formatIndex = lastFormat;
    private String problem = "";
    private Path target;
    private boolean overwrite;

    public SaveSchematicScreen(Screen parent, Path directory, String initialName,
                               int regions, Vec3i size, Handler handler) {
        super(Component.literal("Save as schematic"));
        this.parent = parent;
        this.directory = directory;
        this.initialName = initialName == null ? "" : initialName;
        this.regions = regions;
        this.size = size;
        this.handler = handler;
    }

    @Override
    protected void init() {
        panelWidth = Math.min(width - MARGIN * 2, 360);
        panelHeight = Math.min(height - MARGIN * 2, 190);
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;
        initContents();
    }

    @Override
    protected void initContents() {
        String carried = nameBox == null ? initialName : nameBox.getValue();

        nameBox = new EditBox(font, panelX + 12, panelY + 52, panelWidth - 24, 18,
                Component.literal("File name"));
        nameBox.setMaxLength(64);
        nameBox.setValue(carried);
        nameBox.setResponder(value -> updateState());
        addRenderableWidget(nameBox);

        // The name is the only thing anyone wants to type here, so it starts focused.
        setFocused(nameBox);
        //? if >=1.19.4 {
        nameBox.setFocused(true);
        //?} else {
        /*nameBox.setFocus(true);
        *///?}

        formatButton = Buttons.of(Component.literal(""), b -> cycleFormat(),
                panelX + 12, panelY + 78, 180, 18);
        addRenderableWidget(formatButton);

        int buttonsY = panelY + 136;
        addRenderableWidget(Buttons.of(Component.literal("Cancel"), b -> onClose(),
                panelX + 12, buttonsY, 90, 20));
        saveButton = Buttons.of(Component.literal("Save"), b -> accept(),
                panelX + panelWidth - 102, buttonsY, 90, 20);
        addRenderableWidget(saveButton);

        updateState();
    }

    private SchematicFormat format() {
        return FORMATS[formatIndex];
    }

    private void cycleFormat() {
        formatIndex = (formatIndex + 1) % FORMATS.length;
        lastFormat = formatIndex;
        updateState();
    }

    /** Recomputes the target path, the warnings and what the buttons say. */
    private void updateState() {
        String name = nameBox == null ? "" : nameBox.getValue().trim();
        problem = "";
        target = null;

        if (name.isEmpty()) {
            problem = "Type a name for the file";
        } else if (containsIllegal(name)) {
            problem = "A file name cannot contain " + ILLEGAL;
        } else if (name.endsWith(".") || name.endsWith(" ")) {
            problem = "A file name cannot end with a dot or a space";
        } else {
            try {
                target = SchematicIo.withExtension(directory.resolve(name), format());
            } catch (InvalidPathException e) {
                problem = "That is not a usable file name";
            }
        }

        overwrite = target != null && Files.exists(target);

        if (formatButton != null) {
            formatButton.setMessage(Component.literal(
                    "Format: " + format().displayName() + "  (." + format().extension() + ")"));
        }
        if (saveButton != null) {
            saveButton.active = target != null;
            saveButton.setMessage(Component.literal(overwrite ? "Overwrite" : "Save"));
        }
    }

    private static boolean containsIllegal(String name) {
        for (int i = 0; i < name.length(); i++) {
            if (ILLEGAL.indexOf(name.charAt(i)) >= 0) return true;
        }
        return false;
    }

    /** What this format will do to the capture, in the terms the choice actually turns on. */
    private String formatNote() {
        switch (format()) {
            case SPONGE:
                return regions > 1
                        ? "WorldEdit and FAWE read this. The " + regions + " regions are merged into "
                        + "one box, so the gaps between them are stored as air."
                        : "WorldEdit and FAWE read this. One box, no sub-regions.";
            case VANILLA_STRUCTURE:
                String note = "Structure blocks and datapacks read this. One box, no sub-regions.";
                if (size != null && Math.max(size.x(), Math.max(size.y(), size.z()))
                        > VanillaStructureFormat.STRUCTURE_BLOCK_LIMIT) {
                    note += " This one is over "
                            + VanillaStructureFormat.STRUCTURE_BLOCK_LIMIT
                            + " blocks on a side, so a structure block will refuse to load it.";
                }
                return note;
            default:
                return regions > 1
                        ? "Keeps all " + regions + " regions separately, with entities and metadata. "
                        + "Litematica reads it too."
                        : "Keeps entities and metadata, and is what Litematica reads.";
        }
    }

    @Override
    protected void renderContents(Canvas gfx, int mouseX, int mouseY) {
        gfx.text(font, "File name", panelX + 12, contentTop(), TEXT_DIM);
        gfx.textWithWordWrap(font, Component.literal(formatNote()),
                panelX + 12, panelY + 102, panelWidth - 24, TEXT_DIM);
    }

    @Override
    protected String footerText() {
        if (!problem.isEmpty()) return problem;
        if (target == null) return "";
        String name = target.getFileName().toString();
        return overwrite ? "Replaces " + name : "Writes " + name;
    }

    @Override
    protected boolean onKey(int key, int modifiers) {
        // Enter is what anyone types after a name; the box itself ignores it.
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER
                || key == org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER) {
            accept();
            return true;
        }
        return false;
    }

    private void accept() {
        if (target == null) return;
        String name = nameBox.getValue().trim();
        SchematicFormat chosen = format();
        // Back to the menu before saving: reopening the parent re-initialises the tab, which
        // rewrites its status line - so a message set before that would never be seen.
        onClose();
        handler.save(name, chosen);
    }

    @Override
    public void onClose() {
        dev.buildmatic.client.BuildmaticClient.openScreen(
                net.minecraft.client.Minecraft.getInstance(), parent);
    }
}
