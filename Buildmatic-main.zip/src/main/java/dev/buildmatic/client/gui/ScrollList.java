package dev.buildmatic.client.gui;


import java.util.List;
import java.util.function.BiConsumer;

/**
 * A scrolling list of fixed-height rows.
 *
 * <p>Not a widget: the panels drive it directly, which keeps them free of the widget hierarchy's
 * focus and narration plumbing for what is really just a clipped column of text.
 *
 * @param <T> the row model
 */
public final class ScrollList<T> {

    /** Draws one row. Receives the row's top-left Y and whether the cursor is over it. */
    public interface RowRenderer<T> {
        void render(Canvas gfx, T item, int index, int x, int y, int width,
                    boolean hovered, boolean selected);
    }

    private final int rowHeight;
    private final RowRenderer<T> renderer;

    private List<T> items = List.of();
    private int x;
    private int y;
    private int width;
    private int height;

    private double scroll;
    private int selected = -1;
    private int hovered = -1;

    public ScrollList(int rowHeight, RowRenderer<T> renderer) {
        this.rowHeight = rowHeight;
        this.renderer = renderer;
    }

    public void setBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        clampScroll();
    }

    public void setItems(List<T> items) {
        this.items = items == null ? List.of() : items;
        if (selected >= this.items.size()) selected = -1;
        clampScroll();
    }

    public List<T> items() { return items; }

    /** Y of the first row, so a caller can put column headings just above the list. */
    public int itemsTop() { return y; }

    public int selectedIndex() { return selected; }

    public T selectedItem() {
        return selected >= 0 && selected < items.size() ? items.get(selected) : null;
    }

    public void select(int index) {
        selected = index >= 0 && index < items.size() ? index : -1;
    }

    /** Scrolls so the selected row is on screen; used when the selection moves by keyboard. */
    public void scrollToSelected() {
        if (selected < 0) return;
        int top = selected * rowHeight;
        if (top < scroll) scroll = top;
        else if (top + rowHeight > scroll + height) scroll = top + rowHeight - height;
        clampScroll();
    }

    public void render(Canvas gfx, int mouseX, int mouseY) {
        hovered = indexAt(mouseX, mouseY);

        gfx.enableScissor(x, y, x + width, y + height);
        int first = Math.max(0, (int) (scroll / rowHeight));
        int last = Math.min(items.size(), first + height / rowHeight + 2);

        for (int i = first; i < last; i++) {
            int rowY = y + (int) (i * rowHeight - scroll);
            if (i % 2 == 1) {
                gfx.fill(x, rowY, x + width, rowY + rowHeight, BuildmaticScreen.ROW_ODD);
            }
            if (i == selected) {
                gfx.fill(x, rowY, x + width, rowY + rowHeight, BuildmaticScreen.ROW_SELECTED);
            } else if (i == hovered) {
                gfx.fill(x, rowY, x + width, rowY + rowHeight, BuildmaticScreen.ROW_HOVER);
            }
            renderer.render(gfx, items.get(i), i, x, rowY, width, i == hovered, i == selected);
        }
        gfx.disableScissor();

        renderScrollbar(gfx);
    }

    private void renderScrollbar(Canvas gfx) {
        int contentHeight = items.size() * rowHeight;
        if (contentHeight <= height) return;

        int trackX = x + width - 3;
        gfx.fill(trackX, y, trackX + 3, y + height, 0x40000000);

        int thumbHeight = Math.max(16, height * height / contentHeight);
        int travel = height - thumbHeight;
        int thumbY = y + (int) (scroll / (contentHeight - height) * travel);
        gfx.fill(trackX, thumbY, trackX + 3, thumbY + thumbHeight, BuildmaticScreen.PANEL_BORDER);
    }

    /** Returns the clicked index, or -1. */
    public int mouseClicked(double mouseX, double mouseY) {
        int index = indexAt((int) mouseX, (int) mouseY);
        if (index >= 0) selected = index;
        return index;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!contains((int) mouseX, (int) mouseY)) return false;
        scroll -= amount * rowHeight * 3;
        clampScroll();
        return true;
    }

    /** Moves the selection by {@code delta}, wrapping, and keeps it visible. */
    public void moveSelection(int delta, BiConsumer<Integer, T> onChange) {
        if (items.isEmpty()) return;
        int next = Math.floorMod((selected < 0 ? -1 : selected) + delta, items.size());
        selected = next;
        scrollToSelected();
        if (onChange != null) onChange.accept(next, items.get(next));
    }

    private int indexAt(int mouseX, int mouseY) {
        if (!contains(mouseX, mouseY)) return -1;
        int index = (int) ((mouseY - y + scroll) / rowHeight);
        return index >= 0 && index < items.size() ? index : -1;
    }

    private boolean contains(int mouseX, int mouseY) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    private void clampScroll() {
        double max = Math.max(0, items.size() * rowHeight - height);
        scroll = Math.max(0, Math.min(scroll, max));
    }
}
