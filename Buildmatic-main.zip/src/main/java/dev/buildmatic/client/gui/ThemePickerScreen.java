package dev.buildmatic.client.gui;

import dev.buildmatic.client.BuildmaticClient;
import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.core.swap.SwapLayer;
import dev.buildmatic.core.swap.SwapRule;
import dev.buildmatic.core.theme.BuildTheme;
import dev.buildmatic.core.theme.BuildThemes;
import dev.buildmatic.core.theme.StyleMaterial;
import dev.buildmatic.core.theme.StyleRole;
import dev.buildmatic.core.theme.ThemeReport;
import dev.buildmatic.core.theme.ThemeVariant;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Re-dresses the whole build in one click.
 *
 * <p>The variant picker changes one block at a time; this changes the palette of an entire
 * schematic - every stone tone, every wood, every roof - while leaving its shape alone. Selecting a
 * row applies it straight away, so the preview behind the panel is the answer to "what would this
 * look like in cobblestone" rather than a description of it.
 *
 * <p>Up and down choose the theme, left and right the combination within it: a cobblestone keep and
 * a mossy ruin are both medieval and share none of their blocks, so the theme is the intent and the
 * combination is the answer. Combinations the running version has no blocks for are not offered.
 *
 * <p>A theme is one ordinary swap layer. It can be switched off on the Swaps tab or undone with
 * Ctrl+Z, and picking another one replaces it rather than stacking, because two themes chain into
 * each other and land somewhere neither of them describes.
 */
public final class ThemePickerScreen extends BuildmaticScreen {

    private static final int ROW = 28;

    /** The tones shown as a swatch strip on each row, left to right. */
    private static final List<StyleRole> SWATCH_ROLES = List.of(
            StyleRole.STONE_PLAIN, StyleRole.STONE_ROUGH, StyleRole.STONE_REFINED,
            StyleRole.STONE_DARK, StyleRole.WOOD_LIGHT, StyleRole.WOOD_DARK);

    /** How many of the theme's dye colours are shown next to its materials. */
    private static final int SWATCH_COLOURS = 4;

    private static final int SWATCH_WIDTH = SWATCH_ROLES.size() * 18 + 8 + SWATCH_COLOURS * 18;

    /**
     * How much of the swatch strip a row of this width can afford.
     *
     * <p>A fullscreen window at a high GUI scale leaves a few hundred virtual pixels, and a fixed
     * 188-pixel strip would eat the description whole. The colours go first, then the materials:
     * both are a nicety next to knowing which theme the row is.
     */
    private int swatchWidth(int rowWidth) {
        if (rowWidth >= 460) return SWATCH_WIDTH;
        if (rowWidth >= 360) return SWATCH_ROLES.size() * 18;
        return 0;
    }

    private final ScrollList<BuildTheme> list = new ScrollList<>(ROW, this::renderRow);

    /** Replaced on every selection change, so browsing does not fill the stack with discards. */
    private SwapLayer previewLayer;
    private ThemeReport report;

    /** Which combination of the selected theme is showing, within its available ones. */
    private int combination;
    private BuildTheme lastTheme;

    /**
     * What each theme would do to the open schematic, by theme id.
     *
     * <p>Worked out once when the panel opens and again when a combination changes. It is the
     * answer to the only question the list cannot otherwise show: a theme that comes out looking
     * unchanged has usually met a build already in its own palette, and the count says so.
     */
    private final Map<String, ThemeReport> coverage = new HashMap<>();

    private Button combinationButton;

    /** Height of the summary line that sits between the list and the buttons. */
    private static final int SUMMARY_HEIGHT = 14;

    public ThemePickerScreen() {
        super(Component.literal("Buildmatic - Themes"));
    }

    // Wider and taller than the other panels: seven rows of two lines each, with a swatch strip on
    // the right that must not squeeze the descriptions into ellipses.
    @Override
    protected int preferredWidth() { return 580; }

    @Override
    protected int preferredHeight() { return 340; }

    @Override
    protected void initContents() {
        int buttonsY = panelY + panelHeight - 24;
        addRenderableWidget(Buttons.of(Component.literal("Remove"), b -> clearPreview(), panelX + 8, buttonsY, 60, 18));
        combinationButton = addRenderableWidget(
                Buttons.of(Component.literal(""), b -> cycleCombination(1), panelX + 72, buttonsY, 150, 18));

        // The footer band belongs to the buttons, so the summary gets its own line above them.
        list.setBounds(panelX + 8, contentTop(), panelWidth - 16,
                contentHeight() - SUMMARY_HEIGHT);
        list.setItems(BuildThemes.all());
        adoptExistingTheme();
        measureCoverage();
        updateCombinationButton();
    }

    /** Counts what each theme would change, using the combination that would be applied. */
    private void measureCoverage() {
        BuildmaticSession session = session();
        BuildmaticSession.OpenSchematic open = session == null ? null : session.active();
        if (open == null) return;

        for (BuildTheme theme : BuildThemes.all()) {
            coverage.put(theme.id(),
                    ThemeReport.of(shownVariant(theme), open.schematic(), session.variants()));
        }
    }

    /**
     * Reopens on whichever theme and combination the build is already wearing.
     *
     * <p>Without this the panel starts blank and the next pick lands on top of the old theme rather
     * than in place of it - and two themes stacked chain into each other, so the build ends up in a
     * palette neither of them describes.
     */
    private void adoptExistingTheme() {
        BuildmaticSession session = session();
        BuildmaticSession.OpenSchematic open = session == null ? null : session.active();
        if (open == null) return;

        List<SwapLayer> layers = open.swaps().layers();
        for (int i = layers.size() - 1; i >= 0; i--) {
            SwapRule.Target.Themed themed = themeOf(layers.get(i));
            if (themed == null) continue;

            previewLayer = layers.get(i);
            lastTheme = themed.theme();
            list.select(BuildThemes.all().indexOf(themed.theme()));
            combination = Math.max(0, available(themed.theme()).indexOf(themed.variant()));
            report = ThemeReport.of(themed.variant(), open.schematic(), session.variants());
            return;
        }
    }

    /** The theme rule a layer applies, or null when it is an ordinary swap. */
    private static SwapRule.Target.Themed themeOf(SwapLayer layer) {
        for (SwapRule rule : layer.rules()) {
            if (rule.target() instanceof SwapRule.Target.Themed themed) return themed;
        }
        return null;
    }

    // --- combinations -----------------------------------------------------------------------------

    /**
     * The combinations this game version can build.
     *
     * <p>Filtered against the running block registry, so a combination resting on cherry wood or
     * the tuff family is simply absent on a version that predates them rather than offered and
     * doing nothing.
     */
    private List<ThemeVariant> available(BuildTheme theme) {
        BuildmaticSession session = session();
        return session == null ? theme.variants() : theme.availableVariants(session.variants());
    }

    private ThemeVariant shownVariant(BuildTheme theme) {
        List<ThemeVariant> variants = available(theme);
        if (variants.isEmpty()) return theme.defaultVariant();
        if (theme != list.selectedItem()) return variants.get(0);
        return variants.get(Math.floorMod(combination, variants.size()));
    }

    private void cycleCombination(int delta) {
        if (list.selectedItem() == null) {
            list.select(0);
            combination = 0;
        } else {
            combination += delta;
        }
        applySelection();
    }

    private void updateCombinationButton() {
        BuildTheme theme = list.selectedItem();
        if (theme == null) {
            combinationButton.setMessage(Component.literal("Combination"));
            combinationButton.active = false;
            return;
        }

        List<ThemeVariant> variants = available(theme);
        int index = variants.isEmpty() ? 0 : Math.floorMod(combination, variants.size());
        combinationButton.active = variants.size() > 1;
        combinationButton.setMessage(Component.literal(variants.isEmpty()
                ? "No combination"
                : (index + 1) + "/" + variants.size() + "  " + variants.get(index).displayName()));
    }

    // --- applying ---------------------------------------------------------------------------------

    private void applySelection() {
        BuildTheme theme = list.selectedItem();
        BuildmaticSession session = session();
        if (theme == null || session == null) return;

        BuildmaticSession.OpenSchematic open = session.active();
        if (open == null) return;

        // Moving to another theme starts at its first combination rather than carrying an index
        // across, which would land on an unrelated look.
        if (theme != lastTheme) {
            combination = 0;
            lastTheme = theme;
        }

        List<ThemeVariant> variants = available(theme);
        if (variants.isEmpty()) return;
        combination = Math.floorMod(combination, variants.size());
        ThemeVariant variant = variants.get(combination);

        // A build wears one theme. Any other theme layer goes, because they chain: mesa under
        // ancient under desert is three restyles of a restyle, not the desert palette.
        for (SwapLayer layer : List.copyOf(open.swaps().layers())) {
            if (layer != previewLayer && themeOf(layer) != null) session.discardSwap(layer);
        }

        // Replaces the previous preview outright, undo entry included, so trying every theme and
        // every combination still costs one Ctrl+Z.
        previewLayer = session.replaceSwap(previewLayer, label(theme, variant),
                SwapRule.of(new SwapRule.Matcher.Any(),
                        new SwapRule.Target.Themed(theme, variant)));
        report = ThemeReport.of(variant, open.schematic(), session.variants());
        coverage.put(theme.id(), report);
        updateCombinationButton();
    }

    private static String label(BuildTheme theme, ThemeVariant variant) {
        return theme.displayName() + " theme"
                + (variant.equals(theme.defaultVariant()) ? "" : " (" + variant.displayName() + ")");
    }

    /** Drops the theme again, for comparing it against the build as it was. */
    private void clearPreview() {
        BuildmaticSession session = session();
        BuildmaticSession.OpenSchematic open = session == null ? null : session.active();
        if (open == null || previewLayer == null) return;

        session.discardSwap(previewLayer);
        previewLayer = null;
        report = null;
        lastTheme = null;
        combination = 0;
        list.select(-1);
        updateCombinationButton();
    }

    // --- rendering --------------------------------------------------------------------------------

    private void renderRow(Canvas gfx, BuildTheme theme, int index, int x, int y,
                           int width, boolean hovered, boolean selected) {
        gfx.text(font, theme.displayName(), x + 6, y + 3, selected ? ACCENT : TEXT);

        // The combination, named rather than numbered, with the keys that walk it spelled out on
        // the row it applies to: a control nobody can see is a control nobody uses.
        List<ThemeVariant> variants = available(theme);
        int nameEnd = x + 12 + font.width(theme.displayName());
        if (selected && variants.size() > 1) {
            int index0 = Math.floorMod(combination, variants.size());
            gfx.text(font, "< " + variants.get(index0).displayName() + " >", nameEnd, y + 3, ACCENT);
        } else if (variants.size() > 1) {
            gfx.text(font, variants.size() + " combinations", nameEnd, y + 3, TEXT_DIM);
        }

        int swatches = swatchWidth(width);
        String changes = coverageLabel(theme);
        int changesWidth = changes.isEmpty() ? 0 : font.width(changes) + 10;
        gfx.text(font, fit(theme.description(), width - swatches - changesWidth - 24),
                x + 6, y + 15, TEXT_DIM);
        if (!changes.isEmpty()) {
            gfx.text(font, changes, x + width - swatches - changesWidth - 8, y + 15,
                    selected ? TEXT : TEXT_DIM);
        }

        if (swatches > 0) {
            renderSwatches(gfx, shownVariant(theme), x + width - 8 - swatches, y + 4, swatches);
        }
    }

    /** How much of the open build this theme would actually touch. */
    private String coverageLabel(BuildTheme theme) {
        ThemeReport measured = coverage.get(theme.id());
        if (measured == null || measured.totalTypes() == 0) return "";
        return measured.restyledTypes() + "/" + measured.totalTypes() + " types";
    }

    /**
     * The combination's palette as the blocks themselves: its tones, then the dyes it keeps.
     *
     * <p>Item icons say more about a palette than material names do, and they are the same blocks
     * the swap will actually place - so cycling combinations on the selected row shows the change
     * before it is applied. The colours shown are the last few of the list, which is where a
     * palette's character sits: they all start with the same white-to-black ramp.
     */
    private void renderSwatches(Canvas gfx, ThemeVariant variant, int x, int y, int room) {
        var platform = BuildmaticClient.platform();
        if (platform == null) return;

        int drawn = 0;
        for (StyleRole role : SWATCH_ROLES) {
            StyleMaterial material = variant.materialFor(role);
            if (material == null) continue;
            gfx.item(platform.schema().icon(material.block()), x + drawn * 18, y);
            drawn++;
        }

        // The colours are the first thing dropped when the row is narrow.
        if (room < SWATCH_WIDTH) return;

        List<String> colours = variant.colours();
        int first = Math.max(0, colours.size() - SWATCH_COLOURS);
        int colourX = x + SWATCH_ROLES.size() * 18 + 8;
        for (int i = first; i < colours.size(); i++) {
            gfx.item(platform.schema().icon("minecraft:" + colours.get(i) + "_wool"),
                    colourX + (i - first) * 18, y);
        }
    }

    @Override
    protected void renderContents(Canvas gfx, int mouseX, int mouseY) {
        list.render(gfx, mouseX, mouseY);
        gfx.text(font, fit(summary(), panelWidth - 20), panelX + 10,
                contentBottom() - SUMMARY_HEIGHT + 3, TEXT_DIM);
    }

    /**
     * Where the blocks went, in words.
     *
     * <p>Drawn above the buttons rather than in the footer, which they occupy. A theme that looks
     * like it did nothing has usually met a build already in its own palette, and saying so is the
     * difference between a bug and an answer.
     */
    private String summary() {
        BuildmaticSession session = session();
        if (session == null || session.active() == null) return "No schematic is open";
        if (report == null) {
            return "Click a theme to try it on   -   left and right for other combinations";
        }

        StringBuilder summary = new StringBuilder();
        summary.append(report.restyledTypes()).append(" of ").append(report.totalTypes())
                .append(" block types restyled");
        if (report.guardedTypes() > 0) {
            summary.append("   -   ").append(report.guardedTypes()).append(" mechanisms kept");
        }
        if (report.keptTypes() > 0) {
            summary.append("   -   ").append(report.keptTypes())
                    .append(" already right or not building blocks");
        }
        return summary.toString();
    }

    @Override
    protected String footerText() {
        return "";
    }

    // --- input ------------------------------------------------------------------------------------

    @Override
    protected boolean onClick(double x, double y, int button, boolean doubled) {
        if (list.mouseClicked(x, y) >= 0) {
            applySelection();
            if (doubled) onClose();
            return true;
        }
        return false;
    }

    @Override
    protected boolean onScroll(double x, double y, double amount) {
        return list.mouseScrolled(x, y, amount);
    }

    @Override
    protected boolean onKey(int key, int modifiers) {
        switch (key) {
            case org.lwjgl.glfw.GLFW.GLFW_KEY_DOWN -> {
                list.moveSelection(1, (i, t) -> applySelection());
                return true;
            }
            case org.lwjgl.glfw.GLFW.GLFW_KEY_UP -> {
                list.moveSelection(-1, (i, t) -> applySelection());
                return true;
            }
            case org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT -> {
                cycleCombination(1);
                return true;
            }
            case org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT -> {
                cycleCombination(-1);
                return true;
            }
            case org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER, org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER -> {
                onClose();
                return true;
            }
            default -> {
                return false;
            }
        }
    }
}
