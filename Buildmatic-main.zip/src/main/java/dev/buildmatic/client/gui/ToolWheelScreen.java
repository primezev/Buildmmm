package dev.buildmatic.client.gui;

import dev.buildmatic.client.BuildmaticClient;
import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.core.tool.ToolMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The tool's mode picker, as a ring around the crosshair.
 *
 * <p>Nine modes on a keyboard cycle means pressing a key eight times to go back one. A ring turns
 * that into a flick of the mouse: every mode is one gesture away and the choice is visible rather
 * than remembered.
 *
 * <p>Modes that would need creative are left out entirely in survival, so the ring only ever offers
 * things that will work.
 */
public final class ToolWheelScreen extends Screen {

    private static final int BACKDROP = 0x90000000;
    private static final int SLICE = 0xC0202028;
    private static final int SLICE_HOVER = 0xF04FC3F7;
    private static final int RING_TEXT = 0xFFE6E6E6;

    /** The centre panel the hint sits in; the ring is always kept clear of it. */
    private static final int PANEL_WIDTH = 176;
    private static final int PANEL_HEIGHT = 46;
    private static final int LABEL_HEIGHT = 18;

    /** Ring radii, worked out from the screen and the labels in {@link #init}. */
    private double radiusX;
    private double radiusY;
    private int[] labelWidths;

    private final List<ToolMode> modes = new ArrayList<>();
    private int hovered = -1;

    public ToolWheelScreen(boolean creative) {
        super(Component.literal("Buildmatic tool"));
        for (ToolMode mode : ToolMode.values()) {
            if (creative || !mode.isCreativeOnly()) modes.add(mode);
        }
    }

    public static ToolWheelScreen create() {
        Minecraft client = Minecraft.getInstance();
        boolean creative = client.player != null && client.player.isCreative();
        return new ToolWheelScreen(creative);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /**
     * Maps the cursor onto a slice.
     *
     * <p>Slot zero sits at the top and they run clockwise, matching the way the ring is drawn.
     */
    private void updateHover(int mouseX, int mouseY) {
        if (modes.isEmpty()) {
            hovered = -1;
            return;
        }

        double dx = mouseX - width / 2.0;
        double dy = mouseY - height / 2.0;

        // The dead zone is the centre panel itself, so resting on the hint never selects anything.
        if (Math.abs(dx) < PANEL_WIDTH / 2.0 && Math.abs(dy) < PANEL_HEIGHT / 2.0) {
            hovered = -1;
            return;
        }

        // The ring is an ellipse, so the angle has to be taken in circle space or the labels near
        // the sides would answer to the wrong slice.
        double angle = Math.atan2(dx / radiusX, -dy / radiusY);
        if (angle < 0) angle += Math.PI * 2;

        double slice = Math.PI * 2 / modes.size();
        hovered = (int) Math.floor((angle + slice / 2) / slice) % modes.size();
    }

    /**
     * Sizes the ring to the screen and to the labels actually on it.
     *
     * <p>A fixed radius and a fixed label width cannot work: nine labels of 116 pixels need 1044
     * pixels of circumference and a radius of 118 only provides 741, so they overlapped by a third.
     * Labels are measured instead of padded to a constant, and the ring is an ellipse because
     * screens are wider than they are tall - which is exactly where the spare room is.
     */
    @Override
    protected void init() {
        labelWidths = new int[modes.size()];
        int widest = 0;
        for (int i = 0; i < modes.size(); i++) {
            labelWidths[i] = font.width(modes.get(i).displayName()) + 12;
            widest = Math.max(widest, labelWidths[i]);
        }

        // Push out far enough that the labels clear the centre panel, then as far as the screen
        // allows, so a crowded ring uses every pixel available before it starts to collide.
        double minX = PANEL_WIDTH / 2.0 + widest / 2.0 + 8;
        double minY = PANEL_HEIGHT / 2.0 + LABEL_HEIGHT + 6;
        radiusX = Math.max(minX, width / 2.0 - widest / 2.0 - 6);
        radiusY = Math.max(minY, height / 2.0 - LABEL_HEIGHT - 10);
    }

    // See BuildmaticScreen: 26.1 collects render state, older versions draw immediately.
    //? if >=26.1 {
    @Override
    public void extractRenderState(net.minecraft.client.gui.GuiGraphicsExtractor gfx, int mouseX,
                                   int mouseY, float partialTick) {
        paint(new Canvas(gfx), mouseX, mouseY);
    }
    //?} elif >=1.20 {
    /*@Override
    public void render(net.minecraft.client.gui.GuiGraphics gfx, int mouseX, int mouseY,
                       float partialTick) {
        paint(new Canvas(gfx), mouseX, mouseY);
    }
    *///?} else {
    /*@Override
    public void render(com.mojang.blaze3d.vertex.PoseStack pose, int mouseX, int mouseY,
                       float partialTick) {
        paint(new Canvas(pose), mouseX, mouseY);
    }
    *///?}

    private void paint(Canvas gfx, int mouseX, int mouseY) {
        updateHover(mouseX, mouseY);

        gfx.fill(0, 0, width, height, BACKDROP);

        int centreX = width / 2;
        int centreY = height / 2;

        drawCentrePanel(gfx, centreX, centreY);

        for (int i = 0; i < modes.size(); i++) {
            double angle = angleOf(i);
            int x = centreX + (int) Math.round(Math.sin(angle) * radiusX);
            int y = centreY - (int) Math.round(Math.cos(angle) * radiusY);
            drawLabel(gfx, modes.get(i), labelWidths[i], x, y, i == hovered);
        }
    }

    private double angleOf(int index) {
        return (Math.PI * 2 / modes.size()) * index;
    }

    private void drawLabel(Canvas gfx, ToolMode mode, int labelWidth,
                           int x, int y, boolean active) {
        // Clamped so a label on the far left or right cannot run off the edge of the screen.
        int left = Math.max(2, Math.min(x - labelWidth / 2, width - labelWidth - 2));
        int top = y - LABEL_HEIGHT / 2;

        gfx.fill(left, top, left + labelWidth, top + LABEL_HEIGHT, active ? SLICE_HOVER : SLICE);
        gfx.outline(left, top, labelWidth, LABEL_HEIGHT,
                active ? SLICE_HOVER : BuildmaticScreen.PANEL_BORDER);
        gfx.centeredText(font, mode.displayName(), left + labelWidth / 2, y - 4,
                active ? 0xFF0B0B0F : RING_TEXT);
    }

    /**
     * The middle of the ring: what is highlighted, and what its buttons do.
     *
     * <p>Boxed and word-wrapped on purpose. Loose centred text over the world runs into the ring
     * labels and becomes unreadable the moment the hint is longer than a few words.
     */
    private void drawCentrePanel(Canvas gfx, int centreX, int centreY) {
        ToolMode selected = hovered >= 0 ? modes.get(hovered) : null;

        int left = centreX - PANEL_WIDTH / 2;
        int top = centreY - PANEL_HEIGHT / 2;
        gfx.fill(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, BuildmaticScreen.PANEL_BACKGROUND);
        gfx.outline(left, top, PANEL_WIDTH, PANEL_HEIGHT, BuildmaticScreen.PANEL_BORDER);

        if (selected == null) {
            gfx.centeredText(font, "Point at a mode", centreX, top + 12, BuildmaticScreen.TEXT_DIM);
            gfx.centeredText(font, "release to choose", centreX, top + 26,
                    BuildmaticScreen.TEXT_DIM);
            return;
        }

        gfx.centeredText(font, selected.displayName(), centreX, top + 7, BuildmaticScreen.ACCENT);
        gfx.textWithWordWrap(font, net.minecraft.network.chat.Component.literal(selected.hint()),
                left + 8, top + 21, PANEL_WIDTH - 16, BuildmaticScreen.TEXT_DIM);
    }

    private ToolMode currentMode() {
        BuildmaticSession session = BuildmaticClient.session();
        return session == null ? null : session.tool().mode();
    }

    /** Applies the highlighted mode. Called when the key that opened the ring is let go. */
    public void confirm() {
        BuildmaticSession session = BuildmaticClient.session();
        Minecraft client = Minecraft.getInstance();

        if (session != null && hovered >= 0 && hovered < modes.size()) {
            ToolMode mode = modes.get(hovered);
            session.tool().setMode(mode);
            BuildmaticClient.actionBar(client, mode.displayName() + "   -   " + mode.hint());
        }
        onClose();
    }

    // The wheel sits on Screen rather than BuildmaticScreen, so it carries its own copy of the
    // bridge: 26.1 wraps clicks and keys in records, every earlier version passes them loose.
    //? if >=1.21.9 {
    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
        return click(event.x(), event.y());
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (event.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }
    //?} else {
    /*@Override
    public boolean mouseClicked(double x, double y, int button) {
        return click(x, y);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }
    *///?}

    private boolean click(double x, double y) {
        updateHover((int) x, (int) y);
        confirm();
        return true;
    }
}
