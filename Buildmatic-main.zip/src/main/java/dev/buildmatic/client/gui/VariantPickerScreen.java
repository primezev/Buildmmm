package dev.buildmatic.client.gui;

import dev.buildmatic.client.BuildmaticClient;
import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.render.GhostRaycast;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapLayer;
import dev.buildmatic.core.swap.SwapRule;
import dev.buildmatic.core.swap.SwapScopes;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * The variant picker: every block that could stand in for the one under the crosshair.
 *
 * <p>Selecting a row applies the swap immediately as a layer, so the ghost behind the panel changes
 * while the list is still open and choosing is a matter of looking rather than guessing. Closing
 * keeps whatever is selected; undo removes it.
 */
public final class VariantPickerScreen extends BuildmaticScreen {

    private final SchematicRegion region;
    private final Vec3i localPos;
    private final BlockStateRef original;

    private final ScrollList<VariantIndex.Candidate> list;

    private VariantIndex.Axis axis = VariantIndex.Axis.MATERIAL;
    private SwapScopes.Strictness strictness = SwapScopes.Strictness.SAME_BLOCK;
    private boolean familiesOnly;
    private boolean floodFill;

    /** Replaced on every selection change so the stack does not fill with discarded previews. */
    private SwapLayer previewLayer;

    private Button axisButton;
    private Button scopeButton;
    private Button familyButton;

    private VariantPickerScreen(SchematicRegion region, Vec3i localPos, BlockStateRef original) {
        super(Component.literal("Buildmatic - Variants"));
        this.region = region;
        this.localPos = localPos;
        this.original = original;
        this.list = new ScrollList<>(ROW_HEIGHT, this::renderRow);
        // Without a clicked position there is nothing to scope a single-block swap to, so the
        // narrowest sensible default becomes "every block like this one".
        if (region == null) this.strictness = SwapScopes.Strictness.SAME_BLOCK;
    }

    /** Opens on whatever ghost block the player is looking at, or returns null when none. */
    public static VariantPickerScreen forTargetedBlock() {
        GhostRaycast.Hit hit = BuildmaticClient.target(net.minecraft.client.Minecraft.getInstance());
        if (hit == null) return null;
        return new VariantPickerScreen(hit.region(), hit.localPos(), hit.state());
    }

    /**
     * Opens on a block chosen from a list rather than pointed at in the world.
     *
     * <p>This is how the material list converts a material: pick the row, pick the replacement, and
     * every block of that kind in the build changes at once - no hunting for one to click.
     */
    public static VariantPickerScreen forBlock(BlockStateRef state) {
        return new VariantPickerScreen(null, null, state);
    }

    /** True when the picker was opened from a list and has no single block to scope to. */
    private boolean isPositionless() { return region == null; }

    @Override
    protected void initContents() {
        int buttonsY = panelY + HEADER_HEIGHT - 26;
        axisButton = addRenderableWidget(Buttons.of(Component.literal(""), b -> toggleAxis(), panelX + panelWidth - 296, buttonsY, 96, 16));
        scopeButton = addRenderableWidget(Buttons.of(Component.literal(""), b -> cycleScope(), panelX + panelWidth - 196, buttonsY, 110, 16));
        familyButton = addRenderableWidget(Buttons.of(Component.literal(""), b -> toggleFamily(), panelX + panelWidth - 82, buttonsY, 72, 16));
        updateButtonLabels();

        list.setBounds(panelX + 8, contentTop(), panelWidth - 16, contentHeight());
        refresh();
    }

    private void toggleAxis() {
        axis = axis == VariantIndex.Axis.MATERIAL
                ? VariantIndex.Axis.SHAPE
                : VariantIndex.Axis.MATERIAL;
        updateButtonLabels();
        refresh();
    }

    private void cycleScope() {
        // Opened from a list there is no clicked block, so the two position-bound scopes are out.
        if (isPositionless()) {
            strictness = strictness == SwapScopes.Strictness.SAME_BLOCK
                    ? SwapScopes.Strictness.SAME_MATERIAL
                    : SwapScopes.Strictness.SAME_BLOCK;
            updateButtonLabels();
            applySelection();
            return;
        }

        // Four steps rather than three: flood fill is a scope in its own right to the user.
        if (floodFill) {
            floodFill = false;
            strictness = SwapScopes.Strictness.EXACT_STATE;
        } else if (strictness == SwapScopes.Strictness.EXACT_STATE) {
            strictness = SwapScopes.Strictness.SAME_BLOCK;
        } else if (strictness == SwapScopes.Strictness.SAME_BLOCK) {
            strictness = SwapScopes.Strictness.SAME_MATERIAL;
        } else {
            strictness = SwapScopes.Strictness.SAME_BLOCK;
            floodFill = true;
        }
        updateButtonLabels();
        applySelection();
    }

    private void toggleFamily() {
        familiesOnly = !familiesOnly;
        updateButtonLabels();
        refresh();
    }

    private void updateButtonLabels() {
        axisButton.setMessage(Component.literal(
                axis == VariantIndex.Axis.MATERIAL ? "Other materials" : "Other shapes"));
        scopeButton.setMessage(Component.literal(scopeLabel()));
        familyButton.setMessage(Component.literal(familiesOnly ? "Family only" : "Everything"));
    }

    private String scopeLabel() {
        if (floodFill) return "Connected";
        return switch (strictness) {
            case EXACT_STATE -> "This block";
            case SAME_BLOCK -> "All identical";
            case SAME_MATERIAL -> "Whole material";
        };
    }

    private void refresh() {
        BuildmaticSession session = session();
        if (session == null) return;

        VariantIndex.Query query = new VariantIndex.Query(
                axis, "", original.namespace(), familiesOnly, 512);
        list.setItems(session.variants().candidates(original.blockId(), query));
    }

    // --- applying ---------------------------------------------------------------------------------

    /**
     * Applies the highlighted candidate, replacing any previous preview.
     *
     * <p>This is what makes the panel feel direct: the schematic, the ghost and the material list
     * are already updated by the time the eye moves back to the world.
     */
    private void applySelection() {
        VariantIndex.Candidate candidate = list.selectedItem();
        BuildmaticSession session = session();
        if (candidate == null || session == null) return;

        if (session.active() == null) return;

        // The previous preview is replaced rather than stacked on, undo entry included: walking the
        // list with the arrow keys must not cost one Ctrl+Z per row visited.
        previewLayer = session.replaceSwap(previewLayer, label(candidate), buildRule(candidate));
    }

    private SwapRule buildRule(VariantIndex.Candidate candidate) {
        SwapRule.Target target = new SwapRule.Target.Block(candidate.kind().blockId());
        BuildmaticSession session = session();

        if (isPositionless()) {
            if (strictness == SwapScopes.Strictness.SAME_MATERIAL) {
                VariantIndex.BlockKind from = session.variants().kindOf(original.blockId());
                if (from != null) {
                    return new SwapRule(new SwapRule.Matcher.Material(from.material()),
                            new SwapRule.Target.Material(candidate.kind().material()),
                            SwapScopes.everywhere());
                }
            }
            return new SwapRule(new SwapRule.Matcher.Block(original.blockId()), target,
                    SwapScopes.everywhere());
        }

        if (floodFill) {
            var flood = SwapScopes.flood(region, localPos, strictness, session.variants());
            return new SwapRule(new SwapRule.Matcher.Any(), target,
                    new SwapRule.Scope.Positions(region.name(), flood.positions()));
        }

        return switch (strictness) {
            case EXACT_STATE -> new SwapRule(new SwapRule.Matcher.Any(), target,
                    SwapScopes.single(region, localPos));
            case SAME_BLOCK -> new SwapRule(new SwapRule.Matcher.Block(original.blockId()),
                    target, SwapScopes.everywhere());
            case SAME_MATERIAL -> {
                VariantIndex.BlockKind from = session.variants().kindOf(original.blockId());
                // Material to material, so every shape follows rather than collapsing into one block.
                yield from == null
                        ? new SwapRule(new SwapRule.Matcher.Block(original.blockId()), target,
                        SwapScopes.everywhere())
                        : new SwapRule(new SwapRule.Matcher.Material(from.material()),
                        new SwapRule.Target.Material(candidate.kind().material()),
                        SwapScopes.everywhere());
            }
        };
    }

    private String label(VariantIndex.Candidate candidate) {
        return original.path() + " -> " + candidate.kind().blockId() + "  (" + scopeLabel() + ")";
    }

    // --- rendering --------------------------------------------------------------------------------

    private void renderRow(Canvas gfx, VariantIndex.Candidate candidate, int index,
                           int x, int y, int width, boolean hovered, boolean selected) {
        String blockId = candidate.kind().blockId();
        var schema = dev.buildmatic.client.BuildmaticClient.platform() == null
                ? null : dev.buildmatic.client.BuildmaticClient.platform().schema();

        // The block's own icon and translated name: far quicker to scan than a column of ids.
        if (schema != null) {
            gfx.item(schema.icon(blockId), x + 2, y);
            gfx.text(font, schema.displayName(blockId), x + 22, y + 5, TEXT);
        } else {
            gfx.text(font, fit(blockId, 200), x + 22, y + 5, TEXT);
        }

        if (candidate.sameFamily()) {
            gfx.text(font, "same family", x + 210, y + 5, ACCENT);
        }
        gfx.text(font, candidate.kind().shape().displayName(), x + width - 90, y + 5, TEXT_DIM);
    }

    @Override
    protected void renderContents(Canvas gfx, int mouseX, int mouseY) {
        renderSubject(gfx);
        list.render(gfx, mouseX, mouseY);
    }

    /**
     * Says what is being changed, in words.
     *
     * <p>The raw descriptor - {@code minecraft:glass_pane[east=true,...]} - is both unreadable and
     * too long for the header, so it was arriving truncated mid-word. The icon carries the identity
     * at a glance and the properties are spelled out only where they mean something.
     */
    private void renderSubject(Canvas gfx) {
        var platform = dev.buildmatic.client.BuildmaticClient.platform();
        int textX = panelX + 10;
        int y = panelY + 24;

        if (platform != null) {
            gfx.item(platform.schema().icon(original.blockId()), panelX + 8, y - 4);
            textX = panelX + 30;
            gfx.text(font, platform.schema().displayName(original.blockId()), textX, y, TEXT);
        } else {
            gfx.text(font, original.path(), textX, y, TEXT);
        }

        String properties = describeProperties();
        if (!properties.isEmpty()) {
            int nameWidth = platform == null
                    ? font.width(original.path())
                    : font.width(platform.schema().displayName(original.blockId()));
            gfx.text(font, fit(properties, panelWidth - (textX - panelX) - nameWidth - 320),
                    textX + nameWidth + 8, y, TEXT_DIM);
        }
    }

    /**
     * The properties worth naming.
     *
     * <p>Connection flags on a pane or a fence are decided by its neighbours, not by the builder,
     * so listing eight of them buries the one thing that was actually chosen.
     */
    private String describeProperties() {
        StringBuilder out = new StringBuilder();
        for (var entry : original.properties().entrySet()) {
            String key = entry.getKey();
            if (key.equals("north") || key.equals("south") || key.equals("east")
                    || key.equals("west") || key.equals("up") || key.equals("down")
                    || key.equals("waterlogged") || key.equals("powered")) {
                continue;
            }
            if (out.length() > 0) out.append(", ");
            out.append(key.replace('_', ' ')).append(' ').append(entry.getValue());
        }
        return out.toString();
    }

    @Override
    protected String footerText() {
        List<VariantIndex.Candidate> items = list.items();
        if (items.isEmpty()) return "No variants known for " + original.blockId();
        int position = list.selectedIndex() + 1;
        return items.size() + " variant(s)"
                + (position > 0 ? "   -   " + position + " of " + items.size() : "")
                + "   -   arrows to preview, Enter to keep";
    }

    // --- input ------------------------------------------------------------------------------------

    @Override
    protected boolean onClick(double x, double y, int button, boolean doubled) {
        if (list.mouseClicked(x, y) >= 0) {
            applySelection();
            if (doubled) onClose();
            return true;
        }
        return false;
    }

    @Override
    protected boolean onScroll(double x, double y, double amount) {
        return list.mouseScrolled(x, y, amount);
    }

    @Override
    protected boolean onKey(int key, int modifiers) {
        switch (key) {
            case org.lwjgl.glfw.GLFW.GLFW_KEY_DOWN -> {
                list.moveSelection(1, (i, c) -> applySelection());
                return true;
            }
            case org.lwjgl.glfw.GLFW.GLFW_KEY_UP -> {
                list.moveSelection(-1, (i, c) -> applySelection());
                return true;
            }
            case org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER, org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER -> {
                onClose();
                return true;
            }
            case org.lwjgl.glfw.GLFW.GLFW_KEY_TAB -> {
                toggleAxis();
                return true;
            }
            default -> {
                return false;
            }
        }
    }
}
