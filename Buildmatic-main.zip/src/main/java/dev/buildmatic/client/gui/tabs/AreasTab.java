package dev.buildmatic.client.gui.tabs;

import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.BuildmaticScreen;
import dev.buildmatic.client.gui.Buttons;
import dev.buildmatic.client.gui.Canvas;
import dev.buildmatic.client.gui.MenuTab;
import dev.buildmatic.client.gui.SaveSchematicScreen;
import dev.buildmatic.client.gui.ScrollList;
import dev.buildmatic.core.area.AreaSelection;
import dev.buildmatic.core.area.SelectionBox;
import dev.buildmatic.core.area.WorldCapture;
import dev.buildmatic.core.schematic.SchematicFormat;
import dev.buildmatic.core.schematic.SchematicIo;
import dev.buildmatic.core.tool.SchematicTool;
import dev.buildmatic.core.tool.ToolMode;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.platform.LevelCaptureSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Area selections: draw a box round a build and save it as a schematic.
 *
 * <p>A selection can hold several named sub-regions sharing one origin, so a sparse build - two
 * towers with a gap - is captured without storing the empty space between them. Each sub-region
 * becomes a region of the saved file.
 */
public final class AreasTab implements MenuTab {

    /** Rows are either a selection or one of its boxes, so the tree reads as one list. */
    private record Row(AreaSelection selection, SelectionBox box) {
        boolean isSelectionHeader() { return box == null; }
    }

    private final ScrollList<Row> list = new ScrollList<>(18, this::renderRow);
    private BuildmaticMenuScreen screen;
    private Button subModeButton;
    private String status = "";

    @Override
    public String title() { return "Areas"; }

    @Override
    public void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
                     Consumer<AbstractWidget> addWidget) {
        this.screen = screen;
        list.setBounds(x, y, width, height - 46);

        int row1 = y + height - 42;
        int row2 = y + height - 20;

        addWidget.accept(Buttons.of(Component.literal("New area"), b -> newSelection(), x, row1, 66, 18));
        addWidget.accept(Buttons.of(Component.literal("Add region"), b -> addRegion(), x + 70, row1, 76, 18));
        addWidget.accept(Buttons.of(Component.literal("Remove"), b -> removeRow(), x + 150, row1, 56, 18));
        addWidget.accept(Buttons.of(Component.literal("Set origin here"), b -> originHere(), x + 210, row1, 96, 18));

        subModeButton = Buttons.of(Component.literal(""), b -> toggleSubMode(), x, row2, 110, 18);
        addWidget.accept(subModeButton);
        addWidget.accept(Buttons.of(Component.literal("Use the tool"), b -> useTool(), x + 114, row2, 88, 18));
        addWidget.accept(Buttons.of(Component.literal("Save as schematic"), b -> save(), x + 206, row2, 116, 18));

        refresh();
    }

    private SchematicTool tool() {
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        return session == null ? null : session.tool();
    }

    @Override
    public void refresh() {
        SchematicTool tool = tool();
        if (tool == null) return;

        if (subModeButton != null) {
            subModeButton.setMessage(Component.literal(
                    "Mode: " + tool.selectionSubMode().displayName()));
        }

        List<Row> rows = new ArrayList<>();
        for (AreaSelection selection : tool.selections()) {
            rows.add(new Row(selection, null));
            for (SelectionBox box : selection.boxes()) rows.add(new Row(selection, box));
        }
        list.setItems(rows);

        AreaSelection active = tool.currentSelectionOrNull();
        if (active == null) {
            status = "No area yet - press New area, then click two corners with the tool";
        } else {
            Vec3i size = active.size();
            status = active.name() + ": " + active.boxCount() + " region(s), "
                    + size.x() + "x" + size.y() + "x" + size.z()
                    + ", " + active.volume() + " blocks   -   origin " + active.origin();
        }
    }

    private void newSelection() {
        SchematicTool tool = tool();
        if (tool == null) return;
        tool.createSelection("Selection " + (tool.selections().size() + 1));
        refresh();
    }

    private void addRegion() {
        SchematicTool tool = tool();
        if (tool == null) return;
        status = tool.addSubRegion().message();
        refresh();
    }

    private void removeRow() {
        SchematicTool tool = tool();
        Row row = list.selectedItem();
        if (tool == null || row == null) return;

        if (row.isSelectionHeader()) tool.removeSelection(row.selection());
        else row.selection().removeBox(row.box());
        refresh();
    }

    private void originHere() {
        SchematicTool tool = tool();
        Minecraft client = Minecraft.getInstance();
        if (tool == null || client.player == null) return;

        AreaSelection selection = tool.activeSelection();
        var pos = client.player.position();
        selection.setOrigin(new Vec3i(
                (int) Math.floor(pos.x), (int) Math.floor(pos.y), (int) Math.floor(pos.z)));
        refresh();
    }

    private void toggleSubMode() {
        SchematicTool tool = tool();
        if (tool == null) return;
        tool.toggleSelectionSubMode();
        refresh();
    }

    /** Switches the tool to area mode so the next clicks draw a box. */
    private void useTool() {
        SchematicTool tool = tool();
        if (tool == null) return;
        tool.setMode(ToolMode.AREA_SELECTION);
        status = "Tool set to area selection - close this menu and click two corners";
    }

    /** Asks for a name and a format before anything is read out of the world. */
    private void save() {
        SchematicTool tool = tool();
        BuildmaticSession session = screen.sessionOrNull();
        Minecraft client = Minecraft.getInstance();
        if (tool == null || session == null || client.level == null) return;

        AreaSelection selection = tool.currentSelectionOrNull();
        if (selection == null || !selection.hasCompleteBox()) {
            status = "Draw a box first: click two corners with the tool";
            return;
        }

        int regions = 0;
        for (SelectionBox box : selection.boxes()) {
            if (box.isEnabled() && box.isComplete()) regions++;
        }

        dev.buildmatic.client.BuildmaticClient.openScreen(client, new SaveSchematicScreen(
                screen, session.platform().schematicsDirectory(), selection.name(),
                regions, selection.size(), this::write));
    }

    /**
     * Reads the world inside the selection and writes the file.
     *
     * <p>Positions in unloaded chunks are counted and reported rather than saved as air; a build
     * saved with half its chunks unloaded looks fine until it is placed.
     */
    private void write(String name, SchematicFormat format) {
        SchematicTool tool = tool();
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        Minecraft client = Minecraft.getInstance();
        if (tool == null || session == null || client.level == null) return;

        AreaSelection selection = tool.currentSelectionOrNull();
        if (selection == null || !selection.hasCompleteBox()) return;

        var source = new LevelCaptureSource(client.level,
                dev.buildmatic.client.BuildmaticClient.platform().schema());
        String author = client.player == null ? "" : client.player.getName().getString();

        WorldCapture.Result result = WorldCapture.capture(selection, source, name, author);

        Path file = SchematicIo.withExtension(
                session.platform().schematicsDirectory().resolve(name), format);
        try {
            SchematicIo.save(result.schematic(), file, format, session.platform().dataVersion());
        } catch (IOException e) {
            status = "Save failed: " + e.getMessage();
            return;
        }

        status = "Saved " + file.getFileName() + "   -   " + result.capturedBlocks() + " blocks, "
                + result.blockEntities() + " block entities"
                + (result.isComplete()
                ? "" : "   -   WARNING: " + result.unloadedPositions()
                + " unloaded chunk sample(s), walk the perimeter and save again");
    }

    private void renderRow(Canvas gfx, Row row, int index, int x, int y,
                           int width, boolean hovered, boolean selected) {
        var font = Minecraft.getInstance().font;
        SchematicTool tool = tool();
        boolean active = tool != null && tool.currentSelectionOrNull() == row.selection();

        if (row.isSelectionHeader()) {
            gfx.text(font, row.selection().name(), x + 4, y + 5,
                    active ? BuildmaticScreen.ACCENT : BuildmaticScreen.TEXT);
            gfx.text(font, row.selection().boxCount() + " region(s)", x + width - 90, y + 5,
                    BuildmaticScreen.TEXT_DIM);
            return;
        }

        SelectionBox box = row.box();
        gfx.text(font, box.isEnabled() ? "on" : "off", x + 16, y + 5,
                box.isEnabled() ? BuildmaticScreen.GOOD : BuildmaticScreen.TEXT_DIM);
        gfx.text(font, box.name(), x + 42, y + 5,
                box.isEnabled() ? BuildmaticScreen.TEXT : BuildmaticScreen.TEXT_DIM);

        Vec3i size = box.size();
        String detail = box.isComplete()
                ? size.x() + "x" + size.y() + "x" + size.z() + "   " + box.volume() + " blocks"
                : "waiting for a corner";
        gfx.text(font, detail, x + width - 150, y + 5, BuildmaticScreen.TEXT_DIM);
    }

    @Override
    public void render(Canvas gfx, int mouseX, int mouseY) {
        list.render(gfx, mouseX, mouseY);
    }

    @Override
    public String status() { return status; }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, boolean doubleClick) {
        if (list.mouseClicked(mouseX, mouseY) < 0) return false;
        Row row = list.selectedItem();
        SchematicTool tool = tool();
        if (row == null || tool == null) return true;

        tool.setActiveSelection(row.selection());
        if (row.box() != null) {
            row.selection().selectBox(row.box());
            // Double click toggles a sub-region, which is the quickest way to preview without it.
            if (doubleClick) row.box().setEnabled(!row.box().isEnabled());
        }
        refresh();
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return list.mouseScrolled(mouseX, mouseY, amount);
    }
}
