package dev.buildmatic.client.gui.tabs;

import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.BuildmaticScreen;
import dev.buildmatic.client.gui.ButtonRow;
import dev.buildmatic.client.gui.Buttons;
import dev.buildmatic.client.gui.Canvas;
import dev.buildmatic.client.gui.MenuTab;
import dev.buildmatic.client.gui.ScrollList;
import dev.buildmatic.core.material.ItemMapper;
import dev.buildmatic.core.material.MaterialList;
import dev.buildmatic.platform.Registries;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/**
 * What the build costs and what is still missing.
 *
 * <p>Counts come from the swap engine's effective palette, so the list follows every swap the
 * moment it is made. Convert a build from oak to deepslate and the shopping list changes with it,
 * which is the point of swapping before starting rather than after.
 */
public final class MaterialsTab implements MenuTab {

    private final ScrollList<MaterialList.Entry> list = new ScrollList<>(18, this::renderRow);
    private BuildmaticMenuScreen screen;
    private MaterialList materials;
    /** One block state per item id, so a list row can be traced back to something swappable. */
    private final Map<String, dev.buildmatic.core.block.BlockStateRef> representatives =
            new HashMap<>();

    private boolean missingOnly;
    private boolean countInventory = true;
    private int multiplier = 1;

    /**
     * Blocks no installed mod provides. Computed on refresh, never in {@link #status()}: that runs
     * every frame and this walks the whole schematic.
     */
    private dev.buildmatic.core.schematic.MissingBlocks missingMods;

    private Button missingButton;
    private Button inventoryButton;
    private Button multiplierButton;
    private int listX;
    private int listWidth;

    @Override
    public String title() { return "Materials"; }

    @Override
    public void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
                     Consumer<AbstractWidget> addWidget) {
        this.screen = screen;
        this.listX = x;
        this.listWidth = width;
        ButtonRow row = new ButtonRow(x, y + height - 20, width, 18, addWidget);
        row.add("", 84, b -> {
                    missingOnly = !missingOnly;
                    refresh();
                }, button -> missingButton = button)
                .add("", 96, b -> {
                    countInventory = !countInventory;
                    refresh();
                }, button -> inventoryButton = button)
                .add("", 70, b -> {
                    multiplier = multiplier >= 8 ? 1 : multiplier * 2;
                    refresh();
                }, button -> multiplierButton = button)
                .add("Swap this", 74, b -> swapSelected())
                .add("Themes", 58, b -> openThemes());

        list.setBounds(x, y + 12, width, height - row.finish() - 24);
        refresh();
    }

    /**
     * Opens the variant picker on the selected line and converts that material across the build.
     *
     * <p>This is the shortest path from "I am 320 spruce stairs short" to "make them oak instead":
     * the shopping list is where you find out a material is a problem, so it is where you should be
     * able to change it, without going to find one of those blocks in the world to click on.
     */
    private void swapSelected() {
        MaterialList.Entry entry = list.selectedItem();
        if (entry == null) return;

        dev.buildmatic.core.block.BlockStateRef state = representatives.get(entry.itemId());
        if (state == null) return;

        dev.buildmatic.client.BuildmaticClient.openScreen(Minecraft.getInstance(),
                dev.buildmatic.client.gui.VariantPickerScreen.forBlock(state));
    }

    /**
     * The shopping list is where a palette turns out to be unaffordable, so it is also where
     * re-dressing the whole build should be one click away.
     */
    private void openThemes() {
        dev.buildmatic.client.BuildmaticClient.openScreen(Minecraft.getInstance(),
                new dev.buildmatic.client.gui.ThemePickerScreen());
    }

    @Override
    public void refresh() {
        missingButton.setMessage(Component.literal(missingOnly ? "Missing only" : "Show all"));
        inventoryButton.setMessage(Component.literal(
                countInventory ? "Inventory: on" : "Inventory: off"));
        multiplierButton.setMessage(Component.literal("x" + multiplier));

        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        BuildmaticSession.OpenSchematic open = session == null ? null : session.active();
        if (open == null) {
            materials = null;
            missingMods = null;
            list.setItems(List.of());
            return;
        }

        var platform = dev.buildmatic.client.BuildmaticClient.platform();
        missingMods = platform == null ? null
                : dev.buildmatic.core.schematic.MissingBlocks.scan(open.schematic(), platform.schema());

        Map<String, Integer> inventory = countInventory ? readInventory() : null;
        var counts = open.swaps().countEffectiveBlocks();

        // Remember one state per item so a row can be swapped; the most used one, since that is
        // what the player is looking at when they decide the material has to change.
        representatives.clear();
        Map<String, Integer> best = new HashMap<>();
        for (var entry : counts.entrySet()) {
            ItemMapper.Cost cost = ItemMapper.VANILLA.costOf(entry.getKey());
            if (cost.isFree()) continue;
            if (entry.getValue() > best.getOrDefault(cost.itemId(), 0)) {
                best.put(cost.itemId(), entry.getValue());
                representatives.put(cost.itemId(), entry.getKey());
            }
        }

        MaterialList base = MaterialList.of(open.swaps(), ItemMapper.VANILLA, inventory);
        materials = multiplier == 1 ? base : scale(base, inventory);
        list.setItems(missingOnly ? materials.missingEntries() : materials.entries());
    }

    /** Multiplies every requirement, for building the same thing several times. */
    private MaterialList scale(MaterialList base, Map<String, Integer> inventory) {
        Map<dev.buildmatic.core.block.BlockStateRef, Integer> counts = new HashMap<>();
        BuildmaticSession session = screen.sessionOrNull();
        var open = session.active();
        for (var entry : open.swaps().countEffectiveBlocks().entrySet()) {
            counts.put(entry.getKey(), entry.getValue() * multiplier);
        }
        return MaterialList.from(counts, ItemMapper.VANILLA, inventory);
    }

    private Map<String, Integer> readInventory() {
        Map<String, Integer> counts = new HashMap<>();
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return counts;

        var inventory = client.player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) continue;
            var key = Registries.ITEM.getKey(stack.getItem());
            if (key == null) continue;
            counts.merge(key.getNamespace() + ":" + key.getPath(), stack.getCount(), Integer::sum);
        }
        return counts;
    }

    private void renderRow(Canvas gfx, MaterialList.Entry entry, int index,
                           int x, int y, int width, boolean hovered, boolean selected) {
        var font = Minecraft.getInstance().font;

        // Show the block the row stands for, icon and translated name, not its registry id.
        var state = representatives.get(entry.itemId());
        var schema = dev.buildmatic.client.BuildmaticClient.platform() == null
                ? null : dev.buildmatic.client.BuildmaticClient.platform().schema();
        if (schema != null && state != null) {
            gfx.item(schema.icon(state.blockId()), x + 2, y);
            gfx.text(font, schema.displayName(state.blockId()), x + 22, y + 5, BuildmaticScreen.TEXT);
        } else {
            gfx.text(font, prettyItem(entry.itemId()), x + 22, y + 5, BuildmaticScreen.TEXT);
        }
        gfx.text(font, entry.describeQuantity(), x + width - 200, y + 5, BuildmaticScreen.TEXT_DIM);
        gfx.text(font, Integer.toString(entry.missing()), x + width - 110, y + 5,
                entry.isSatisfied() ? BuildmaticScreen.GOOD : BuildmaticScreen.BAD);
        gfx.text(font, Integer.toString(entry.available()), x + width - 50, y + 5,
                BuildmaticScreen.TEXT_DIM);
    }

    private static String prettyItem(String itemId) {
        String path = itemId.substring(itemId.indexOf(':') + 1).replace('_', ' ');
        return Character.toUpperCase(path.charAt(0)) + path.substring(1);
    }

    @Override
    public void render(Canvas gfx, int mouseX, int mouseY) {
        var font = Minecraft.getInstance().font;
        int headerY = list.itemsTop() - 11;
        gfx.text(font, "Item", listX + 4, headerY, BuildmaticScreen.ACCENT);
        gfx.text(font, "Total", listX + listWidth - 200, headerY, BuildmaticScreen.ACCENT);
        gfx.text(font, "Missing", listX + listWidth - 110, headerY, BuildmaticScreen.ACCENT);
        gfx.text(font, "Have", listX + listWidth - 50, headerY, BuildmaticScreen.ACCENT);
        list.render(gfx, mouseX, mouseY);
    }

    @Override
    public String status() {
        if (materials == null) return "No schematic is open";
        String summary = String.format(Locale.ROOT, "%d types   -   %d items   -   %d missing",
                materials.distinctItems(), materials.totalItems(), materials.totalMissing());
        // Missing mods outrank a satisfied inventory: those blocks are not in this list at all,
        // so "everything is in the inventory" would be a lie about an incomplete build.
        if (missingMods != null && !missingMods.isEmpty()) {
            return summary + "   -   " + missingMods.describeShort();
        }
        return materials.isComplete() ? summary + "   -   everything is in the inventory" : summary;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, boolean doubleClick) {
        if (list.mouseClicked(mouseX, mouseY) < 0) return false;
        if (doubleClick) swapSelected();
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return list.mouseScrolled(mouseX, mouseY, amount);
    }
}
