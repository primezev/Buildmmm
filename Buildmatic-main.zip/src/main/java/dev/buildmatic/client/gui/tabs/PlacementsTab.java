package dev.buildmatic.client.gui.tabs;

import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.BuildmaticScreen;
import dev.buildmatic.client.gui.ButtonRow;
import dev.buildmatic.client.gui.Buttons;
import dev.buildmatic.client.gui.Canvas;
import dev.buildmatic.client.gui.MenuTab;
import dev.buildmatic.client.gui.ScrollList;
import dev.buildmatic.core.placement.LayerRange;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;
import dev.buildmatic.core.util.Vec3i;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Loaded schematics and where each one sits: position, rotation, mirroring, layer slice. */
public final class PlacementsTab implements MenuTab {

    private final ScrollList<BuildmaticSession.OpenSchematic> list =
            new ScrollList<>(18, this::renderRow);
    private BuildmaticMenuScreen screen;
    private Button layerButton;
    private String status = "";

    @Override
    public String title() { return "Placements"; }

    @Override
    public void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
                     Consumer<AbstractWidget> addWidget) {
        this.screen = screen;

        // Laid out rather than positioned: twelve buttons need 436 pixels, and a fullscreen window
        // at a high GUI scale leaves fewer than that. They wrap instead of leaving the panel.
        ButtonRow row = new ButtonRow(x, y + height - 20, width, 18, addWidget);
        row.add("Here", 48, b -> moveToPlayer())
                .add("Rotate", 52, b -> rotate())
                .add("Mirror", 52, b -> mirror())
                .add("Show/hide", 70, b -> toggleEnabled())
                .add("Close", 50, b -> close())
                .add("Paste", 46, b -> paste(false))
                .add("Clear", 46, b -> paste(true))
                .add("Lock", 44, b -> toggleLock())
                .add("", 120, b -> cycleLayerMode(), button -> layerButton = button)
                .add("Layer -", 52, b -> shiftLayer(-1))
                .add("Layer +", 52, b -> shiftLayer(1))
                .add("Snap to me", 70, b -> snapLayer());

        list.setBounds(x, y, width, height - row.finish() - 8);
        refresh();
    }

    @Override
    public void refresh() {
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        List<BuildmaticSession.OpenSchematic> open =
                session == null ? new ArrayList<>() : new ArrayList<>(session.open());
        list.setItems(open);
        if (session != null && session.active() != null) {
            list.select(open.indexOf(session.active()));
        }
        updateLayerLabel();
    }

    private void updateLayerLabel() {
        if (layerButton == null) return;
        SchematicPlacement placement = placement();
        layerButton.setMessage(Component.literal(
                placement == null ? "Layers: all" : "Layers: " + placement.layerRange().describe()));
    }

    private SchematicPlacement placement() {
        BuildmaticSession.OpenSchematic open = list.selectedItem();
        return open == null ? null : open.placement();
    }

    private void select() {
        BuildmaticSession session = screen.sessionOrNull();
        BuildmaticSession.OpenSchematic open = list.selectedItem();
        if (session != null && open != null) session.setActive(open);
    }

    private void moveToPlayer() {
        SchematicPlacement placement = placement();
        Minecraft client = Minecraft.getInstance();
        if (placement == null || client.player == null) return;
        var pos = client.player.position();
        placement.setOrigin(new Vec3i(
                (int) Math.floor(pos.x), (int) Math.floor(pos.y), (int) Math.floor(pos.z)));
        screen.invalidatePreview();
    }

    private void rotate() {
        SchematicPlacement placement = placement();
        if (placement == null) return;
        placement.rotateBy(Rotation.CLOCKWISE_90);
        screen.invalidatePreview();
    }

    private void mirror() {
        SchematicPlacement placement = placement();
        if (placement == null) return;
        placement.setMirror(switch (placement.mirror()) {
            case NONE -> Mirror.FRONT_BACK;
            case FRONT_BACK -> Mirror.LEFT_RIGHT;
            case LEFT_RIGHT -> Mirror.NONE;
        });
        screen.invalidatePreview();
    }

    /** Locking stops a stray click or scroll from moving a build that is finally lined up. */
    private void toggleLock() {
        SchematicPlacement placement = placement();
        if (placement == null) return;
        placement.setLocked(!placement.isLocked());
        status = placement.name() + (placement.isLocked() ? " locked" : " unlocked");
    }

    private void toggleEnabled() {
        SchematicPlacement placement = placement();
        if (placement == null) return;
        placement.setEnabled(!placement.isEnabled());
    }

    private void close() {
        BuildmaticSession session = screen.sessionOrNull();
        BuildmaticSession.OpenSchematic open = list.selectedItem();
        if (session == null || open == null) return;
        session.close(open);
        screen.invalidatePreview();
        refresh();
    }

    /**
     * Writes the placement into the world, or clears its volume.
     *
     * <p>Creative singleplayer only: on a server this would need operator commands, and half a
     * pasted build is worse than none.
     */
    private void paste(boolean clear) {
        SchematicPlacement placement = placement();
        if (placement == null) {
            status = "Select a placement first";
            return;
        }
        var schema = dev.buildmatic.client.BuildmaticClient.platform().schema();
        // Both run over many ticks and close the menu, so the whole point - watching the build go
        // up, or come down - is not hidden behind this panel.
        var plan = clear
                ? dev.buildmatic.client.WorldEditJob.deletePlacement(placement, schema)
                : dev.buildmatic.client.WorldEditJob.paste(placement, schema);
        status = dev.buildmatic.client.BuildmaticClient.startJob(plan, screen);
    }

    private void cycleLayerMode() {
        SchematicPlacement placement = placement();
        if (placement == null) return;
        LayerRange range = placement.layerRange();
        LayerRange.Mode next = switch (range.mode()) {
            case ALL -> LayerRange.Mode.SINGLE;
            case SINGLE -> LayerRange.Mode.BELOW;
            case BELOW -> LayerRange.Mode.ABOVE;
            case ABOVE -> LayerRange.Mode.RANGE;
            case RANGE -> LayerRange.Mode.ALL;
        };
        placement.setLayerRange(range.withMode(next));
        screen.invalidatePreview();
        updateLayerLabel();
    }

    private void shiftLayer(int delta) {
        SchematicPlacement placement = placement();
        if (placement == null) return;
        placement.setLayerRange(placement.layerRange().shift(delta));
        screen.invalidatePreview();
        updateLayerLabel();
    }

    /** Sets the slice to the player's own height, the move you make on every new floor. */
    private void snapLayer() {
        SchematicPlacement placement = placement();
        Minecraft client = Minecraft.getInstance();
        if (placement == null || client.player == null) return;

        Vec3i world = new Vec3i(
                (int) Math.floor(client.player.getX()),
                (int) Math.floor(client.player.getY()),
                (int) Math.floor(client.player.getZ()));
        Vec3i local = placement.toSchematic(world);
        LayerRange range = placement.layerRange();
        int layer = range.axis() == Direction.Axis.X ? local.x()
                : range.axis() == Direction.Axis.Z ? local.z() : local.y();
        placement.setLayerRange(LayerRange.single(range.axis(), layer));
        screen.invalidatePreview();
        updateLayerLabel();
    }

    private void renderRow(Canvas gfx, BuildmaticSession.OpenSchematic open, int index,
                           int x, int y, int width, boolean hovered, boolean selected) {
        var font = Minecraft.getInstance().font;
        SchematicPlacement placement = open.placement();
        gfx.text(font, placement.isEnabled() ? "on" : "off", x + 4, y + 5,
                placement.isEnabled() ? BuildmaticScreen.GOOD : BuildmaticScreen.TEXT_DIM);
        gfx.text(font, open.name(), x + 28, y + 5, BuildmaticScreen.TEXT);

        String detail = placement.origin().toString()
                + (placement.rotation() == Rotation.NONE
                ? "" : "   " + placement.rotation().degrees() + " deg")
                + (placement.mirror() == Mirror.NONE ? "" : "   " + placement.mirror());
        gfx.text(font, detail, x + 200, y + 5, BuildmaticScreen.TEXT_DIM);
    }

    @Override
    public void render(Canvas gfx, int mouseX, int mouseY) {
        list.render(gfx, mouseX, mouseY);
    }

    @Override
    public String status() {
        if (!status.isEmpty()) return status;
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        if (session == null || session.open().isEmpty()) {
            return "Nothing loaded - open the Schematics tab";
        }
        return session.open().size() + " loaded   -   Paste and Clear need creative singleplayer";
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, boolean doubleClick) {
        if (list.mouseClicked(mouseX, mouseY) >= 0) {
            select();
            updateLayerLabel();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return list.mouseScrolled(mouseX, mouseY, amount);
    }
}
