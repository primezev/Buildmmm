package dev.buildmatic.client.gui.tabs;

import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.BuildmaticScreen;
import dev.buildmatic.client.gui.Buttons;
import dev.buildmatic.client.gui.Canvas;
import dev.buildmatic.client.gui.MenuTab;
import dev.buildmatic.client.gui.ScrollList;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicIo;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.platform.FileBrowser;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * The schematic list.
 *
 * <p>Every row is read far enough to show its real size, block count and author, so choosing the
 * right build out of a folder of thirty is a matter of looking rather than loading them one by one.
 */
public final class SchematicsTab implements MenuTab {

    private record Entry(Path file, String title, String detail, boolean readable) {}

    private final ScrollList<Entry> list = new ScrollList<>(18, this::renderRow);
    private BuildmaticMenuScreen screen;
    private String status = "";

    @Override
    public String title() { return "Schematics"; }

    @Override
    public void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
                     Consumer<AbstractWidget> addWidget) {
        this.screen = screen;
        list.setBounds(x, y, width, height - 24);

        int buttonsY = y + height - 20;
        addWidget.accept(Buttons.of(Component.literal("Load"), b -> load(), x, buttonsY, 60, 18));
        addWidget.accept(Buttons.of(Component.literal("Refresh"), b -> refresh(), x + 64, buttonsY, 60, 18));
        addWidget.accept(Buttons.of(Component.literal("Open folder"), b -> openFolder(),
                x + 128, buttonsY, 80, 18));
        refresh();
    }

    @Override
    public void refresh() {
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        if (session == null) {
            status = "Buildmatic is still starting up";
            return;
        }
        Path dir = session.platform().schematicsDirectory();
        List<Entry> entries = new ArrayList<>();
        try {
            for (Path file : SchematicIo.list(dir)) entries.add(describe(file));
        } catch (IOException e) {
            status = "Could not read " + dir;
        }
        list.setItems(entries);
        if (entries.isEmpty()) {
            status = "No schematics in " + dir;
        } else {
            status = entries.size() + " file(s) in " + dir;
        }
    }

    private Entry describe(Path file) {
        String fileName = file.getFileName().toString();
        try {
            Schematic schematic = SchematicIo.load(file);
            Vec3i size = schematic.enclosingSize();
            StringBuilder detail = new StringBuilder();
            detail.append(size.x()).append('x').append(size.y()).append('x').append(size.z());
            detail.append("   ").append(schematic.totalBlocks()).append(" blocks");
            if (!schematic.metadata().author().isEmpty()) {
                detail.append("   by ").append(schematic.metadata().author());
            }
            String title = schematic.metadata().name().isBlank()
                    ? fileName : schematic.metadata().name();
            return new Entry(file, title, detail.toString(), true);
        } catch (IOException | RuntimeException e) {
            return new Entry(file, fileName, "unreadable", false);
        }
    }

    private void load() {
        Entry entry = list.selectedItem();
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        Minecraft client = Minecraft.getInstance();
        if (entry == null) {
            status = "Select a file first";
            return;
        }
        if (session == null || client.player == null) return;

        try {
            Schematic schematic = SchematicIo.load(entry.file());
            var pos = client.player.position();
            session.adopt(schematic, new Vec3i(
                    (int) Math.floor(pos.x), (int) Math.floor(pos.y), (int) Math.floor(pos.z)));
            // Straight into placement mode: the first thing anyone does after loading is move it.
            session.tool().setMode(dev.buildmatic.core.tool.ToolMode.PLACEMENT);
            screen.invalidatePreview();

            // Blocks the running game does not have become air, so the build loads with holes in
            // it. Saying so is the difference between "this mod is broken" and "I need Macaw's".
            var missing = dev.buildmatic.core.schematic.MissingBlocks.scan(
                    schematic, dev.buildmatic.client.BuildmaticClient.platform().schema());
            if (missing.isEmpty()) {
                status = "Loaded " + schematic.metadata().name()
                        + " - hold a stick and click to move it, or use the Placements tab";
            } else {
                status = "Loaded " + schematic.metadata().name() + "  -  " + missing.describe();
                dev.buildmatic.client.BuildmaticClient.actionBar(client,
                        "Buildmatic: " + missing.describe());
            }
        } catch (IOException e) {
            status = "Load failed: " + e.getMessage();
        }
    }

    /**
     * Opens the folder the selected file lives in, or the schematics folder when nothing is
     * selected - which is the same directory today, but stops being so the moment listing
     * recurses.
     */
    private void openFolder() {
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        if (session == null) return;

        Entry entry = list.selectedItem();
        Path dir = entry == null ? null : entry.file().getParent();
        if (dir == null) dir = session.platform().schematicsDirectory();

        FileBrowser.open(dir);
        status = "Opened " + dir;
    }

    private void renderRow(Canvas gfx, Entry entry, int index, int x, int y,
                           int width, boolean hovered, boolean selected) {
        var font = Minecraft.getInstance().font;
        gfx.text(font, entry.title(), x + 4, y + 5,
                entry.readable() ? BuildmaticScreen.TEXT : BuildmaticScreen.BAD);
        gfx.text(font, entry.detail(), x + 190, y + 5, BuildmaticScreen.TEXT_DIM);
    }

    @Override
    public void render(Canvas gfx, int mouseX, int mouseY) {
        list.render(gfx, mouseX, mouseY);
    }

    @Override
    public String status() { return status; }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, boolean doubleClick) {
        if (list.mouseClicked(mouseX, mouseY) >= 0) {
            if (doubleClick) load();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return list.mouseScrolled(mouseX, mouseY, amount);
    }
}
