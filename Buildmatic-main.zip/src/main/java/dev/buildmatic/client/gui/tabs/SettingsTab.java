package dev.buildmatic.client.gui.tabs;

import dev.buildmatic.client.BuildmaticConfig;
import dev.buildmatic.client.BuildmaticKeys;
import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.BuildmaticScreen;
import dev.buildmatic.client.gui.Buttons;
import dev.buildmatic.client.gui.Canvas;
import dev.buildmatic.client.gui.MenuTab;
import dev.buildmatic.client.gui.ScrollList;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.Consumer;

/**
 * Preview appearance and the key list.
 *
 * <p>Rebinding goes through the vanilla controls screen rather than a second binding editor here:
 * that screen already handles conflicts, modifiers and the mouse, and a home-grown copy of it would
 * be a worse version of something the player already knows.
 */
public final class SettingsTab implements MenuTab {

    /** The transparency steps the button walks through. */
    private static final float[] ALPHA_STEPS = {0.15f, 0.30f, 0.45f, 0.55f, 0.70f, 0.85f, 1.00f};

    private final ScrollList<KeyMapping> keys = new ScrollList<>(16, this::renderKeyRow);
    private BuildmaticMenuScreen screen;

    private Button alphaButton;
    private Button highlightButton;
    private Button hidePlacedButton;
    private Button scrollButton;
    private Button easyPlaceButton;
    private int contentX;
    private int contentY;

    @Override
    public String title() { return "Settings"; }

    private BuildmaticConfig config() {
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        return session == null ? null : session.config();
    }

    @Override
    public void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
                     Consumer<AbstractWidget> addWidget) {
        this.screen = screen;
        this.contentX = x;
        this.contentY = y;

        alphaButton = Buttons.of(Component.literal(""), b -> stepAlpha(), x, y + 4, 150, 18);
        highlightButton = Buttons.of(Component.literal(""), b -> {
            config().setHighlightErrors(!config().highlightErrors());
            apply();
        }, x + 156, y + 4, 150, 18);
        hidePlacedButton = Buttons.of(Component.literal(""), b -> {
            config().setHidePlaced(!config().hidePlaced());
            apply();
        }, x, y + 26, 150, 18);
        scrollButton = Buttons.of(Component.literal(""), b -> {
            int step = config().scrollStep();
            config().setScrollStep(step >= 8 ? 1 : step * 2);
            apply();
        }, x + 156, y + 26, 150, 18);

        easyPlaceButton = Buttons.of(Component.literal(""), b -> {
            config().setEasyPlace(!config().easyPlace());
            apply();
        }, x, y + 48, 306, 18);

        addWidget.accept(alphaButton);
        addWidget.accept(highlightButton);
        addWidget.accept(hidePlacedButton);
        addWidget.accept(scrollButton);
        addWidget.accept(easyPlaceButton);
        addWidget.accept(Buttons.of(Component.literal("Rebind keys"), b -> openControls(), x, y + height - 20, 100, 18));

        keys.setBounds(x, y + 62, width, height - 88);
        keys.setItems(List.of(
                BuildmaticKeys.MENU,
                BuildmaticKeys.OPEN_BROWSER,
                BuildmaticKeys.OPEN_MATERIALS,
                BuildmaticKeys.OPEN_LAYERS,
                BuildmaticKeys.OPEN_AREAS,
                BuildmaticKeys.VARIANT_WHEEL,
                BuildmaticKeys.TOOL_WHEEL,
                BuildmaticKeys.EXECUTE,
                BuildmaticKeys.PICK_BLOCK,
                BuildmaticKeys.TOOL_MODE_NEXT,
                BuildmaticKeys.TOOL_MODE_PREV,
                BuildmaticKeys.NUDGE_FORWARD,
                BuildmaticKeys.NUDGE_BACK,
                BuildmaticKeys.TOGGLE_RENDERING,
                BuildmaticKeys.LAYER_UP,
                BuildmaticKeys.LAYER_DOWN,
                BuildmaticKeys.UNDO,
                BuildmaticKeys.REDO));
        refresh();
    }

    private void stepAlpha() {
        BuildmaticConfig config = config();
        float current = config.previewAlpha();
        for (float step : ALPHA_STEPS) {
            if (step > current + 0.01f) {
                config.setPreviewAlpha(step);
                apply();
                return;
            }
        }
        config.setPreviewAlpha(ALPHA_STEPS[0]);
        apply();
    }

    /** Writes the file and drops the mesh cache, since several of these change what is drawn. */
    private void apply() {
        BuildmaticConfig config = config();
        if (config == null) return;
        config.save();
        screen.invalidatePreview();
        refresh();
    }

    private void openControls() {
        Minecraft client = Minecraft.getInstance();
        // The options screens moved under an `options` package in 1.21.
        //? if >=1.21 {
        dev.buildmatic.client.BuildmaticClient.openScreen(client,
                new net.minecraft.client.gui.screens.options.controls.KeyBindsScreen(
                        screen, client.options));
        //?} else {
        /*dev.buildmatic.client.BuildmaticClient.openScreen(client,
                new net.minecraft.client.gui.screens.controls.KeyBindsScreen(
                        screen, client.options));
        *///?}
    }

    @Override
    public void refresh() {
        BuildmaticConfig config = config();
        if (config == null || alphaButton == null) return;

        alphaButton.setMessage(Component.literal(
                "Transparency: " + Math.round(config.previewAlpha() * 100) + "%"));
        highlightButton.setMessage(Component.literal(
                "Tint wrong blocks red: " + (config.highlightErrors() ? "on" : "off")));
        hidePlacedButton.setMessage(Component.literal(
                "Hide blocks already built: " + (config.hidePlaced() ? "on" : "off")));
        scrollButton.setMessage(Component.literal("Move step: " + config.scrollStep()));
        easyPlaceButton.setMessage(Component.literal(
                "Easy place (right click builds the right block): "
                        + (config.easyPlace() ? "on" : "off")));
    }

    private void renderKeyRow(Canvas gfx, KeyMapping key, int index, int x, int y,
                              int width, boolean hovered, boolean selected) {
        var font = Minecraft.getInstance().font;
        gfx.text(font, Component.translatable(key.getName()), x + 4, y + 4, BuildmaticScreen.TEXT);
        gfx.text(font, key.getTranslatedKeyMessage(), x + width - 120, y + 4,
                BuildmaticScreen.ACCENT);
    }

    @Override
    public void render(Canvas gfx, int mouseX, int mouseY) {
        var font = Minecraft.getInstance().font;
        gfx.text(font, "Keys", contentX + 4, contentY + 52, BuildmaticScreen.ACCENT);
        keys.render(gfx, mouseX, mouseY);
    }

    @Override
    public String status() {
        BuildmaticConfig config = config();
        if (config != null && config.highlightErrors()) {
            return "Wrong blocks show red in the preview, blocks already built show green";
        }
        return "Rebind opens Minecraft's own controls screen, where combinations are handled too";
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return keys.mouseScrolled(mouseX, mouseY, amount);
    }
}
