package dev.buildmatic.client.gui.tabs;

import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.BuildmaticScreen;
import dev.buildmatic.client.gui.ButtonRow;
import dev.buildmatic.client.gui.Buttons;
import dev.buildmatic.client.gui.Canvas;
import dev.buildmatic.client.gui.MenuTab;
import dev.buildmatic.client.gui.ScrollList;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.swap.SwapLayer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.Consumer;

/**
 * The swap stack: every block change made to the schematic, in order, each one reversible.
 *
 * <p>Layers apply bottom to top and a later one wins where they overlap. Switching one off is the
 * fastest way to compare two palettes without losing either.
 */
public final class SwapsTab implements MenuTab {

    private final ScrollList<SwapLayer> list = new ScrollList<>(18, this::renderRow);
    private BuildmaticMenuScreen screen;

    @Override
    public String title() { return "Swaps"; }

    @Override
    public void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
                     Consumer<AbstractWidget> addWidget) {
        this.screen = screen;
        ButtonRow row = new ButtonRow(x, y + height - 20, width, 18, addWidget);
        row.add("On/off", 52, b -> toggle())
                .add("Remove", 56, b -> remove())
                .add("Up", 34, b -> move(-1))
                .add("Down", 42, b -> move(1))
                .add("Clear all", 58, b -> clear())
                .add("Undo", 44, b -> undo())
                .add("Themes", 58, b -> openThemes());

        list.setBounds(x, y, width, height - row.finish() - 6);
        refresh();
    }

    private SwapEngine swaps() {
        BuildmaticSession session = screen == null ? null : screen.sessionOrNull();
        BuildmaticSession.OpenSchematic open = session == null ? null : session.active();
        return open == null ? null : open.swaps();
    }

    @Override
    public void refresh() {
        SwapEngine engine = swaps();
        list.setItems(engine == null ? List.of() : engine.layers());
    }

    private void toggle() {
        SwapEngine engine = swaps();
        SwapLayer layer = list.selectedItem();
        if (engine == null || layer == null) return;
        engine.setLayerEnabled(layer, !layer.isEnabled());
        screen.invalidatePreview();
    }

    private void remove() {
        SwapEngine engine = swaps();
        SwapLayer layer = list.selectedItem();
        if (engine == null || layer == null) return;
        engine.removeLayer(layer);
        screen.invalidatePreview();
        refresh();
    }

    private void move(int delta) {
        SwapEngine engine = swaps();
        SwapLayer layer = list.selectedItem();
        if (engine == null || layer == null) return;
        int index = engine.layers().indexOf(layer);
        if (engine.moveLayer(layer, index + delta)) {
            list.select(index + delta);
            screen.invalidatePreview();
        }
        refresh();
    }

    private void clear() {
        SwapEngine engine = swaps();
        if (engine == null) return;
        engine.clearLayers();
        screen.invalidatePreview();
        refresh();
    }

    /** A whole-build restyle is still just a layer, so it belongs on the layer list. */
    private void openThemes() {
        dev.buildmatic.client.BuildmaticClient.openScreen(Minecraft.getInstance(),
                new dev.buildmatic.client.gui.ThemePickerScreen());
    }

    private void undo() {
        BuildmaticSession session = screen.sessionOrNull();
        if (session == null) return;
        session.undo();
        screen.invalidatePreview();
        refresh();
    }

    private void renderRow(Canvas gfx, SwapLayer layer, int index, int x, int y,
                           int width, boolean hovered, boolean selected) {
        var font = Minecraft.getInstance().font;
        gfx.text(font, layer.isEnabled() ? "on" : "off", x + 4, y + 5,
                layer.isEnabled() ? BuildmaticScreen.GOOD : BuildmaticScreen.TEXT_DIM);
        gfx.text(font, layer.describe(), x + 28, y + 5,
                layer.isEnabled() ? BuildmaticScreen.TEXT : BuildmaticScreen.TEXT_DIM);
    }

    @Override
    public void render(Canvas gfx, int mouseX, int mouseY) {
        list.render(gfx, mouseX, mouseY);
    }

    @Override
    public String status() {
        SwapEngine engine = swaps();
        if (engine == null) return "No schematic is open";
        if (engine.layers().isEmpty()) {
            return "No swaps yet - point at a block with the tool and right click";
        }
        int enabled = 0;
        for (SwapLayer layer : engine.layers()) {
            if (layer.isEnabled()) enabled++;
        }
        return engine.layers().size() + " layer(s), " + enabled + " active";
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, boolean doubleClick) {
        if (list.mouseClicked(mouseX, mouseY) >= 0) {
            if (doubleClick) toggle();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return list.mouseScrolled(mouseX, mouseY, amount);
    }
}
