package dev.buildmatic.client.gui.tabs;

import dev.buildmatic.client.BuildmaticClient;
import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.client.gui.BuildmaticMenuScreen;
import dev.buildmatic.client.gui.BuildmaticScreen;
import dev.buildmatic.client.gui.Buttons;
import dev.buildmatic.client.gui.Canvas;
import dev.buildmatic.client.gui.MenuTab;
import dev.buildmatic.core.verify.SchematicVerifier;
import dev.buildmatic.platform.LevelWorldView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.function.Consumer;

/**
 * Compares the build against the world.
 *
 * <p>"Wrong block" and "wrong state" are reported separately because they cost very different
 * things to fix: a stair facing the wrong way is two seconds, a wrong material is a trip to the
 * chest. Litematica lumps both together.
 */
public final class VerifyTab implements MenuTab {

    private BuildmaticMenuScreen screen;
    private SchematicVerifier.Result result;
    private int contentX;
    private int contentY;
    private String status = "Press Check to compare the build against the world";

    @Override
    public String title() { return "Verify"; }

    @Override
    public void init(BuildmaticMenuScreen screen, int x, int y, int width, int height,
                     Consumer<AbstractWidget> addWidget) {
        this.screen = screen;
        this.contentX = x;
        this.contentY = y;

        addWidget.accept(Buttons.of(Component.literal("Check"), b -> run(), x, y + height - 20, 60, 18));
        addWidget.accept(Buttons.of(Component.literal("Clear"), b -> {
            result = null;
            status = "Press Check to compare the build against the world";
        }, x + 64, y + height - 20, 60, 18));
    }

    private void run() {
        BuildmaticSession session = screen.sessionOrNull();
        BuildmaticSession.OpenSchematic open = session == null ? null : session.active();
        Minecraft client = Minecraft.getInstance();
        if (open == null || client.level == null) {
            status = "No schematic is open";
            return;
        }
        var world = new LevelWorldView(client.level, BuildmaticClient.platform().schema());
        result = SchematicVerifier.verify(open.placement(), world);
        status = result.isComplete()
                ? "The build matches the schematic"
                : result.wrong() + " block(s) to fix";
    }

    @Override
    public void render(Canvas gfx, int mouseX, int mouseY) {
        var font = Minecraft.getInstance().font;
        if (result == null) {
            gfx.text(font, "No results yet.", contentX + 4, contentY + 8, BuildmaticScreen.TEXT_DIM);
            return;
        }

        int y = contentY + 6;
        gfx.text(font, String.format(Locale.ROOT, "Progress  %.1f%%", result.progress() * 100),
                contentX + 4, y, BuildmaticScreen.ACCENT);
        y += 16;

        // A bar reads faster than the number when checking a build repeatedly.
        int barWidth = 260;
        gfx.fill(contentX + 4, y, contentX + 4 + barWidth, y + 6, 0x40000000);
        gfx.fill(contentX + 4, y, contentX + 4 + (int) (barWidth * result.progress()), y + 6,
                BuildmaticScreen.GOOD);
        y += 18;

        y = line(gfx, y, "Correct", result.count(SchematicVerifier.Status.CORRECT), BuildmaticScreen.GOOD);
        y = line(gfx, y, "Missing", result.count(SchematicVerifier.Status.MISSING), BuildmaticScreen.BAD);
        y = line(gfx, y, "Wrong block", result.count(SchematicVerifier.Status.WRONG_BLOCK), BuildmaticScreen.BAD);
        y = line(gfx, y, "Wrong state", result.count(SchematicVerifier.Status.WRONG_STATE), 0xFFFFC66B);
        y = line(gfx, y, "Extra", result.count(SchematicVerifier.Status.EXTRA), 0xFFFFC66B);

        if (result.skippedUnloaded() > 0) {
            gfx.text(font, result.skippedUnloaded() + " position(s) in unloaded chunks - walk the "
                            + "perimeter and check again",
                    contentX + 4, y + 6, BuildmaticScreen.TEXT_DIM);
        }
    }

    private int line(Canvas gfx, int y, String label, int count, int colour) {
        var font = Minecraft.getInstance().font;
        gfx.text(font, label, contentX + 4, y, BuildmaticScreen.TEXT_DIM);
        gfx.text(font, Integer.toString(count), contentX + 110, y, colour);
        return y + 13;
    }

    @Override
    public String status() { return status; }
}
