package dev.buildmatic.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.buildmatic.client.BuildmaticSession;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.render.GhostSlice;
import dev.buildmatic.core.render.GhostSliceBuilder;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.platform.MinecraftStateSchema;
// Both eras submit their geometry to a collector and both call the same types BlockStateModel and
// BakedQuad - the packages moved and the quad gained a couple of record components, which is why
// the branching here is mostly imports rather than two renderers.
//? if >=26.1 {
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import com.mojang.blaze3d.vertex.QuadInstance;
import net.minecraft.client.resources.model.geometry.BakedQuad;
//?} elif >=1.21.9 {
/*import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.renderer.block.model.BlockStateModel;
import net.minecraft.client.renderer.block.model.BakedQuad;
*///?} elif >=1.21.5 {
/*import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.renderer.block.model.BlockStateModel;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.RenderType;
*///?} else {
/*import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.RenderType;
*///?}
import net.minecraft.client.Minecraft;
//? if >=1.21.9 {
import net.minecraft.client.renderer.rendertype.RenderTypes;
//?}
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.world.level.block.state.BlockState;
//? if >=26.1 {
import org.joml.Matrix4f;
//?}

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Draws the schematic preview into the world.
 *
 * <p>All the decisions about what to draw live in {@link GhostSliceBuilder}, which is plain Java and
 * unit-tested. This class only walks the resulting slice lists and hands them to Minecraft, which
 * keeps the version-specific surface small - and it needs to be small, because 26.1 replaced the
 * immediate-mode block renderer with a deferred submit-node collector.
 *
 * <p>Slices are cached and rebuilt only when the swap engine reports them dirty, so clicking one
 * block re-meshes one 16-cube rather than the whole build.
 */
public final class GhostRenderer {

    /**
     * Packed lightmap value for "fully lit", block light 15 and sky light 15. The ghost is drawn at
     * full brightness so a preview inside a dark building is still readable.
     */
    private static final int FULL_BRIGHT = 0x00F000F0;

    /** Hard cap on blocks drawn per frame, so pointing at a huge build cannot stall the client. */
    private static final int MAX_BLOCKS_PER_FRAME = 250_000;


    private final BuildmaticSession session;
    private final MinecraftStateSchema schema;

    private final Map<SwapEngine.ChunkKey, GhostSlice> slices = new HashMap<>();
    //? if >=26.1 {
    private final BlockModelRenderState renderState = new BlockModelRenderState();
    //?}
    //? if >=26.1 {
    private final Matrix4f identity = new Matrix4f();
    //?}
    /** Reused so a frame drawing a hundred thousand blocks does not allocate a hundred thousand arrays. */
    private int[] tintScratch = new int[1];

    private int drawnBlocksLastFrame;

    public GhostRenderer(BuildmaticSession session, MinecraftStateSchema schema) {
        this.session = session;
        this.schema = schema;
    }

    public void register() {
        // Submissions only get drawn from the phase that is still collecting them: level rendering
        // is deferred, so registering on a later event - after translucent terrain, say - silently
        // produces nothing at all. Fabric renamed the event group along with the context.
        //? if >=26.1 {
        LevelRenderEvents.COLLECT_SUBMITS.register(this::render);
        //?} elif >=1.21.9 {
        /*WorldRenderEvents.AFTER_ENTITIES.register(this::render);
        *///?} else {
        /*// Older versions draw as they go rather than collecting, so the ghost goes down after
        // the translucent terrain pass - late enough to sit on top of the world, early enough to
        // be depth-tested against it.
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
        *///?}
    }

    public int drawnBlocksLastFrame() { return drawnBlocksLastFrame; }

    /** Drops every cached slice; call when a schematic is closed, moved or reloaded. */
    public void invalidate() {
        slices.clear();
        geometry.clear();
        bounds.clear();
        positions.clear();
    }

    /**
     * Drops the one slice a changed world block falls in.
     *
     * <p>Both "hide blocks already built" and the red tint read the world, so the mesh has to
     * follow what gets built. This used to be a full cache wipe on a one-second timer, which
     * re-meshed an entire build sixty times a minute no matter how little had happened. A single
     * block only ever affects the 16-cube around it.
     */
    public void onWorldBlockChanged(int x, int y, int z) {
        if (slices.isEmpty()) return;
        if (!config().hidePlaced() && !config().highlightErrors()) return;

        SchematicPlacement placement = session.activePlacement();
        if (placement == null) return;

        Vec3i local = placement.toSchematic(new Vec3i(x, y, z));
        for (SchematicRegion region : placement.schematic().regions()) {
            Vec3i inRegion = local.subtract(region.origin());
            if (!region.contains(inRegion.x(), inRegion.y(), inRegion.z())) continue;

            SwapEngine.ChunkKey key = SwapEngine.ChunkKey.of(region.name(), inRegion);
            forget(key);
            return;
        }
    }

    //? if >=26.1 {
    private void render(LevelRenderContext context) {
    //?} else {
    /*private void render(WorldRenderContext context) {
    *///?}
        BuildmaticSession.OpenSchematic open = session.active();
        if (open == null) return;

        SchematicPlacement placement = session.activePlacement();
        if (placement == null || !placement.isEnabled()) return;

        refreshDirtySlices(open.swaps(), placement);

        //? if >=26.1 {
        var camera = context.levelState().cameraRenderState.pos;
        var frustum = context.levelState().cameraRenderState.cullFrustum;
        PoseStack poseStack = context.poseStack();
        //?} elif >=1.21.9 {
        /*var camera = context.worldState().cameraRenderState.pos;
        // 1.21.9's camera state carries no frustum, so slices are not culled there. It costs
        // frames on a big build rather than correctness, and is the one gap in this file worth
        // revisiting if that target ever feels slow.
        net.minecraft.client.renderer.culling.Frustum frustum = null;
        PoseStack poseStack = context.matrices();
        *///?} else {
        /*var camera = context.camera().getPosition();
        var frustum = context.frustum();
        PoseStack poseStack = context.matrixStack();
        *///?}
        drawnBlocksLastFrame = 0;
        boolean translucent = config().previewAlpha() < 0.99f;

        slices:
        for (SchematicRegion region : open.schematic().regions()) {
            if (!placement.isRegionVisible(region)) continue;

            for (SwapEngine.ChunkKey key : GhostSliceBuilder.slicesOf(region)) {
                // Cull the whole 16-cube before touching its contents; off-screen slices are the
                // common case as soon as the player stands inside a large build.
                if (frustum != null && !frustum.isVisible(boundsOf(key, region, placement))) {
                    continue;
                }

                GhostSlice slice = slices.computeIfAbsent(key,
                        k -> GhostSliceBuilder.build(region, k, contextFor(placement, open.swaps())));
                if (slice.isEmpty()) continue;

                if (translucent) {
                    drawnBlocksLastFrame += drawTranslucentSlice(
                            key, slice, region, placement, poseStack, camera, context);
                    continue;
                }

                // World positions are resolved once per slice, not once per block per frame:
                // toWorld allocates, and at fifty thousand blocks that was a hundred thousand
                // short-lived objects every frame.
                int[] positions = positionsOf(key, slice, region, placement);
                List<GhostSlice.Entry> entries = slice.entries();

                for (int i = 0; i < entries.size(); i++) {
                    if (drawnBlocksLastFrame >= MAX_BLOCKS_PER_FRAME) break slices;

                    poseStack.pushPose();
                    poseStack.translate(
                            positions[i * 3] - camera.x(),
                            positions[i * 3 + 1] - camera.y(),
                            positions[i * 3 + 2] - camera.z());

                    submit(entries.get(i), poseStack, context);

                    poseStack.popPose();
                    drawnBlocksLastFrame++;
                }
            }
        }

        //? if <1.21.9 {
        /*// Drawing immediately means the vertices are only queued, not drawn: the buffer source
        // flushes when the game gets round to it, by which point the model-view matrix belongs to
        // something else entirely. That is a ghost that will not stay on its own coordinates and
        // jitters as the camera moves. Flushing here pins it to the matrix it was built with.
        if (context.consumers() instanceof net.minecraft.client.renderer.MultiBufferSource.BufferSource batch) {
            batch.endBatch();
        }
        *///?}
    }

    //? if >=26.1 {
    private void submit(GhostSlice.Entry entry, PoseStack poseStack, LevelRenderContext context) {
        BlockState state = schema.toBlockState(entry.state());
        if (state.isAir()) return;

        BlockStateModel model = Minecraft.getInstance().getModelManager()
                .getBlockStateModelSet().get(state);
        if (model == null) return;

        renderState.clear();
        var parts = renderState.setupModel(identity, false);
        // The seed keeps randomised models (grass, flowers) stable between frames.
        model.collectParts(renderState.scratchRandomSource(entry.localPos().pack()), parts);
        if (renderState.isEmpty()) return;

        int outline = outlineOf(entry);
        if (outline != 0) {
            // A coloured outline is drawn as its own pass; the model itself still needs a zero
            // outline or the whole block turns into a flat silhouette in that colour.
            renderState.submitOnlyOutline(poseStack, context.submitNodeCollector(),
                    FULL_BRIGHT, OverlayTexture.NO_OVERLAY, outline);
        }

        renderState.submit(poseStack, context.submitNodeCollector(),
                FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 0);
    }
    //?} elif >=1.21.9 {
    /*private void submit(GhostSlice.Entry entry, PoseStack poseStack, WorldRenderContext context) {
        BlockState state = schema.toBlockState(entry.state());
        if (state.isAir()) return;

        // Simpler than 26.1's: the collector takes the whole block, model lookup included, and
        // carries the outline colour itself rather than needing a second pass for it.
        context.commandQueue().submitBlock(poseStack, state,
                FULL_BRIGHT, OverlayTexture.NO_OVERLAY, outlineOf(entry));
    }
    *///?} else {
    /*private void submit(GhostSlice.Entry entry, PoseStack poseStack, WorldRenderContext context) {
        BlockState state = schema.toBlockState(entry.state());
        if (state.isAir()) return;

        // Immediate mode: the dispatcher writes the block straight into the buffer source. There is
        // nowhere to hang an outline colour here, so a wrong block is signalled by the translucent
        // path's tint alone on these versions.
        Minecraft.getInstance().getBlockRenderer().renderSingleBlock(
                state, poseStack, context.consumers(), FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
    }
    *///?}

    // --- translucent path ------------------------------------------------------------------------

    /**
     * A run of quads sharing one colour, already moved into slice-local space.
     *
     * <p>Pre-offsetting is what allows a whole slice to go down under a single pose.
     * {@link VertexConsumer#putBakedQuad} transforms by the pose it is given and nothing else, so
     * the block's position has to be baked into the quad rather than pushed onto the stack.
     */
    private record ColouredQuads(int colour, List<BakedQuad> quads) {}

    /** Cached geometry per slice, rebuilt only when the slice is. */
    private final Map<SwapEngine.ChunkKey, List<ColouredQuads>> geometry = new HashMap<>();

    /**
     * Draws a whole 16-cube see-through in one submission.
     *
     * <p>This is the shape of Litematica's renderer: build the geometry once per chunk, keep it,
     * and replay it. Collecting quads per block per frame - which is what this did before - meant a
     * few tens of thousands of allocations every frame and a hard cap to stop it stuttering.
     * {@code putBlockBakedQuad} takes the block offset directly, so an entire slice goes through a
     * single pose and a single callback.
     */
    //? if >=26.1 {
    private int drawTranslucentSlice(SwapEngine.ChunkKey key, GhostSlice slice,
                                     SchematicRegion region, SchematicPlacement placement,
                                     PoseStack poseStack, net.minecraft.world.phys.Vec3 camera,
                                     LevelRenderContext context) {
    //?} else {
    /*private int drawTranslucentSlice(SwapEngine.ChunkKey key, GhostSlice slice,
                                     SchematicRegion region, SchematicPlacement placement,
                                     PoseStack poseStack, net.minecraft.world.phys.Vec3 camera,
                                     WorldRenderContext context) {
    *///?}
        List<ColouredQuads> groups = geometry.computeIfAbsent(key,
                k -> buildGeometry(slice, region, placement));
        if (groups.isEmpty()) return 0;

        // The pose sits on the slice's own corner; the quads already carry their offset from it.
        Vec3i anchor = sliceAnchor(region, key, placement);

        poseStack.pushPose();
        poseStack.translate(anchor.x() - camera.x(), anchor.y() - camera.y(), anchor.z() - camera.z());

        //? if >=26.1 {
        context.submitNodeCollector().submitCustomGeometry(
                poseStack,
                RenderTypes.entityTranslucent(TextureAtlas.LOCATION_BLOCKS),
                (pose, consumer) -> {
                    QuadInstance instance = new QuadInstance();
                    instance.setLightCoords(FULL_BRIGHT);
                    instance.setOverlayCoords(OverlayTexture.NO_OVERLAY);
                    for (ColouredQuads group : groups) {
                        instance.setColor(group.colour());
                        for (BakedQuad quad : group.quads()) {
                            consumer.putBakedQuad(pose, quad, instance);
                        }
                    }
                });
        //?} elif >=1.21.9 {
        /*context.commandQueue().submitCustomGeometry(
                poseStack,
                RenderTypes.entityTranslucent(TextureAtlas.LOCATION_BLOCKS),
                (pose, consumer) -> {
                    // No QuadInstance to carry the colour before 26.1: the tint goes in per quad,
                    // unpacked from the same packed ARGB the groups are keyed by.
                    for (ColouredQuads group : groups) {
                        int colour = group.colour();
                        for (BakedQuad quad : group.quads()) {
                            consumer.putBulkData(pose, quad,
                                    red(colour), green(colour), blue(colour), alpha(colour),
                                    FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
                        }
                    }
                });
        *///?} elif >=1.20.5 {
        /*var consumer = context.consumers().getBuffer(
                RenderType.entityTranslucent(TextureAtlas.LOCATION_BLOCKS));
        var pose = poseStack.last();
        for (ColouredQuads group : groups) {
            int colour = group.colour();
            for (BakedQuad quad : group.quads()) {
                consumer.putBulkData(pose, quad,
                        red(colour), green(colour), blue(colour), alpha(colour),
                        FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
            }
        }
        *///?} else {
        /*// The same immediate-mode draw, but the older call has no alpha channel: transparency
        // comes from the render type alone, so the preview's opacity slider does not reach these
        // versions.
        var consumer = context.consumers().getBuffer(
                RenderType.entityTranslucent(TextureAtlas.LOCATION_BLOCKS));
        var pose = poseStack.last();
        for (ColouredQuads group : groups) {
            int colour = group.colour();
            for (BakedQuad quad : group.quads()) {
                consumer.putBulkData(pose, quad,
                        red(colour), green(colour), blue(colour),
                        FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
            }
        }
        *///?}

        poseStack.popPose();
        return slice.size();
    }

    // Colour channels out of the packed ARGB the quad groups are keyed by.
    private static float alpha(int argb) { return (argb >>> 24) / 255f; }

    private static float red(int argb) { return ((argb >> 16) & 0xFF) / 255f; }

    private static float green(int argb) { return ((argb >> 8) & 0xFF) / 255f; }

    private static float blue(int argb) { return (argb & 0xFF) / 255f; }

    private static Vec3i sliceAnchor(SchematicRegion region, SwapEngine.ChunkKey key,
                                     SchematicPlacement placement) {
        return placement.toWorld(region.origin()
                .add(key.cx() << 4, key.cy() << 4, key.cz() << 4));
    }

    /**
     * Collects a slice's quads once, each one shifted into slice-local space.
     *
     * <p>Blocks sharing a colour - which is nearly all of them - are merged into one group, so a
     * full slice usually costs a single colour change rather than one per block.
     */
    private List<ColouredQuads> buildGeometry(GhostSlice slice, SchematicRegion region,
                                              SchematicPlacement placement) {
        Vec3i anchor = sliceAnchor(region, slice.key(), placement);

        Map<Integer, List<BakedQuad>> byColour = new java.util.LinkedHashMap<>();

        for (GhostSlice.Entry entry : slice.entries()) {
            BlockState state = schema.toBlockState(entry.state());
            if (state.isAir()) continue;

            //? if >=26.1 {
            BlockStateModel model =
                    Minecraft.getInstance().getModelManager().getBlockStateModelSet().get(state);
            if (model == null) continue;

            renderState.clear();
            var parts = renderState.setupModel(identity, true);
            model.collectParts(renderState.scratchRandomSource(entry.localPos().pack()), parts);
            if (renderState.isEmpty()) continue;
            //?} elif >=1.21.5 {
            /*BlockStateModel model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
            if (model == null) continue;

            // The seed keeps randomised models (grass, flowers) stable between frames.
            var parts = model.collectParts(
                    net.minecraft.util.RandomSource.create(entry.localPos().pack()));
            if (parts.isEmpty()) continue;
            *///?} else {
            /*// Older models are asked for their quads a face at a time rather than handing over
            // parts, so there is nothing to collect first.
            var model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
            if (model == null) continue;
            var random = net.minecraft.util.RandomSource.create(entry.localPos().pack());
            *///?}

            // A rotated placement means the offset is not simply the local position, so the world
            // position is resolved here and expressed relative to the slice corner.
            Vec3i world = placement.toWorld(region.origin().add(entry.localPos()));
            float dx = world.x() - anchor.x();
            float dy = world.y() - anchor.y();
            float dz = world.z() - anchor.z();

            List<BakedQuad> target = byColour.computeIfAbsent(
                    config().alphaMask() | statusColour(entry), c -> new ArrayList<>());

            //? if >=1.21.5 {
            for (var part : parts) {
                offsetInto(target, part.getQuads(null), dx, dy, dz);
                for (net.minecraft.core.Direction face : net.minecraft.core.Direction.values()) {
                    offsetInto(target, part.getQuads(face), dx, dy, dz);
                }
            }
            //?} else {
            /*offsetInto(target, model.getQuads(state, null, random), dx, dy, dz);
            for (net.minecraft.core.Direction face : net.minecraft.core.Direction.values()) {
                offsetInto(target, model.getQuads(state, face, random), dx, dy, dz);
            }
            *///?}
        }

        List<ColouredQuads> groups = new ArrayList<>(byColour.size());
        for (var e : byColour.entrySet()) {
            if (!e.getValue().isEmpty()) groups.add(new ColouredQuads(e.getKey(), e.getValue()));
        }
        return groups;
    }

    /** Copies quads with their vertices moved, since a quad's position is fixed at bake time. */
    private static void offsetInto(List<BakedQuad> target, List<BakedQuad> source,
                                   float dx, float dy, float dz) {
        // 26.1 folded tint, sprite, shading and light emission into one materialInfo record; before
        // that they are four separate components of the quad.
        for (BakedQuad quad : source) {
            //? if >=26.1 {
            target.add(new BakedQuad(
                    shift(quad.position0(), dx, dy, dz),
                    shift(quad.position1(), dx, dy, dz),
                    shift(quad.position2(), dx, dy, dz),
                    shift(quad.position3(), dx, dy, dz),
                    quad.packedUV0(), quad.packedUV1(), quad.packedUV2(), quad.packedUV3(),
                    quad.direction(), quad.materialInfo()));
            //?} elif >=1.21.9 {
            /*target.add(new BakedQuad(
                    shift(quad.position0(), dx, dy, dz),
                    shift(quad.position1(), dx, dy, dz),
                    shift(quad.position2(), dx, dy, dz),
                    shift(quad.position3(), dx, dy, dz),
                    quad.packedUV0(), quad.packedUV1(), quad.packedUV2(), quad.packedUV3(),
                    quad.tintIndex(), quad.direction(), quad.sprite(), quad.shade(),
                    quad.lightEmission()));
            *///?} elif >=1.21.5 {
            /*target.add(new BakedQuad(offsetVertices(quad.vertices(), dx, dy, dz),
                    quad.tintIndex(), quad.direction(), quad.sprite(), quad.shade(),
                    quad.lightEmission()));
            *///?} elif >=1.21.2 {
            /*// Same packed vertices, but the quad is a plain class here rather than a record.
            target.add(new BakedQuad(offsetVertices(quad.getVertices(), dx, dy, dz),
                    quad.getTintIndex(), quad.getDirection(), quad.getSprite(), quad.isShade(),
                    quad.getLightEmission()));
            *///?} else {
            /*// Older still: quads carry no light emission of their own.
            target.add(new BakedQuad(offsetVertices(quad.getVertices(), dx, dy, dz),
                    quad.getTintIndex(), quad.getDirection(), quad.getSprite(), quad.isShade()));
            *///?}
        }
    }

    //? if >=1.21.9 {
    private static org.joml.Vector3fc shift(org.joml.Vector3fc position,
                                            float dx, float dy, float dz) {
        return new org.joml.Vector3f(position.x() + dx, position.y() + dy, position.z() + dz);
    }
    //?} else {
    /*// One vertex of the block format: position, colour, uv, light and normal, as eight ints.
    private static final int VERTEX_STRIDE = 8;

    // Moves a quad's vertices, which older versions keep as raw packed ints. The three floats at
    // the start of each vertex are the position, stored as their bit patterns; everything after
    // them is colour, texture and lighting, and is copied untouched.
    private static int[] offsetVertices(int[] vertices, float dx, float dy, float dz) {
        int[] moved = vertices.clone();
        for (int v = 0; v + VERTEX_STRIDE <= moved.length; v += VERTEX_STRIDE) {
            moved[v] = Float.floatToRawIntBits(Float.intBitsToFloat(moved[v]) + dx);
            moved[v + 1] = Float.floatToRawIntBits(Float.intBitsToFloat(moved[v + 1]) + dy);
            moved[v + 2] = Float.floatToRawIntBits(Float.intBitsToFloat(moved[v + 2]) + dz);
        }
        return moved;
    }
    *///?}

    /**
     * White for everything except a mismatch, which goes hard red.
     *
     * <p>Only the problem is coloured. Tinting the correct blocks green as well made two thirds of
     * a half-finished build coloured, which buried the handful of places that actually need
     * attention - and those are the whole reason to look.
     */
    private int statusColour(GhostSlice.Entry entry) {
        if (!config().highlightErrors()) return 0xFFFFFF;
        return entry.status() == GhostSlice.Status.WRONG ? 0xFF1010 : 0xFFFFFF;
    }

    /**
     * The outline colour carried alongside the model, which is how a block's status is signalled:
     * red for wrong, blue for missing, none for a plain preview.
     */
    /**
     * The outline colour for a block, or 0 for none.
     *
     * <p>Only mistakes get one. Outlining every block would drown the preview in colour, and a
     * non-zero outline is expensive: it costs a second submission per block.
     */
    private int outlineOf(GhostSlice.Entry entry) {
        if (!config().highlightErrors()) return 0;
        return entry.status() == GhostSlice.Status.WRONG ? 0xFFFF5050 : 0;
    }

    private dev.buildmatic.client.BuildmaticConfig config() {
        return session.config();
    }

    /** Drops every cached form of one slice. The four caches must never disagree. */
    private void forget(SwapEngine.ChunkKey key) {
        slices.remove(key);
        geometry.remove(key);
        positions.remove(key);
        bounds.remove(key);
    }

    private final Map<SwapEngine.ChunkKey, net.minecraft.world.phys.AABB> bounds = new HashMap<>();
    /** Flattened x,y,z triples per slice entry, for the opaque path. */
    private final Map<SwapEngine.ChunkKey, int[]> positions = new HashMap<>();

    /** The culling box for a slice, computed once - it only moves when the placement does. */
    private net.minecraft.world.phys.AABB boundsOf(SwapEngine.ChunkKey key, SchematicRegion region,
                                                   SchematicPlacement placement) {
        return bounds.computeIfAbsent(key, k -> sliceBounds(region, k, placement));
    }

    private int[] positionsOf(SwapEngine.ChunkKey key, GhostSlice slice, SchematicRegion region,
                              SchematicPlacement placement) {
        return positions.computeIfAbsent(key, k -> {
            List<GhostSlice.Entry> entries = slice.entries();
            int[] out = new int[entries.size() * 3];
            for (int i = 0; i < entries.size(); i++) {
                Vec3i world = placement.toWorld(region.origin().add(entries.get(i).localPos()));
                out[i * 3] = world.x();
                out[i * 3 + 1] = world.y();
                out[i * 3 + 2] = world.z();
            }
            return out;
        });
    }

    /** The world-space box a slice occupies, for frustum culling. */
    private static net.minecraft.world.phys.AABB sliceBounds(
            SchematicRegion region, SwapEngine.ChunkKey key, SchematicPlacement placement) {
        Vec3i min = region.origin().add(key.cx() << 4, key.cy() << 4, key.cz() << 4);
        Vec3i max = min.add(15, 15, 15);
        Vec3i a = placement.toWorld(min);
        Vec3i b = placement.toWorld(max);
        return new net.minecraft.world.phys.AABB(
                Math.min(a.x(), b.x()), Math.min(a.y(), b.y()), Math.min(a.z(), b.z()),
                Math.max(a.x(), b.x()) + 1, Math.max(a.y(), b.y()) + 1, Math.max(a.z(), b.z()) + 1);
    }

    private GhostSliceBuilder.Context contextFor(SchematicPlacement placement, SwapEngine swaps) {
        GhostSliceBuilder.Context context = GhostSliceBuilder.Context.of(placement, swaps)
                .withOcclusion(dev.buildmatic.core.render.OcclusionOracle.HEURISTIC);

        // Reading the world costs a lookup per block, so only do it when the answer is used -
        // either to tint mistakes or to hide what is already built.
        var client = Minecraft.getInstance();
        if ((config().highlightErrors() || config().hidePlaced()) && client.level != null) {
            context = context.withWorld(
                    new dev.buildmatic.platform.LevelWorldView(client.level, schema));
        }
        if (config().hidePlaced()) {
            context = context.withFilter(GhostSliceBuilder.Filter.MISSING);
        }
        return context;
    }

    /**
     * Re-meshes only the slices the swap engine flagged.
     *
     * <p>This is the payoff for the engine tracking dirt at 16-cube granularity: a whole-build
     * material swap re-meshes everything once, while a single clicked block re-meshes one slice.
     */
    private void refreshDirtySlices(SwapEngine swaps, SchematicPlacement placement) {
        if (!swaps.hasDirtyChunks()) return;

        Set<SwapEngine.ChunkKey> dirty = swaps.consumeDirtyChunks();
        List<SchematicRegion> regions = new ArrayList<>(placement.schematic().regions());

        for (SwapEngine.ChunkKey key : dirty) {
            SchematicRegion region = null;
            for (SchematicRegion candidate : regions) {
                if (candidate.name().equals(key.regionName())) {
                    region = candidate;
                    break;
                }
            }
            if (region == null) {
                forget(key);
                continue;
            }
            slices.put(key, GhostSliceBuilder.build(region, key, contextFor(placement, swaps)));
            // The cached quads and positions belong to the old contents of this slice.
            geometry.remove(key);
            positions.remove(key);
        }
    }
}
