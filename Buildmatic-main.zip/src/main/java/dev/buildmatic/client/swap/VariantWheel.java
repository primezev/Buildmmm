package dev.buildmatic.client.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.block.PropertyTranslator;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapRule;
import dev.buildmatic.core.swap.SwapScopes;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.VariantIndex;

import java.util.List;

/**
 * The state behind the radial variant picker.
 *
 * <p>Deliberately free of Minecraft types: the wheel is a small state machine over a candidate
 * list, and keeping it here means the interaction can be driven from a test rather than only by
 * moving a real mouse. The client screen is a thin renderer on top of it.
 *
 * <p>The wheel opens on the block the player is looking at, shows one ring of candidates, and
 * commits to a {@link SwapRule} whose breadth depends on the held modifier.
 */
public final class VariantWheel {

    /** How many candidates fit on the ring before the list needs paging. */
    public static final int RING_CAPACITY = 12;

    private final VariantIndex variants;
    private final BlockStateSchema schema;

    private boolean open;
    private SchematicRegion region;
    private Vec3i localPos;
    private BlockStateRef target;

    private VariantIndex.Axis axis = VariantIndex.Axis.MATERIAL;
    private SwapScopes.Strictness strictness = SwapScopes.Strictness.SAME_BLOCK;
    private boolean familiesOnly;
    private String search = "";

    private List<VariantIndex.Candidate> candidates = List.of();
    private int page;
    private int hovered = -1;

    public VariantWheel(VariantIndex variants, BlockStateSchema schema) {
        this.variants = variants;
        this.schema = schema;
    }

    // --- lifecycle -----------------------------------------------------------------------------

    /**
     * Opens the wheel on a block of the ghost preview.
     *
     * @param state the block as it currently renders, after any swaps already applied
     */
    public void open(SchematicRegion region, Vec3i localPos, BlockStateRef state) {
        this.open = true;
        this.region = region;
        this.localPos = localPos;
        this.target = state;
        this.search = "";
        this.page = 0;
        this.hovered = -1;
        refresh();
    }

    public void close() {
        open = false;
        candidates = List.of();
        hovered = -1;
    }

    public boolean isOpen() { return open; }

    public BlockStateRef target() { return target; }

    public SchematicRegion region() { return region; }

    public Vec3i localPos() { return localPos; }

    // --- query controls ------------------------------------------------------------------------

    public VariantIndex.Axis axis() { return axis; }

    /** Flips between "other materials, same shape" and "other shapes, same material". */
    public void setAxis(VariantIndex.Axis axis) {
        if (this.axis == axis) return;
        this.axis = axis;
        page = 0;
        hovered = -1;
        refresh();
    }

    public void toggleAxis() {
        setAxis(axis == VariantIndex.Axis.MATERIAL
                ? VariantIndex.Axis.SHAPE
                : VariantIndex.Axis.MATERIAL);
    }

    public String search() { return search; }

    public void setSearch(String search) {
        String next = search == null ? "" : search;
        if (this.search.equals(next)) return;
        this.search = next;
        page = 0;
        hovered = -1;
        refresh();
    }

    public boolean familiesOnly() { return familiesOnly; }

    /** Restricts the ring to the block's own material family, which is usually what is wanted. */
    public void setFamiliesOnly(boolean familiesOnly) {
        if (this.familiesOnly == familiesOnly) return;
        this.familiesOnly = familiesOnly;
        page = 0;
        hovered = -1;
        refresh();
    }

    public SwapScopes.Strictness strictness() { return strictness; }

    public void setStrictness(SwapScopes.Strictness strictness) { this.strictness = strictness; }

    private void refresh() {
        if (!open || target == null) {
            candidates = List.of();
            return;
        }
        VariantIndex.Query query = new VariantIndex.Query(
                axis, search, target.namespace(), familiesOnly, 512);
        candidates = variants.candidates(target.blockId(), query);
        if (page > maxPage()) page = maxPage();
    }

    // --- ring navigation -----------------------------------------------------------------------

    public List<VariantIndex.Candidate> allCandidates() { return candidates; }

    /** The slice of candidates currently drawn on the ring. */
    public List<VariantIndex.Candidate> ring() {
        int from = page * RING_CAPACITY;
        if (from >= candidates.size()) return List.of();
        int to = Math.min(from + RING_CAPACITY, candidates.size());
        return candidates.subList(from, to);
    }

    public int page() { return page; }

    public int maxPage() {
        if (candidates.isEmpty()) return 0;
        return (candidates.size() - 1) / RING_CAPACITY;
    }

    public void nextPage() {
        if (page < maxPage()) {
            page++;
            hovered = -1;
        }
    }

    public void previousPage() {
        if (page > 0) {
            page--;
            hovered = -1;
        }
    }

    /** Index into {@link #ring()}, or -1 when the cursor sits in the dead zone at the centre. */
    public int hovered() { return hovered; }

    public void setHovered(int index) {
        hovered = index >= 0 && index < ring().size() ? index : -1;
    }

    /**
     * Maps a cursor offset from the wheel centre onto a ring slot.
     *
     * <p>Slot 0 sits at the top and they run clockwise, matching how the ring is drawn. Inside
     * {@code deadZone} nothing is selected, so releasing the key without moving cancels rather than
     * picking whatever happened to be under the crosshair.
     */
    public void hoverAt(double dx, double dy, double deadZone) {
        int slots = ring().size();
        if (slots == 0) {
            hovered = -1;
            return;
        }
        double distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < deadZone) {
            hovered = -1;
            return;
        }
        // atan2(dx, -dy) puts zero at the top and grows clockwise in screen coordinates,
        // where y points down.
        double angle = Math.atan2(dx, -dy);
        if (angle < 0) angle += Math.PI * 2;

        double slice = Math.PI * 2 / slots;
        hovered = (int) Math.floor((angle + slice / 2) / slice) % slots;
    }

    public VariantIndex.Candidate hoveredCandidate() {
        List<VariantIndex.Candidate> ring = ring();
        return hovered >= 0 && hovered < ring.size() ? ring.get(hovered) : null;
    }

    // --- outcome -------------------------------------------------------------------------------

    /**
     * The state the hovered candidate would produce, for the live in-world preview.
     *
     * <p>Returns null when nothing is hovered, so the caller can fall back to the unswapped block.
     */
    public BlockStateRef preview() {
        VariantIndex.Candidate candidate = hoveredCandidate();
        if (candidate == null) return null;
        return PropertyTranslator.translate(target, candidate.kind().blockId(), schema);
    }

    /**
     * The rule confirming the wheel would apply, or null when nothing is hovered.
     *
     * <p>Scope and matcher are chosen together: a narrow strictness with a wide scope means "every
     * block like this one in the build", while {@code alt} produces an explicit position set from a
     * flood fill.
     */
    public SwapRule buildRule(boolean floodFill) {
        VariantIndex.Candidate candidate = hoveredCandidate();
        if (candidate == null || region == null) return null;

        SwapRule.Target swapTarget = new SwapRule.Target.Block(candidate.kind().blockId());

        if (floodFill) {
            SwapScopes.FloodResult flood =
                    SwapScopes.flood(region, localPos, strictness, variants);
            return new SwapRule(new SwapRule.Matcher.Any(), swapTarget,
                    new SwapRule.Scope.Positions(region.name(), flood.positions()));
        }

        return switch (strictness) {
            case EXACT_STATE -> new SwapRule(new SwapRule.Matcher.Any(), swapTarget,
                    SwapScopes.single(region, localPos));
            case SAME_BLOCK -> new SwapRule(new SwapRule.Matcher.Block(target.blockId()),
                    swapTarget, SwapScopes.everywhere());
            case SAME_MATERIAL -> {
                VariantIndex.BlockKind kind = variants.kindOf(target.blockId());
                VariantIndex.BlockKind picked = candidate.kind();
                // Swapping a whole material is best expressed material-to-material, so every shape
                // in the build follows along rather than collapsing into the picked block.
                yield kind == null
                        ? new SwapRule(new SwapRule.Matcher.Block(target.blockId()), swapTarget,
                        SwapScopes.everywhere())
                        : new SwapRule(new SwapRule.Matcher.Material(kind.material()),
                        new SwapRule.Target.Material(picked.material()),
                        SwapScopes.everywhere());
            }
        };
    }

    /** The label the resulting swap layer carries in the layer list. */
    public String layerLabel(boolean floodFill) {
        VariantIndex.Candidate candidate = hoveredCandidate();
        if (candidate == null) return "";
        String from = VariantIndex.prettify(
                variants.kindOf(target.blockId()) != null
                        ? variants.kindOf(target.blockId()).material()
                        : target.path());
        String to = candidate.kind().materialDisplayName();
        if (floodFill) return from + " -> " + to + " (connected)";
        return switch (strictness) {
            case EXACT_STATE -> from + " -> " + to + " (one block)";
            case SAME_BLOCK -> target.path() + " -> " + candidate.kind().blockId();
            case SAME_MATERIAL -> from + " -> " + to + " (everything)";
        };
    }
}
