package dev.buildmatic.core.area;

import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A named area selection: one or more boxes sharing an origin.
 *
 * <p>Multi-box selections are what let a sparse build - two towers with a gap between them - be
 * captured without storing the empty space, and each box becomes a region in the saved schematic.
 *
 * <p>The origin is the point every box is measured from when the schematic is placed later. By
 * default it tracks the minimum corner of everything selected; pinning it lets a builder keep a
 * meaningful anchor (a door, a redstone input) even as the selection grows.
 */
public final class AreaSelection {

    /** How many boxes a selection may hold. */
    public enum Mode {
        /** One box, no naming, no origin fiddling. */
        SIMPLE,
        /** Any number of named boxes sharing an origin. */
        NORMAL
    }

    private String name;
    private Mode mode = Mode.NORMAL;

    private final List<SelectionBox> boxes = new ArrayList<>();
    private int selectedBox = -1;
    private SelectionBox.Corner selectedCorner = SelectionBox.Corner.NONE;
    /** True when the tool has hold of the origin rather than a box. */
    private boolean originGrabbed;

    private Vec3i explicitOrigin;

    public AreaSelection(String name) {
        this.name = name;
    }

    public String name() { return name; }

    public void setName(String name) { this.name = name; }

    public Mode mode() { return mode; }

    public void setMode(Mode mode) {
        this.mode = mode;
        // Dropping to Simple keeps the first box; the rest would be unreachable.
        if (mode == Mode.SIMPLE && boxes.size() > 1) {
            SelectionBox first = boxes.get(0);
            boxes.clear();
            boxes.add(first);
            selectedBox = 0;
        }
    }

    // --- boxes ---------------------------------------------------------------------------------

    public List<SelectionBox> boxes() { return Collections.unmodifiableList(boxes); }

    public int boxCount() { return boxes.size(); }

    public boolean isEmpty() { return boxes.isEmpty(); }

    /** The box the tool is acting on, creating a first one when the selection is empty. */
    public SelectionBox activeBox() {
        if (boxes.isEmpty()) {
            addBox(mode == Mode.SIMPLE ? "Selection" : "Region 1");
        }
        if (selectedBox < 0 || selectedBox >= boxes.size()) selectedBox = 0;
        return boxes.get(selectedBox);
    }

    public SelectionBox addBox(String name) {
        if (mode == Mode.SIMPLE && !boxes.isEmpty()) return boxes.get(0);
        SelectionBox box = new SelectionBox(uniqueName(name));
        boxes.add(box);
        selectedBox = boxes.size() - 1;
        selectedCorner = SelectionBox.Corner.NONE;
        return box;
    }

    /** Adds a box named "Region N", the default when the player presses "add sub-region". */
    public SelectionBox addBox() {
        return addBox("Region " + (boxes.size() + 1));
    }

    public boolean removeBox(SelectionBox box) {
        int index = boxes.indexOf(box);
        if (index < 0) return false;
        boxes.remove(index);
        if (selectedBox >= boxes.size()) selectedBox = boxes.size() - 1;
        return true;
    }

    public void renameBox(SelectionBox box, String newName) {
        if (boxes.contains(box)) box.setName(uniqueName(newName, box));
    }

    private String uniqueName(String candidate) {
        return uniqueName(candidate, null);
    }

    /** Box names become region names in the saved file, where duplicates would collide. */
    private String uniqueName(String candidate, SelectionBox ignoring) {
        String base = candidate == null || candidate.isBlank() ? "Region" : candidate.trim();
        String name = base;
        int suffix = 2;
        while (hasBoxNamed(name, ignoring)) {
            name = base + " " + suffix++;
        }
        return name;
    }

    private boolean hasBoxNamed(String name, SelectionBox ignoring) {
        for (SelectionBox box : boxes) {
            if (box != ignoring && box.name().equals(name)) return true;
        }
        return false;
    }

    // --- tool selection ------------------------------------------------------------------------

    public int selectedBoxIndex() { return selectedBox; }

    public SelectionBox selectedBox() {
        return selectedBox >= 0 && selectedBox < boxes.size() ? boxes.get(selectedBox) : null;
    }

    public void selectBox(int index) {
        selectedBox = index >= 0 && index < boxes.size() ? index : -1;
        selectedCorner = SelectionBox.Corner.NONE;
        originGrabbed = false;
    }

    public void selectBox(SelectionBox box) {
        selectBox(boxes.indexOf(box));
    }

    public SelectionBox.Corner selectedCorner() { return selectedCorner; }

    public void setSelectedCorner(SelectionBox.Corner corner) {
        selectedCorner = corner;
        originGrabbed = false;
    }

    public boolean isOriginGrabbed() { return originGrabbed; }

    public void grabOrigin() {
        originGrabbed = true;
        selectedCorner = SelectionBox.Corner.NONE;
    }

    /**
     * Cycles what the tool holds: the whole box, then each of its corners, then the next box.
     *
     * <p>This is what middle-click walks through, so a builder can grab a corner without opening a
     * menu.
     */
    public void cycleGrabbed() {
        if (boxes.isEmpty()) return;
        switch (selectedCorner) {
            case NONE -> selectedCorner = SelectionBox.Corner.CORNER_1;
            case CORNER_1 -> selectedCorner = SelectionBox.Corner.CORNER_2;
            case CORNER_2 -> {
                selectedCorner = SelectionBox.Corner.NONE;
                selectedBox = (selectedBox + 1) % boxes.size();
            }
        }
        originGrabbed = false;
    }

    // --- origin --------------------------------------------------------------------------------

    /** The point boxes are measured from: the pinned origin, or the minimum corner of everything. */
    public Vec3i origin() {
        if (explicitOrigin != null) return explicitOrigin;
        BlockBox bounds = bounds();
        return bounds == null ? Vec3i.ZERO : bounds.min();
    }

    public boolean hasExplicitOrigin() { return explicitOrigin != null; }

    public void setOrigin(Vec3i origin) { this.explicitOrigin = origin; }

    /** Lets the origin follow the selection again. */
    public void clearExplicitOrigin() { this.explicitOrigin = null; }

    // --- geometry ------------------------------------------------------------------------------

    /** The box enclosing every complete, enabled sub-region, or null when there is nothing yet. */
    public BlockBox bounds() {
        BlockBox result = null;
        for (SelectionBox box : boxes) {
            if (!box.isEnabled()) continue;
            BlockBox current = box.box();
            if (current == null) continue;
            result = result == null ? current : result.union(current);
        }
        return result;
    }

    public Vec3i size() {
        BlockBox bounds = bounds();
        return bounds == null ? Vec3i.ZERO : bounds.size();
    }

    /** Total blocks across every enabled sub-region, counting overlaps once per box. */
    public long volume() {
        long total = 0;
        for (SelectionBox box : boxes) {
            if (box.isEnabled()) total += box.volume();
        }
        return total;
    }

    public boolean hasCompleteBox() {
        for (SelectionBox box : boxes) {
            if (box.isEnabled() && box.isComplete()) return true;
        }
        return false;
    }

    /** Moves whatever the tool holds - a corner, a box, or the origin - one step. */
    public void nudge(Direction direction, int amount) {
        if (originGrabbed) {
            setOrigin(origin().offset(direction, amount));
            return;
        }
        SelectionBox box = selectedBox();
        if (box == null) return;
        if (selectedCorner == SelectionBox.Corner.NONE) box.move(direction, amount);
        else box.nudgeCorner(selectedCorner, direction, amount);
    }

    public AreaSelection copy() {
        AreaSelection copy = new AreaSelection(name);
        copy.mode = mode;
        copy.explicitOrigin = explicitOrigin;
        for (SelectionBox box : boxes) copy.boxes.add(box.copy());
        copy.selectedBox = selectedBox;
        copy.selectedCorner = selectedCorner;
        return copy;
    }

    @Override
    public String toString() {
        Vec3i size = size();
        return name + " [" + boxes.size() + " box(es), "
                + size.x() + "x" + size.y() + "x" + size.z() + "]";
    }
}
