package dev.buildmatic.core.area;

import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;

/**
 * One named box of an area selection.
 *
 * <p>Corners are kept exactly as the player clicked them rather than normalised, because the tool
 * lets you grab "corner 1" or "corner 2" individually and nudge it; swapping them behind the
 * player's back would make the grabbed corner jump to the other side of the box.
 */
public final class SelectionBox {

    /** Which corner the tool currently has hold of. */
    public enum Corner {
        NONE,
        CORNER_1,
        CORNER_2
    }

    private String name;
    private Vec3i corner1;
    private Vec3i corner2;
    private boolean enabled = true;

    public SelectionBox(String name) {
        this.name = name;
    }

    public SelectionBox(String name, Vec3i corner1, Vec3i corner2) {
        this.name = name;
        this.corner1 = corner1;
        this.corner2 = corner2;
    }

    public String name() { return name; }

    public void setName(String name) { this.name = name; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public Vec3i corner1() { return corner1; }

    public Vec3i corner2() { return corner2; }

    public void setCorner1(Vec3i pos) { this.corner1 = pos; }

    public void setCorner2(Vec3i pos) { this.corner2 = pos; }

    public Vec3i corner(Corner which) {
        return which == Corner.CORNER_1 ? corner1 : (which == Corner.CORNER_2 ? corner2 : null);
    }

    public void setCorner(Corner which, Vec3i pos) {
        if (which == Corner.CORNER_1) corner1 = pos;
        else if (which == Corner.CORNER_2) corner2 = pos;
    }

    /** True once both corners have been placed. */
    public boolean isComplete() { return corner1 != null && corner2 != null; }

    /** The normalised box, or null while a corner is still missing. */
    public BlockBox box() {
        return isComplete() ? BlockBox.of(corner1, corner2) : null;
    }

    public Vec3i size() {
        BlockBox box = box();
        return box == null ? Vec3i.ZERO : box.size();
    }

    public long volume() {
        BlockBox box = box();
        return box == null ? 0 : box.volume();
    }

    /**
     * Grows the box to include {@code pos}, which is how Expand mode builds a selection: right
     * click collapses it onto one block, then every left click pushes out whichever faces need to
     * move to swallow the clicked position.
     */
    public void expandToInclude(Vec3i pos) {
        if (corner1 == null || corner2 == null) {
            corner1 = pos;
            corner2 = pos;
            return;
        }
        Vec3i min = corner1.min(corner2).min(pos);
        Vec3i max = corner1.max(corner2).max(pos);
        corner1 = min;
        corner2 = max;
    }

    /** Collapses the box onto a single block, the starting point of an Expand-mode selection. */
    public void collapseTo(Vec3i pos) {
        corner1 = pos;
        corner2 = pos;
    }

    /** Moves one corner a block along {@code direction}. */
    public void nudgeCorner(Corner which, Direction direction, int amount) {
        Vec3i corner = corner(which);
        if (corner == null) return;
        setCorner(which, corner.offset(direction, amount));
    }

    /** Moves the whole box without changing its size. */
    public void move(Direction direction, int amount) {
        if (corner1 != null) corner1 = corner1.offset(direction, amount);
        if (corner2 != null) corner2 = corner2.offset(direction, amount);
    }

    public void moveTo(Vec3i newMin) {
        BlockBox box = box();
        if (box == null) return;
        Vec3i delta = newMin.subtract(box.min());
        corner1 = corner1.add(delta);
        corner2 = corner2.add(delta);
    }

    public SelectionBox copy() {
        SelectionBox copy = new SelectionBox(name, corner1, corner2);
        copy.enabled = enabled;
        return copy;
    }

    @Override
    public String toString() {
        BlockBox box = box();
        return box == null ? name + " (incomplete)" : name + " " + box;
    }
}
