package dev.buildmatic.core.area;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;

import java.util.List;

/**
 * Turns an {@link AreaSelection} into a {@link Schematic} by reading the world.
 *
 * <p>Each enabled sub-region becomes one schematic region positioned relative to the selection's
 * origin, so a sparse build costs only the boxes the player drew rather than the empty space
 * between them.
 *
 * <p>Unloaded chunks are counted and reported rather than saved as air. Litematica warns about this
 * with a "Missing Chunks" counter for good reason: a build saved while half its chunks were
 * unloaded looks fine until it is placed and half of it is gone.
 */
public final class WorldCapture {

    /** What a capture produced, and what it could not read. */
    public record Result(Schematic schematic, int unloadedPositions, int capturedBlocks,
                         int blockEntities, int entities) {

        public boolean isComplete() { return unloadedPositions == 0; }
    }

    private WorldCapture() {}

    /** Counts positions in unloaded chunks without reading anything, for the pre-save warning. */
    public static int countUnloaded(AreaSelection selection, WorldCaptureSource world) {
        int missing = 0;
        for (SelectionBox box : selection.boxes()) {
            if (!box.isEnabled()) continue;
            BlockBox bounds = box.box();
            if (bounds == null) continue;
            // Sampling every 16th block on each axis is enough: chunks are 16 wide, so a fully
            // unloaded chunk cannot hide between samples, and a large selection stays instant.
            for (int y = bounds.min().y(); y <= bounds.max().y(); y += 16) {
                for (int z = bounds.min().z(); z <= bounds.max().z(); z += 16) {
                    for (int x = bounds.min().x(); x <= bounds.max().x(); x += 16) {
                        if (!world.isLoaded(x, y, z)) missing++;
                    }
                }
            }
        }
        return missing;
    }

    public static Result capture(AreaSelection selection, WorldCaptureSource world,
                                 String name, String author) {
        Schematic schematic = new Schematic();
        schematic.metadata().setName(name == null || name.isBlank() ? selection.name() : name)
                .setAuthor(author == null ? "" : author);

        Vec3i origin = selection.origin();
        int unloaded = 0;
        int captured = 0;
        int blockEntities = 0;
        int entities = 0;

        for (SelectionBox box : selection.boxes()) {
            if (!box.isEnabled()) continue;
            BlockBox bounds = box.box();
            if (bounds == null) continue;

            Vec3i regionOrigin = bounds.min().subtract(origin);
            SchematicRegion region = new SchematicRegion(box.name(), regionOrigin, bounds.size());

            for (int y = 0; y < region.sizeY(); y++) {
                for (int z = 0; z < region.sizeZ(); z++) {
                    for (int x = 0; x < region.sizeX(); x++) {
                        int wx = bounds.min().x() + x;
                        int wy = bounds.min().y() + y;
                        int wz = bounds.min().z() + z;

                        if (!world.isLoaded(wx, wy, wz)) {
                            unloaded++;
                            continue;
                        }

                        BlockStateRef state = world.blockAt(wx, wy, wz);
                        if (state == null || state.isAir()) continue;

                        region.setBlock(x, y, z, state);
                        captured++;

                        NbtCompound blockEntity = world.blockEntityAt(wx, wy, wz);
                        if (blockEntity != null) {
                            NbtCompound stored = blockEntity.copy();
                            // Block entity coordinates are region-local on disk.
                            stored.putInt("x", x);
                            stored.putInt("y", y);
                            stored.putInt("z", z);
                            region.blockEntities().put(new Vec3i(x, y, z), stored);
                            blockEntities++;
                        }
                    }
                }
            }

            for (SchematicEntity entity : world.entitiesIn(bounds)) {
                region.entities().add(entity.withPosition(
                        entity.x() - bounds.min().x(),
                        entity.y() - bounds.min().y(),
                        entity.z() - bounds.min().z()));
                entities++;
            }

            schematic.addRegion(region);
        }

        if (schematic.regionCount() == 0) {
            // A selection with no usable boxes still has to produce something placeable.
            schematic.addRegion(new SchematicRegion("main", Vec3i.ZERO, new Vec3i(1, 1, 1)));
        }

        schematic.refreshStatistics();
        return new Result(schematic, unloaded, captured, blockEntities, entities);
    }
}
