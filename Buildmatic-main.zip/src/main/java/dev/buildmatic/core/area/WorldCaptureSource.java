package dev.buildmatic.core.area;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.util.BlockBox;

import java.util.List;

/**
 * Everything {@link WorldCapture} needs to read out of a live world.
 *
 * <p>Wider than {@link dev.buildmatic.core.verify.WorldView} because saving a build has to carry
 * chest contents, sign text and item frames, not just block states. Kept as an interface so the
 * capture logic can be driven from a hand-built fake world in tests.
 */
public interface WorldCaptureSource {

    BlockStateRef blockAt(int x, int y, int z);

    /** False when the chunk is not loaded; those positions are counted, not silently saved as air. */
    boolean isLoaded(int x, int y, int z);

    /** The block entity NBT at this position, or null. Coordinates are absolute world positions. */
    NbtCompound blockEntityAt(int x, int y, int z);

    /** Entities whose position falls inside the box, in world coordinates. */
    List<SchematicEntity> entitiesIn(BlockBox box);
}
