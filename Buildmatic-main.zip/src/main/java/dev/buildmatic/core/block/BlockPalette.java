package dev.buildmatic.core.block;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * An ordered, de-duplicated set of block states addressed by index.
 *
 * <p>Index 0 is always air. Every schematic format on disk makes the same guarantee, and holding to
 * it means a freshly allocated region is already all-air without touching the block storage.
 */
public final class BlockPalette {

    private final List<BlockStateRef> entries = new ArrayList<>();
    private final Map<BlockStateRef, Integer> indices = new HashMap<>();

    public BlockPalette() {
        add(BlockStateRef.AIR);
    }

    public static BlockPalette of(List<BlockStateRef> states) {
        BlockPalette palette = new BlockPalette();
        for (BlockStateRef state : states) palette.add(state);
        return palette;
    }

    /**
     * Builds a palette that preserves the exact order given, including index 0.
     *
     * <p>Format readers must use this: rewriting indices while parsing would invalidate every block
     * reference already decoded from the file.
     */
    public static BlockPalette verbatim(List<BlockStateRef> states) {
        BlockPalette palette = new BlockPalette();
        palette.entries.clear();
        palette.indices.clear();
        for (BlockStateRef state : states) {
            if (palette.indices.putIfAbsent(state, palette.entries.size()) == null) {
                palette.entries.add(state);
            } else {
                // Duplicated entries do occur in third-party files. Keep the slot so later indices
                // still line up, but point lookups at the first occurrence.
                palette.entries.add(state);
            }
        }
        if (palette.entries.isEmpty()) palette.add(BlockStateRef.AIR);
        return palette;
    }

    /** Returns the index of {@code state}, appending it when new. */
    public int add(BlockStateRef state) {
        Integer existing = indices.get(state);
        if (existing != null) return existing;
        int index = entries.size();
        entries.add(state);
        indices.put(state, index);
        return index;
    }

    /** Returns the index of {@code state}, or -1 when absent. */
    public int indexOf(BlockStateRef state) {
        Integer index = indices.get(state);
        return index == null ? -1 : index;
    }

    public BlockStateRef get(int index) {
        if (index < 0 || index >= entries.size()) return BlockStateRef.AIR;
        return entries.get(index);
    }

    public int size() { return entries.size(); }

    public List<BlockStateRef> entries() { return Collections.unmodifiableList(entries); }

    /** Replaces the state at {@code index} in place, keeping every block reference valid. */
    public void replace(int index, BlockStateRef state) {
        BlockStateRef previous = entries.get(index);
        if (previous.equals(state)) return;
        entries.set(index, state);
        // Only clear the reverse mapping if no other slot still holds the previous state.
        if (indices.get(previous) != null && indices.get(previous) == index) {
            indices.remove(previous);
            for (int i = 0; i < entries.size(); i++) {
                if (i != index && entries.get(i).equals(previous)) {
                    indices.put(previous, i);
                    break;
                }
            }
        }
        indices.putIfAbsent(state, index);
    }

    public BlockPalette copy() {
        BlockPalette copy = new BlockPalette();
        copy.entries.clear();
        copy.indices.clear();
        copy.entries.addAll(entries);
        copy.indices.putAll(indices);
        return copy;
    }

    @Override
    public String toString() {
        return "BlockPalette[" + entries.size() + " states]";
    }
}
