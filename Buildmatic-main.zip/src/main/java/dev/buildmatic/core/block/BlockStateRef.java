package dev.buildmatic.core.block;

import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A block state described purely by text: a namespaced id plus its property map.
 *
 * <p>This is the single most important type in Buildmatic. Because it never references a Minecraft
 * class, the whole schematic pipeline, variant index and swap engine work identically on every
 * supported game version, and a schematic edited on 1.19.2 stays meaningful on 26.2 even when the
 * block does not exist there yet. Conversion to and from the real registry happens once, at the
 * boundary, in the per-version platform layer.
 *
 * <p>Instances are immutable, canonical and interned, so equality and hashing are cheap even when a
 * schematic holds tens of millions of blocks.
 */
public final class BlockStateRef implements Comparable<BlockStateRef> {

    private static final ConcurrentHashMap<String, BlockStateRef> POOL = new ConcurrentHashMap<>();

    public static final String DEFAULT_NAMESPACE = "minecraft";

    public static final BlockStateRef AIR = of("minecraft:air");
    public static final BlockStateRef CAVE_AIR = of("minecraft:cave_air");
    public static final BlockStateRef VOID_AIR = of("minecraft:void_air");
    public static final BlockStateRef STRUCTURE_VOID = of("minecraft:structure_void");

    private final String blockId;
    private final Map<String, String> properties;
    private final String descriptor;
    private final int hash;

    private BlockStateRef(String blockId, Map<String, String> properties, String descriptor) {
        this.blockId = blockId;
        this.properties = properties;
        this.descriptor = descriptor;
        this.hash = descriptor.hashCode();
    }

    // --- construction --------------------------------------------------------------------------

    public static BlockStateRef of(String blockId) {
        return of(blockId, Collections.emptyMap());
    }

    public static BlockStateRef of(String blockId, Map<String, String> properties) {
        String id = normaliseId(blockId);
        // TreeMap keeps the descriptor canonical: two states with the same properties in a
        // different source order must intern to the same instance.
        Map<String, String> sorted = properties.isEmpty()
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(new TreeMap<>(properties));
        String descriptor = buildDescriptor(id, sorted);
        return POOL.computeIfAbsent(descriptor, d -> new BlockStateRef(id, sorted, d));
    }

    /**
     * Parses {@code minecraft:oak_stairs[facing=north,half=bottom]}. The bracket section and the
     * namespace are both optional.
     *
     * @throws IllegalArgumentException when the descriptor is malformed
     */
    public static BlockStateRef parse(String descriptor) {
        BlockStateRef cached = POOL.get(descriptor);
        if (cached != null) return cached;

        String text = descriptor.trim();
        if (text.isEmpty()) throw new IllegalArgumentException("empty block state descriptor");

        int bracket = text.indexOf('[');
        if (bracket < 0) {
            return of(text);
        }
        if (!text.endsWith("]")) {
            throw new IllegalArgumentException("unterminated property list in '" + descriptor + "'");
        }

        String id = text.substring(0, bracket).trim();
        String body = text.substring(bracket + 1, text.length() - 1).trim();
        if (body.isEmpty()) return of(id);

        Map<String, String> props = new LinkedHashMap<>();
        for (String pair : body.split(",")) {
            int eq = pair.indexOf('=');
            if (eq < 0) {
                throw new IllegalArgumentException(
                        "property '" + pair.trim() + "' has no value in '" + descriptor + "'");
            }
            String key = pair.substring(0, eq).trim();
            String value = pair.substring(eq + 1).trim();
            if (key.isEmpty()) {
                throw new IllegalArgumentException("empty property name in '" + descriptor + "'");
            }
            props.put(key, value);
        }
        return of(id, props);
    }

    /** Like {@link #parse} but returns {@code fallback} instead of throwing on malformed input. */
    public static BlockStateRef parseOrDefault(String descriptor, BlockStateRef fallback) {
        try {
            return parse(descriptor);
        } catch (RuntimeException e) {
            return fallback;
        }
    }

    private static String normaliseId(String raw) {
        String id = raw.trim().toLowerCase(Locale.ROOT);
        if (id.isEmpty()) throw new IllegalArgumentException("empty block id");
        int colon = id.indexOf(':');
        if (colon < 0) return DEFAULT_NAMESPACE + ':' + id;
        if (colon == 0) return DEFAULT_NAMESPACE + ':' + id.substring(1);
        return id;
    }

    private static String buildDescriptor(String id, Map<String, String> properties) {
        if (properties.isEmpty()) return id;
        StringBuilder sb = new StringBuilder(id.length() + properties.size() * 16);
        sb.append(id).append('[');
        boolean first = true;
        for (Map.Entry<String, String> e : properties.entrySet()) {
            if (!first) sb.append(',');
            first = false;
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.append(']').toString();
    }

    // --- accessors -----------------------------------------------------------------------------

    /** The full namespaced id, e.g. {@code minecraft:oak_stairs}. */
    public String blockId() { return blockId; }

    public String namespace() { return blockId.substring(0, blockId.indexOf(':')); }

    /** The id without its namespace, e.g. {@code oak_stairs}. */
    public String path() { return blockId.substring(blockId.indexOf(':') + 1); }

    public boolean isVanilla() { return blockId.startsWith("minecraft:"); }

    /** Property names sorted alphabetically, matching the descriptor. */
    public Map<String, String> properties() { return properties; }

    public String property(String key) { return properties.get(key); }

    public String property(String key, String fallback) {
        return properties.getOrDefault(key, fallback);
    }

    public boolean hasProperty(String key) { return properties.containsKey(key); }

    public boolean is(String key, String value) { return value.equals(properties.get(key)); }

    public boolean booleanProperty(String key, boolean fallback) {
        String v = properties.get(key);
        if (v == null) return fallback;
        return "true".equals(v);
    }

    public int intProperty(String key, int fallback) {
        String v = properties.get(key);
        if (v == null) return fallback;
        try {
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    /** The canonical {@code id[k=v,...]} form. Stable across runs and safe to persist. */
    public String descriptor() { return descriptor; }

    public boolean isAir() {
        return this == AIR || this == CAVE_AIR || this == VOID_AIR
                || blockId.equals("minecraft:air")
                || blockId.equals("minecraft:cave_air")
                || blockId.equals("minecraft:void_air");
    }

    /** Structure voids mean "leave whatever is here alone" rather than "place nothing". */
    public boolean isStructureVoid() {
        return blockId.equals("minecraft:structure_void");
    }

    /** True when the state occupies no space and needs no material to build. */
    public boolean isEmpty() { return isAir() || isStructureVoid(); }

    // --- derivation ----------------------------------------------------------------------------

    public BlockStateRef with(String key, String value) {
        if (value == null) return without(key);
        if (value.equals(properties.get(key))) return this;
        Map<String, String> next = new TreeMap<>(properties);
        next.put(key, value);
        return of(blockId, next);
    }

    public BlockStateRef with(String key, boolean value) {
        return with(key, Boolean.toString(value));
    }

    public BlockStateRef with(String key, int value) {
        return with(key, Integer.toString(value));
    }

    public BlockStateRef without(String key) {
        if (!properties.containsKey(key)) return this;
        Map<String, String> next = new TreeMap<>(properties);
        next.remove(key);
        return of(blockId, next);
    }

    public BlockStateRef withProperties(Map<String, String> replacement) {
        return of(blockId, replacement);
    }

    /**
     * Swaps the block while keeping every property.
     *
     * <p>Callers doing a variant swap should go through
     * {@code PropertyTranslator} instead, which drops properties the target block cannot accept.
     */
    public BlockStateRef withBlock(String newBlockId) {
        String id = normaliseId(newBlockId);
        if (id.equals(blockId)) return this;
        return of(id, properties);
    }

    /** Drops every property, yielding the bare block. */
    public BlockStateRef bare() {
        return properties.isEmpty() ? this : of(blockId);
    }

    public BlockStateRef rotate(Rotation rotation) {
        return PropertyTransforms.rotate(this, rotation);
    }

    public BlockStateRef mirror(Mirror mirror) {
        return PropertyTransforms.mirror(this, mirror);
    }

    // --- identity ------------------------------------------------------------------------------

    @Override
    public boolean equals(Object o) {
        // Interning makes reference equality the fast path; the descriptor check covers instances
        // that survived a pool eviction or arrived through deserialisation.
        if (this == o) return true;
        return o instanceof BlockStateRef other && descriptor.equals(other.descriptor);
    }

    @Override
    public int hashCode() { return hash; }

    @Override
    public int compareTo(BlockStateRef o) { return descriptor.compareTo(o.descriptor); }

    @Override
    public String toString() { return descriptor; }

    /** Number of distinct states interned so far; used by the debug overlay. */
    public static int internedCount() { return POOL.size(); }
}
