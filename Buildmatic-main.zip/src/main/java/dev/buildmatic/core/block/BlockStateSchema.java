package dev.buildmatic.core.block;

import java.util.List;
import java.util.Set;

/**
 * What properties a block accepts and what values are legal for them.
 *
 * <p>Only the running game knows this, so the platform layer implements it against the real block
 * registry. The core depends on the interface alone, which keeps swap translation testable and
 * lets a schematic loaded on one version still be reasoned about on another.
 */
public interface BlockStateSchema {

    /** Property names the block defines, or an empty set when the block is unknown. */
    Set<String> propertiesOf(String blockId);

    /** Legal values for a property, in the order the game declares them. */
    List<String> valuesOf(String blockId, String property);

    /** The block's default state, or a bare {@code BlockStateRef} when the block is unknown. */
    BlockStateRef defaultState(String blockId);

    /** True when the block exists in the running game. */
    boolean isKnownBlock(String blockId);

    default boolean accepts(String blockId, String property, String value) {
        List<String> values = valuesOf(blockId, property);
        return !values.isEmpty() && values.contains(value);
    }

    /** Strips any property the block does not define or cannot hold at that value. */
    default BlockStateRef sanitise(BlockStateRef state) {
        if (!isKnownBlock(state.blockId())) return state;
        BlockStateRef result = defaultState(state.blockId());
        for (var entry : state.properties().entrySet()) {
            if (accepts(state.blockId(), entry.getKey(), entry.getValue())) {
                result = result.with(entry.getKey(), entry.getValue());
            }
        }
        return result;
    }

    /**
     * A schema that accepts anything, for headless use and unit tests.
     *
     * <p>Translation still works with it - properties are copied verbatim - but nothing is
     * validated, so it must never be used to build states that get placed in a world.
     */
    BlockStateSchema PERMISSIVE = new BlockStateSchema() {
        @Override public Set<String> propertiesOf(String blockId) { return Set.of(); }
        @Override public List<String> valuesOf(String blockId, String property) { return List.of(); }
        @Override public BlockStateRef defaultState(String blockId) { return BlockStateRef.of(blockId); }
        @Override public boolean isKnownBlock(String blockId) { return true; }
        @Override public boolean accepts(String blockId, String property, String value) { return true; }
        @Override public BlockStateRef sanitise(BlockStateRef state) { return state; }
    };
}
