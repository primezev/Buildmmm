package dev.buildmatic.core.block;

import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Rotates and mirrors block states by rewriting their properties.
 *
 * <p>Vanilla implements this per block class, which is unavailable to a version-agnostic core. The
 * rules below are driven by property <em>names</em> instead, which covers every vanilla block and,
 * usefully, most modded ones too since mods reuse the same vocabulary.
 */
public final class PropertyTransforms {

    private PropertyTransforms() {}

    /** Properties holding a single {@link Direction} value. */
    private static final Set<String> DIRECTION_PROPERTIES = Set.of("facing");

    /** The four horizontal connection properties, permuted as a group. */
    private static final String[] CONNECTIONS = {"north", "east", "south", "west"};

    public static BlockStateRef rotate(BlockStateRef state, Rotation rotation) {
        if (rotation == Rotation.NONE || state.properties().isEmpty()) return state;

        Map<String, String> props = new TreeMap<>(state.properties());
        boolean changed = false;

        changed |= rotateDirections(props, rotation);
        changed |= rotateAxis(props, rotation);
        changed |= rotateRotationIndex(props, rotation);
        changed |= rotateConnections(props, rotation);
        changed |= rotateRailShape(props, rotation, Mirror.NONE);
        changed |= rotateOrientation(props, rotation, Mirror.NONE);

        return changed ? state.withProperties(props) : state;
    }

    public static BlockStateRef mirror(BlockStateRef state, Mirror mirror) {
        if (mirror == Mirror.NONE || state.properties().isEmpty()) return state;

        Map<String, String> props = new TreeMap<>(state.properties());
        // Captured before `facing` is rewritten - the stairs and door rules key off the original.
        Direction originalFacing = Direction.byName(props.getOrDefault("facing", ""));
        boolean changed = false;

        changed |= mirrorDirections(props, mirror);
        changed |= mirrorRotationIndex(props, mirror);
        changed |= mirrorConnections(props, mirror);
        changed |= rotateRailShape(props, Rotation.NONE, mirror);
        changed |= rotateOrientation(props, Rotation.NONE, mirror);
        changed |= mirrorStairShape(props, mirror, originalFacing);
        changed |= mirrorHinge(props);
        changed |= mirrorChestType(props);

        return changed ? state.withProperties(props) : state;
    }

    // --- direction properties ------------------------------------------------------------------

    private static boolean rotateDirections(Map<String, String> props, Rotation rotation) {
        boolean changed = false;
        for (String key : DIRECTION_PROPERTIES) {
            String value = props.get(key);
            if (value == null) continue;
            Direction dir = Direction.byName(value);
            if (dir == null) continue;
            Direction rotated = dir.rotate(rotation);
            if (rotated != dir) {
                props.put(key, rotated.lowerName());
                changed = true;
            }
        }
        return changed;
    }

    private static boolean mirrorDirections(Map<String, String> props, Mirror mirror) {
        boolean changed = false;
        for (String key : DIRECTION_PROPERTIES) {
            String value = props.get(key);
            if (value == null) continue;
            Direction dir = Direction.byName(value);
            if (dir == null) continue;
            Direction mirrored = dir.mirror(mirror);
            if (mirrored != dir) {
                props.put(key, mirrored.lowerName());
                changed = true;
            }
        }
        return changed;
    }

    /** Logs, pillars and chains: a quarter turn swaps the X and Z axes. */
    private static boolean rotateAxis(Map<String, String> props, Rotation rotation) {
        if (!rotation.swapsAxes()) return false;
        String axis = props.get("axis");
        if ("x".equals(axis)) {
            props.put("axis", "z");
            return true;
        }
        if ("z".equals(axis)) {
            props.put("axis", "x");
            return true;
        }
        return false;
    }

    /** Signs, banners and skulls store a 16-step compass index. */
    private static boolean rotateRotationIndex(Map<String, String> props, Rotation rotation) {
        String raw = props.get("rotation");
        if (raw == null) return false;
        int value;
        try {
            value = Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return false;
        }
        int rotated = Math.floorMod(value + rotation.quarterTurns() * 4, 16);
        if (rotated == value) return false;
        props.put("rotation", Integer.toString(rotated));
        return true;
    }

    private static boolean mirrorRotationIndex(Map<String, String> props, Mirror mirror) {
        String raw = props.get("rotation");
        if (raw == null) return false;
        int value;
        try {
            value = Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return false;
        }
        // Mirrors the index around the axis, matching vanilla's Mirror#mirror(int, int).
        int half = 8;
        int signed = value > half ? value - 16 : value;
        int mirrored = switch (mirror) {
            case NONE -> value;
            case FRONT_BACK -> Math.floorMod(16 - signed, 16);
            case LEFT_RIGHT -> Math.floorMod(half - signed, 16);
        };
        if (mirrored == value) return false;
        props.put("rotation", Integer.toString(mirrored));
        return true;
    }

    /** Fences, walls, panes, redstone dust and chorus plants. */
    private static boolean rotateConnections(Map<String, String> props, Rotation rotation) {
        if (rotation == Rotation.NONE) return false;
        return permuteConnections(props, rotation, Mirror.NONE);
    }

    private static boolean mirrorConnections(Map<String, String> props, Mirror mirror) {
        return permuteConnections(props, Rotation.NONE, mirror);
    }

    private static boolean permuteConnections(Map<String, String> props, Rotation rotation, Mirror mirror) {
        if (!hasAllConnections(props)) return false;

        // The whole permutation is computed from a snapshot before anything is written back,
        // otherwise an earlier write would feed into a later read.
        String[] original = new String[4];
        for (int i = 0; i < 4; i++) original[i] = props.get(CONNECTIONS[i]);

        String[] next = original.clone();
        for (int i = 0; i < 4; i++) {
            Direction source = Direction.byName(CONNECTIONS[i]);
            Direction target = transform(source, rotation, mirror);
            next[indexOf(target)] = original[i];
        }

        boolean changed = false;
        for (int i = 0; i < 4; i++) {
            if (!next[i].equals(original[i])) {
                props.put(CONNECTIONS[i], next[i]);
                changed = true;
            }
        }
        return changed;
    }

    private static int indexOf(Direction dir) {
        for (int i = 0; i < 4; i++) {
            if (CONNECTIONS[i].equals(dir.lowerName())) return i;
        }
        throw new IllegalArgumentException("not a horizontal connection: " + dir);
    }

    private static boolean hasAllConnections(Map<String, String> props) {
        for (String key : CONNECTIONS) {
            if (!props.containsKey(key)) return false;
        }
        return true;
    }

    // --- rails ---------------------------------------------------------------------------------

    /**
     * Rail shapes are decomposed into their component directions, transformed, then reassembled in
     * canonical order. That single path covers straights, slopes and corners for both operations.
     */
    private static boolean rotateRailShape(Map<String, String> props, Rotation rotation, Mirror mirror) {
        String shape = props.get("shape");
        if (shape == null || !shape.contains("_")) return false;

        String transformed;
        if (shape.startsWith("ascending_")) {
            Direction dir = Direction.byName(shape.substring("ascending_".length()));
            if (dir == null) return false;
            transformed = "ascending_" + transform(dir, rotation, mirror).lowerName();
        } else {
            int underscore = shape.indexOf('_');
            Direction a = Direction.byName(shape.substring(0, underscore));
            Direction b = Direction.byName(shape.substring(underscore + 1));
            if (a == null || b == null) return false;
            transformed = canonicalPair(transform(a, rotation, mirror), transform(b, rotation, mirror));
            if (transformed == null) return false;
        }

        if (transformed.equals(shape)) return false;
        props.put("shape", transformed);
        return true;
    }

    private static Direction transform(Direction dir, Rotation rotation, Mirror mirror) {
        return dir.rotate(rotation).mirror(mirror);
    }

    /**
     * Rebuilds a two-direction shape name. Straight rails are named by axis
     * ({@code north_south} / {@code east_west}); corners always list the Z component first.
     */
    private static String canonicalPair(Direction a, Direction b) {
        if (a.axis() == b.axis()) {
            return a.axis() == Direction.Axis.Z ? "north_south" : "east_west";
        }
        Direction zPart = a.axis() == Direction.Axis.Z ? a : b;
        Direction xPart = a.axis() == Direction.Axis.X ? a : b;
        if (zPart.axis() != Direction.Axis.Z || xPart.axis() != Direction.Axis.X) return null;
        return zPart.lowerName() + "_" + xPart.lowerName();
    }

    // --- jigsaw and crafter orientation ---------------------------------------------------------

    /** {@code orientation} pairs a facing with a top direction, e.g. {@code down_east}. */
    private static boolean rotateOrientation(Map<String, String> props, Rotation rotation, Mirror mirror) {
        String value = props.get("orientation");
        if (value == null) return false;
        int underscore = value.indexOf('_');
        if (underscore < 0) return false;
        Direction front = Direction.byName(value.substring(0, underscore));
        Direction top = Direction.byName(value.substring(underscore + 1));
        if (front == null || top == null) return false;

        String transformed = transform(front, rotation, mirror).lowerName()
                + "_" + transform(top, rotation, mirror).lowerName();
        if (transformed.equals(value)) return false;
        props.put("orientation", transformed);
        return true;
    }

    // --- shape-specific mirror rules -------------------------------------------------------------

    /**
     * Stair corners flip handedness, but only when the stair faces along the mirrored axis -
     * otherwise the facing flip alone already produces the right shape.
     */
    private static boolean mirrorStairShape(Map<String, String> props, Mirror mirror, Direction facing) {
        String shape = props.get("shape");
        if (shape == null || facing == null) return false;
        boolean affected = switch (mirror) {
            case NONE -> false;
            case FRONT_BACK -> facing.axis() == Direction.Axis.X;
            case LEFT_RIGHT -> facing.axis() == Direction.Axis.Z;
        };
        if (!affected) return false;

        String flipped = switch (shape) {
            case "inner_left" -> "inner_right";
            case "inner_right" -> "inner_left";
            case "outer_left" -> "outer_right";
            case "outer_right" -> "outer_left";
            default -> null;
        };
        if (flipped == null) return false;
        props.put("shape", flipped);
        return true;
    }

    /** Door hinges always swap sides under a mirror, matching vanilla. */
    private static boolean mirrorHinge(Map<String, String> props) {
        String hinge = props.get("hinge");
        if ("left".equals(hinge)) {
            props.put("hinge", "right");
            return true;
        }
        if ("right".equals(hinge)) {
            props.put("hinge", "left");
            return true;
        }
        return false;
    }

    /**
     * Double chests, and anything else using {@code type=left|right}, swap halves under a mirror.
     * Vanilla leaves this alone and produces broken double chests; Buildmatic fixes it.
     * Slabs also use {@code type}, but with {@code top|bottom|double}, so they fall through.
     */
    private static boolean mirrorChestType(Map<String, String> props) {
        String type = props.get("type");
        if ("left".equals(type)) {
            props.put("type", "right");
            return true;
        }
        if ("right".equals(type)) {
            props.put("type", "left");
            return true;
        }
        return false;
    }

    /** Every property name this class understands; used by the swap engine's compatibility check. */
    public static Set<String> transformableProperties() {
        Set<String> all = new LinkedHashSet<>(DIRECTION_PROPERTIES);
        all.add("axis");
        all.add("rotation");
        all.add("shape");
        all.add("orientation");
        all.add("hinge");
        all.add("type");
        for (String c : CONNECTIONS) all.add(c);
        return all;
    }
}
