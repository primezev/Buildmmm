package dev.buildmatic.core.block;

import dev.buildmatic.core.util.Direction;

import java.util.List;
import java.util.Map;

/**
 * Carries a block state's properties across a variant swap.
 *
 * <p>Naively replacing the id and keeping the property map produces invalid states the moment the
 * shapes differ, and Litematica's answer - drop everything and use the default - throws away the
 * facing and half a builder carefully set. This class keeps everything the target block can
 * legitimately hold, translates the handful of properties that mean the same thing under a
 * different name, and falls back to the default only for what is genuinely untranslatable.
 */
public final class PropertyTranslator {

    private PropertyTranslator() {}

    /**
     * Rebuilds {@code source} as {@code targetBlockId}.
     *
     * @param schema the running game's block definitions; use
     *               {@link BlockStateSchema#PERMISSIVE} only in tests
     */
    public static BlockStateRef translate(BlockStateRef source, String targetBlockId,
                                          BlockStateSchema schema) {
        if (source.blockId().equals(normalise(targetBlockId))) return source;
        if (!schema.isKnownBlock(targetBlockId)) {
            // Unknown target: keep the properties so the swap survives a round trip to a version
            // that does know the block.
            return source.withBlock(targetBlockId);
        }

        BlockStateRef result = schema.defaultState(targetBlockId);

        // 1. Direct copies for every property both blocks share.
        for (Map.Entry<String, String> entry : source.properties().entrySet()) {
            if (schema.accepts(targetBlockId, entry.getKey(), entry.getValue())) {
                result = result.with(entry.getKey(), entry.getValue());
            }
        }

        // 2. Cross-shape translations for properties that survive under a different name.
        result = translateOrientation(source, result, targetBlockId, schema);
        result = translateVerticalHalf(source, result, targetBlockId, schema);
        result = translateSlabType(source, result, targetBlockId, schema);
        result = carry(source, result, targetBlockId, schema, "waterlogged");
        result = carry(source, result, targetBlockId, schema, "lit");
        result = carry(source, result, targetBlockId, schema, "powered");
        result = carry(source, result, targetBlockId, schema, "open");

        return result;
    }

    /** Convenience overload that also confirms the target exists. */
    public static BlockStateRef translateOrNull(BlockStateRef source, String targetBlockId,
                                                BlockStateSchema schema) {
        if (!schema.isKnownBlock(targetBlockId)) return null;
        return translate(source, targetBlockId, schema);
    }

    // --- individual rules ------------------------------------------------------------------------

    /**
     * {@code facing} and {@code axis} describe the same intent for pillars and logs, so a swap
     * between a stair and a log keeps the build pointing the same way.
     */
    private static BlockStateRef translateOrientation(BlockStateRef source, BlockStateRef result,
                                                      String target, BlockStateSchema schema) {
        boolean targetHasFacing = !schema.valuesOf(target, "facing").isEmpty();
        boolean targetHasAxis = !schema.valuesOf(target, "axis").isEmpty();

        String sourceFacing = source.property("facing");
        String sourceAxis = source.property("axis");

        if (sourceFacing != null && targetHasAxis && !result.hasProperty("axis")) {
            Direction dir = Direction.byName(sourceFacing);
            if (dir != null) {
                String axis = switch (dir.axis()) {
                    case X -> "x";
                    case Y -> "y";
                    case Z -> "z";
                };
                if (schema.accepts(target, "axis", axis)) return result.with("axis", axis);
            }
        }

        if (sourceAxis != null && targetHasFacing && !source.hasProperty("facing")) {
            // Pick the positive face of the axis; it is the one a builder reads as "along X".
            String facing = switch (sourceAxis) {
                case "x" -> "east";
                case "z" -> "south";
                default -> "up";
            };
            if (schema.accepts(target, "facing", facing)) return result.with("facing", facing);
        }

        return result;
    }

    /**
     * Stairs and trapdoors use {@code half=top|bottom}; slabs call the same idea
     * {@code type=top|bottom}. Doors and tall plants also use {@code half}, with
     * {@code upper|lower}, which must not be confused with it.
     */
    private static BlockStateRef translateVerticalHalf(BlockStateRef source, BlockStateRef result,
                                                       String target, BlockStateSchema schema) {
        String half = source.property("half");
        if (half == null || (!half.equals("top") && !half.equals("bottom"))) return result;

        if (schema.accepts(target, "half", half)) return result.with("half", half);
        if (schema.accepts(target, "type", half)) return result.with("type", half);
        return result;
    }

    /**
     * A slab swapped to a full cube loses nothing, but a full cube swapped to a slab would halve
     * the build. Defaulting to {@code type=double} keeps the silhouette intact.
     */
    private static BlockStateRef translateSlabType(BlockStateRef source, BlockStateRef result,
                                                   String target, BlockStateSchema schema) {
        List<String> targetTypes = schema.valuesOf(target, "type");
        if (!targetTypes.contains("double")) return result;
        if (result.hasProperty("type") && !"bottom".equals(result.property("type"))) return result;

        String sourceType = source.property("type");
        if (sourceType != null && targetTypes.contains(sourceType)) {
            return result.with("type", sourceType);
        }
        if (source.hasProperty("half")) {
            // The half rule above already placed it; leave that decision alone.
            return result;
        }
        return result.with("type", "double");
    }

    private static BlockStateRef carry(BlockStateRef source, BlockStateRef result, String target,
                                       BlockStateSchema schema, String property) {
        String value = source.property(property);
        if (value == null) return result;
        if (result.hasProperty(property) && value.equals(result.property(property))) return result;
        if (!schema.accepts(target, property, value)) return result;
        return result.with(property, value);
    }

    private static String normalise(String blockId) {
        String lower = blockId.trim().toLowerCase(java.util.Locale.ROOT);
        return lower.indexOf(':') < 0 ? "minecraft:" + lower : lower;
    }
}
