package dev.buildmatic.core.material;

import dev.buildmatic.core.block.BlockStateRef;

/**
 * Turns a block state into the item a builder has to carry, and how many of it.
 *
 * <p>The mapping is rarely one-to-one: a double slab costs two slabs, the upper half of a door
 * costs nothing because the lower half already paid for it, and four candles in a cell cost four
 * candles. Litematica gets several of these wrong and reports material lists that send people to
 * the chest for twice what they need.
 *
 * <p>The platform layer can supply a registry-backed implementation for exact item ids;
 * {@link #VANILLA} covers vanilla by pattern and is what the headless tests use.
 */
public interface ItemMapper {

    /** What one placed block costs. */
    record Cost(String itemId, int count) {
        public static final Cost FREE = new Cost("", 0);

        public boolean isFree() { return count <= 0 || itemId.isEmpty(); }
    }

    Cost costOf(BlockStateRef state);

    /**
     * Pattern-based vanilla mapping.
     *
     * <p>Rules are ordered from most to least specific: the multi-block and multi-item cases first,
     * then the blocks whose item id differs from the block id, then the identity case.
     */
    ItemMapper VANILLA = state -> {
        if (state.isEmpty()) return Cost.FREE;

        String path = state.path();

        // Fluids are carried as buckets, and only source blocks count.
        if (path.equals("water") || path.equals("lava")) {
            return state.intProperty("level", 0) == 0
                    ? new Cost("minecraft:" + path + "_bucket", 1)
                    : Cost.FREE;
        }

        // The second half of a two-block structure is placed by the first.
        if (state.is("half", "upper")) return Cost.FREE;
        if (state.is("part", "head")) return Cost.FREE;
        if (state.is("type", "top") && path.endsWith("piston_head")) return Cost.FREE;
        if (path.equals("piston_head") || path.equals("moving_piston")) return Cost.FREE;

        // A double slab is two slabs.
        if (state.is("type", "double") && path.endsWith("_slab")) {
            return new Cost("minecraft:" + path, 2);
        }

        // Stackable-in-place blocks charge per unit.
        for (String property : new String[]{"candles", "pickles", "eggs", "layers", "flower_amount"}) {
            if (state.hasProperty(property)) {
                int count = state.intProperty(property, 1);
                return new Cost("minecraft:" + path, Math.max(1, count));
            }
        }

        // Blocks whose item is named differently.
        String item = switch (path) {
            case "redstone_wire" -> "redstone";
            case "tripwire" -> "string";
            case "cocoa" -> "cocoa_beans";
            case "carrots" -> "carrot";
            case "potatoes" -> "potato";
            case "beetroots" -> "beetroot_seeds";
            case "wheat" -> "wheat_seeds";
            case "melon_stem", "attached_melon_stem" -> "melon_seeds";
            case "pumpkin_stem", "attached_pumpkin_stem" -> "pumpkin_seeds";
            case "bamboo_sapling" -> "bamboo";
            case "sweet_berry_bush" -> "sweet_berries";
            case "cave_vines", "cave_vines_plant" -> "glow_berries";
            case "frosted_ice" -> "";
            case "fire", "soul_fire" -> "";
            case "nether_portal", "end_portal", "end_gateway" -> "";
            case "bubble_column", "void_air", "cave_air" -> "";
            default -> null;
        };
        if (item != null) {
            return item.isEmpty() ? Cost.FREE : new Cost("minecraft:" + item, 1);
        }

        // Wall-mounted variants share the item of their free-standing form.
        if (path.startsWith("wall_")) {
            return new Cost(state.namespace() + ":" + path.substring("wall_".length()), 1);
        }
        if (path.endsWith("_wall_torch")) {
            return new Cost(state.namespace() + ":"
                    + path.substring(0, path.length() - "_wall_torch".length()) + "_torch", 1);
        }
        if (path.endsWith("_wall_sign")) {
            return new Cost(state.namespace() + ":"
                    + path.substring(0, path.length() - "_wall_sign".length()) + "_sign", 1);
        }
        if (path.endsWith("_wall_hanging_sign")) {
            return new Cost(state.namespace() + ":"
                    + path.substring(0, path.length() - "_wall_hanging_sign".length())
                    + "_hanging_sign", 1);
        }
        if (path.endsWith("_wall_banner")) {
            return new Cost(state.namespace() + ":"
                    + path.substring(0, path.length() - "_wall_banner".length()) + "_banner", 1);
        }
        if (path.endsWith("_wall_head") || path.endsWith("_wall_skull")) {
            return new Cost(state.namespace() + ":"
                    + path.replace("_wall_", "_"), 1);
        }

        return new Cost(state.blockId(), 1);
    };
}
