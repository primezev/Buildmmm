package dev.buildmatic.core.material;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.swap.SwapEngine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * What a build costs, and what is still missing from the player's inventory.
 *
 * <p>Computed from the <em>effective</em> block counts, so the list reflects every swap the moment
 * it is made - swap a build from oak to deepslate and the shopping list changes with it, which is
 * the whole point of doing the swap before starting to build rather than after.
 */
public final class MaterialList {

    /** One line of the list. */
    public record Entry(String itemId, int required, int available) implements Comparable<Entry> {

        public int missing() { return Math.max(0, required - available); }

        public boolean isSatisfied() { return available >= required; }

        /** Full stacks needed, assuming the usual 64-per-stack. */
        public int stacks() { return required / 64; }

        public int remainder() { return required % 64; }

        /** Shulker boxes needed, at 27 stacks each. */
        public int shulkerBoxes() { return required / (64 * 27); }

        public String describeQuantity() {
            if (required < 64) return Integer.toString(required);
            int boxes = shulkerBoxes();
            int stacks = (required / 64) % 27;
            int items = required % 64;
            StringBuilder sb = new StringBuilder();
            if (boxes > 0) sb.append(boxes).append(" SB ");
            if (stacks > 0) sb.append(stacks).append(" x64 ");
            if (items > 0) sb.append('+').append(items);
            return sb.toString().trim();
        }

        @Override
        public int compareTo(Entry o) {
            int byMissing = Integer.compare(o.missing(), missing());
            if (byMissing != 0) return byMissing;
            int byRequired = Integer.compare(o.required, required);
            if (byRequired != 0) return byRequired;
            return itemId.compareTo(o.itemId);
        }
    }

    private final List<Entry> entries;
    private final int totalItems;
    private final int totalMissing;

    private MaterialList(List<Entry> entries) {
        this.entries = Collections.unmodifiableList(entries);
        int items = 0;
        int missing = 0;
        for (Entry entry : entries) {
            items += entry.required();
            missing += entry.missing();
        }
        this.totalItems = items;
        this.totalMissing = missing;
    }

    /** The list for a schematic with no swaps applied. */
    public static MaterialList of(Schematic schematic, ItemMapper mapper,
                                  Map<String, Integer> inventory) {
        return from(schematic.countBlocks(), mapper, inventory);
    }

    /** The list for a schematic as it currently looks through its swap stack. */
    public static MaterialList of(SwapEngine swaps, ItemMapper mapper,
                                  Map<String, Integer> inventory) {
        return from(swaps.countEffectiveBlocks(), mapper, inventory);
    }

    public static MaterialList from(Map<BlockStateRef, Integer> blockCounts, ItemMapper mapper,
                                    Map<String, Integer> inventory) {
        Map<String, Integer> required = new HashMap<>();
        for (Map.Entry<BlockStateRef, Integer> e : blockCounts.entrySet()) {
            ItemMapper.Cost cost = mapper.costOf(e.getKey());
            if (cost.isFree()) continue;
            required.merge(cost.itemId(), cost.count() * e.getValue(), Integer::sum);
        }

        List<Entry> entries = new ArrayList<>(required.size());
        for (Map.Entry<String, Integer> e : required.entrySet()) {
            int available = inventory == null ? 0 : inventory.getOrDefault(e.getKey(), 0);
            entries.add(new Entry(e.getKey(), e.getValue(), available));
        }
        Collections.sort(entries);
        return new MaterialList(entries);
    }

    public List<Entry> entries() { return entries; }

    public int distinctItems() { return entries.size(); }

    public int totalItems() { return totalItems; }

    public int totalMissing() { return totalMissing; }

    public boolean isComplete() { return totalMissing == 0; }

    /** Only the lines the player still has to gather. */
    public List<Entry> missingEntries() {
        List<Entry> missing = new ArrayList<>();
        for (Entry entry : entries) {
            if (!entry.isSatisfied()) missing.add(entry);
        }
        return missing;
    }

    /** Difference against another list, for "what does this swap change?" in the swap panel. */
    public Map<String, Integer> delta(MaterialList other) {
        Map<String, Integer> delta = new HashMap<>();
        for (Entry entry : entries) delta.merge(entry.itemId(), entry.required(), Integer::sum);
        for (Entry entry : other.entries) delta.merge(entry.itemId(), -entry.required(), Integer::sum);
        delta.values().removeIf(value -> value == 0);
        return delta;
    }

    /** Tab-separated dump, for pasting into a spreadsheet or a chat message. */
    public String toPlainText() {
        StringBuilder sb = new StringBuilder();
        sb.append("Item\tRequired\tAvailable\tMissing\n");
        for (Entry entry : entries) {
            sb.append(entry.itemId()).append('\t')
                    .append(entry.required()).append('\t')
                    .append(entry.available()).append('\t')
                    .append(entry.missing()).append('\n');
        }
        return sb.toString();
    }
}
