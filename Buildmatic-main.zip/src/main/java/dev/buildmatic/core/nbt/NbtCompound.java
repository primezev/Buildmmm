package dev.buildmatic.core.nbt;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * A mutable NBT compound with insertion-ordered keys.
 *
 * <p>Insertion order is preserved so that re-saving a schematic produces a byte layout close to the
 * original, which keeps diffs readable and avoids gratuitous churn in version control.
 */
public final class NbtCompound implements NbtTag {

    private final Map<String, NbtTag> entries;

    public NbtCompound() {
        this.entries = new LinkedHashMap<>();
    }

    private NbtCompound(Map<String, NbtTag> entries) {
        this.entries = entries;
    }

    @Override public byte id() { return TAG_COMPOUND; }

    @Override
    public NbtCompound copy() {
        Map<String, NbtTag> copied = new LinkedHashMap<>(entries.size() * 2);
        for (Map.Entry<String, NbtTag> e : entries.entrySet()) {
            copied.put(e.getKey(), e.getValue().copy());
        }
        return new NbtCompound(copied);
    }

    public Set<String> keys() { return Collections.unmodifiableSet(entries.keySet()); }

    public Map<String, NbtTag> asMap() { return Collections.unmodifiableMap(entries); }

    public int size() { return entries.size(); }

    public boolean isEmpty() { return entries.isEmpty(); }

    public boolean contains(String key) { return entries.containsKey(key); }

    public boolean contains(String key, byte typeId) {
        NbtTag t = entries.get(key);
        return t != null && t.id() == typeId;
    }

    public NbtTag get(String key) { return entries.get(key); }

    public NbtCompound put(String key, NbtTag value) {
        entries.put(key, value);
        return this;
    }

    public NbtTag remove(String key) { return entries.remove(key); }

    // --- typed writers -------------------------------------------------------------------------

    public NbtCompound putByte(String key, byte v) { return put(key, new NbtByte(v)); }
    public NbtCompound putBoolean(String key, boolean v) { return put(key, NbtByte.of(v)); }
    public NbtCompound putShort(String key, short v) { return put(key, new NbtShort(v)); }
    public NbtCompound putInt(String key, int v) { return put(key, new NbtInt(v)); }
    public NbtCompound putLong(String key, long v) { return put(key, new NbtLong(v)); }
    public NbtCompound putFloat(String key, float v) { return put(key, new NbtFloat(v)); }
    public NbtCompound putDouble(String key, double v) { return put(key, new NbtDouble(v)); }
    public NbtCompound putString(String key, String v) { return put(key, new NbtString(v)); }
    public NbtCompound putByteArray(String key, byte[] v) { return put(key, new NbtByteArray(v)); }
    public NbtCompound putIntArray(String key, int[] v) { return put(key, new NbtIntArray(v)); }
    public NbtCompound putLongArray(String key, long[] v) { return put(key, new NbtLongArray(v)); }

    // --- typed readers -------------------------------------------------------------------------
    // Readers are lenient: a numeric tag of any width answers any numeric getter, matching how
    // vanilla's own NBT accessors behave and how third-party schematic writers actually behave.

    public byte getByte(String key, byte fallback) {
        return (byte) getNumber(key, fallback);
    }

    public boolean getBoolean(String key, boolean fallback) {
        return getNumber(key, fallback ? 1 : 0) != 0;
    }

    public short getShort(String key, short fallback) {
        return (short) getNumber(key, fallback);
    }

    public int getInt(String key, int fallback) {
        return (int) getNumber(key, fallback);
    }

    public long getLong(String key, long fallback) {
        return (long) getNumber(key, fallback);
    }

    public double getDouble(String key, double fallback) {
        return getNumber(key, fallback);
    }

    public float getFloat(String key, float fallback) {
        return (float) getNumber(key, fallback);
    }

    private double getNumber(String key, double fallback) {
        NbtTag t = entries.get(key);
        if (t instanceof NbtByte v) return v.value();
        if (t instanceof NbtShort v) return v.value();
        if (t instanceof NbtInt v) return v.value();
        if (t instanceof NbtLong v) return v.value();
        if (t instanceof NbtFloat v) return v.value();
        if (t instanceof NbtDouble v) return v.value();
        return fallback;
    }

    public String getString(String key, String fallback) {
        return entries.get(key) instanceof NbtString v ? v.value() : fallback;
    }

    public byte[] getByteArray(String key) {
        return entries.get(key) instanceof NbtByteArray v ? v.value() : new byte[0];
    }

    public int[] getIntArray(String key) {
        return entries.get(key) instanceof NbtIntArray v ? v.value() : new int[0];
    }

    public long[] getLongArray(String key) {
        return entries.get(key) instanceof NbtLongArray v ? v.value() : new long[0];
    }

    public NbtCompound getCompound(String key) {
        return entries.get(key) instanceof NbtCompound v ? v : null;
    }

    /** Returns the child compound, creating and inserting an empty one when absent. */
    public NbtCompound getOrCreateCompound(String key) {
        NbtTag t = entries.get(key);
        if (t instanceof NbtCompound v) return v;
        NbtCompound created = new NbtCompound();
        entries.put(key, created);
        return created;
    }

    public NbtList getList(String key) {
        return entries.get(key) instanceof NbtList v ? v : null;
    }

    /** Returns the child list, creating and inserting an empty one of {@code elementType} when absent. */
    public NbtList getOrCreateList(String key, byte elementType) {
        NbtTag t = entries.get(key);
        if (t instanceof NbtList v) return v;
        NbtList created = new NbtList(elementType);
        entries.put(key, created);
        return created;
    }

    public Optional<NbtCompound> compound(String key) { return Optional.ofNullable(getCompound(key)); }

    public Optional<NbtList> list(String key) { return Optional.ofNullable(getList(key)); }

    @Override
    public boolean equals(Object o) {
        return o instanceof NbtCompound c && entries.equals(c.entries);
    }

    @Override
    public int hashCode() { return entries.hashCode(); }

    @Override
    public String toString() { return SNbt.write(this); }
}
