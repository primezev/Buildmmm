package dev.buildmatic.core.nbt;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Binary NBT reader/writer.
 *
 * <p>Reading transparently accepts gzip-compressed and raw streams, because the schematic formats in
 * the wild are inconsistent about it: {@code .litematic} and {@code .schem} are always gzipped,
 * hand-made {@code .nbt} structure files often are not.
 */
public final class NbtIo {

    /** Guards against hostile or corrupt files claiming absurd nesting. */
    private static final int MAX_DEPTH = 512;

    private NbtIo() {}

    /** Root tag plus its name; schematic formats occasionally rely on the root name. */
    public record Named(String name, NbtCompound tag) {}

    public static NbtCompound read(Path path) throws IOException {
        return readNamed(path).tag();
    }

    public static Named readNamed(Path path) throws IOException {
        try (InputStream in = Files.newInputStream(path)) {
            return readNamed(in);
        }
    }

    public static NbtCompound read(InputStream in) throws IOException {
        return readNamed(in).tag();
    }

    /** Reads a root compound, auto-detecting gzip framing. Does not close {@code in}. */
    public static Named readNamed(InputStream in) throws IOException {
        PushbackInputStream probe = new PushbackInputStream(new BufferedInputStream(in), 2);
        int b0 = probe.read();
        int b1 = probe.read();
        if (b1 >= 0) probe.unread(b1);
        if (b0 >= 0) probe.unread(b0);

        boolean gzipped = b0 == 0x1F && b1 == 0x8B;
        InputStream body = gzipped ? new GZIPInputStream(probe) : probe;
        return readRoot(new DataInputStream(body));
    }

    /** Reads a root compound from an already-framed stream. Named apart from the
     *  {@link InputStream} overloads because {@code DataInputStream} satisfies both. */
    public static Named readRoot(DataInput in) throws IOException {
        byte type = in.readByte();
        if (type == NbtTag.TAG_END) {
            return new Named("", new NbtCompound());
        }
        if (type != NbtTag.TAG_COMPOUND) {
            throw new IOException("root tag must be a compound, got type " + type);
        }
        String name = in.readUTF();
        NbtTag root = readTag(in, NbtTag.TAG_COMPOUND, 0);
        return new Named(name, (NbtCompound) root);
    }

    private static NbtTag readTag(DataInput in, byte type, int depth) throws IOException {
        if (depth > MAX_DEPTH) {
            throw new IOException("NBT nesting deeper than " + MAX_DEPTH);
        }
        switch (type) {
            case NbtTag.TAG_END:
                return NbtTag.NbtEnd.INSTANCE;
            case NbtTag.TAG_BYTE:
                return new NbtTag.NbtByte(in.readByte());
            case NbtTag.TAG_SHORT:
                return new NbtTag.NbtShort(in.readShort());
            case NbtTag.TAG_INT:
                return new NbtTag.NbtInt(in.readInt());
            case NbtTag.TAG_LONG:
                return new NbtTag.NbtLong(in.readLong());
            case NbtTag.TAG_FLOAT:
                return new NbtTag.NbtFloat(in.readFloat());
            case NbtTag.TAG_DOUBLE:
                return new NbtTag.NbtDouble(in.readDouble());
            case NbtTag.TAG_BYTE_ARRAY: {
                int len = readLength(in);
                byte[] data = new byte[len];
                in.readFully(data);
                return new NbtTag.NbtByteArray(data);
            }
            case NbtTag.TAG_STRING:
                return new NbtTag.NbtString(in.readUTF());
            case NbtTag.TAG_LIST: {
                byte elementType = in.readByte();
                int len = readLength(in);
                if (elementType == NbtTag.TAG_END && len > 0) {
                    throw new IOException("non-empty list of TAG_End");
                }
                NbtList list = new NbtList(elementType);
                for (int i = 0; i < len; i++) {
                    list.add(readTag(in, elementType, depth + 1));
                }
                return list;
            }
            case NbtTag.TAG_COMPOUND: {
                NbtCompound compound = new NbtCompound();
                byte childType;
                while ((childType = in.readByte()) != NbtTag.TAG_END) {
                    String key = in.readUTF();
                    compound.put(key, readTag(in, childType, depth + 1));
                }
                return compound;
            }
            case NbtTag.TAG_INT_ARRAY: {
                int len = readLength(in);
                int[] data = new int[len];
                for (int i = 0; i < len; i++) data[i] = in.readInt();
                return new NbtTag.NbtIntArray(data);
            }
            case NbtTag.TAG_LONG_ARRAY: {
                int len = readLength(in);
                long[] data = new long[len];
                for (int i = 0; i < len; i++) data[i] = in.readLong();
                return new NbtTag.NbtLongArray(data);
            }
            default:
                throw new IOException("unknown NBT type " + type);
        }
    }

    private static int readLength(DataInput in) throws IOException {
        int len = in.readInt();
        if (len < 0) throw new IOException("negative NBT array length " + len);
        return len;
    }

    // --- writing -------------------------------------------------------------------------------

    public static void write(NbtCompound root, Path path) throws IOException {
        write("", root, path, true);
    }

    public static void write(String rootName, NbtCompound root, Path path, boolean gzip)
            throws IOException {
        Path parent = path.getParent();
        if (parent != null) Files.createDirectories(parent);
        // Write to a sibling temp file first so a crash mid-save cannot destroy an existing schematic.
        Path tmp = path.resolveSibling(path.getFileName() + ".tmp");
        try (OutputStream out = Files.newOutputStream(tmp)) {
            write(rootName, root, out, gzip);
        }
        Files.move(tmp, path, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }

    public static void write(String rootName, NbtCompound root, OutputStream out, boolean gzip)
            throws IOException {
        OutputStream body = gzip
                ? new GZIPOutputStream(new BufferedOutputStream(out))
                : new BufferedOutputStream(out);
        DataOutputStream data = new DataOutputStream(body);
        writeNamed(rootName, root, data);
        data.flush();
        if (body instanceof GZIPOutputStream gz) gz.finish();
        body.flush();
    }

    public static void writeNamed(String rootName, NbtCompound root, DataOutput out)
            throws IOException {
        out.writeByte(NbtTag.TAG_COMPOUND);
        out.writeUTF(rootName);
        writeTag(root, out);
    }

    private static void writeTag(NbtTag tag, DataOutput out) throws IOException {
        if (tag instanceof NbtTag.NbtByte v) {
            out.writeByte(v.value());
        } else if (tag instanceof NbtTag.NbtShort v) {
            out.writeShort(v.value());
        } else if (tag instanceof NbtTag.NbtInt v) {
            out.writeInt(v.value());
        } else if (tag instanceof NbtTag.NbtLong v) {
            out.writeLong(v.value());
        } else if (tag instanceof NbtTag.NbtFloat v) {
            out.writeFloat(v.value());
        } else if (tag instanceof NbtTag.NbtDouble v) {
            out.writeDouble(v.value());
        } else if (tag instanceof NbtTag.NbtByteArray v) {
            out.writeInt(v.value().length);
            out.write(v.value());
        } else if (tag instanceof NbtTag.NbtString v) {
            out.writeUTF(v.value());
        } else if (tag instanceof NbtList v) {
            out.writeByte(v.elementType());
            out.writeInt(v.size());
            for (NbtTag child : v) writeTag(child, out);
        } else if (tag instanceof NbtCompound v) {
            for (var e : v.asMap().entrySet()) {
                out.writeByte(e.getValue().id());
                out.writeUTF(e.getKey());
                writeTag(e.getValue(), out);
            }
            out.writeByte(NbtTag.TAG_END);
        } else if (tag instanceof NbtTag.NbtIntArray v) {
            out.writeInt(v.value().length);
            for (int i : v.value()) out.writeInt(i);
        } else if (tag instanceof NbtTag.NbtLongArray v) {
            out.writeInt(v.value().length);
            for (long l : v.value()) out.writeLong(l);
        } else if (!(tag instanceof NbtTag.NbtEnd)) {
            throw new IOException("cannot serialise " + tag.getClass());
        }
    }
}
