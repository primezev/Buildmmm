package dev.buildmatic.core.nbt;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

/**
 * A mutable, homogeneously typed NBT list.
 *
 * <p>The element type is fixed on first insertion. An empty list keeps {@link NbtTag#TAG_END},
 * matching the vanilla format.
 */
public final class NbtList extends AbstractList<NbtTag> implements NbtTag {

    private final List<NbtTag> items;
    private byte elementType;

    public NbtList() {
        this(TAG_END);
    }

    public NbtList(byte elementType) {
        this.items = new ArrayList<>();
        this.elementType = elementType;
    }

    private NbtList(List<NbtTag> items, byte elementType) {
        this.items = items;
        this.elementType = elementType;
    }

    public static NbtList ofCompounds(List<NbtCompound> compounds) {
        NbtList list = new NbtList(TAG_COMPOUND);
        list.items.addAll(compounds);
        return list;
    }

    public static NbtList ofStrings(List<String> strings) {
        NbtList list = new NbtList(TAG_STRING);
        for (String s : strings) list.items.add(new NbtString(s));
        return list;
    }

    public static NbtList ofInts(int... values) {
        NbtList list = new NbtList(TAG_INT);
        for (int v : values) list.items.add(new NbtInt(v));
        return list;
    }

    public static NbtList ofDoubles(double... values) {
        NbtList list = new NbtList(TAG_DOUBLE);
        for (double v : values) list.items.add(new NbtDouble(v));
        return list;
    }

    @Override public byte id() { return TAG_LIST; }

    public byte elementType() { return elementType; }

    @Override
    public NbtList copy() {
        List<NbtTag> copied = new ArrayList<>(items.size());
        for (NbtTag t : items) copied.add(t.copy());
        return new NbtList(copied, elementType);
    }

    @Override public NbtTag get(int index) { return items.get(index); }

    @Override public int size() { return items.size(); }

    @Override
    public boolean add(NbtTag tag) {
        checkType(tag);
        return items.add(tag);
    }

    @Override
    public void add(int index, NbtTag tag) {
        checkType(tag);
        items.add(index, tag);
    }

    @Override
    public NbtTag set(int index, NbtTag tag) {
        checkType(tag);
        return items.set(index, tag);
    }

    @Override
    public NbtTag remove(int index) {
        NbtTag removed = items.remove(index);
        if (items.isEmpty()) elementType = TAG_END;
        return removed;
    }

    private void checkType(NbtTag tag) {
        if (tag.id() == TAG_END) {
            throw new IllegalArgumentException("cannot store TAG_End inside a list");
        }
        if (elementType == TAG_END) {
            elementType = tag.id();
        } else if (elementType != tag.id()) {
            throw new IllegalArgumentException(
                    "list holds type " + elementType + ", got " + tag.id());
        }
    }

    public NbtCompound getCompound(int index) {
        return items.get(index) instanceof NbtCompound c ? c : null;
    }

    public String getString(int index) {
        return items.get(index) instanceof NbtString s ? s.value() : "";
    }

    public int getInt(int index) {
        return items.get(index) instanceof NbtInt i ? i.value() : 0;
    }

    public double getDouble(int index) {
        NbtTag t = items.get(index);
        if (t instanceof NbtDouble d) return d.value();
        if (t instanceof NbtFloat f) return f.value();
        if (t instanceof NbtInt i) return i.value();
        return 0;
    }

    @Override
    public String toString() { return SNbt.write(this); }
}
