package dev.buildmatic.core.nbt;

import java.util.Arrays;

/**
 * A version-agnostic NBT tag.
 *
 * <p>Buildmatic never touches {@code net.minecraft.nbt} so that schematic parsing, the variant
 * index and the swap engine all compile and run without Minecraft on the classpath. That keeps a
 * single source tree valid from 1.19.2 through 26.2 and makes the whole core unit-testable.
 *
 * <p>Scalar and array tags are immutable records; {@link NbtCompound} and {@link NbtList} are
 * mutable because schematic editing rewrites them in place.
 */
public sealed interface NbtTag permits
        NbtTag.NbtEnd,
        NbtTag.NbtByte,
        NbtTag.NbtShort,
        NbtTag.NbtInt,
        NbtTag.NbtLong,
        NbtTag.NbtFloat,
        NbtTag.NbtDouble,
        NbtTag.NbtByteArray,
        NbtTag.NbtString,
        NbtTag.NbtIntArray,
        NbtTag.NbtLongArray,
        NbtCompound,
        NbtList {

    byte TAG_END = 0;
    byte TAG_BYTE = 1;
    byte TAG_SHORT = 2;
    byte TAG_INT = 3;
    byte TAG_LONG = 4;
    byte TAG_FLOAT = 5;
    byte TAG_DOUBLE = 6;
    byte TAG_BYTE_ARRAY = 7;
    byte TAG_STRING = 8;
    byte TAG_LIST = 9;
    byte TAG_COMPOUND = 10;
    byte TAG_INT_ARRAY = 11;
    byte TAG_LONG_ARRAY = 12;

    /** The NBT type id, matching the vanilla wire format. */
    byte id();

    /** A deep copy; immutable tags return themselves. */
    NbtTag copy();

    record NbtEnd() implements NbtTag {
        public static final NbtEnd INSTANCE = new NbtEnd();

        @Override public byte id() { return TAG_END; }
        @Override public NbtTag copy() { return this; }
    }

    record NbtByte(byte value) implements NbtTag {
        public static final NbtByte ZERO = new NbtByte((byte) 0);
        public static final NbtByte ONE = new NbtByte((byte) 1);

        public static NbtByte of(boolean b) { return b ? ONE : ZERO; }

        @Override public byte id() { return TAG_BYTE; }
        @Override public NbtTag copy() { return this; }
    }

    record NbtShort(short value) implements NbtTag {
        @Override public byte id() { return TAG_SHORT; }
        @Override public NbtTag copy() { return this; }
    }

    record NbtInt(int value) implements NbtTag {
        @Override public byte id() { return TAG_INT; }
        @Override public NbtTag copy() { return this; }
    }

    record NbtLong(long value) implements NbtTag {
        @Override public byte id() { return TAG_LONG; }
        @Override public NbtTag copy() { return this; }
    }

    record NbtFloat(float value) implements NbtTag {
        @Override public byte id() { return TAG_FLOAT; }
        @Override public NbtTag copy() { return this; }
    }

    record NbtDouble(double value) implements NbtTag {
        @Override public byte id() { return TAG_DOUBLE; }
        @Override public NbtTag copy() { return this; }
    }

    record NbtString(String value) implements NbtTag {
        @Override public byte id() { return TAG_STRING; }
        @Override public NbtTag copy() { return this; }
    }

    /** Backing arrays are shared on construction and defensively copied by {@link #copy()}. */
    record NbtByteArray(byte[] value) implements NbtTag {
        @Override public byte id() { return TAG_BYTE_ARRAY; }
        @Override public NbtTag copy() { return new NbtByteArray(value.clone()); }
        @Override public boolean equals(Object o) {
            return o instanceof NbtByteArray a && Arrays.equals(value, a.value);
        }
        @Override public int hashCode() { return Arrays.hashCode(value); }
        @Override public String toString() { return "NbtByteArray[len=" + value.length + "]"; }
    }

    record NbtIntArray(int[] value) implements NbtTag {
        @Override public byte id() { return TAG_INT_ARRAY; }
        @Override public NbtTag copy() { return new NbtIntArray(value.clone()); }
        @Override public boolean equals(Object o) {
            return o instanceof NbtIntArray a && Arrays.equals(value, a.value);
        }
        @Override public int hashCode() { return Arrays.hashCode(value); }
        @Override public String toString() { return "NbtIntArray[len=" + value.length + "]"; }
    }

    record NbtLongArray(long[] value) implements NbtTag {
        @Override public byte id() { return TAG_LONG_ARRAY; }
        @Override public NbtTag copy() { return new NbtLongArray(value.clone()); }
        @Override public boolean equals(Object o) {
            return o instanceof NbtLongArray a && Arrays.equals(value, a.value);
        }
        @Override public int hashCode() { return Arrays.hashCode(value); }
        @Override public String toString() { return "NbtLongArray[len=" + value.length + "]"; }
    }
}
