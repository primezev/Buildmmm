package dev.buildmatic.core.nbt;

import java.util.Map;
import java.util.regex.Pattern;

/**
 * Stringified NBT, the {@code {Items:[{id:"minecraft:stone",Count:1b}]}} notation.
 *
 * <p>Used for tooltips, the in-game block-state inspector and the {@code /buildmatic} command
 * output. Round-tripping through {@link #write} is lossless for every tag type Buildmatic stores.
 */
public final class SNbt {

    private static final Pattern BARE_KEY = Pattern.compile("[A-Za-z0-9._+-]+");

    private SNbt() {}

    public static String write(NbtTag tag) {
        StringBuilder sb = new StringBuilder();
        append(tag, sb);
        return sb.toString();
    }

    private static void append(NbtTag tag, StringBuilder sb) {
        if (tag instanceof NbtTag.NbtByte v) {
            sb.append(v.value()).append('b');
        } else if (tag instanceof NbtTag.NbtShort v) {
            sb.append(v.value()).append('s');
        } else if (tag instanceof NbtTag.NbtInt v) {
            sb.append(v.value());
        } else if (tag instanceof NbtTag.NbtLong v) {
            sb.append(v.value()).append('L');
        } else if (tag instanceof NbtTag.NbtFloat v) {
            sb.append(v.value()).append('f');
        } else if (tag instanceof NbtTag.NbtDouble v) {
            sb.append(v.value()).append('d');
        } else if (tag instanceof NbtTag.NbtString v) {
            quote(v.value(), sb);
        } else if (tag instanceof NbtTag.NbtByteArray v) {
            sb.append("[B;");
            for (int i = 0; i < v.value().length; i++) {
                if (i > 0) sb.append(',');
                sb.append(v.value()[i]).append('B');
            }
            sb.append(']');
        } else if (tag instanceof NbtTag.NbtIntArray v) {
            sb.append("[I;");
            for (int i = 0; i < v.value().length; i++) {
                if (i > 0) sb.append(',');
                sb.append(v.value()[i]);
            }
            sb.append(']');
        } else if (tag instanceof NbtTag.NbtLongArray v) {
            sb.append("[L;");
            for (int i = 0; i < v.value().length; i++) {
                if (i > 0) sb.append(',');
                sb.append(v.value()[i]).append('L');
            }
            sb.append(']');
        } else if (tag instanceof NbtList v) {
            sb.append('[');
            for (int i = 0; i < v.size(); i++) {
                if (i > 0) sb.append(',');
                append(v.get(i), sb);
            }
            sb.append(']');
        } else if (tag instanceof NbtCompound v) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<String, NbtTag> e : v.asMap().entrySet()) {
                if (!first) sb.append(',');
                first = false;
                if (BARE_KEY.matcher(e.getKey()).matches()) {
                    sb.append(e.getKey());
                } else {
                    quote(e.getKey(), sb);
                }
                sb.append(':');
                append(e.getValue(), sb);
            }
            sb.append('}');
        }
    }

    private static void quote(String s, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') sb.append('\\');
            sb.append(c);
        }
        sb.append('"');
    }
}
