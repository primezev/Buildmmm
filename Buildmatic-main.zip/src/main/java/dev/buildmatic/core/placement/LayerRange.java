package dev.buildmatic.core.placement;

import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;

/**
 * Restricts a placement to a slice of the build, so a builder can work one course at a time.
 *
 * <p>The slice axis is free: Y for floors, X or Z for walls seen edge-on.
 */
public record LayerRange(Mode mode, Direction.Axis axis, int min, int max) {

    public enum Mode {
        /** No restriction. */
        ALL,
        /** Exactly one layer. */
        SINGLE,
        /** Everything from {@code min} upwards along the axis. */
        ABOVE,
        /** Everything from {@code max} downwards along the axis. */
        BELOW,
        /** A closed interval. */
        RANGE
    }

    public static final LayerRange ALL_LAYERS =
            new LayerRange(Mode.ALL, Direction.Axis.Y, 0, 0);

    public LayerRange {
        if (min > max) {
            int swap = min;
            min = max;
            max = swap;
        }
    }

    public static LayerRange single(Direction.Axis axis, int layer) {
        return new LayerRange(Mode.SINGLE, axis, layer, layer);
    }

    public static LayerRange range(Direction.Axis axis, int from, int to) {
        return new LayerRange(Mode.RANGE, axis, from, to);
    }

    public boolean isUnrestricted() { return mode == Mode.ALL; }

    /** The coordinate this range slices on. */
    public int coordinateOf(Vec3i pos) {
        return switch (axis) {
            case X -> pos.x();
            case Y -> pos.y();
            case Z -> pos.z();
        };
    }

    public boolean contains(Vec3i pos) {
        return contains(coordinateOf(pos));
    }

    public boolean contains(int coordinate) {
        return switch (mode) {
            case ALL -> true;
            case SINGLE -> coordinate == min;
            case ABOVE -> coordinate >= min;
            case BELOW -> coordinate <= max;
            case RANGE -> coordinate >= min && coordinate <= max;
        };
    }

    /** Moves the slice by {@code delta}, for the "next layer" / "previous layer" keybinds. */
    public LayerRange shift(int delta) {
        return switch (mode) {
            case ALL -> this;
            case SINGLE -> new LayerRange(mode, axis, min + delta, min + delta);
            case ABOVE -> new LayerRange(mode, axis, min + delta, max);
            case BELOW -> new LayerRange(mode, axis, min, max + delta);
            case RANGE -> new LayerRange(mode, axis, min + delta, max + delta);
        };
    }

    public LayerRange withMode(Mode mode) {
        return new LayerRange(mode, axis, min, max);
    }

    public LayerRange withAxis(Direction.Axis axis) {
        return new LayerRange(mode, axis, min, max);
    }

    public String describe() {
        return switch (mode) {
            case ALL -> "all layers";
            case SINGLE -> axis + " = " + min;
            case ABOVE -> axis + " >= " + min;
            case BELOW -> axis + " <= " + max;
            case RANGE -> min + " <= " + axis + " <= " + max;
        };
    }
}
