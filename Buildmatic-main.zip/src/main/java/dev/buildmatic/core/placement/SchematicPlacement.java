package dev.buildmatic.core.placement;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;
import dev.buildmatic.core.util.Vec3i;

import java.util.HashSet;
import java.util.Set;

/**
 * Where and how a schematic sits in the world.
 *
 * <p>A schematic can be placed several times at once - mirrored, rotated, at different heights -
 * and each placement carries its own layer slice and its own set of hidden regions. The schematic
 * itself stays untouched.
 *
 * <h2>Anchoring</h2>
 * Rotating a non-cubic build around its own corner would swing it away from where the player put
 * it. Instead the rotated bounding box is re-anchored so its minimum corner always lands on
 * {@link #origin()}: rotating a placement spins the build in place rather than orbiting it.
 */
public final class SchematicPlacement {

    private final Schematic schematic;
    private final SwapEngine swaps;

    private Vec3i origin;
    private Rotation rotation = Rotation.NONE;
    private Mirror mirror = Mirror.NONE;
    private LayerRange layerRange = LayerRange.ALL_LAYERS;
    private boolean enabled = true;
    /** Guards against knocking a carefully aligned build out of place with a stray click. */
    private boolean locked;
    private String name;

    private final Set<String> hiddenRegions = new HashSet<>();

    /** Re-anchoring offset, recomputed whenever the transform changes. */
    private Vec3i anchorOffset = Vec3i.ZERO;

    public SchematicPlacement(Schematic schematic, SwapEngine swaps, Vec3i origin) {
        this.schematic = schematic;
        this.swaps = swaps;
        this.origin = origin;
        this.name = schematic.metadata().name();
        recomputeAnchor();
    }

    public Schematic schematic() { return schematic; }

    /** The swap stack whose results this placement renders; may be null for a plain preview. */
    public SwapEngine swaps() { return swaps; }

    public String name() { return name; }

    public void setName(String name) { this.name = name; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public boolean isLocked() { return locked; }

    public void setLocked(boolean locked) { this.locked = locked; }

    public Vec3i origin() { return origin; }

    public void setOrigin(Vec3i origin) { this.origin = origin; }

    public void move(int dx, int dy, int dz) { this.origin = origin.add(dx, dy, dz); }

    public Rotation rotation() { return rotation; }

    public void setRotation(Rotation rotation) {
        this.rotation = rotation;
        recomputeAnchor();
    }

    public void rotateBy(Rotation delta) { setRotation(rotation.add(delta)); }

    public Mirror mirror() { return mirror; }

    public void setMirror(Mirror mirror) {
        this.mirror = mirror;
        recomputeAnchor();
    }

    public LayerRange layerRange() { return layerRange; }

    public void setLayerRange(LayerRange layerRange) { this.layerRange = layerRange; }

    public Set<String> hiddenRegions() { return hiddenRegions; }

    public boolean isRegionVisible(SchematicRegion region) {
        return !hiddenRegions.contains(region.name());
    }

    public void setRegionVisible(String regionName, boolean visible) {
        if (visible) hiddenRegions.remove(regionName);
        else hiddenRegions.add(regionName);
    }

    // --- coordinate transforms -------------------------------------------------------------------

    /** Maps a schematic-local position to a world position. */
    public Vec3i toWorld(Vec3i schematicLocal) {
        return rotation.apply(mirror.apply(schematicLocal)).subtract(anchorOffset).add(origin);
    }

    /** Maps a world position back to schematic-local space. */
    public Vec3i toSchematic(Vec3i world) {
        Vec3i transformed = world.subtract(origin).add(anchorOffset);
        return mirror.apply(rotation.inverse().apply(transformed));
    }

    /** Maps a region-local position to a world position. */
    public Vec3i regionToWorld(SchematicRegion region, int x, int y, int z) {
        return toWorld(region.origin().add(x, y, z));
    }

    /** The world-space box this placement occupies. */
    public BlockBox worldBounds() {
        BlockBox local = schematic.enclosingBox();
        Vec3i a = toWorld(local.min());
        Vec3i b = toWorld(local.max());
        return BlockBox.of(a, b);
    }

    /**
     * The block this placement wants at a world position, or null when the placement does not
     * cover it, the region is hidden, or the layer slice excludes it.
     */
    public BlockStateRef expectedAt(Vec3i world) {
        if (!enabled) return null;

        Vec3i local = toSchematic(world);
        if (!layerRange.contains(local)) return null;

        for (SchematicRegion region : schematic.regions()) {
            if (!isRegionVisible(region)) continue;
            Vec3i inRegion = local.subtract(region.origin());
            if (!region.contains(inRegion.x(), inRegion.y(), inRegion.z())) continue;

            BlockStateRef state = swaps != null
                    ? swaps.stateAt(region, inRegion)
                    : region.getBlock(inRegion);
            if (state.isEmpty()) continue;
            // The transform has to be applied to the state too, or a rotated build keeps its
            // stairs facing the original way.
            return state.mirror(mirror).rotate(rotation);
        }
        return null;
    }

    /**
     * Re-derives the offset that keeps the transformed build anchored at {@link #origin()}.
     *
     * <p>Called on every transform change rather than on every block lookup, which matters because
     * the renderer calls {@link #toWorld} millions of times per rebuild.
     */
    private void recomputeAnchor() {
        BlockBox box = schematic.enclosingBox();
        Vec3i a = rotation.apply(mirror.apply(box.min()));
        Vec3i b = rotation.apply(mirror.apply(box.max()));
        anchorOffset = a.min(b);
    }

    /** Recomputes cached geometry after the schematic itself was resized. */
    public void refresh() { recomputeAnchor(); }

    public SchematicPlacement copy() {
        SchematicPlacement copy = new SchematicPlacement(schematic, swaps, origin);
        copy.rotation = rotation;
        copy.mirror = mirror;
        copy.layerRange = layerRange;
        copy.enabled = enabled;
        copy.name = name + " (copy)";
        copy.hiddenRegions.addAll(hiddenRegions);
        copy.recomputeAnchor();
        return copy;
    }

    @Override
    public String toString() {
        return "SchematicPlacement[" + name + " at " + origin
                + ", " + rotation + ", " + mirror + "]";
    }
}
