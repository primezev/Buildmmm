package dev.buildmatic.core.render;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;

/**
 * Finds the schematic block under the crosshair.
 *
 * <p>Targeting the ghost rather than the world is what makes clicking a preview block possible at
 * all: the blocks the player wants to swap usually are not placed yet, so vanilla's own ray trace
 * looks straight through them.
 *
 * <p>Uses Amanatides-Woo voxel traversal, which visits exactly the cells the ray passes through -
 * no sampling steps to tune, and no missed blocks at grazing angles.
 */
public final class GhostRaycast {

    /** What the ray hit. */
    public record Hit(SchematicRegion region, Vec3i localPos, Vec3i worldPos, BlockStateRef state,
                      Direction face, double distance) {}

    private GhostRaycast() {}

    /**
     * Traces from {@code origin} along {@code direction}.
     *
     * @param direction   need not be normalised
     * @param maxDistance in blocks
     * @return the first non-empty schematic block along the ray, or null
     */
    public static Hit trace(SchematicPlacement placement, SwapEngine swaps,
                            double originX, double originY, double originZ,
                            double directionX, double directionY, double directionZ,
                            double maxDistance) {
        if (placement == null || !placement.isEnabled()) return null;

        double length = Math.sqrt(directionX * directionX
                + directionY * directionY + directionZ * directionZ);
        if (length < 1.0e-9) return null;
        double dx = directionX / length;
        double dy = directionY / length;
        double dz = directionZ / length;

        int x = (int) Math.floor(originX);
        int y = (int) Math.floor(originY);
        int z = (int) Math.floor(originZ);

        int stepX = dx > 0 ? 1 : (dx < 0 ? -1 : 0);
        int stepY = dy > 0 ? 1 : (dy < 0 ? -1 : 0);
        int stepZ = dz > 0 ? 1 : (dz < 0 ? -1 : 0);

        double tMaxX = boundaryDistance(originX, x, dx, stepX);
        double tMaxY = boundaryDistance(originY, y, dy, stepY);
        double tMaxZ = boundaryDistance(originZ, z, dz, stepZ);

        double tDeltaX = stepX == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dx);
        double tDeltaY = stepY == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dy);
        double tDeltaZ = stepZ == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dz);

        double travelled = 0;
        Direction enteredFace = null;

        // The first cell is tested before any step, so a ray starting inside a block hits it.
        while (travelled <= maxDistance) {
            Hit hit = testCell(placement, swaps, x, y, z, enteredFace, travelled);
            if (hit != null) return hit;

            if (tMaxX < tMaxY && tMaxX < tMaxZ) {
                x += stepX;
                travelled = tMaxX;
                tMaxX += tDeltaX;
                enteredFace = stepX > 0 ? Direction.WEST : Direction.EAST;
            } else if (tMaxY < tMaxZ) {
                y += stepY;
                travelled = tMaxY;
                tMaxY += tDeltaY;
                enteredFace = stepY > 0 ? Direction.DOWN : Direction.UP;
            } else {
                z += stepZ;
                travelled = tMaxZ;
                tMaxZ += tDeltaZ;
                enteredFace = stepZ > 0 ? Direction.NORTH : Direction.SOUTH;
            }

            if (stepX == 0 && stepY == 0 && stepZ == 0) break;
        }
        return null;
    }

    /** Distance along the ray to the first cell boundary on this axis. */
    private static double boundaryDistance(double origin, int cell, double direction, int step) {
        if (step == 0) return Double.POSITIVE_INFINITY;
        double boundary = step > 0 ? cell + 1 : cell;
        return (boundary - origin) / direction;
    }

    private static Hit testCell(SchematicPlacement placement, SwapEngine swaps,
                                int x, int y, int z, Direction face, double distance) {
        Vec3i worldPos = new Vec3i(x, y, z);
        Vec3i schematicPos = placement.toSchematic(worldPos);
        if (!placement.layerRange().contains(schematicPos)) return null;

        for (SchematicRegion region : placement.schematic().regions()) {
            if (!placement.isRegionVisible(region)) continue;

            Vec3i local = schematicPos.subtract(region.origin());
            if (!region.contains(local.x(), local.y(), local.z())) continue;

            BlockStateRef state = swaps != null
                    ? swaps.stateAt(region, local)
                    : region.getBlock(local);
            if (state.isEmpty()) continue;

            return new Hit(region, local, worldPos, state, face, distance);
        }
        return null;
    }
}
