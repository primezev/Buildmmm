package dev.buildmatic.core.render;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.util.Vec3i;

import java.util.List;

/**
 * The draw list for one 16-cube of a region.
 *
 * <p>Deciding <em>what</em> to draw is separated from <em>how</em> to draw it: this class and
 * {@link GhostSliceBuilder} contain all the culling, filtering and layer logic and are plain Java,
 * while the per-version renderer only walks the resulting list and pushes geometry. That split is
 * what keeps the Minecraft-specific rendering code small enough to port between versions that
 * rewrote their pipeline.
 */
public record GhostSlice(SwapEngine.ChunkKey key, List<Entry> entries, int drawnFaces) {

    /**
     * One block to draw.
     *
     * @param localPos   position within the region
     * @param state      the state after swaps, which is what the player should see
     * @param faceMask   bit per {@link dev.buildmatic.core.util.Direction#index()}; a set bit means
     *                   the face is visible and worth submitting
     * @param status     why this block is in the list, which drives its tint
     */
    public record Entry(Vec3i localPos, BlockStateRef state, int faceMask, Status status) {

        public boolean isFaceVisible(dev.buildmatic.core.util.Direction direction) {
            return (faceMask & (1 << direction.index())) != 0;
        }

        public boolean isFullyHidden() { return faceMask == 0; }
    }

    /** How a drawn block relates to what is already in the world. */
    public enum Status {
        /** The world state is unknown, so the block is drawn plainly. */
        UNKNOWN,
        /** The world already matches; usually not drawn at all. */
        PLACED,
        /** Nothing is there yet. */
        MISSING,
        /** Something else is there. */
        WRONG
    }

    public boolean isEmpty() { return entries.isEmpty(); }

    public int size() { return entries.size(); }
}
