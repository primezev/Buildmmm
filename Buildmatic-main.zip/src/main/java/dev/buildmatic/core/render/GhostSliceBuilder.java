package dev.buildmatic.core.render;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.placement.LayerRange;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.verify.WorldView;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the draw list for one 16-cube.
 *
 * <p>Three things cut the geometry down, in this order:
 * <ol>
 *   <li>the layer slice, which removes whole rows before anything else is computed;</li>
 *   <li>the render filter, which is how "show only what is still missing" avoids drawing a
 *       finished build at all;</li>
 *   <li>face culling against neighbours, including across the slice boundary so two adjacent
 *       slices do not each draw the wall between them.</li>
 * </ol>
 *
 * <p>Rebuilds are per-slice, which is what makes the swap engine's dirty tracking pay off: swapping
 * one clicked block re-runs this for one 16-cube, not for the whole build.
 */
public final class GhostSliceBuilder {

    /** What the player wants to see. */
    public enum Filter {
        /** Every block of the schematic. */
        ALL,
        /** Only blocks that are not yet placed correctly. */
        MISSING,
        /** Only positions where the world holds something different. */
        WRONG,
        /** Only blocks that a swap layer has changed, for reviewing an edit. */
        SWAPPED
    }

    /** Everything the builder needs that does not change between slices. */
    public record Context(SchematicPlacement placement, SwapEngine swaps, OcclusionOracle occlusion,
                          WorldView world, Filter filter) {

        public static Context of(SchematicPlacement placement, SwapEngine swaps) {
            return new Context(placement, swaps, OcclusionOracle.HEURISTIC, null, Filter.ALL);
        }

        public Context withFilter(Filter filter) {
            return new Context(placement, swaps, occlusion, world, filter);
        }

        public Context withWorld(WorldView world) {
            return new Context(placement, swaps, occlusion, world, filter);
        }

        public Context withOcclusion(OcclusionOracle occlusion) {
            return new Context(placement, swaps, occlusion, world, filter);
        }
    }

    private GhostSliceBuilder() {}

    public static GhostSlice build(SchematicRegion region, SwapEngine.ChunkKey key, Context context) {
        int baseX = key.cx() << 4;
        int baseY = key.cy() << 4;
        int baseZ = key.cz() << 4;

        int maxX = Math.min(baseX + 16, region.sizeX());
        int maxY = Math.min(baseY + 16, region.sizeY());
        int maxZ = Math.min(baseZ + 16, region.sizeZ());

        List<GhostSlice.Entry> entries = new ArrayList<>();
        int drawnFaces = 0;

        LayerRange layers = context.placement().layerRange();

        for (int y = Math.max(0, baseY); y < maxY; y++) {
            for (int z = Math.max(0, baseZ); z < maxZ; z++) {
                for (int x = Math.max(0, baseX); x < maxX; x++) {
                    Vec3i local = new Vec3i(x, y, z);
                    Vec3i schematicPos = region.origin().add(local);
                    if (!layers.contains(schematicPos)) continue;

                    BlockStateRef state = effectiveState(region, context, x, y, z);
                    if (state.isEmpty()) continue;

                    // The entry carries the state in world orientation, the same one the paste
                    // writes. The renderer only translates each block, so leaving the schematic's
                    // own orientation here drew a rotated build with every door, trapdoor and stair
                    // still facing the way it did before the turn - and the preview then disagreed
                    // with what pasting actually produced.
                    BlockStateRef oriented = state
                            .mirror(context.placement().mirror())
                            .rotate(context.placement().rotation());

                    GhostSlice.Status status = statusOf(context, schematicPos, oriented);
                    // The filter still compares against the untransformed state: SWAPPED asks
                    // whether a swap changed the block, which the rotation must not answer for it.
                    if (!passesFilter(context, region, local, state, status)) continue;

                    int faceMask = faceMask(region, context, x, y, z, layers);
                    if (faceMask == 0) continue;

                    drawnFaces += Integer.bitCount(faceMask);
                    entries.add(new GhostSlice.Entry(local, oriented, faceMask, status));
                }
            }
        }
        return new GhostSlice(key, List.copyOf(entries), drawnFaces);
    }

    private static BlockStateRef effectiveState(SchematicRegion region, Context context,
                                                int x, int y, int z) {
        return context.swaps() != null
                ? context.swaps().stateAt(region, x, y, z)
                : region.getBlock(x, y, z);
    }

    /**
     * Which faces are worth drawing.
     *
     * <p>A face is dropped when the neighbour on that side is an opaque full cube that is itself
     * being drawn. Neighbours outside the layer slice do not count as occluders: hiding a face
     * behind a block the player has sliced away would leave the cut surface transparent.
     */
    private static int faceMask(SchematicRegion region, Context context,
                                int x, int y, int z, LayerRange layers) {
        int mask = 0;
        for (Direction direction : Direction.values()) {
            int nx = x + direction.stepX();
            int ny = y + direction.stepY();
            int nz = z + direction.stepZ();

            boolean visible;
            if (!region.contains(nx, ny, nz)) {
                // The region edge is always drawn: something else may or may not be beyond it.
                visible = true;
            } else if (!layers.contains(region.origin().add(nx, ny, nz))) {
                visible = true;
            } else {
                BlockStateRef neighbour = effectiveState(region, context, nx, ny, nz);
                visible = !context.occlusion().occludesNeighbourFace(neighbour);
            }
            if (visible) mask |= 1 << direction.index();
        }
        return mask;
    }

    /** @param expected the state already in world orientation, as the entry stores it */
    private static GhostSlice.Status statusOf(Context context, Vec3i schematicPos,
                                              BlockStateRef expected) {
        WorldView world = context.world();
        if (world == null) return GhostSlice.Status.UNKNOWN;

        Vec3i worldPos = context.placement().toWorld(schematicPos);
        if (!world.isLoaded(worldPos.x(), worldPos.y(), worldPos.z())) {
            return GhostSlice.Status.UNKNOWN;
        }

        BlockStateRef found = world.blockAt(worldPos.x(), worldPos.y(), worldPos.z());
        if (found == null || found.isEmpty()) return GhostSlice.Status.MISSING;
        // Both sides are already in world orientation, so they compare directly.
        return found.equals(expected) ? GhostSlice.Status.PLACED : GhostSlice.Status.WRONG;
    }

    private static boolean passesFilter(Context context, SchematicRegion region, Vec3i local,
                                        BlockStateRef state, GhostSlice.Status status) {
        switch (context.filter()) {
            case ALL:
                return true;
            case MISSING:
                return status != GhostSlice.Status.PLACED;
            case WRONG:
                return status == GhostSlice.Status.WRONG;
            case SWAPPED:
                return context.swaps() != null
                        && !state.equals(region.getBlock(local.x(), local.y(), local.z()));
            default:
                return true;
        }
    }

    /**
     * The slice keys covering a region.
     *
     * <p>Cached per region: the renderer walks this list every frame, and a region's dimensions
     * never change, so rebuilding it was allocating a few hundred keys sixty times a second for an
     * answer that is always the same.
     */
    public static List<SwapEngine.ChunkKey> slicesOf(SchematicRegion region) {
        return SLICE_KEYS.computeIfAbsent(region, GhostSliceBuilder::computeSlicesOf);
    }

    private static final java.util.Map<SchematicRegion, List<SwapEngine.ChunkKey>> SLICE_KEYS =
            java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    private static List<SwapEngine.ChunkKey> computeSlicesOf(SchematicRegion region) {
        List<SwapEngine.ChunkKey> keys = new ArrayList<>();
        int cx = (region.sizeX() + 15) >> 4;
        int cy = (region.sizeY() + 15) >> 4;
        int cz = (region.sizeZ() + 15) >> 4;
        for (int y = 0; y < cy; y++) {
            for (int z = 0; z < cz; z++) {
                for (int x = 0; x < cx; x++) {
                    keys.add(new SwapEngine.ChunkKey(region.name(), x, y, z));
                }
            }
        }
        return List.copyOf(keys);
    }
}
