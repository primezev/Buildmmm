package dev.buildmatic.core.render;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.variant.BlockShape;

/**
 * Whether a block hides the face of its neighbour.
 *
 * <p>Only the running game knows this exactly, so the platform supplies an implementation backed by
 * the real block shapes. {@link #HEURISTIC} answers from the block id alone, which is accurate for
 * every full cube and deliberately conservative for everything else - drawing a face that would
 * have been hidden costs a few triangles, hiding one that should be visible leaves a hole.
 */
@FunctionalInterface
public interface OcclusionOracle {

    /** True when a block of this state completely covers the face pointing back at it. */
    boolean occludesNeighbourFace(BlockStateRef state);

    OcclusionOracle HEURISTIC = state -> {
        if (state.isEmpty()) return false;
        // Anything that can hold water has gaps in it.
        if (state.booleanProperty("waterlogged", false)) return false;
        String path = state.path();
        if (path.contains("glass") || path.contains("leaves") || path.contains("ice")) return false;
        if (state.hasProperty("open") || state.hasProperty("layers")) return false;
        // A double slab fills its cube; any other slab does not.
        if (state.hasProperty("type")) return state.is("type", "double");
        return BlockShape.of(path).shape().isFullCube();
    };

    /** Nothing occludes anything; every face is drawn. Used by the wireframe mode. */
    OcclusionOracle NONE = state -> false;
}
