package dev.buildmatic.core.schematic;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * The blocks in a schematic that the running game has never heard of.
 *
 * <p>Unknown ids become air when they reach the world, so a build that needs mods you do not have
 * loads with holes in it. Silently: the windows and the lanterns are simply absent, and the file
 * looks corrupt rather than incomplete. This turns that into something the player can read, which
 * is usually enough to recognise the mod they are missing from its namespace alone.
 *
 * @param total       how many blocks were dropped
 * @param byNamespace how many per mod id, most first
 * @param byBlock     how many per block id, most first
 */
public record MissingBlocks(int total, Map<String, Integer> byNamespace,
                            Map<String, Integer> byBlock) {

    private static final MissingBlocks NONE =
            new MissingBlocks(0, Map.of(), Map.of());

    /**
     * Counts what {@code schema} cannot resolve.
     *
     * <p>Driven by the palette counts rather than by walking every position: a schematic has a few
     * hundred distinct states at most, however many million blocks it places.
     */
    public static MissingBlocks scan(Schematic schematic, BlockStateSchema schema) {
        if (schematic == null || schema == null) return NONE;

        Map<String, Integer> perBlock = new TreeMap<>();
        int total = 0;
        for (Map.Entry<BlockStateRef, Integer> entry : schematic.countBlocks().entrySet()) {
            BlockStateRef state = entry.getKey();
            if (state.isEmpty() || schema.isKnownBlock(state.blockId())) continue;
            perBlock.merge(state.blockId(), entry.getValue(), Integer::sum);
            total += entry.getValue();
        }
        if (total == 0) return NONE;

        Map<String, Integer> perNamespace = new TreeMap<>();
        for (Map.Entry<String, Integer> entry : perBlock.entrySet()) {
            perNamespace.merge(namespaceOf(entry.getKey()), entry.getValue(), Integer::sum);
        }
        return new MissingBlocks(total, sortedByCount(perNamespace), sortedByCount(perBlock));
    }

    public boolean isEmpty() { return total == 0; }

    /** How many distinct mods the missing blocks come from. */
    public int modCount() { return byNamespace.size(); }

    /**
     * One line for the status bar.
     *
     * <p>Namespaces rather than block ids: "mcwwindows" tells you to go and install Macaw's Windows,
     * while "mcwwindows:dark_oak_four_window" tells you the same thing in four times the space.
     */
    public String describe() {
        if (isEmpty()) return "";

        StringBuilder out = new StringBuilder();
        out.append(total).append(total == 1 ? " block from " : " blocks from ")
                .append(modCount()).append(modCount() == 1 ? " missing mod: " : " missing mods: ");

        int shown = 0;
        for (Map.Entry<String, Integer> entry : byNamespace.entrySet()) {
            if (shown == 3) {
                out.append(", and ").append(modCount() - shown).append(" more");
                break;
            }
            if (shown > 0) out.append(", ");
            out.append(entry.getKey()).append(" (").append(entry.getValue()).append(')');
            shown++;
        }
        return out.toString();
    }

    /**
     * The count without the mod names, for lines that already carry other figures.
     *
     * <p>The Materials footer follows three counts of its own, and the names pushed it off the
     * panel. The full list is on the load message, which is where someone reads it once and goes
     * to install something.
     */
    public String describeShort() {
        if (isEmpty()) return "";
        return total + (total == 1 ? " block from " : " blocks from ")
                + modCount() + (modCount() == 1 ? " missing mod" : " missing mods");
    }

    private static String namespaceOf(String blockId) {
        int colon = blockId.indexOf(':');
        return colon < 0 ? "minecraft" : blockId.substring(0, colon);
    }

    private static Map<String, Integer> sortedByCount(Map<String, Integer> counts) {
        Map<String, Integer> sorted = new LinkedHashMap<>();
        counts.entrySet().stream()
                .sorted((a, b) -> {
                    int byCount = b.getValue() - a.getValue();
                    return byCount != 0 ? byCount : a.getKey().compareTo(b.getKey());
                })
                .forEach(e -> sorted.put(e.getKey(), e.getValue()));
        return sorted;
    }
}
