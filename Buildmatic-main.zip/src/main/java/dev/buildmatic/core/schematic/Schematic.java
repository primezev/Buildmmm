package dev.buildmatic.core.schematic;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A complete build: metadata plus one or more {@link SchematicRegion regions}.
 *
 * <p>All coordinates exposed here are schematic-local. Where a region sits in the world is the
 * placement's business, not the schematic's - the same schematic can be placed many times at once.
 */
public final class Schematic {

    private final SchematicMetadata metadata;
    private final List<SchematicRegion> regions = new ArrayList<>();

    /** Where the file came from, when it came from a file. */
    private Path sourceFile;
    private SchematicFormat sourceFormat = SchematicFormat.BUILDMATIC;

    public Schematic() {
        this(new SchematicMetadata());
    }

    public Schematic(SchematicMetadata metadata) {
        this.metadata = metadata;
    }

    /** Convenience factory for a single-region schematic of the given size. */
    public static Schematic single(String name, Vec3i size) {
        Schematic schematic = new Schematic();
        schematic.metadata.setName(name);
        schematic.addRegion(new SchematicRegion("main", Vec3i.ZERO, size));
        schematic.refreshStatistics();
        return schematic;
    }

    public SchematicMetadata metadata() { return metadata; }

    public List<SchematicRegion> regions() { return Collections.unmodifiableList(regions); }

    public int regionCount() { return regions.size(); }

    public SchematicRegion region(int index) { return regions.get(index); }

    public SchematicRegion region(String name) {
        for (SchematicRegion r : regions) {
            if (r.name().equals(name)) return r;
        }
        return null;
    }

    public void addRegion(SchematicRegion region) {
        regions.add(region);
    }

    public boolean removeRegion(SchematicRegion region) {
        return regions.remove(region);
    }

    public Path sourceFile() { return sourceFile; }

    public void setSourceFile(Path sourceFile) { this.sourceFile = sourceFile; }

    public SchematicFormat sourceFormat() { return sourceFormat; }

    public void setSourceFormat(SchematicFormat sourceFormat) { this.sourceFormat = sourceFormat; }

    // --- geometry ------------------------------------------------------------------------------

    /** The smallest box containing every region, in schematic-local space. */
    public BlockBox enclosingBox() {
        if (regions.isEmpty()) return new BlockBox(Vec3i.ZERO, Vec3i.ZERO);
        BlockBox box = regions.get(0).bounds();
        for (int i = 1; i < regions.size(); i++) {
            box = box.union(regions.get(i).bounds());
        }
        return box;
    }

    public Vec3i enclosingSize() { return enclosingBox().size(); }

    /**
     * Reads a block in schematic-local space, searching regions front to back.
     *
     * <p>Overlapping regions resolve to the first one that holds a non-air block there, which is
     * how Litematica's multi-region files are meant to be read.
     */
    public BlockStateRef getBlock(int x, int y, int z) {
        BlockStateRef found = BlockStateRef.AIR;
        for (SchematicRegion region : regions) {
            Vec3i origin = region.origin();
            int lx = x - origin.x();
            int ly = y - origin.y();
            int lz = z - origin.z();
            if (!region.contains(lx, ly, lz)) continue;
            BlockStateRef state = region.getBlock(lx, ly, lz);
            if (!state.isAir()) return state;
            found = state;
        }
        return found;
    }

    public BlockStateRef getBlock(Vec3i pos) {
        return getBlock(pos.x(), pos.y(), pos.z());
    }

    /** The region containing a schematic-local position, or null when none does. */
    public SchematicRegion regionAt(Vec3i pos) {
        for (SchematicRegion region : regions) {
            Vec3i local = pos.subtract(region.origin());
            if (region.contains(local.x(), local.y(), local.z())) return region;
        }
        return null;
    }

    // --- statistics ----------------------------------------------------------------------------

    /** Counts non-empty blocks per state across every region. */
    public Map<BlockStateRef, Integer> countBlocks() {
        Map<BlockStateRef, Integer> counts = new HashMap<>();
        for (SchematicRegion region : regions) {
            int[] histogram = region.paletteHistogram();
            for (int i = 0; i < histogram.length; i++) {
                if (histogram[i] == 0) continue;
                BlockStateRef state = region.palette().get(i);
                if (state.isEmpty()) continue;
                counts.merge(state, histogram[i], Integer::sum);
            }
        }
        return counts;
    }

    /** Every distinct non-empty state present, in stable descriptor order. */
    public List<BlockStateRef> distinctStates() {
        List<BlockStateRef> states = new ArrayList<>(countBlocks().keySet());
        Collections.sort(states);
        return states;
    }

    /** Distinct block ids mapped to the states that use them, in stable order. */
    public Map<String, List<BlockStateRef>> statesByBlock() {
        Map<String, List<BlockStateRef>> grouped = new LinkedHashMap<>();
        for (BlockStateRef state : distinctStates()) {
            grouped.computeIfAbsent(state.blockId(), k -> new ArrayList<>()).add(state);
        }
        return grouped;
    }

    public long totalBlocks() {
        long total = 0;
        for (Map.Entry<BlockStateRef, Integer> e : countBlocks().entrySet()) {
            total += e.getValue();
        }
        return total;
    }

    public long totalVolume() {
        long total = 0;
        for (SchematicRegion region : regions) total += region.volume();
        return total;
    }

    /** Recomputes the cached counters in {@link #metadata()}. Call after bulk edits. */
    public Schematic refreshStatistics() {
        metadata.setRegionCount(regions.size());
        metadata.setEnclosingSize(enclosingSize());
        metadata.setTotalBlocks(totalBlocks());
        metadata.setTotalVolume(totalVolume());
        return this;
    }

    public Schematic copy() {
        Schematic copy = new Schematic(metadata.copy());
        for (SchematicRegion region : regions) copy.regions.add(region.copy());
        copy.sourceFile = sourceFile;
        copy.sourceFormat = sourceFormat;
        return copy;
    }

    @Override
    public String toString() {
        Vec3i size = enclosingSize();
        return "Schematic[" + metadata.name() + " " + size.x() + "x" + size.y() + "x" + size.z()
                + ", " + regions.size() + " region(s)]";
    }
}
