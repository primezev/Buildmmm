package dev.buildmatic.core.schematic;

import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtList;
import dev.buildmatic.core.nbt.NbtTag;
import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;

/**
 * An entity stored inside a schematic, positioned relative to its region origin.
 *
 * <p>The raw NBT is kept verbatim so nothing is lost on a load/save round trip, even for entity
 * types or data fields the running game version has never heard of.
 */
public record SchematicEntity(String id, double x, double y, double z, NbtCompound nbt) {

    public static SchematicEntity fromNbt(NbtCompound tag) {
        NbtList pos = tag.getList("Pos");
        double x = pos != null && pos.size() > 0 ? pos.getDouble(0) : 0;
        double y = pos != null && pos.size() > 1 ? pos.getDouble(1) : 0;
        double z = pos != null && pos.size() > 2 ? pos.getDouble(2) : 0;
        String id = tag.getString("id", tag.getString("Id", ""));
        return new SchematicEntity(id, x, y, z, tag);
    }

    /** Returns a copy of the backing NBT with {@code Pos} rewritten to this entity's coordinates. */
    public NbtCompound toNbt() {
        NbtCompound out = nbt.copy();
        out.put("Pos", NbtList.ofDoubles(x, y, z));
        if (!id.isEmpty() && !out.contains("id")) out.putString("id", id);
        return out;
    }

    public SchematicEntity withPosition(double nx, double ny, double nz) {
        return new SchematicEntity(id, nx, ny, nz, nbt);
    }

    /**
     * Rotates the entity around the origin of a region of the given size.
     *
     * <p>Yaw lives in the {@code Rotation} list, which is also rewritten so that mobs, item frames
     * and armour stands keep facing the way the builder intended.
     */
    public SchematicEntity rotate(Rotation rotation, double sizeX, double sizeZ) {
        if (rotation == Rotation.NONE) return this;
        double nx;
        double nz;
        switch (rotation) {
            case CLOCKWISE_90 -> { nx = sizeZ - z; nz = x; }
            case CLOCKWISE_180 -> { nx = sizeX - x; nz = sizeZ - z; }
            case COUNTERCLOCKWISE_90 -> { nx = z; nz = sizeX - x; }
            default -> { nx = x; nz = z; }
        }
        return new SchematicEntity(id, nx, y, nz, withYaw(rotation.degrees()));
    }

    public SchematicEntity mirror(Mirror mirror, double sizeX, double sizeZ) {
        return switch (mirror) {
            case NONE -> this;
            case FRONT_BACK -> new SchematicEntity(id, sizeX - x, y, z, withMirroredYaw(true));
            case LEFT_RIGHT -> new SchematicEntity(id, x, y, sizeZ - z, withMirroredYaw(false));
        };
    }

    private NbtCompound withYaw(double degrees) {
        NbtList rot = nbt.getList("Rotation");
        if (rot == null || rot.isEmpty()) return nbt;
        NbtCompound out = nbt.copy();
        float yaw = (float) (rot.getDouble(0) + degrees);
        float pitch = rot.size() > 1 ? (float) rot.getDouble(1) : 0f;
        NbtList replacement = new NbtList(NbtTag.TAG_FLOAT);
        replacement.add(new NbtTag.NbtFloat(wrapDegrees(yaw)));
        replacement.add(new NbtTag.NbtFloat(pitch));
        out.put("Rotation", replacement);
        return out;
    }

    private NbtCompound withMirroredYaw(boolean acrossX) {
        NbtList rot = nbt.getList("Rotation");
        if (rot == null || rot.isEmpty()) return nbt;
        NbtCompound out = nbt.copy();
        float yaw = (float) rot.getDouble(0);
        // Yaw 0 faces south (+Z) and grows clockwise, so a west/east flip negates it and a
        // north/south flip reflects it about the 180 line.
        float mirrored = acrossX ? -yaw : 180f - yaw;
        float pitch = rot.size() > 1 ? (float) rot.getDouble(1) : 0f;
        NbtList replacement = new NbtList(NbtTag.TAG_FLOAT);
        replacement.add(new NbtTag.NbtFloat(wrapDegrees(mirrored)));
        replacement.add(new NbtTag.NbtFloat(pitch));
        out.put("Rotation", replacement);
        return out;
    }

    private static float wrapDegrees(float degrees) {
        float wrapped = degrees % 360f;
        if (wrapped >= 180f) wrapped -= 360f;
        if (wrapped < -180f) wrapped += 360f;
        return wrapped;
    }
}
