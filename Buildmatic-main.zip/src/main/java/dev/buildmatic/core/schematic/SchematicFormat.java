package dev.buildmatic.core.schematic;

import java.util.Locale;

/** The schematic container formats Buildmatic understands. */
public enum SchematicFormat {

    /** Litematica's own format. Multi-region, keeps entities and pending ticks. */
    LITEMATICA("litematic", "Litematica", true, true),

    /** Sponge schematic, versions 1 through 3. Single region, widely supported by WorldEdit. */
    SPONGE("schem", "Sponge Schematic", true, true),

    /** Vanilla structure block NBT. Single region, capped at 48x48x48 by the game itself. */
    VANILLA_STRUCTURE("nbt", "Vanilla Structure", true, true),

    /** MCEdit's pre-flattening format with numeric block ids. Read-only. */
    MCEDIT("schematic", "MCEdit (legacy)", true, false),

    /** Buildmatic's native format: a Litematica file plus persisted swap layers. */
    BUILDMATIC("buildmatic", "Buildmatic", true, true);

    private final String extension;
    private final String displayName;
    private final boolean readable;
    private final boolean writable;

    SchematicFormat(String extension, String displayName, boolean readable, boolean writable) {
        this.extension = extension;
        this.displayName = displayName;
        this.readable = readable;
        this.writable = writable;
    }

    public String extension() { return extension; }

    public String displayName() { return displayName; }

    public boolean readable() { return readable; }

    public boolean writable() { return writable; }

    /** Matches a file name against the known extensions; returns null when nothing fits. */
    public static SchematicFormat byFileName(String fileName) {
        String lower = fileName.toLowerCase(Locale.ROOT);
        int dot = lower.lastIndexOf('.');
        if (dot < 0) return null;
        String ext = lower.substring(dot + 1);
        for (SchematicFormat format : values()) {
            if (format.extension.equals(ext)) return format;
        }
        return null;
    }

    /**
     * Identifies the format from the parsed root tag, for files with a wrong or missing extension.
     *
     * <p>Each format has an unambiguous marker: Litematica has {@code Regions}, Sponge v3 nests
     * everything under {@code Schematic}, Sponge v1/v2 has {@code BlockData}, vanilla structures
     * have {@code blocks}, and MCEdit has a byte array named {@code Blocks}.
     */
    public static SchematicFormat byContent(dev.buildmatic.core.nbt.NbtCompound root) {
        if (root.contains("SwapLayers") && root.contains("Regions")) return BUILDMATIC;
        if (root.contains("Regions")) return LITEMATICA;
        if (root.contains("Schematic")) return SPONGE;
        if (root.contains("BlockData") || root.contains("Palette")) return SPONGE;
        if (root.contains("blocks") && root.contains("palette")) return VANILLA_STRUCTURE;
        if (root.contains("Blocks")) return MCEDIT;
        return null;
    }
}
