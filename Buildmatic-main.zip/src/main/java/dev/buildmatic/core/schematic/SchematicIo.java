package dev.buildmatic.core.schematic;

import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtIo;
import dev.buildmatic.core.schematic.format.LitematicaFormat;
import dev.buildmatic.core.schematic.format.SpongeSchematicFormat;
import dev.buildmatic.core.schematic.format.VanillaStructureFormat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * The single entry point for reading and writing schematic files.
 *
 * <p>Format detection prefers the file's own contents over its extension, because renaming a
 * {@code .schem} to {@code .litematic} is a common way for a build to arrive broken.
 */
public final class SchematicIo {

    private SchematicIo() {}

    /** Loads a schematic, detecting the format from its contents. */
    public static Schematic load(Path file) throws IOException {
        NbtCompound root = NbtIo.read(file);

        SchematicFormat format = SchematicFormat.byContent(root);
        if (format == null) format = SchematicFormat.byFileName(file.getFileName().toString());
        if (format == null) {
            throw new IOException("not a recognised schematic: " + file.getFileName());
        }

        Schematic schematic = read(root, format);
        schematic.setSourceFile(file);
        schematic.setSourceFormat(format);
        if (schematic.metadata().name().isBlank()) {
            schematic.metadata().setName(stripExtension(file.getFileName().toString()));
        }
        return schematic;
    }

    public static Schematic read(NbtCompound root, SchematicFormat format) throws IOException {
        switch (format) {
            case LITEMATICA:
            case BUILDMATIC:
                return LitematicaFormat.read(root);
            case SPONGE:
                return SpongeSchematicFormat.read(root);
            case VANILLA_STRUCTURE:
                return VanillaStructureFormat.read(root);
            case MCEDIT:
                throw new IOException("MCEdit schematics are not supported yet; "
                        + "convert the file with WorldEdit first");
            default:
                throw new IOException("unsupported format " + format);
        }
    }

    /**
     * Writes a schematic.
     *
     * @param dataVersion the running game's data version, stamped into the file so other tools
     *                    know which Minecraft release the block states belong to
     */
    public static void save(Schematic schematic, Path file, SchematicFormat format, int dataVersion)
            throws IOException {
        if (!format.writable()) {
            throw new IOException(format.displayName() + " files cannot be written");
        }
        schematic.metadata().touch();
        schematic.refreshStatistics();

        NbtCompound root = write(schematic, format, dataVersion);
        // Vanilla structures are the only format the game itself reads uncompressed as well;
        // everything else is always gzipped.
        NbtIo.write("", root, file, true);
        schematic.setSourceFile(file);
        schematic.setSourceFormat(format);
    }

    public static NbtCompound write(Schematic schematic, SchematicFormat format, int dataVersion)
            throws IOException {
        switch (format) {
            case LITEMATICA:
            case BUILDMATIC:
                return LitematicaFormat.write(schematic, dataVersion);
            case SPONGE:
                return SpongeSchematicFormat.write(schematic, dataVersion);
            case VANILLA_STRUCTURE:
                return VanillaStructureFormat.write(schematic, dataVersion);
            default:
                throw new IOException("cannot write " + format);
        }
    }

    /** Every readable schematic in a directory, newest first. Never recurses. */
    public static List<Path> list(Path directory) throws IOException {
        if (!Files.isDirectory(directory)) return List.of();
        List<Path> files = new ArrayList<>();
        try (Stream<Path> stream = Files.list(directory)) {
            stream.filter(Files::isRegularFile)
                    .filter(SchematicIo::looksLikeSchematic)
                    .forEach(files::add);
        }
        files.sort(Comparator.comparingLong(SchematicIo::lastModified).reversed());
        return files;
    }

    private static boolean looksLikeSchematic(Path file) {
        SchematicFormat format = SchematicFormat.byFileName(file.getFileName().toString());
        return format != null && format.readable();
    }

    private static long lastModified(Path file) {
        try {
            return Files.getLastModifiedTime(file).toMillis();
        } catch (IOException e) {
            return 0L;
        }
    }

    /**
     * Appends the format's extension unless the path already carries it.
     *
     * <p>Only a schematic extension is replaced. Everything after a dot is not a suffix -
     * {@code castle v1.2} is a name someone typed - so a trailing {@code .2} is kept and the
     * extension goes after it.
     */
    public static Path withExtension(Path file, SchematicFormat format) {
        String name = file.getFileName().toString();
        if (name.toLowerCase(Locale.ROOT).endsWith("." + format.extension())) return file;
        String base = SchematicFormat.byFileName(name) == null ? name : stripExtension(name);
        return file.resolveSibling(base + "." + format.extension());
    }

    static String stripExtension(String fileName) {
        int dot = fileName.lastIndexOf('.');
        return dot <= 0 ? fileName : fileName.substring(0, dot);
    }
}
