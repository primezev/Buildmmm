package dev.buildmatic.core.schematic;

import dev.buildmatic.core.util.Vec3i;

/** Descriptive information about a schematic; none of it affects the blocks. */
public final class SchematicMetadata {

    private String name = "Unnamed";
    private String author = "";
    private String description = "";
    private long timeCreated = System.currentTimeMillis();
    private long timeModified = System.currentTimeMillis();

    /** Optional ARGB thumbnail rendered by the schematic browser, or null. */
    private int[] previewImage;
    private int previewWidth;
    private int previewHeight;

    /** The Minecraft data version the file was written with; 0 when unknown. */
    private int dataVersion;
    /** The Minecraft release the file claims to target, e.g. {@code 1.21.8}; empty when unknown. */
    private String gameVersion = "";

    private Vec3i enclosingSize = Vec3i.ZERO;
    private long totalBlocks;
    private long totalVolume;
    private int regionCount;

    public String name() { return name; }

    public SchematicMetadata setName(String name) {
        this.name = name == null ? "" : name;
        return this;
    }

    public String author() { return author; }

    public SchematicMetadata setAuthor(String author) {
        this.author = author == null ? "" : author;
        return this;
    }

    public String description() { return description; }

    public SchematicMetadata setDescription(String description) {
        this.description = description == null ? "" : description;
        return this;
    }

    public long timeCreated() { return timeCreated; }

    public SchematicMetadata setTimeCreated(long millis) {
        this.timeCreated = millis;
        return this;
    }

    public long timeModified() { return timeModified; }

    public SchematicMetadata setTimeModified(long millis) {
        this.timeModified = millis;
        return this;
    }

    public void touch() { this.timeModified = System.currentTimeMillis(); }

    public int[] previewImage() { return previewImage; }

    public int previewWidth() { return previewWidth; }

    public int previewHeight() { return previewHeight; }

    public SchematicMetadata setPreviewImage(int[] argb, int width, int height) {
        this.previewImage = argb;
        this.previewWidth = width;
        this.previewHeight = height;
        return this;
    }

    public int dataVersion() { return dataVersion; }

    public SchematicMetadata setDataVersion(int dataVersion) {
        this.dataVersion = dataVersion;
        return this;
    }

    public String gameVersion() { return gameVersion; }

    public SchematicMetadata setGameVersion(String gameVersion) {
        this.gameVersion = gameVersion == null ? "" : gameVersion;
        return this;
    }

    public Vec3i enclosingSize() { return enclosingSize; }

    public SchematicMetadata setEnclosingSize(Vec3i size) {
        this.enclosingSize = size;
        return this;
    }

    public long totalBlocks() { return totalBlocks; }

    public SchematicMetadata setTotalBlocks(long totalBlocks) {
        this.totalBlocks = totalBlocks;
        return this;
    }

    public long totalVolume() { return totalVolume; }

    public SchematicMetadata setTotalVolume(long totalVolume) {
        this.totalVolume = totalVolume;
        return this;
    }

    public int regionCount() { return regionCount; }

    public SchematicMetadata setRegionCount(int regionCount) {
        this.regionCount = regionCount;
        return this;
    }

    public SchematicMetadata copy() {
        SchematicMetadata copy = new SchematicMetadata();
        copy.name = name;
        copy.author = author;
        copy.description = description;
        copy.timeCreated = timeCreated;
        copy.timeModified = timeModified;
        copy.previewImage = previewImage == null ? null : previewImage.clone();
        copy.previewWidth = previewWidth;
        copy.previewHeight = previewHeight;
        copy.dataVersion = dataVersion;
        copy.gameVersion = gameVersion;
        copy.enclosingSize = enclosingSize;
        copy.totalBlocks = totalBlocks;
        copy.totalVolume = totalVolume;
        copy.regionCount = regionCount;
        return copy;
    }
}
