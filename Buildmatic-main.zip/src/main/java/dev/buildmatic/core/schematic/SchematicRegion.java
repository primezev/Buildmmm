package dev.buildmatic.core.schematic;

import dev.buildmatic.core.block.BlockPalette;
import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.util.BitStorage;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.ObjIntConsumer;

/**
 * One cuboid of blocks inside a schematic.
 *
 * <p>A schematic may hold several regions, which is how Litematica represents non-cuboid builds
 * without wasting storage on the empty space between them.
 *
 * <p>Blocks live in a palette plus a {@link BitStorage}, exactly as they do on disk, so loading is
 * close to a straight memcpy and a large build costs a few bits per block rather than an object
 * reference.
 */
public final class SchematicRegion {

    /** Blocks are indexed y-major, then z, then x - the layout every schematic format uses. */
    private final Vec3i size;
    private final int sizeX;
    private final int sizeY;
    private final int sizeZ;

    private String name;
    private Vec3i origin;

    private BlockPalette palette;
    private BitStorage blocks;

    private final Map<Vec3i, NbtCompound> blockEntities = new LinkedHashMap<>();
    private final List<SchematicEntity> entities = new ArrayList<>();
    private final List<NbtCompound> pendingBlockTicks = new ArrayList<>();
    private final List<NbtCompound> pendingFluidTicks = new ArrayList<>();

    public SchematicRegion(String name, Vec3i origin, Vec3i size) {
        this(name, origin, size, new BlockPalette(), null);
    }

    public SchematicRegion(String name, Vec3i origin, Vec3i size, BlockPalette palette,
                           BitStorage blocks) {
        if (size.x() <= 0 || size.y() <= 0 || size.z() <= 0) {
            throw new IllegalArgumentException("region size must be positive, got " + size);
        }
        long volume = (long) size.x() * size.y() * size.z();
        if (volume > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("region of " + volume + " blocks exceeds the limit");
        }
        this.name = name;
        this.origin = origin;
        this.size = size;
        this.sizeX = size.x();
        this.sizeY = size.y();
        this.sizeZ = size.z();
        this.palette = palette;
        this.blocks = blocks != null
                ? blocks
                : new BitStorage(bitsForPalette(palette.size()), (int) volume, BitStorage.Layout.PACKED);
    }

    /** Litematica clamps palette indices to at least two bits even for a single-entry palette. */
    public static int bitsForPalette(int paletteSize) {
        return Math.max(2, BitStorage.bitsFor(Math.max(1, paletteSize - 1)));
    }

    // --- geometry ------------------------------------------------------------------------------

    public String name() { return name; }

    public void setName(String name) { this.name = name; }

    /** Position of the region's minimum corner, relative to the schematic origin. */
    public Vec3i origin() { return origin; }

    public void setOrigin(Vec3i origin) { this.origin = origin; }

    public Vec3i size() { return size; }

    public int sizeX() { return sizeX; }

    public int sizeY() { return sizeY; }

    public int sizeZ() { return sizeZ; }

    public int volume() { return sizeX * sizeY * sizeZ; }

    /** The region's extent in schematic-local coordinates. */
    public BlockBox bounds() {
        return new BlockBox(origin, origin.add(sizeX - 1, sizeY - 1, sizeZ - 1));
    }

    public boolean contains(int x, int y, int z) {
        return x >= 0 && x < sizeX && y >= 0 && y < sizeY && z >= 0 && z < sizeZ;
    }

    /** Flattens region-local coordinates into a storage index, or -1 when out of bounds. */
    public int index(int x, int y, int z) {
        if (!contains(x, y, z)) return -1;
        return (y * sizeZ + z) * sizeX + x;
    }

    public Vec3i positionOf(int index) {
        int x = index % sizeX;
        int z = (index / sizeX) % sizeZ;
        int y = index / (sizeX * sizeZ);
        return new Vec3i(x, y, z);
    }

    // --- blocks --------------------------------------------------------------------------------

    public BlockPalette palette() { return palette; }

    public BitStorage storage() { return blocks; }

    public BlockStateRef getBlock(int x, int y, int z) {
        int index = index(x, y, z);
        return index < 0 ? BlockStateRef.AIR : palette.get(blocks.get(index));
    }

    public BlockStateRef getBlock(Vec3i pos) {
        return getBlock(pos.x(), pos.y(), pos.z());
    }

    /** Palette index at the given position, or 0 (air) when out of bounds. */
    public int getPaletteIndex(int x, int y, int z) {
        int index = index(x, y, z);
        return index < 0 ? 0 : blocks.get(index);
    }

    public void setBlock(int x, int y, int z, BlockStateRef state) {
        int index = index(x, y, z);
        if (index < 0) return;
        // internState may swap `blocks` for a wider storage, so it has to run before the receiver
        // of set() is evaluated - otherwise the write lands in the array that just got discarded.
        int paletteIndex = internState(state);
        blocks.set(index, paletteIndex);
    }

    public void setBlock(Vec3i pos, BlockStateRef state) {
        setBlock(pos.x(), pos.y(), pos.z(), state);
    }

    /** Adds the state to the palette, widening the block storage when the index no longer fits. */
    public int internState(BlockStateRef state) {
        int paletteIndex = palette.add(state);
        int required = bitsForPalette(palette.size());
        if (required > blocks.bits()) {
            blocks = blocks.resize(required);
        }
        return paletteIndex;
    }

    /**
     * Rewrites a palette slot in place.
     *
     * <p>This is what makes variant swapping cheap: replacing every {@code oak_stairs} in a
     * ten-million-block schematic touches one palette entry instead of ten million block indices.
     */
    public void replacePaletteEntry(int index, BlockStateRef state) {
        palette.replace(index, state);
    }

    /** Visits every non-air block as (position, palette index). */
    public void forEachBlock(ObjIntConsumer<Vec3i> consumer) {
        int volume = volume();
        for (int i = 0; i < volume; i++) {
            int paletteIndex = blocks.get(i);
            if (paletteIndex == 0) continue;
            consumer.accept(positionOf(i), paletteIndex);
        }
    }

    /** Counts how many blocks reference each palette slot. Index 0 (air) is included. */
    public int[] paletteHistogram() {
        int[] counts = new int[palette.size()];
        int volume = volume();
        for (int i = 0; i < volume; i++) {
            int paletteIndex = blocks.get(i);
            if (paletteIndex < counts.length) counts[paletteIndex]++;
        }
        return counts;
    }

    // --- attached data -------------------------------------------------------------------------

    /** Block entity NBT keyed by region-local position. */
    public Map<Vec3i, NbtCompound> blockEntities() { return blockEntities; }

    public NbtCompound blockEntity(Vec3i pos) { return blockEntities.get(pos); }

    public List<SchematicEntity> entities() { return entities; }

    public List<NbtCompound> pendingBlockTicks() { return pendingBlockTicks; }

    public List<NbtCompound> pendingFluidTicks() { return pendingFluidTicks; }

    // --- copying -------------------------------------------------------------------------------

    public SchematicRegion copy() {
        SchematicRegion copy = new SchematicRegion(name, origin, size, palette.copy(), blocks.copy());
        for (Map.Entry<Vec3i, NbtCompound> e : blockEntities.entrySet()) {
            copy.blockEntities.put(e.getKey(), e.getValue().copy());
        }
        copy.entities.addAll(entities);
        for (NbtCompound tick : pendingBlockTicks) copy.pendingBlockTicks.add(tick.copy());
        for (NbtCompound tick : pendingFluidTicks) copy.pendingFluidTicks.add(tick.copy());
        return copy;
    }

    /** Replaces the palette wholesale; the caller guarantees indices still line up. */
    public void setPalette(BlockPalette palette) {
        this.palette = palette;
        int required = bitsForPalette(palette.size());
        if (required > blocks.bits()) blocks = blocks.resize(required);
    }

    public List<BlockStateRef> distinctStates() {
        int[] histogram = paletteHistogram();
        List<BlockStateRef> present = new ArrayList<>();
        for (int i = 0; i < histogram.length; i++) {
            if (histogram[i] > 0) present.add(palette.get(i));
        }
        return Collections.unmodifiableList(present);
    }

    @Override
    public String toString() {
        return "SchematicRegion[" + name + " " + sizeX + "x" + sizeY + "x" + sizeZ
                + " at " + origin + "]";
    }
}
