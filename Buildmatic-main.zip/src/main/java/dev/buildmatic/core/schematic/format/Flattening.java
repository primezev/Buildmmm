package dev.buildmatic.core.schematic.format;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;

import java.util.Map;

/**
 * Collapses a multi-region schematic into one cuboid.
 *
 * <p>Sponge, vanilla structures and MCEdit all describe a single box, so anything Litematica-shaped
 * has to be flattened before it can be exported to them. The gaps between regions become air, which
 * is why exporting a sparse build to {@code .schem} can inflate the file dramatically.
 */
final class Flattening {

    private Flattening() {}

    static SchematicRegion toSingleRegion(Schematic schematic) {
        if (schematic.regionCount() == 1) return schematic.region(0);
        if (schematic.regionCount() == 0) {
            return new SchematicRegion("main", Vec3i.ZERO, new Vec3i(1, 1, 1));
        }

        BlockBox box = schematic.enclosingBox();
        Vec3i origin = box.min();
        SchematicRegion merged = new SchematicRegion(
                schematic.metadata().name().isEmpty() ? "main" : schematic.metadata().name(),
                origin,
                box.size());

        for (SchematicRegion region : schematic.regions()) {
            Vec3i delta = region.origin().subtract(origin);
            for (int y = 0; y < region.sizeY(); y++) {
                for (int z = 0; z < region.sizeZ(); z++) {
                    for (int x = 0; x < region.sizeX(); x++) {
                        BlockStateRef state = region.getBlock(x, y, z);
                        // Later regions must not blank out earlier ones where they overlap.
                        if (state.isAir()) continue;
                        merged.setBlock(x + delta.x(), y + delta.y(), z + delta.z(), state);
                    }
                }
            }
            for (Map.Entry<Vec3i, NbtCompound> e : region.blockEntities().entrySet()) {
                merged.blockEntities().put(e.getKey().add(delta), e.getValue().copy());
            }
            for (SchematicEntity entity : region.entities()) {
                merged.entities().add(entity.withPosition(
                        entity.x() + delta.x(), entity.y() + delta.y(), entity.z() + delta.z()));
            }
            merged.pendingBlockTicks().addAll(region.pendingBlockTicks());
            merged.pendingFluidTicks().addAll(region.pendingFluidTicks());
        }
        return merged;
    }
}
