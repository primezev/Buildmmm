package dev.buildmatic.core.schematic.format;

import dev.buildmatic.core.block.BlockPalette;
import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtList;
import dev.buildmatic.core.nbt.NbtTag;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.schematic.SchematicFormat;
import dev.buildmatic.core.schematic.SchematicMetadata;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.BitStorage;
import dev.buildmatic.core.util.Vec3i;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Reader and writer for Litematica's {@code .litematic} format, schema versions 4 through 7.
 *
 * <p>Region sizes on disk may be negative, meaning the stored {@code Position} is the corner the
 * player selected rather than the minimum corner. Everything is normalised to a positive size with
 * a minimum-corner origin on load, and denormalised again on save only if the caller asks.
 */
public final class LitematicaFormat {

    /** Schema version Buildmatic writes. Read by every Litematica release since 1.16. */
    public static final int WRITE_VERSION = 6;
    public static final int WRITE_SUB_VERSION = 1;

    private LitematicaFormat() {}

    // --- reading -------------------------------------------------------------------------------

    public static Schematic read(NbtCompound root) throws IOException {
        int version = root.getInt("Version", 0);
        if (version < 4 || version > 7) {
            throw new IOException("unsupported Litematica schema version " + version);
        }

        SchematicMetadata metadata = readMetadata(root.getCompound("Metadata"));
        metadata.setDataVersion(root.getInt("MinecraftDataVersion", 0));

        Schematic schematic = new Schematic(metadata);
        schematic.setSourceFormat(SchematicFormat.LITEMATICA);

        NbtCompound regions = root.getCompound("Regions");
        if (regions == null || regions.isEmpty()) {
            throw new IOException("Litematica file has no regions");
        }
        for (String name : regions.keys()) {
            NbtCompound regionTag = regions.getCompound(name);
            if (regionTag == null) continue;
            schematic.addRegion(readRegion(name, regionTag));
        }
        return schematic.refreshStatistics();
    }

    private static SchematicMetadata readMetadata(NbtCompound tag) {
        SchematicMetadata metadata = new SchematicMetadata();
        if (tag == null) return metadata;

        metadata.setName(tag.getString("Name", "Unnamed"))
                .setAuthor(tag.getString("Author", ""))
                .setDescription(tag.getString("Description", ""))
                .setTimeCreated(tag.getLong("TimeCreated", System.currentTimeMillis()))
                .setTimeModified(tag.getLong("TimeModified", System.currentTimeMillis()))
                .setTotalBlocks(tag.getLong("TotalBlocks", 0))
                .setTotalVolume(tag.getLong("TotalVolume", 0))
                .setRegionCount(tag.getInt("RegionCount", 1));

        NbtCompound size = tag.getCompound("EnclosingSize");
        if (size != null) metadata.setEnclosingSize(readVec(size));

        int[] preview = tag.getIntArray("PreviewImageData");
        if (preview.length > 0) {
            // Litematica always writes a square thumbnail.
            int side = (int) Math.round(Math.sqrt(preview.length));
            if (side * side == preview.length) {
                metadata.setPreviewImage(preview, side, side);
            }
        }
        return metadata;
    }

    private static SchematicRegion readRegion(String name, NbtCompound tag) throws IOException {
        Vec3i position = readVec(tag.getCompound("Position"));
        Vec3i rawSize = readVec(tag.getCompound("Size"));

        // A negative extent means the region grows towards -X/-Y/-Z from Position.
        int sizeX = Math.abs(rawSize.x());
        int sizeY = Math.abs(rawSize.y());
        int sizeZ = Math.abs(rawSize.z());
        if (sizeX == 0 || sizeY == 0 || sizeZ == 0) {
            throw new IOException("region '" + name + "' has a zero dimension: " + rawSize);
        }
        Vec3i origin = new Vec3i(
                rawSize.x() < 0 ? position.x() + rawSize.x() + 1 : position.x(),
                rawSize.y() < 0 ? position.y() + rawSize.y() + 1 : position.y(),
                rawSize.z() < 0 ? position.z() + rawSize.z() + 1 : position.z());
        Vec3i size = new Vec3i(sizeX, sizeY, sizeZ);

        BlockPalette palette = readPalette(tag.getList("BlockStatePalette"));
        long[] raw = tag.getLongArray("BlockStates");
        int volume = sizeX * sizeY * sizeZ;
        int bits = SchematicRegion.bitsForPalette(palette.size());

        int expected = BitStorage.longCount(bits, volume, BitStorage.Layout.PACKED);
        if (raw.length < expected) {
            throw new IOException("region '" + name + "' has " + raw.length
                    + " longs of block data, expected " + expected);
        }
        BitStorage storage = new BitStorage(bits, volume, BitStorage.Layout.PACKED, raw);

        SchematicRegion region = new SchematicRegion(name, origin, size, palette, storage);
        readBlockEntities(tag.getList("TileEntities"), region);
        readEntities(tag.getList("Entities"), region);
        copyTicks(tag.getList("PendingBlockTicks"), region.pendingBlockTicks());
        copyTicks(tag.getList("PendingFluidTicks"), region.pendingFluidTicks());
        return region;
    }

    private static BlockPalette readPalette(NbtList list) throws IOException {
        if (list == null || list.isEmpty()) {
            throw new IOException("region has an empty block state palette");
        }
        List<BlockStateRef> states = new ArrayList<>(list.size());
        for (int i = 0; i < list.size(); i++) {
            NbtCompound entry = list.getCompound(i);
            if (entry == null) {
                states.add(BlockStateRef.AIR);
                continue;
            }
            states.add(readPaletteEntry(entry));
        }
        return BlockPalette.verbatim(states);
    }

    static BlockStateRef readPaletteEntry(NbtCompound entry) {
        String id = entry.getString("Name", "minecraft:air");
        NbtCompound properties = entry.getCompound("Properties");
        if (properties == null || properties.isEmpty()) return BlockStateRef.of(id);

        Map<String, String> map = new TreeMap<>();
        for (String key : properties.keys()) {
            map.put(key, properties.getString(key, ""));
        }
        return BlockStateRef.of(id, map);
    }

    private static void readBlockEntities(NbtList list, SchematicRegion region) {
        if (list == null) return;
        for (int i = 0; i < list.size(); i++) {
            NbtCompound tag = list.getCompound(i);
            if (tag == null) continue;
            Vec3i pos = new Vec3i(tag.getInt("x", 0), tag.getInt("y", 0), tag.getInt("z", 0));
            region.blockEntities().put(pos, tag);
        }
    }

    private static void readEntities(NbtList list, SchematicRegion region) {
        if (list == null) return;
        for (int i = 0; i < list.size(); i++) {
            NbtCompound tag = list.getCompound(i);
            if (tag == null) continue;
            region.entities().add(SchematicEntity.fromNbt(tag));
        }
    }

    private static void copyTicks(NbtList list, List<NbtCompound> target) {
        if (list == null) return;
        for (int i = 0; i < list.size(); i++) {
            NbtCompound tag = list.getCompound(i);
            if (tag != null) target.add(tag);
        }
    }

    private static Vec3i readVec(NbtCompound tag) {
        if (tag == null) return Vec3i.ZERO;
        return new Vec3i(tag.getInt("x", 0), tag.getInt("y", 0), tag.getInt("z", 0));
    }

    // --- writing -------------------------------------------------------------------------------

    public static NbtCompound write(Schematic schematic, int dataVersion) {
        schematic.refreshStatistics();

        NbtCompound root = new NbtCompound();
        root.putInt("Version", WRITE_VERSION);
        root.putInt("SubVersion", WRITE_SUB_VERSION);
        root.putInt("MinecraftDataVersion",
                dataVersion > 0 ? dataVersion : schematic.metadata().dataVersion());
        root.put("Metadata", writeMetadata(schematic));

        NbtCompound regions = new NbtCompound();
        for (SchematicRegion region : schematic.regions()) {
            regions.put(uniqueName(regions, region.name()), writeRegion(region));
        }
        root.put("Regions", regions);
        return root;
    }

    /** Region names are map keys, so a duplicate would silently drop a region. */
    private static String uniqueName(NbtCompound regions, String name) {
        String candidate = name == null || name.isEmpty() ? "main" : name;
        int suffix = 2;
        while (regions.contains(candidate)) {
            candidate = name + " (" + suffix++ + ")";
        }
        return candidate;
    }

    private static NbtCompound writeMetadata(Schematic schematic) {
        SchematicMetadata metadata = schematic.metadata();
        NbtCompound tag = new NbtCompound();
        tag.putString("Name", metadata.name());
        tag.putString("Author", metadata.author());
        tag.putString("Description", metadata.description());
        tag.putLong("TimeCreated", metadata.timeCreated());
        tag.putLong("TimeModified", metadata.timeModified());
        tag.putInt("RegionCount", schematic.regionCount());
        tag.putLong("TotalBlocks", metadata.totalBlocks());
        tag.putLong("TotalVolume", metadata.totalVolume());
        tag.put("EnclosingSize", writeVec(metadata.enclosingSize()));
        if (metadata.previewImage() != null) {
            tag.putIntArray("PreviewImageData", metadata.previewImage());
        }
        return tag;
    }

    private static NbtCompound writeRegion(SchematicRegion region) {
        NbtCompound tag = new NbtCompound();
        tag.put("Position", writeVec(region.origin()));
        tag.put("Size", writeVec(region.size()));

        NbtList palette = new NbtList(NbtTag.TAG_COMPOUND);
        for (BlockStateRef state : region.palette().entries()) {
            palette.add(writePaletteEntry(state));
        }
        tag.put("BlockStatePalette", palette);

        // The on-disk width must match what a reader will derive from the palette size.
        BitStorage storage = region.storage();
        int required = SchematicRegion.bitsForPalette(region.palette().size());
        if (storage.bits() != required) storage = storage.resize(required);
        tag.putLongArray("BlockStates", storage.data());

        NbtList blockEntities = new NbtList(NbtTag.TAG_COMPOUND);
        for (Map.Entry<Vec3i, NbtCompound> e : region.blockEntities().entrySet()) {
            NbtCompound entry = e.getValue().copy();
            entry.putInt("x", e.getKey().x());
            entry.putInt("y", e.getKey().y());
            entry.putInt("z", e.getKey().z());
            blockEntities.add(entry);
        }
        tag.put("TileEntities", blockEntities);

        NbtList entities = new NbtList(NbtTag.TAG_COMPOUND);
        for (SchematicEntity entity : region.entities()) {
            entities.add(entity.toNbt());
        }
        tag.put("Entities", entities);

        tag.put("PendingBlockTicks", toList(region.pendingBlockTicks()));
        tag.put("PendingFluidTicks", toList(region.pendingFluidTicks()));
        return tag;
    }

    static NbtCompound writePaletteEntry(BlockStateRef state) {
        NbtCompound entry = new NbtCompound();
        entry.putString("Name", state.blockId());
        if (!state.properties().isEmpty()) {
            NbtCompound properties = new NbtCompound();
            // LinkedHashMap keeps the alphabetical order the descriptor already guarantees.
            for (Map.Entry<String, String> p : new LinkedHashMap<>(state.properties()).entrySet()) {
                properties.putString(p.getKey(), p.getValue());
            }
            entry.put("Properties", properties);
        }
        return entry;
    }

    private static NbtList toList(List<NbtCompound> items) {
        NbtList list = new NbtList(NbtTag.TAG_COMPOUND);
        for (NbtCompound item : items) list.add(item);
        return list;
    }

    private static NbtCompound writeVec(Vec3i vec) {
        NbtCompound tag = new NbtCompound();
        tag.putInt("x", vec.x());
        tag.putInt("y", vec.y());
        tag.putInt("z", vec.z());
        return tag;
    }
}
