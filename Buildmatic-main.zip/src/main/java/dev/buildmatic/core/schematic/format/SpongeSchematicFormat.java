package dev.buildmatic.core.schematic.format;

import dev.buildmatic.core.block.BlockPalette;
import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtList;
import dev.buildmatic.core.nbt.NbtTag;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.schematic.SchematicFormat;
import dev.buildmatic.core.schematic.SchematicMetadata;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.Vec3i;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Reader and writer for the Sponge schematic format used by WorldEdit and FAWE.
 *
 * <p>Versions 1 and 2 keep everything at the root; version 3 moves it under a {@code Schematic}
 * compound and splits blocks and biomes into their own sub-compounds. All three are read; version 3
 * is written by default because it is what current WorldEdit produces.
 */
public final class SpongeSchematicFormat {

    private SpongeSchematicFormat() {}

    // --- reading -------------------------------------------------------------------------------

    public static Schematic read(NbtCompound root) throws IOException {
        NbtCompound body = root.getCompound("Schematic");
        boolean v3 = body != null;
        if (!v3) body = root;

        int version = body.getInt("Version", v3 ? 3 : 1);
        int width = readDimension(body, "Width");
        int height = readDimension(body, "Height");
        int length = readDimension(body, "Length");
        if (width <= 0 || height <= 0 || length <= 0) {
            throw new IOException("schematic has a zero dimension: "
                    + width + "x" + height + "x" + length);
        }

        NbtCompound blocksTag = version >= 3 ? body.getCompound("Blocks") : body;
        if (blocksTag == null) {
            throw new IOException("Sponge v3 schematic has no Blocks compound");
        }

        NbtCompound paletteTag = blocksTag.getCompound(version >= 3 ? "Palette" : "Palette");
        byte[] data = blocksTag.getByteArray(version >= 3 ? "Data" : "BlockData");
        if (paletteTag == null || data.length == 0) {
            throw new IOException("schematic has no block data");
        }

        BlockPalette palette = readPalette(paletteTag);

        // Offset is where the build sat relative to the player's origin when it was copied.
        int[] offset = body.getIntArray("Offset");
        Vec3i origin = offset.length >= 3 ? new Vec3i(offset[0], offset[1], offset[2]) : Vec3i.ZERO;

        SchematicMetadata metadata = readMetadata(body);
        metadata.setDataVersion(body.getInt("DataVersion", 0));

        Schematic schematic = new Schematic(metadata);
        schematic.setSourceFormat(SchematicFormat.SPONGE);

        SchematicRegion region = new SchematicRegion(
                metadata.name().isEmpty() ? "main" : metadata.name(),
                origin,
                new Vec3i(width, height, length),
                palette,
                null);
        decodeBlocks(data, region, width, height, length);

        NbtList blockEntities = blocksTag.getList("BlockEntities");
        if (blockEntities == null) blockEntities = body.getList("TileEntities");
        readBlockEntities(blockEntities, region);
        readEntities(body.getList("Entities"), region);

        schematic.addRegion(region);
        return schematic.refreshStatistics();
    }

    /** Dimensions are shorts on disk but represent unsigned values up to 65535. */
    private static int readDimension(NbtCompound tag, String key) {
        int value = tag.getInt(key, 0);
        return value < 0 ? value & 0xFFFF : value;
    }

    private static SchematicMetadata readMetadata(NbtCompound body) {
        SchematicMetadata metadata = new SchematicMetadata();
        NbtCompound tag = body.getCompound("Metadata");
        if (tag == null) return metadata;
        metadata.setName(tag.getString("Name", ""))
                .setAuthor(tag.getString("Author", ""));
        long date = tag.getLong("Date", 0);
        if (date > 0) {
            metadata.setTimeCreated(date).setTimeModified(date);
        }
        return metadata;
    }

    private static BlockPalette readPalette(NbtCompound tag) throws IOException {
        // The palette is stored the wrong way round for our purposes: descriptor -> index.
        Map<Integer, String> byIndex = new TreeMap<>();
        int max = -1;
        for (String descriptor : tag.keys()) {
            int index = tag.getInt(descriptor, -1);
            if (index < 0) continue;
            byIndex.put(index, descriptor);
            max = Math.max(max, index);
        }
        if (max < 0) throw new IOException("schematic palette is empty");

        List<BlockStateRef> states = new ArrayList<>(max + 1);
        for (int i = 0; i <= max; i++) {
            String descriptor = byIndex.get(i);
            states.add(descriptor == null
                    ? BlockStateRef.AIR
                    : BlockStateRef.parseOrDefault(descriptor, BlockStateRef.AIR));
        }
        return BlockPalette.verbatim(states);
    }

    /** Block indices are varint-encoded in y, then z, then x order. */
    private static void decodeBlocks(byte[] data, SchematicRegion region,
                                     int width, int height, int length) throws IOException {
        int cursor = 0;
        int expected = width * height * length;
        for (int i = 0; i < expected; i++) {
            if (cursor >= data.length) {
                throw new IOException("block data ended after " + i + " of " + expected + " blocks");
            }
            int value = 0;
            int shift = 0;
            byte b;
            do {
                if (cursor >= data.length) throw new IOException("truncated varint in block data");
                b = data[cursor++];
                value |= (b & 0x7F) << shift;
                shift += 7;
                if (shift > 35) throw new IOException("varint too long in block data");
            } while ((b & 0x80) != 0);

            int y = i / (width * length);
            int z = (i % (width * length)) / width;
            int x = (i % (width * length)) % width;
            int index = region.index(x, y, z);
            if (index >= 0) region.storage().set(index, value);
        }
    }

    private static void readBlockEntities(NbtList list, SchematicRegion region) {
        if (list == null) return;
        for (int i = 0; i < list.size(); i++) {
            NbtCompound tag = list.getCompound(i);
            if (tag == null) continue;
            int[] pos = tag.getIntArray("Pos");
            Vec3i at = pos.length >= 3
                    ? new Vec3i(pos[0], pos[1], pos[2])
                    : new Vec3i(tag.getInt("x", 0), tag.getInt("y", 0), tag.getInt("z", 0));
            NbtCompound stored = tag.copy();
            // Normalise onto the vanilla key set so downstream code sees one shape.
            String id = stored.getString("Id", stored.getString("id", ""));
            if (!id.isEmpty()) stored.putString("id", id);
            stored.remove("Pos");
            stored.remove("Id");
            stored.putInt("x", at.x());
            stored.putInt("y", at.y());
            stored.putInt("z", at.z());
            region.blockEntities().put(at, stored);
        }
    }

    private static void readEntities(NbtList list, SchematicRegion region) {
        if (list == null) return;
        for (int i = 0; i < list.size(); i++) {
            NbtCompound tag = list.getCompound(i);
            if (tag == null) continue;
            NbtCompound stored = tag.copy();
            String id = stored.getString("Id", stored.getString("id", ""));
            if (!id.isEmpty()) {
                stored.putString("id", id);
                stored.remove("Id");
            }
            region.entities().add(SchematicEntity.fromNbt(stored));
        }
    }

    // --- writing -------------------------------------------------------------------------------

    public static NbtCompound write(Schematic schematic, int dataVersion) {
        return write(schematic, dataVersion, 3);
    }

    /**
     * Flattens the schematic into a single region and serialises it.
     *
     * @param version 2 or 3; anything else is treated as 3
     */
    public static NbtCompound write(Schematic schematic, int dataVersion, int version) {
        SchematicRegion region = Flattening.toSingleRegion(schematic);
        int width = region.sizeX();
        int height = region.sizeY();
        int length = region.sizeZ();

        NbtCompound palette = new NbtCompound();
        List<BlockStateRef> entries = region.palette().entries();
        for (int i = 0; i < entries.size(); i++) {
            palette.putInt(entries.get(i).descriptor(), i);
        }

        byte[] data = encodeBlocks(region, width, height, length);

        NbtCompound metadata = new NbtCompound();
        metadata.putString("Name", schematic.metadata().name());
        metadata.putString("Author", schematic.metadata().author());
        metadata.putLong("Date", schematic.metadata().timeModified());

        NbtList blockEntities = new NbtList(NbtTag.TAG_COMPOUND);
        for (Map.Entry<Vec3i, NbtCompound> e : region.blockEntities().entrySet()) {
            NbtCompound entry = e.getValue().copy();
            entry.remove("x");
            entry.remove("y");
            entry.remove("z");
            entry.putIntArray("Pos", new int[]{e.getKey().x(), e.getKey().y(), e.getKey().z()});
            if (version < 3) {
                entry.putString("Id", entry.getString("id", ""));
            }
            blockEntities.add(entry);
        }

        NbtList entities = new NbtList(NbtTag.TAG_COMPOUND);
        for (SchematicEntity entity : region.entities()) {
            entities.add(entity.toNbt());
        }

        NbtCompound body = new NbtCompound();
        body.putInt("Version", version < 3 ? 2 : 3);
        body.putInt("DataVersion", dataVersion > 0 ? dataVersion : schematic.metadata().dataVersion());
        body.putShort("Width", (short) width);
        body.putShort("Height", (short) height);
        body.putShort("Length", (short) length);
        body.putIntArray("Offset",
                new int[]{region.origin().x(), region.origin().y(), region.origin().z()});
        body.put("Metadata", metadata);

        if (version < 3) {
            body.putInt("PaletteMax", entries.size());
            body.put("Palette", palette);
            body.putByteArray("BlockData", data);
            body.put("BlockEntities", blockEntities);
            body.put("Entities", entities);
            return body;
        }

        NbtCompound blocks = new NbtCompound();
        blocks.put("Palette", palette);
        blocks.putByteArray("Data", data);
        blocks.put("BlockEntities", blockEntities);
        body.put("Blocks", blocks);
        body.put("Entities", entities);

        NbtCompound root = new NbtCompound();
        root.put("Schematic", body);
        return root;
    }

    private static byte[] encodeBlocks(SchematicRegion region, int width, int height, int length) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(width * height * length);
        for (int y = 0; y < height; y++) {
            for (int z = 0; z < length; z++) {
                for (int x = 0; x < width; x++) {
                    int value = region.getPaletteIndex(x, y, z);
                    while ((value & ~0x7F) != 0) {
                        out.write((value & 0x7F) | 0x80);
                        value >>>= 7;
                    }
                    out.write(value);
                }
            }
        }
        return out.toByteArray();
    }
}
