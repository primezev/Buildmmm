package dev.buildmatic.core.schematic.format;

import dev.buildmatic.core.block.BlockPalette;
import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtList;
import dev.buildmatic.core.nbt.NbtTag;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.schematic.SchematicFormat;
import dev.buildmatic.core.schematic.SchematicMetadata;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.Vec3i;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Reader and writer for vanilla structure block files.
 *
 * <p>The format is a sparse list of {@code {pos, state, nbt}} entries, so it stays small for empty
 * builds but has no run-length coding at all for dense ones. Structure blocks refuse to load
 * anything larger than 48 blocks on a side; Buildmatic writes larger files anyway, since other
 * tools read them fine, and warns at the call site instead.
 */
public final class VanillaStructureFormat {

    /** The largest size a vanilla structure block will load. */
    public static final int STRUCTURE_BLOCK_LIMIT = 48;

    private VanillaStructureFormat() {}

    // --- reading -------------------------------------------------------------------------------

    public static Schematic read(NbtCompound root) throws IOException {
        NbtList sizeTag = root.getList("size");
        if (sizeTag == null || sizeTag.size() < 3) {
            throw new IOException("structure file has no size");
        }
        Vec3i size = new Vec3i(sizeTag.getInt(0), sizeTag.getInt(1), sizeTag.getInt(2));
        if (size.x() <= 0 || size.y() <= 0 || size.z() <= 0) {
            throw new IOException("structure file has a zero dimension: " + size);
        }

        List<BlockStateRef> states = readPaletteStates(root);

        // Vanilla orders its palette by first appearance, so slot 0 is whatever block the scan hit
        // first - usually not air. Everything else here assumes index 0 is empty, because every
        // position missing from `blocks` is left at 0 and is meant to be air. Without this the
        // whole empty volume comes back filled with the palette's first block.
        int shift = 0;
        if (states.isEmpty() || !states.get(0).isEmpty()) {
            states.add(0, BlockStateRef.AIR);
            shift = 1;
        }
        BlockPalette palette = BlockPalette.verbatim(states);

        SchematicMetadata metadata = new SchematicMetadata()
                .setName("Structure")
                .setDataVersion(root.getInt("DataVersion", 0));

        Schematic schematic = new Schematic(metadata);
        schematic.setSourceFormat(SchematicFormat.VANILLA_STRUCTURE);

        SchematicRegion region = new SchematicRegion("main", Vec3i.ZERO, size, palette, null);

        NbtList blocks = root.getList("blocks");
        if (blocks != null) {
            for (int i = 0; i < blocks.size(); i++) {
                NbtCompound entry = blocks.getCompound(i);
                if (entry == null) continue;
                NbtList pos = entry.getList("pos");
                if (pos == null || pos.size() < 3) continue;
                int x = pos.getInt(0);
                int y = pos.getInt(1);
                int z = pos.getInt(2);
                int index = region.index(x, y, z);
                if (index < 0) continue;
                region.storage().set(index, entry.getInt("state", 0) + shift);

                NbtCompound blockEntity = entry.getCompound("nbt");
                if (blockEntity != null) {
                    NbtCompound stored = blockEntity.copy();
                    stored.putInt("x", x);
                    stored.putInt("y", y);
                    stored.putInt("z", z);
                    region.blockEntities().put(new Vec3i(x, y, z), stored);
                }
            }
        }

        NbtList entities = root.getList("entities");
        if (entities != null) {
            for (int i = 0; i < entities.size(); i++) {
                NbtCompound entry = entities.getCompound(i);
                if (entry == null) continue;
                NbtCompound data = entry.getCompound("nbt");
                NbtList pos = entry.getList("pos");
                NbtCompound stored = data == null ? new NbtCompound() : data.copy();
                if (pos != null && pos.size() >= 3) {
                    stored.put("Pos", NbtList.ofDoubles(
                            pos.getDouble(0), pos.getDouble(1), pos.getDouble(2)));
                }
                region.entities().add(SchematicEntity.fromNbt(stored));
            }
        }

        schematic.addRegion(region);
        return schematic.refreshStatistics();
    }

    /** The palette exactly as the file orders it. The caller decides what to do about slot 0. */
    private static List<BlockStateRef> readPaletteStates(NbtCompound root) throws IOException {
        NbtList paletteTag = root.getList("palette");
        if (paletteTag == null) {
            // `palettes` holds several alternative palettes for randomised structures.
            NbtList alternatives = root.getList("palettes");
            if (alternatives != null && !alternatives.isEmpty()
                    && alternatives.get(0) instanceof NbtList first) {
                paletteTag = first;
            }
        }
        if (paletteTag == null || paletteTag.isEmpty()) {
            throw new IOException("structure file has no palette");
        }

        List<BlockStateRef> states = new ArrayList<>(paletteTag.size() + 1);
        for (int i = 0; i < paletteTag.size(); i++) {
            NbtCompound entry = paletteTag.getCompound(i);
            states.add(entry == null ? BlockStateRef.AIR : LitematicaFormat.readPaletteEntry(entry));
        }
        return states;
    }

    // --- writing -------------------------------------------------------------------------------

    public static NbtCompound write(Schematic schematic, int dataVersion) {
        SchematicRegion region = Flattening.toSingleRegion(schematic);

        NbtCompound root = new NbtCompound();
        root.putInt("DataVersion",
                dataVersion > 0 ? dataVersion : schematic.metadata().dataVersion());
        root.put("size", NbtList.ofInts(region.sizeX(), region.sizeY(), region.sizeZ()));

        NbtList palette = new NbtList(NbtTag.TAG_COMPOUND);
        for (BlockStateRef state : region.palette().entries()) {
            palette.add(LitematicaFormat.writePaletteEntry(state));
        }
        root.put("palette", palette);

        NbtList blocks = new NbtList(NbtTag.TAG_COMPOUND);
        Map<Vec3i, NbtCompound> blockEntities = region.blockEntities();
        for (int y = 0; y < region.sizeY(); y++) {
            for (int z = 0; z < region.sizeZ(); z++) {
                for (int x = 0; x < region.sizeX(); x++) {
                    int paletteIndex = region.getPaletteIndex(x, y, z);
                    // Structure files omit air entirely; only structure voids are stored explicitly.
                    if (paletteIndex == 0) continue;

                    NbtCompound entry = new NbtCompound();
                    entry.put("pos", NbtList.ofInts(x, y, z));
                    entry.putInt("state", paletteIndex);

                    NbtCompound blockEntity = blockEntities.get(new Vec3i(x, y, z));
                    if (blockEntity != null) {
                        NbtCompound data = blockEntity.copy();
                        data.remove("x");
                        data.remove("y");
                        data.remove("z");
                        entry.put("nbt", data);
                    }
                    blocks.add(entry);
                }
            }
        }
        root.put("blocks", blocks);

        NbtList entities = new NbtList(NbtTag.TAG_COMPOUND);
        for (SchematicEntity entity : region.entities()) {
            NbtCompound entry = new NbtCompound();
            entry.put("pos", NbtList.ofDoubles(entity.x(), entity.y(), entity.z()));
            entry.put("blockPos", NbtList.ofInts(
                    (int) Math.floor(entity.x()),
                    (int) Math.floor(entity.y()),
                    (int) Math.floor(entity.z())));
            entry.put("nbt", entity.toNbt());
            entities.add(entry);
        }
        root.put("entities", entities);
        root.putString("author", schematic.metadata().author());
        return root;
    }

    /** True when the build would be rejected by an in-game structure block. */
    public static boolean exceedsStructureBlockLimit(Schematic schematic) {
        Vec3i size = schematic.enclosingSize();
        return size.x() > STRUCTURE_BLOCK_LIMIT
                || size.y() > STRUCTURE_BLOCK_LIMIT
                || size.z() > STRUCTURE_BLOCK_LIMIT;
    }
}
