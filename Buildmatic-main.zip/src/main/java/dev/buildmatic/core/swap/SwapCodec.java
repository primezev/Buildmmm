package dev.buildmatic.core.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtList;
import dev.buildmatic.core.nbt.NbtTag;
import dev.buildmatic.core.theme.BuildTheme;
import dev.buildmatic.core.theme.BuildThemes;
import dev.buildmatic.core.theme.ThemeVariant;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.BlockShape;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Reads and writes swap layers as NBT, so a restyled build is still restyled tomorrow.
 *
 * <p>Swaps are the one part of Buildmatic that exists nowhere but in memory: the schematic on disk
 * is deliberately never touched, which is what makes a swap free to undo - and what made it
 * evaporate on every quit. A layer is small (a rule is a few strings) so it costs nothing to keep
 * next to the placement it belongs to.
 *
 * <p>Reading is deliberately strict. A rule whose type is not recognised - a theme that has since
 * been renamed, a matcher from a newer version - makes the whole layer unreadable rather than a
 * partial one, because a half-restored layer would change the build in a way the player never
 * asked for and would struggle to spot. Losing the layer is obvious; a silently different one is
 * not.
 */
public final class SwapCodec {

    private SwapCodec() {}

    // --- writing -------------------------------------------------------------------------------

    public static NbtList writeAll(List<SwapLayer> layers) {
        NbtList list = new NbtList(NbtTag.TAG_COMPOUND);
        for (SwapLayer layer : layers) {
            NbtCompound tag = write(layer);
            if (tag != null) list.add(tag);
        }
        return list;
    }

    /** One layer, or null when it holds a rule that cannot be expressed. */
    public static NbtCompound write(SwapLayer layer) {
        NbtList rules = new NbtList(NbtTag.TAG_COMPOUND);
        for (SwapRule rule : layer.rules()) {
            NbtCompound tag = write(rule);
            if (tag == null) return null;
            rules.add(tag);
        }

        NbtCompound tag = new NbtCompound();
        tag.putString("Id", layer.id());
        tag.putString("Name", layer.name());
        tag.putBoolean("Enabled", layer.isEnabled());
        tag.put("Rules", rules);
        return tag;
    }

    private static NbtCompound write(SwapRule rule) {
        NbtCompound matcher = writeMatcher(rule.matcher());
        NbtCompound target = writeTarget(rule.target());
        NbtCompound scope = writeScope(rule.scope());
        if (matcher == null || target == null || scope == null) return null;

        NbtCompound tag = new NbtCompound();
        tag.put("Matcher", matcher);
        tag.put("Target", target);
        tag.put("Scope", scope);
        return tag;
    }

    private static NbtCompound writeMatcher(SwapRule.Matcher matcher) {
        NbtCompound tag = new NbtCompound();
        if (matcher instanceof SwapRule.Matcher.Exact m) {
            return tag.putString("Type", "exact").putString("State", m.state().descriptor());
        }
        if (matcher instanceof SwapRule.Matcher.Block m) {
            return tag.putString("Type", "block").putString("Block", m.blockId());
        }
        if (matcher instanceof SwapRule.Matcher.Material m) {
            return tag.putString("Type", "material").putString("Material", m.material());
        }
        if (matcher instanceof SwapRule.Matcher.Shape m) {
            return tag.putString("Type", "shape").putString("Shape", m.shape().name());
        }
        if (matcher instanceof SwapRule.Matcher.Any) {
            return tag.putString("Type", "any");
        }
        return null;
    }

    private static NbtCompound writeTarget(SwapRule.Target target) {
        NbtCompound tag = new NbtCompound();
        if (target instanceof SwapRule.Target.State t) {
            return tag.putString("Type", "state").putString("State", t.state().descriptor());
        }
        if (target instanceof SwapRule.Target.Block t) {
            return tag.putString("Type", "block").putString("Block", t.blockId());
        }
        if (target instanceof SwapRule.Target.Material t) {
            return tag.putString("Type", "material").putString("Material", t.material());
        }
        if (target instanceof SwapRule.Target.Shape t) {
            return tag.putString("Type", "shape").putString("Shape", t.shape().name());
        }
        if (target instanceof SwapRule.Target.Themed t) {
            return tag.putString("Type", "themed")
                    .putString("Theme", t.theme().id())
                    .putString("Variant", t.variant().id());
        }
        if (target instanceof SwapRule.Target.Remove) {
            return tag.putString("Type", "remove");
        }
        if (target instanceof SwapRule.Target.Weighted t) {
            NbtList entries = new NbtList(NbtTag.TAG_COMPOUND);
            for (SwapRule.Target.WeightedEntry entry : t.entries()) {
                entries.add(new NbtCompound()
                        .putString("Block", entry.blockId())
                        .putInt("Weight", entry.weight()));
            }
            return tag.putString("Type", "weighted")
                    .putLong("Seed", t.seed())
                    .put("Entries", entries);
        }
        return null;
    }

    private static NbtCompound writeScope(SwapRule.Scope scope) {
        NbtCompound tag = new NbtCompound();
        if (scope instanceof SwapRule.Scope.Everywhere) {
            return tag.putString("Type", "everywhere");
        }
        if (scope instanceof SwapRule.Scope.Region s) {
            return tag.putString("Type", "region").putString("Region", s.regionName());
        }
        if (scope instanceof SwapRule.Scope.Box s) {
            return tag.putString("Type", "box")
                    .putString("Region", s.regionName())
                    .putIntArray("Min", triple(s.box().min()))
                    .putIntArray("Max", triple(s.box().max()));
        }
        if (scope instanceof SwapRule.Scope.Positions s) {
            // One flat array rather than a list of compounds: a flood fill can hold a hundred
            // thousand positions, and three ints each is the difference between a file that is
            // megabytes and one that is not.
            int[] packed = new int[s.positions().size() * 3];
            int i = 0;
            for (Vec3i pos : s.positions()) {
                packed[i++] = pos.x();
                packed[i++] = pos.y();
                packed[i++] = pos.z();
            }
            return tag.putString("Type", "positions")
                    .putString("Region", s.regionName())
                    .putIntArray("Positions", packed);
        }
        return null;
    }

    private static int[] triple(Vec3i v) {
        return new int[] {v.x(), v.y(), v.z()};
    }

    // --- reading -------------------------------------------------------------------------------

    /**
     * Adds every readable layer to {@code engine}.
     *
     * @return how many layers were dropped because they could not be read
     */
    public static int readInto(SwapEngine engine, NbtList list) {
        int skipped = 0;
        for (int i = 0; i < list.size(); i++) {
            NbtCompound tag = list.getCompound(i);
            SwapLayer layer = tag == null ? null : read(tag);
            if (layer == null) {
                skipped++;
                continue;
            }
            engine.addLayer(layer);
        }
        return skipped;
    }

    /** One layer, or null when any of its rules is unreadable. */
    public static SwapLayer read(NbtCompound tag) {
        NbtList rules = tag.getList("Rules");
        if (rules == null) return null;

        List<SwapRule> parsed = new ArrayList<>(rules.size());
        for (int i = 0; i < rules.size(); i++) {
            NbtCompound ruleTag = rules.getCompound(i);
            SwapRule rule = ruleTag == null ? null : readRule(ruleTag);
            if (rule == null) return null;
            parsed.add(rule);
        }

        String id = tag.getString("Id", "");
        SwapLayer layer = id.isEmpty()
                ? new SwapLayer(tag.getString("Name", "swap"))
                : new SwapLayer(id, tag.getString("Name", "swap"));
        layer.setEnabled(tag.getBoolean("Enabled", true));
        for (SwapRule rule : parsed) layer.addRule(rule);
        return layer;
    }

    private static SwapRule readRule(NbtCompound tag) {
        SwapRule.Matcher matcher = readMatcher(tag.getCompound("Matcher"));
        SwapRule.Target target = readTarget(tag.getCompound("Target"));
        SwapRule.Scope scope = readScope(tag.getCompound("Scope"));
        if (matcher == null || target == null || scope == null) return null;
        return new SwapRule(matcher, target, scope);
    }

    private static SwapRule.Matcher readMatcher(NbtCompound tag) {
        if (tag == null) return null;
        return switch (tag.getString("Type", "")) {
            case "exact" -> {
                BlockStateRef state = parseState(tag.getString("State", ""));
                yield state == null ? null : new SwapRule.Matcher.Exact(state);
            }
            case "block" -> string(tag, "Block", SwapRule.Matcher.Block::new);
            case "material" -> string(tag, "Material", SwapRule.Matcher.Material::new);
            case "shape" -> {
                BlockShape shape = parseShape(tag.getString("Shape", ""));
                yield shape == null ? null : new SwapRule.Matcher.Shape(shape);
            }
            case "any" -> new SwapRule.Matcher.Any();
            default -> null;
        };
    }

    private static SwapRule.Target readTarget(NbtCompound tag) {
        if (tag == null) return null;
        return switch (tag.getString("Type", "")) {
            case "state" -> {
                BlockStateRef state = parseState(tag.getString("State", ""));
                yield state == null ? null : new SwapRule.Target.State(state);
            }
            case "block" -> {
                String id = tag.getString("Block", "");
                yield id.isEmpty() ? null : new SwapRule.Target.Block(id);
            }
            case "material" -> {
                String material = tag.getString("Material", "");
                yield material.isEmpty() ? null : new SwapRule.Target.Material(material);
            }
            case "shape" -> {
                BlockShape shape = parseShape(tag.getString("Shape", ""));
                yield shape == null ? null : new SwapRule.Target.Shape(shape);
            }
            case "themed" -> {
                // A theme or combination that no longer exists takes its layer with it: guessing a
                // replacement would silently re-dress the build in something never picked. Files
                // written before combinations existed carry no Variant and mean the default one.
                BuildTheme theme = BuildThemes.byId(tag.getString("Theme", ""));
                if (theme == null) yield null;
                ThemeVariant variant = theme.variantById(tag.getString("Variant", "default"));
                yield variant == null ? null : new SwapRule.Target.Themed(theme, variant);
            }
            case "remove" -> new SwapRule.Target.Remove();
            case "weighted" -> {
                NbtList entries = tag.getList("Entries");
                if (entries == null || entries.isEmpty()) yield null;
                List<SwapRule.Target.WeightedEntry> parsed = new ArrayList<>(entries.size());
                for (int i = 0; i < entries.size(); i++) {
                    NbtCompound entry = entries.getCompound(i);
                    if (entry == null) yield null;
                    String block = entry.getString("Block", "");
                    if (block.isEmpty()) yield null;
                    parsed.add(new SwapRule.Target.WeightedEntry(block, entry.getInt("Weight", 1)));
                }
                yield new SwapRule.Target.Weighted(parsed, tag.getLong("Seed", 0L));
            }
            default -> null;
        };
    }

    private static SwapRule.Scope readScope(NbtCompound tag) {
        if (tag == null) return null;
        return switch (tag.getString("Type", "")) {
            case "everywhere" -> new SwapRule.Scope.Everywhere();
            case "region" -> string(tag, "Region", SwapRule.Scope.Region::new);
            case "box" -> {
                String region = tag.getString("Region", "");
                Vec3i min = triple(tag.getIntArray("Min"));
                Vec3i max = triple(tag.getIntArray("Max"));
                yield region.isEmpty() || min == null || max == null
                        ? null : new SwapRule.Scope.Box(region, new BlockBox(min, max));
            }
            case "positions" -> {
                String region = tag.getString("Region", "");
                int[] packed = tag.getIntArray("Positions");
                if (region.isEmpty() || packed.length % 3 != 0) yield null;
                Set<Vec3i> positions = new LinkedHashSet<>(Math.max(16, packed.length / 2));
                for (int i = 0; i < packed.length; i += 3) {
                    positions.add(new Vec3i(packed[i], packed[i + 1], packed[i + 2]));
                }
                yield positions.isEmpty()
                        ? null : new SwapRule.Scope.Positions(region, positions);
            }
            default -> null;
        };
    }

    private static <T> T string(NbtCompound tag, String key, java.util.function.Function<String, T> factory) {
        String value = tag.getString(key, "");
        return value.isEmpty() ? null : factory.apply(value);
    }

    private static Vec3i triple(int[] values) {
        return values.length == 3 ? new Vec3i(values[0], values[1], values[2]) : null;
    }

    private static BlockStateRef parseState(String descriptor) {
        return descriptor.isEmpty() ? null : BlockStateRef.parseOrDefault(descriptor, null);
    }

    private static BlockShape parseShape(String name) {
        try {
            return name.isEmpty() ? null : BlockShape.valueOf(name);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
