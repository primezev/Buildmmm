package dev.buildmatic.core.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.VariantIndex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Applies swap layers to a schematic without modifying it.
 *
 * <p>The schematic on disk is never touched. Everything the player sees - the ghost render, the
 * material list, the verifier - reads through {@link #stateAt}, so a swap takes effect everywhere
 * at once and is undone by deleting a layer.
 *
 * <h2>Why this is fast</h2>
 * Rules scoped to a whole region or the whole schematic are folded into an <em>effective
 * palette</em>: one {@code BlockStateRef} per palette slot, computed once. Converting every oak
 * block in a ten-million-block build to spruce therefore costs a few hundred evaluations, not ten
 * million. Only rules tied to specific positions - a single clicked block, a box, a flood fill -
 * fall back to a per-position override map, and those are bounded by their own scope.
 */
public final class SwapEngine {

    /** A 16-cube of a region, matching the renderer's rebuild granularity. */
    public record ChunkKey(String regionName, int cx, int cy, int cz) {
        public static ChunkKey of(String regionName, Vec3i localPos) {
            return new ChunkKey(regionName, localPos.x() >> 4, localPos.y() >> 4, localPos.z() >> 4);
        }
    }

    private final Schematic schematic;
    private final VariantIndex variants;
    private final BlockStateSchema stateSchema;

    private final List<SwapLayer> layers = new ArrayList<>();

    /** Region -> effective state per palette index. Rebuilt lazily. */
    private final Map<SchematicRegion, BlockStateRef[]> effectivePalettes = new IdentityHashMap<>();
    /** Region -> storage index -> override. Only holds position-scoped results. */
    private final Map<SchematicRegion, Map<Integer, BlockStateRef>> overrides = new IdentityHashMap<>();

    private boolean stale = true;
    private final Set<ChunkKey> dirtyChunks = new HashSet<>();

    public SwapEngine(Schematic schematic, VariantIndex variants, BlockStateSchema stateSchema) {
        this.schematic = schematic;
        this.variants = variants;
        this.stateSchema = stateSchema;
    }

    public Schematic schematic() { return schematic; }

    public VariantIndex variants() { return variants; }

    public BlockStateSchema stateSchema() { return stateSchema; }

    // --- layer management ----------------------------------------------------------------------

    public List<SwapLayer> layers() { return Collections.unmodifiableList(layers); }

    public boolean hasLayers() { return !layers.isEmpty(); }

    public void addLayer(SwapLayer layer) {
        layers.add(layer);
        invalidate(layer);
    }

    public void insertLayer(int index, SwapLayer layer) {
        layers.add(Math.max(0, Math.min(index, layers.size())), layer);
        invalidate(layer);
    }

    public boolean removeLayer(SwapLayer layer) {
        if (!layers.remove(layer)) return false;
        invalidate(layer);
        return true;
    }

    public SwapLayer layerById(String id) {
        for (SwapLayer layer : layers) {
            if (layer.id().equals(id)) return layer;
        }
        return null;
    }

    /** Moves a layer within the stack; later layers override earlier ones. */
    public boolean moveLayer(SwapLayer layer, int newIndex) {
        int current = layers.indexOf(layer);
        if (current < 0) return false;
        int target = Math.max(0, Math.min(newIndex, layers.size() - 1));
        if (current == target) return false;
        layers.remove(current);
        layers.add(target, layer);
        invalidate(layer);
        return true;
    }

    public void setLayerEnabled(SwapLayer layer, boolean enabled) {
        if (layer.isEnabled() == enabled) return;
        layer.setEnabled(enabled);
        invalidate(layer);
    }

    public void clearLayers() {
        if (layers.isEmpty()) return;
        markEverythingDirty();
        layers.clear();
        stale = true;
    }

    // --- queries -------------------------------------------------------------------------------

    /** The state at a region-local position after every enabled layer has been applied. */
    public BlockStateRef stateAt(SchematicRegion region, int x, int y, int z) {
        int index = region.index(x, y, z);
        if (index < 0) return BlockStateRef.AIR;
        return stateAtIndex(region, index);
    }

    public BlockStateRef stateAt(SchematicRegion region, Vec3i localPos) {
        return stateAt(region, localPos.x(), localPos.y(), localPos.z());
    }

    /** Same as {@link #stateAt} but takes a precomputed storage index. */
    public BlockStateRef stateAtIndex(SchematicRegion region, int index) {
        ensureBuilt();
        Map<Integer, BlockStateRef> regionOverrides = overrides.get(region);
        if (regionOverrides != null) {
            BlockStateRef override = regionOverrides.get(index);
            if (override != null) return override;
        }
        BlockStateRef[] palette = effectivePalettes.get(region);
        int paletteIndex = region.storage().get(index);
        if (palette == null || paletteIndex >= palette.length) {
            return region.palette().get(paletteIndex);
        }
        return palette[paletteIndex];
    }

    /** The original state, ignoring every layer. */
    public BlockStateRef originalAt(SchematicRegion region, int x, int y, int z) {
        return region.getBlock(x, y, z);
    }

    /** True when any layer changes this position. */
    public boolean isSwapped(SchematicRegion region, int x, int y, int z) {
        return !stateAt(region, x, y, z).equals(region.getBlock(x, y, z));
    }

    /** Counts every block by its effective state, which is what the material list needs. */
    public Map<BlockStateRef, Integer> countEffectiveBlocks() {
        ensureBuilt();
        Map<BlockStateRef, Integer> counts = new HashMap<>();
        for (SchematicRegion region : schematic.regions()) {
            BlockStateRef[] palette = effectivePalettes.get(region);
            Map<Integer, BlockStateRef> regionOverrides = overrides.get(region);

            int[] histogram = region.paletteHistogram();
            for (int i = 0; i < histogram.length; i++) {
                if (histogram[i] == 0) continue;
                BlockStateRef state = palette != null && i < palette.length
                        ? palette[i] : region.palette().get(i);
                if (state.isEmpty()) continue;
                counts.merge(state, histogram[i], Integer::sum);
            }

            // Position overrides were counted above under their pre-swap state; correct them.
            if (regionOverrides != null) {
                for (Map.Entry<Integer, BlockStateRef> e : regionOverrides.entrySet()) {
                    int paletteIndex = region.storage().get(e.getKey());
                    BlockStateRef before = palette != null && paletteIndex < palette.length
                            ? palette[paletteIndex] : region.palette().get(paletteIndex);
                    if (!before.isEmpty()) {
                        counts.merge(before, -1, Integer::sum);
                    }
                    if (!e.getValue().isEmpty()) {
                        counts.merge(e.getValue(), 1, Integer::sum);
                    }
                }
                counts.values().removeIf(count -> count <= 0);
            }
        }
        return counts;
    }

    // --- dirty tracking ------------------------------------------------------------------------

    /** Returns the chunks whose geometry needs rebuilding and clears the set. */
    public Set<ChunkKey> consumeDirtyChunks() {
        Set<ChunkKey> result = Set.copyOf(dirtyChunks);
        dirtyChunks.clear();
        return result;
    }

    public boolean hasDirtyChunks() { return !dirtyChunks.isEmpty(); }

    private void invalidate(SwapLayer layer) {
        stale = true;
        if (layer.isPaletteResolvable()) {
            markEverythingDirty();
            return;
        }
        // Position-scoped rules only touch the chunks their scope covers.
        for (SwapRule rule : layer.rules()) {
            SwapRule.Scope scope = rule.scope();
            if (scope instanceof SwapRule.Scope.Positions positions) {
                for (Vec3i pos : positions.positions()) {
                    dirtyChunks.add(ChunkKey.of(positions.regionName(), pos));
                }
            } else if (scope instanceof SwapRule.Scope.Box box) {
                markBoxDirty(box.regionName(), box.box());
            } else {
                markEverythingDirty();
            }
        }
    }

    private void markBoxDirty(String regionName, BlockBox box) {
        for (int cy = box.min().y() >> 4; cy <= box.max().y() >> 4; cy++) {
            for (int cz = box.min().z() >> 4; cz <= box.max().z() >> 4; cz++) {
                for (int cx = box.min().x() >> 4; cx <= box.max().x() >> 4; cx++) {
                    dirtyChunks.add(new ChunkKey(regionName, cx, cy, cz));
                }
            }
        }
    }

    private void markEverythingDirty() {
        for (SchematicRegion region : schematic.regions()) {
            markBoxDirty(region.name(),
                    new BlockBox(Vec3i.ZERO,
                            new Vec3i(region.sizeX() - 1, region.sizeY() - 1, region.sizeZ() - 1)));
        }
    }

    /** Forces a full rebuild; call after the schematic itself is edited. */
    public void invalidateAll() {
        stale = true;
        markEverythingDirty();
    }

    // --- evaluation ----------------------------------------------------------------------------

    private void ensureBuilt() {
        if (!stale) return;
        effectivePalettes.clear();
        overrides.clear();

        for (SchematicRegion region : schematic.regions()) {
            effectivePalettes.put(region, buildEffectivePalette(region));
            Map<Integer, BlockStateRef> regionOverrides = buildOverrides(region);
            if (!regionOverrides.isEmpty()) overrides.put(region, regionOverrides);
        }
        stale = false;
    }

    /**
     * Folds every palette-resolvable rule into one replacement state per palette slot.
     *
     * <p>Rules are applied in layer order and chain: a layer turning oak into spruce followed by one
     * turning spruce into birch yields birch, which is what a stack of edits should do.
     */
    private BlockStateRef[] buildEffectivePalette(SchematicRegion region) {
        List<BlockStateRef> entries = region.palette().entries();
        BlockStateRef[] result = new BlockStateRef[entries.size()];

        for (int i = 0; i < entries.size(); i++) {
            BlockStateRef state = entries.get(i);
            for (SwapLayer layer : layers) {
                if (!layer.isEnabled()) continue;
                for (SwapRule rule : layer.rules()) {
                    if (!rule.isPaletteResolvable()) continue;
                    if (!rule.scope().covers(region.name(), Vec3i.ZERO)) continue;
                    if (!rule.matcher().matches(state, variants)) continue;
                    BlockStateRef swapped =
                            rule.target().apply(state, Vec3i.ZERO, variants, stateSchema);
                    if (swapped != null) state = swapped;
                }
            }
            result[i] = state;
        }
        return result;
    }

    /**
     * Evaluates the position-scoped rules over exactly the blocks they cover.
     *
     * <p>A box scope walks its own volume; a position scope walks its own list. Neither ever scans
     * the whole region.
     */
    private Map<Integer, BlockStateRef> buildOverrides(SchematicRegion region) {
        Map<Integer, BlockStateRef> result = new HashMap<>();
        BlockStateRef[] palette = effectivePalettes.get(region);

        for (SwapLayer layer : layers) {
            if (!layer.isEnabled()) continue;
            for (SwapRule rule : layer.rules()) {
                if (rule.isPaletteResolvable()) continue;

                Iterable<Vec3i> positions = positionsOf(rule, region);
                if (positions == null) continue;

                for (Vec3i pos : positions) {
                    int index = region.index(pos.x(), pos.y(), pos.z());
                    if (index < 0) continue;

                    BlockStateRef current = result.get(index);
                    if (current == null) {
                        int paletteIndex = region.storage().get(index);
                        current = palette != null && paletteIndex < palette.length
                                ? palette[paletteIndex] : region.palette().get(paletteIndex);
                    }
                    BlockStateRef swapped =
                            rule.resolve(current, region.name(), pos, variants, stateSchema);
                    if (swapped != null) result.put(index, swapped);
                }
            }
        }
        return result;
    }

    /** The positions a non-palette rule needs to visit within this region, or null when none. */
    private Iterable<Vec3i> positionsOf(SwapRule rule, SchematicRegion region) {
        BlockBox regionBox = new BlockBox(Vec3i.ZERO,
                new Vec3i(region.sizeX() - 1, region.sizeY() - 1, region.sizeZ() - 1));

        SwapRule.Scope scope = rule.scope();
        if (scope instanceof SwapRule.Scope.Positions positions) {
            return positions.regionName().equals(region.name()) ? positions.positions() : null;
        }
        if (scope instanceof SwapRule.Scope.Box box) {
            if (!box.regionName().equals(region.name())) return null;
            return clip(box.box(), regionBox);
        }
        // A position-dependent target under a wide scope has to visit the whole region.
        if (scope instanceof SwapRule.Scope.Region named) {
            return named.regionName().equals(region.name()) ? regionBox : null;
        }
        return regionBox;
    }

    private static BlockBox clip(BlockBox box, BlockBox bounds) {
        if (!box.intersects(bounds)) return null;
        return new BlockBox(box.min().max(bounds.min()), box.max().min(bounds.max()));
    }

    // --- baking --------------------------------------------------------------------------------

    /**
     * Produces a new schematic with every swap applied for real.
     *
     * <p>Used on export, so the resulting {@code .litematic} works in vanilla Litematica and in
     * WorldEdit with no knowledge of Buildmatic's layers.
     */
    public Schematic bake() {
        ensureBuilt();
        Schematic baked = schematic.copy();

        for (int r = 0; r < baked.regionCount(); r++) {
            SchematicRegion source = schematic.region(r);
            SchematicRegion target = baked.region(r);

            BlockStateRef[] palette = effectivePalettes.get(source);
            if (palette != null) {
                // Rewriting palette slots keeps every block index valid, so this is O(palette).
                for (int i = 0; i < palette.length; i++) {
                    target.replacePaletteEntry(i, palette[i]);
                }
            }

            Map<Integer, BlockStateRef> regionOverrides = overrides.get(source);
            if (regionOverrides != null) {
                for (Map.Entry<Integer, BlockStateRef> e : regionOverrides.entrySet()) {
                    Vec3i pos = target.positionOf(e.getKey());
                    target.setBlock(pos, e.getValue());
                }
            }
        }
        baked.metadata().touch();
        return baked.refreshStatistics();
    }
}
