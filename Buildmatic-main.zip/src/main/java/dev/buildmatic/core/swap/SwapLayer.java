package dev.buildmatic.core.swap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * A named, toggleable group of swap rules.
 *
 * <p>Layers are the unit the player manipulates: each swap they make becomes one, they can be
 * reordered, switched off to compare, or deleted without touching the underlying schematic. Later
 * layers win over earlier ones, exactly like layers in an image editor.
 */
public final class SwapLayer {

    private final String id;
    private String name;
    private boolean enabled = true;
    private final List<SwapRule> rules = new ArrayList<>();

    public SwapLayer(String name) {
        this(UUID.randomUUID().toString(), name);
    }

    public SwapLayer(String id, String name) {
        this.id = id;
        this.name = name;
    }

    /** A single-rule layer, which is what one click in the variant wheel produces. */
    public static SwapLayer of(String name, SwapRule rule) {
        SwapLayer layer = new SwapLayer(name);
        layer.rules.add(rule);
        return layer;
    }

    public String id() { return id; }

    public String name() { return name; }

    public void setName(String name) { this.name = name; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public List<SwapRule> rules() { return Collections.unmodifiableList(rules); }

    public void addRule(SwapRule rule) { rules.add(rule); }

    public boolean removeRule(SwapRule rule) { return rules.remove(rule); }

    public void clearRules() { rules.clear(); }

    public boolean isEmpty() { return rules.isEmpty(); }

    /** True when every rule in the layer can be folded into the palette. */
    public boolean isPaletteResolvable() {
        for (SwapRule rule : rules) {
            if (!rule.isPaletteResolvable()) return false;
        }
        return true;
    }

    public SwapLayer copy() {
        SwapLayer copy = new SwapLayer(UUID.randomUUID().toString(), name);
        copy.enabled = enabled;
        copy.rules.addAll(rules);
        return copy;
    }

    /** A one-line summary for the layer list, e.g. {@code minecraft:oak_stairs -> spruce}. */
    public String describe() {
        if (rules.isEmpty()) return name + " (empty)";
        if (rules.size() == 1) return rules.get(0).describe();
        return name + " (" + rules.size() + " rules)";
    }

    @Override
    public String toString() { return "SwapLayer[" + name + ", " + rules.size() + " rules]"; }
}
