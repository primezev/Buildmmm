package dev.buildmatic.core.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.block.PropertyTranslator;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.BlockShape;
import dev.buildmatic.core.variant.VariantIndex;

import java.util.List;
import java.util.Set;

/**
 * One "replace this with that" instruction.
 *
 * <p>A rule is pure data: it never edits a schematic, it only answers what a given state should
 * become. That is what lets Buildmatic keep swaps non-destructive - the original blocks stay on
 * disk and the rules are re-evaluated on the fly.
 *
 * @param matcher which blocks the rule applies to
 * @param target  what they become
 * @param scope   where in the schematic the rule is active
 */
public record SwapRule(Matcher matcher, Target target, Scope scope) {

    public static SwapRule of(Matcher matcher, Target target) {
        return new SwapRule(matcher, target, new Scope.Everywhere());
    }

    // --- matchers ------------------------------------------------------------------------------

    /** Selects the blocks a rule acts on. */
    public sealed interface Matcher {

        boolean matches(BlockStateRef state, VariantIndex variants);

        /** A short label for the swap layer list. */
        String describe();

        /** One exact state, properties included: only north-facing bottom oak stairs. */
        record Exact(BlockStateRef state) implements Matcher {
            @Override public boolean matches(BlockStateRef s, VariantIndex v) {
                return s.equals(state);
            }
            @Override public String describe() { return state.descriptor(); }
        }

        /** Every state of one block: all oak stairs, whatever their facing. */
        record Block(String blockId) implements Matcher {
            @Override public boolean matches(BlockStateRef s, VariantIndex v) {
                return s.blockId().equals(blockId);
            }
            @Override public String describe() { return blockId; }
        }

        /** Every block made of one material: oak planks, stairs, slabs, fences, doors. */
        record Material(String material) implements Matcher {
            @Override public boolean matches(BlockStateRef s, VariantIndex v) {
                VariantIndex.BlockKind kind = v.kindOf(s.blockId());
                return kind != null && kind.material().equals(material);
            }
            @Override public String describe() { return "material " + material; }
        }

        /** Every block of one shape: every stair in the build, whatever it is made of. */
        record Shape(BlockShape shape) implements Matcher {
            @Override public boolean matches(BlockStateRef s, VariantIndex v) {
                VariantIndex.BlockKind kind = v.kindOf(s.blockId());
                return kind != null && kind.shape() == shape;
            }
            @Override public String describe() { return "shape " + shape.displayName(); }
        }

        /** Every non-empty block; only useful together with a narrow scope. */
        record Any() implements Matcher {
            @Override public boolean matches(BlockStateRef s, VariantIndex v) {
                return !s.isEmpty();
            }
            @Override public String describe() { return "any block"; }
        }
    }

    // --- targets -------------------------------------------------------------------------------

    /** Produces the replacement state. Returns null when the swap cannot be expressed. */
    public sealed interface Target {

        BlockStateRef apply(BlockStateRef source, Vec3i position, VariantIndex variants,
                            BlockStateSchema schema);

        String describe();

        /**
         * True when the result depends on where the block sits, which rules the target out of the
         * palette-level fast path.
         */
        default boolean isPositionDependent() { return false; }

        /** Replace with this exact state, ignoring whatever the source had. */
        record State(BlockStateRef state) implements Target {
            @Override public BlockStateRef apply(BlockStateRef s, Vec3i p, VariantIndex v,
                                                 BlockStateSchema schema) {
                return state;
            }
            @Override public String describe() { return state.descriptor(); }
        }

        /** Replace with this block, carrying the source's properties across. */
        record Block(String blockId) implements Target {
            @Override public BlockStateRef apply(BlockStateRef s, Vec3i p, VariantIndex v,
                                                 BlockStateSchema schema) {
                return PropertyTranslator.translate(s, blockId, schema);
            }
            @Override public String describe() { return blockId; }
        }

        /**
         * Keep each block's shape, change its material. Oak stairs become spruce stairs and oak
         * fences become spruce fences, from a single rule.
         */
        record Material(String material) implements Target {
            @Override public BlockStateRef apply(BlockStateRef s, Vec3i p, VariantIndex v,
                                                 BlockStateSchema schema) {
                VariantIndex.BlockKind kind = v.kindOf(s.blockId());
                if (kind == null) return null;
                String resolved = v.resolve(material, kind.shape());
                if (resolved == null) return null;
                return PropertyTranslator.translate(s, resolved, schema);
            }
            @Override public String describe() { return "-> " + material; }
        }

        /** Keep each block's material, change its shape: turn all oak planks into oak slabs. */
        record Shape(BlockShape shape) implements Target {
            @Override public BlockStateRef apply(BlockStateRef s, Vec3i p, VariantIndex v,
                                                 BlockStateSchema schema) {
                VariantIndex.BlockKind kind = v.kindOf(s.blockId());
                if (kind == null) return null;
                String resolved = v.resolve(kind.material(), shape);
                if (resolved == null) return null;
                return PropertyTranslator.translate(s, resolved, schema);
            }
            @Override public String describe() { return "-> " + shape.displayName(); }
        }

        /**
         * Restyles every block a {@link dev.buildmatic.core.theme.BuildTheme} recognises, in one
         * rule.
         *
         * <p>Paired with {@link Matcher.Any} this is a whole-build restyle, and because it stays a
         * pure function of the state it folds into the effective palette like any other swap: a
         * theme costs one evaluation per distinct block, not one per block placed. Blocks the theme
         * has no opinion about - and every mechanism, container and block entity - come back null
         * and are left exactly as they were.
         */
        record Themed(dev.buildmatic.core.theme.BuildTheme theme,
                      dev.buildmatic.core.theme.ThemeVariant variant) implements Target {

            public Themed(dev.buildmatic.core.theme.BuildTheme theme) {
                this(theme, theme.defaultVariant());
            }

            @Override public BlockStateRef apply(BlockStateRef s, Vec3i p, VariantIndex v,
                                                 BlockStateSchema schema) {
                return variant.retarget(s, v, schema);
            }

            @Override public String describe() {
                String name = theme.displayName() + " theme";
                return "-> " + (variant.equals(theme.defaultVariant())
                        ? name : name + " (" + variant.displayName() + ")");
            }
        }

        record WeightedEntry(String blockId, int weight) {}

        /**
         * Picks between several blocks by weight, for texture noise: 70% stone bricks, 20% cracked,
         * 10% mossy.
         *
         * <p>The choice is derived from the block position, so it is stable across reloads, across
         * clients, and across a save/reload cycle. A randomised build looks the same to everyone
         * who opens the file.
         */
        record Weighted(List<WeightedEntry> entries, long seed) implements Target {

            public Weighted {
                if (entries.isEmpty()) throw new IllegalArgumentException("no weighted entries");
                entries = List.copyOf(entries);
            }

            @Override
            public BlockStateRef apply(BlockStateRef s, Vec3i p, VariantIndex v,
                                       BlockStateSchema schema) {
                int total = 0;
                for (WeightedEntry entry : entries) total += Math.max(0, entry.weight());
                if (total <= 0) return null;

                int roll = Math.floorMod(hash(p, seed), total);
                for (WeightedEntry entry : entries) {
                    roll -= Math.max(0, entry.weight());
                    if (roll < 0) return PropertyTranslator.translate(s, entry.blockId(), schema);
                }
                return PropertyTranslator.translate(s, entries.get(0).blockId(), schema);
            }

            /** A cheap, well-mixed integer hash of the position; splitmix64 finalisation. */
            private static int hash(Vec3i p, long seed) {
                long h = seed;
                h = h * 0x9E3779B97F4A7C15L + p.x() * 0xBF58476D1CE4E5B9L;
                h = h * 0x9E3779B97F4A7C15L + p.y() * 0x94D049BB133111EBL;
                h = h * 0x9E3779B97F4A7C15L + p.z() * 0xD6E8FEB86659FD93L;
                h ^= h >>> 30;
                h *= 0xBF58476D1CE4E5B9L;
                h ^= h >>> 27;
                h *= 0x94D049BB133111EBL;
                h ^= h >>> 31;
                return (int) h;
            }

            @Override
            public boolean isPositionDependent() { return true; }

            @Override
            public String describe() {
                return "-> " + entries.size() + " weighted variants";
            }
        }

        /** Deletes the matched blocks. */
        record Remove() implements Target {
            @Override public BlockStateRef apply(BlockStateRef s, Vec3i p, VariantIndex v,
                                                 BlockStateSchema schema) {
                return BlockStateRef.AIR;
            }
            @Override public String describe() { return "-> removed"; }
        }
    }

    // --- scopes --------------------------------------------------------------------------------

    /**
     * Where a rule is active.
     *
     * <p>{@link Everywhere} and {@link Region} are resolvable at the palette level, which is why a
     * whole-build conversion is instant even on a ten-million-block schematic. {@link Box} and
     * {@link Positions} need a per-block check and are stored separately.
     */
    public sealed interface Scope {

        /** True when the rule can be baked into a region's palette instead of checked per block. */
        boolean isPaletteResolvable();

        /** True when the rule applies to a region-local position inside {@code regionName}. */
        boolean covers(String regionName, Vec3i localPos);

        String describe();

        record Everywhere() implements Scope {
            @Override public boolean isPaletteResolvable() { return true; }
            @Override public boolean covers(String r, Vec3i p) { return true; }
            @Override public String describe() { return "whole schematic"; }
        }

        record Region(String regionName) implements Scope {
            @Override public boolean isPaletteResolvable() { return true; }
            @Override public boolean covers(String r, Vec3i p) { return regionName.equals(r); }
            @Override public String describe() { return "region " + regionName; }
        }

        record Box(String regionName, BlockBox box) implements Scope {
            @Override public boolean isPaletteResolvable() { return false; }
            @Override public boolean covers(String r, Vec3i p) {
                return regionName.equals(r) && box.contains(p);
            }
            @Override public String describe() { return "box in " + regionName; }
        }

        record Positions(String regionName, Set<Vec3i> positions) implements Scope {
            public Positions {
                positions = Set.copyOf(positions);
            }
            @Override public boolean isPaletteResolvable() { return false; }
            @Override public boolean covers(String r, Vec3i p) {
                return regionName.equals(r) && positions.contains(p);
            }
            @Override public String describe() {
                return positions.size() + " block(s) in " + regionName;
            }
        }
    }

    // --- evaluation ----------------------------------------------------------------------------

    /**
     * The replacement for {@code state} at {@code localPos}, or null when this rule does not apply.
     */
    public BlockStateRef resolve(BlockStateRef state, String regionName, Vec3i localPos,
                                 VariantIndex variants, BlockStateSchema schema) {
        if (!scope.covers(regionName, localPos)) return null;
        if (!matcher.matches(state, variants)) return null;
        BlockStateRef result = target.apply(state, localPos, variants, schema);
        return result == null || result.equals(state) ? null : result;
    }

    /** True when the rule can be folded into a region's palette rather than checked per block. */
    public boolean isPaletteResolvable() {
        return scope.isPaletteResolvable() && !target.isPositionDependent();
    }

    public String describe() {
        return matcher.describe() + " " + target.describe() + " (" + scope.describe() + ")";
    }
}
