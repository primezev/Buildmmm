package dev.buildmatic.core.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.BiPredicate;

/**
 * Turns a click plus a modifier key into a {@link SwapRule.Scope}.
 *
 * <p>The five scopes below are the whole interaction vocabulary of the variant wheel:
 *
 * <pre>
 *   click              this one block
 *   shift + click      every identical block in the schematic
 *   ctrl + click       every identical block in this region
 *   alt + click        the connected volume of identical blocks
 *   ctrl + shift       every block of the same material, schematic-wide
 * </pre>
 */
public final class SwapScopes {

    /**
     * Upper bound on a flood fill, so alt-clicking a stone floor in a huge build cannot lock the
     * client up. Reaching it is reported rather than silently truncated.
     */
    public static final int DEFAULT_FLOOD_LIMIT = 200_000;

    /** How strictly two blocks must match to be swapped together. */
    public enum Strictness {
        /** Same block and identical properties: only north-facing bottom oak stairs. */
        EXACT_STATE,
        /** Same block, any properties: every oak stair whichever way it faces. */
        SAME_BLOCK,
        /** Same material: every oak block, whatever shape. */
        SAME_MATERIAL
    }

    /** The outcome of a flood fill. */
    public record FloodResult(Set<Vec3i> positions, boolean hitLimit) {

        public int size() { return positions.size(); }
    }

    private SwapScopes() {}

    /** Just the clicked block. */
    public static SwapRule.Scope single(SchematicRegion region, Vec3i localPos) {
        return new SwapRule.Scope.Positions(region.name(), Set.of(localPos));
    }

    /** The whole schematic; combine with a {@code Block} or {@code Material} matcher. */
    public static SwapRule.Scope everywhere() {
        return new SwapRule.Scope.Everywhere();
    }

    public static SwapRule.Scope region(SchematicRegion region) {
        return new SwapRule.Scope.Region(region.name());
    }

    /**
     * The matcher that pairs with a wide scope for the given strictness.
     *
     * <p>Scope and matcher have to agree: "every identical block" is a whole-schematic scope with a
     * narrow matcher, not a narrow scope.
     */
    public static SwapRule.Matcher matcherFor(BlockStateRef clicked, Strictness strictness,
                                              dev.buildmatic.core.variant.VariantIndex variants) {
        switch (strictness) {
            case EXACT_STATE:
                return new SwapRule.Matcher.Exact(clicked);
            case SAME_BLOCK:
                return new SwapRule.Matcher.Block(clicked.blockId());
            case SAME_MATERIAL:
                var kind = variants.kindOf(clicked.blockId());
                return kind == null
                        ? new SwapRule.Matcher.Block(clicked.blockId())
                        : new SwapRule.Matcher.Material(kind.material());
            default:
                return new SwapRule.Matcher.Block(clicked.blockId());
        }
    }

    /**
     * Flood-fills the connected volume of blocks matching the clicked one.
     *
     * <p>Connectivity is face-to-face only. Diagonal spread would leak through the corner gaps a
     * checkerboard pattern leaves, which is never what a builder means by "this wall".
     */
    public static FloodResult flood(SchematicRegion region, Vec3i start, Strictness strictness,
                                    dev.buildmatic.core.variant.VariantIndex variants) {
        return flood(region, start, strictness, variants, DEFAULT_FLOOD_LIMIT);
    }

    public static FloodResult flood(SchematicRegion region, Vec3i start, Strictness strictness,
                                    dev.buildmatic.core.variant.VariantIndex variants, int limit) {
        Set<Vec3i> found = new LinkedHashSet<>();
        if (!region.contains(start.x(), start.y(), start.z())) {
            return new FloodResult(found, false);
        }

        BlockStateRef seed = region.getBlock(start);
        if (seed.isEmpty()) return new FloodResult(found, false);

        BiPredicate<BlockStateRef, BlockStateRef> matches = matcherFor(strictness, variants);

        Set<Vec3i> seen = new HashSet<>();
        Deque<Vec3i> queue = new ArrayDeque<>();
        queue.add(start);
        seen.add(start);
        boolean hitLimit = false;

        while (!queue.isEmpty()) {
            Vec3i pos = queue.poll();
            found.add(pos);
            if (found.size() >= limit) {
                hitLimit = true;
                break;
            }

            for (Direction direction : Direction.values()) {
                Vec3i next = pos.offset(direction);
                if (!region.contains(next.x(), next.y(), next.z())) continue;
                if (!seen.add(next)) continue;
                if (matches.test(seed, region.getBlock(next))) queue.add(next);
            }
        }
        return new FloodResult(found, hitLimit);
    }

    private static BiPredicate<BlockStateRef, BlockStateRef> matcherFor(
            Strictness strictness, dev.buildmatic.core.variant.VariantIndex variants) {
        switch (strictness) {
            case EXACT_STATE:
                return BlockStateRef::equals;
            case SAME_BLOCK:
                return (seed, other) -> seed.blockId().equals(other.blockId());
            case SAME_MATERIAL:
                return (seed, other) -> {
                    var a = variants.kindOf(seed.blockId());
                    var b = variants.kindOf(other.blockId());
                    return a != null && b != null && a.material().equals(b.material());
                };
            default:
                return BlockStateRef::equals;
        }
    }

    /** A short label for the swap layer produced by this interaction. */
    public static String describe(Strictness strictness, SwapRule.Scope scope) {
        String what = switch (strictness) {
            case EXACT_STATE -> "this state";
            case SAME_BLOCK -> "this block";
            case SAME_MATERIAL -> "this material";
        };
        return what + ", " + scope.describe();
    }
}
