package dev.buildmatic.core.theme;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.variant.VariantIndex;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * A whole-build restyle: a named look, offered in several combinations of materials.
 *
 * <p>Each combination is a {@link ThemeVariant} and is a pure function from block to block, which
 * is what lets the swap engine fold it into the effective palette. Restyling a ten-million-block
 * build therefore costs one evaluation per distinct block in the palette - a few hundred - not one
 * per block placed.
 *
 * <p>Three things are preserved by construction, and they are the reason a theme is safe to apply
 * to a finished build:
 *
 * <ol>
 *   <li><b>Shape.</b> A stair becomes a stair, a slab a slab, a fence a fence. When the theme's
 *       material has no counterpart for a shape, the block is left alone rather than approximated.
 *   <li><b>Properties.</b> Facing, half, axis and the rest travel across through
 *       {@code PropertyTranslator}, so a north-facing bottom stair stays one.
 *   <li><b>Function.</b> {@link ThemeSafety} takes mechanisms, containers and block entities out of
 *       reach, and {@link StyleRoles} only recognises building materials in the first place.
 * </ol>
 *
 * @param id          stable identifier, persisted in save files
 * @param displayName what the picker shows
 * @param description one line about the look, shown under the name
 * @param variants    the combinations, the first being the theme's default
 */
public record BuildTheme(String id, String displayName, String description,
                         List<ThemeVariant> variants) {

    public BuildTheme {
        if (variants.isEmpty()) throw new IllegalArgumentException("a theme needs one combination");
        variants = List.copyOf(variants);
    }

    public ThemeVariant defaultVariant() { return variants.get(0); }

    public ThemeVariant variantById(String variantId) {
        for (ThemeVariant variant : variants) {
            if (variant.id().equals(variantId)) return variant;
        }
        return null;
    }

    /**
     * The combinations this version of the game can actually build.
     *
     * <p>Never empty in practice - every theme's default is written to resolve as far back as
     * 1.19.2 - but the caller should still cope with an empty list rather than assume.
     */
    public List<ThemeVariant> availableVariants(VariantIndex variants) {
        List<ThemeVariant> available = new ArrayList<>(this.variants.size());
        for (ThemeVariant variant : this.variants) {
            if (variant.isAvailableIn(variants)) available.add(variant);
        }
        return available;
    }

    // --- convenience for the default combination -----------------------------------------------

    public StyleMaterial materialFor(StyleRole role) {
        return defaultVariant().materialFor(role);
    }

    public List<String> colours() { return defaultVariant().colours(); }

    public String retargetId(String blockId, VariantIndex variants) {
        return defaultVariant().retargetId(blockId, variants);
    }

    public BlockStateRef retarget(BlockStateRef state, VariantIndex variants,
                                  BlockStateSchema schema) {
        return defaultVariant().retarget(state, variants, schema);
    }

    // --- building ------------------------------------------------------------------------------

    public static Builder named(String id, String displayName, String description) {
        return new Builder(id, displayName, description);
    }

    /**
     * Assembles a theme from its default combination plus overlays.
     *
     * <p>Every {@link #variant} inherits from the default rather than from the combination before
     * it, so a variant only has to state what makes it different and reading one does not mean
     * replaying the ones above.
     */
    public static final class Builder {

        private final String id;
        private final String displayName;
        private final String description;
        private final List<Draft> drafts = new ArrayList<>();
        private Draft current;

        private static final class Draft {
            final String id;
            final String displayName;
            final Map<StyleRole, List<StyleMaterial>> palette;
            List<String> colours;

            Draft(String id, String displayName, Map<StyleRole, List<StyleMaterial>> palette,
                  List<String> colours) {
                this.id = id;
                this.displayName = displayName;
                this.palette = palette;
                this.colours = colours;
            }
        }

        private Builder(String id, String displayName, String description) {
            this.id = id;
            this.displayName = displayName;
            this.description = description;
            // "default" is the id every save file written before combinations existed implies.
            this.current = new Draft("default", "Standard", new EnumMap<>(StyleRole.class),
                    List.of());
            drafts.add(current);
        }

        /** Sets the material for a role, discarding any alternatives already listed for it. */
        public Builder role(StyleRole role, String block, String... stems) {
            current.palette.put(role, new ArrayList<>(List.of(StyleMaterial.of(block, stems))));
            return this;
        }

        /**
         * Adds a second choice for a role, used when the first does not exist in every version.
         *
         * <p>Deepslate arrived in 1.17 and tuff bricks in 1.21; a theme leading with either needs
         * somewhere to fall back to, or it would leave half a build untouched on an older world.
         */
        public Builder fallback(StyleRole role, String block, String... stems) {
            List<StyleMaterial> alternatives = current.palette.get(role);
            if (alternatives == null) return role(role, block, stems);
            alternatives.add(StyleMaterial.of(block, stems));
            return this;
        }

        /** The dye colours this combination keeps; everything else is pulled to the nearest. */
        public Builder colours(String... colours) {
            current.colours = List.of(colours);
            return this;
        }

        /**
         * Starts another combination, inheriting the default's materials and colours.
         *
         * <p>Subsequent {@code role}, {@code fallback} and {@code colours} calls apply to it.
         */
        public Builder variant(String variantId, String variantName) {
            Draft base = drafts.get(0);
            Map<StyleRole, List<StyleMaterial>> palette = new EnumMap<>(StyleRole.class);
            for (Map.Entry<StyleRole, List<StyleMaterial>> entry : base.palette.entrySet()) {
                palette.put(entry.getKey(), new ArrayList<>(entry.getValue()));
            }
            current = new Draft(variantId, variantName, palette, base.colours);
            drafts.add(current);
            return this;
        }

        public BuildTheme build() {
            List<ThemeVariant> variants = new ArrayList<>(drafts.size());
            for (Draft draft : drafts) {
                Map<StyleRole, List<StyleMaterial>> palette = new EnumMap<>(StyleRole.class);
                for (Map.Entry<StyleRole, List<StyleMaterial>> entry : draft.palette.entrySet()) {
                    palette.put(entry.getKey(), List.copyOf(entry.getValue()));
                }
                variants.add(new ThemeVariant(draft.id, draft.displayName, palette, draft.colours));
            }
            return new BuildTheme(id, displayName, description, variants);
        }
    }
}
