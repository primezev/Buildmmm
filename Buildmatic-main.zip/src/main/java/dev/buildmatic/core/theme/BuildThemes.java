package dev.buildmatic.core.theme;

import java.util.List;

/**
 * The built-in palettes.
 *
 * <p>Each theme fills in the same handful of roles, so they are directly comparable: clicking
 * through the list re-dresses the same build seven ways without touching its shape. Every theme
 * then offers several combinations of materials, because "medieval" is not one palette - a
 * cobblestone keep, an oak-framed village house and a mossy ruin share none of their blocks.
 *
 * <p>The entries are a judgement call about what each style looks like, and they are meant to be
 * edited: the whole table is data, and a combination is a handful of {@code .role(...)} lines over
 * the theme's default.
 *
 * <h2>Versions</h2>
 * Buildmatic targets 1.19.2 upwards from one source tree, and the block list is built from whatever
 * the running game reports. Two rules keep these tables honest across that range:
 *
 * <ul>
 *   <li>Anything added after 1.19.2 - cherry and bamboo in 1.20, the tuff family in 1.21 - is
 *       followed by a {@code fallback} to something older, so a theme never leaves half a build
 *       untouched.</li>
 *   <li>A combination whose materials genuinely do not exist yet, like the tuff keep below, is
 *       hidden by the picker on versions that lack them rather than offered and silently doing
 *       nothing.</li>
 * </ul>
 *
 * <p>Every full-block form here is an ordinary opaque building block, and every stem list leads
 * with a material that has a full set of stairs, slabs and walls. That is what keeps a restyle from
 * quietly changing how a build behaves; see {@link ThemeSafety}.
 */
public final class BuildThemes {

    /** Cobble, stone brick and heavy timber: a keep, a village, a tavern. */
    public static final BuildTheme MEDIEVAL = BuildTheme
            .named("medieval", "Medieval", "Cobblestone, stone brick, spruce and dark oak")
            .role(StyleRole.STONE_PLAIN, "minecraft:stone_bricks", "stone_brick")
            .role(StyleRole.STONE_ROUGH, "minecraft:cobblestone", "cobblestone", "mossy_cobblestone")
            .role(StyleRole.STONE_REFINED, "minecraft:mossy_stone_bricks",
                    "mossy_stone_brick", "stone_brick")
            .role(StyleRole.STONE_DARK, "minecraft:deepslate_bricks",
                    "deepslate_brick", "deepslate_tile")
            .role(StyleRole.WOOD_LIGHT, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_ACCENT, "minecraft:oak_planks", "oak")
            .role(StyleRole.METAL, "minecraft:oxidized_copper",
                    "oxidized_cut_copper", "weathered_cut_copper", "cut_copper")
            .role(StyleRole.LAMP, "minecraft:glowstone")
            .role(StyleRole.GLASS, "minecraft:light_gray_stained_glass")
            .role(StyleRole.GLASS_PANE, "minecraft:light_gray_stained_glass_pane")
            // Dyes a village could plausibly have made: earths, iron oxide, soot, woad.
            .colours("white", "light_gray", "gray", "black", "brown", "red", "green", "blue")

            .variant("timber", "Timber frame")
            .role(StyleRole.STONE_PLAIN, "minecraft:cobblestone", "cobblestone")
            .role(StyleRole.STONE_ROUGH, "minecraft:stone_bricks", "stone_brick")
            .role(StyleRole.STONE_REFINED, "minecraft:chiseled_stone_bricks", "stone_brick")
            .role(StyleRole.WOOD_LIGHT, "minecraft:oak_planks", "oak")
            .role(StyleRole.WOOD_DARK, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.WOOD_ACCENT, "minecraft:birch_planks", "birch")

            .variant("mossy", "Mossy ruin")
            .role(StyleRole.STONE_PLAIN, "minecraft:mossy_stone_bricks", "mossy_stone_brick")
            .role(StyleRole.STONE_ROUGH, "minecraft:mossy_cobblestone", "mossy_cobblestone")
            .role(StyleRole.STONE_REFINED, "minecraft:cracked_stone_bricks", "stone_brick")
            .role(StyleRole.STONE_DARK, "minecraft:cobbled_deepslate", "cobbled_deepslate")
            .role(StyleRole.WOOD_LIGHT, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_ACCENT, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.METAL, "minecraft:oxidized_copper", "oxidized_cut_copper")

            .variant("keep", "Dark keep")
            .role(StyleRole.STONE_PLAIN, "minecraft:deepslate_bricks", "deepslate_brick")
            .role(StyleRole.STONE_ROUGH, "minecraft:cobbled_deepslate", "cobbled_deepslate")
            .role(StyleRole.STONE_REFINED, "minecraft:deepslate_tiles",
                    "deepslate_tile", "deepslate_brick")
            .role(StyleRole.STONE_DARK, "minecraft:polished_blackstone_bricks",
                    "polished_blackstone_brick", "polished_blackstone")
            .role(StyleRole.WOOD_LIGHT, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_DARK, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.WOOD_ACCENT, "minecraft:dark_oak_planks", "dark_oak")

            // 1.21 and up only: on anything older the picker does not offer this one.
            .variant("tuff", "Tuff keep")
            .role(StyleRole.STONE_PLAIN, "minecraft:polished_tuff", "polished_tuff")
            .role(StyleRole.STONE_ROUGH, "minecraft:tuff", "tuff")
            .role(StyleRole.STONE_REFINED, "minecraft:tuff_bricks", "tuff_brick")
            .role(StyleRole.STONE_DARK, "minecraft:chiseled_tuff", "tuff_brick", "polished_tuff")
            .role(StyleRole.WOOD_LIGHT, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .build();

    /** Quartz, concrete and polished deepslate, with the nether woods standing in for timber. */
    public static final BuildTheme FUTURISTIC = BuildTheme
            .named("futuristic", "Futuristic", "Quartz, grey concrete, polished deepslate")
            // The trailing stems exist for walls and the other shapes quartz and concrete have no
            // form of: without them a restyled build keeps its cobblestone walls.
            .role(StyleRole.STONE_PLAIN, "minecraft:smooth_quartz",
                    "smooth_quartz", "quartz", "diorite")
            .role(StyleRole.STONE_ROUGH, "minecraft:light_gray_concrete",
                    "polished_andesite", "smooth_stone", "andesite")
            .role(StyleRole.STONE_REFINED, "minecraft:quartz_bricks",
                    "quartz", "smooth_quartz", "diorite")
            .role(StyleRole.STONE_DARK, "minecraft:polished_deepslate",
                    "polished_deepslate", "deepslate_tile")
            // Warped and crimson are the only non-wood-looking woods with a full set of shapes,
            // so panelling, fences and doors all convert instead of half of them staying oak.
            .role(StyleRole.WOOD_LIGHT, "minecraft:warped_planks", "warped")
            .role(StyleRole.WOOD_DARK, "minecraft:crimson_planks", "crimson")
            .role(StyleRole.WOOD_ACCENT, "minecraft:warped_planks", "warped")
            .role(StyleRole.GLASS, "minecraft:light_blue_stained_glass")
            .role(StyleRole.GLASS_PANE, "minecraft:light_blue_stained_glass_pane")
            .role(StyleRole.METAL, "minecraft:copper_block", "cut_copper")
            .role(StyleRole.LAMP, "minecraft:sea_lantern")
            .colours("white", "light_gray", "gray", "black", "light_blue", "cyan")

            .variant("black", "Black tech")
            .role(StyleRole.STONE_PLAIN, "minecraft:polished_deepslate",
                    "polished_deepslate", "deepslate_tile")
            .role(StyleRole.STONE_ROUGH, "minecraft:black_concrete",
                    "polished_blackstone", "polished_deepslate")
            .role(StyleRole.STONE_REFINED, "minecraft:deepslate_tiles",
                    "deepslate_tile", "deepslate_brick")
            .role(StyleRole.STONE_DARK, "minecraft:blackstone",
                    "polished_blackstone_brick", "polished_blackstone")
            .role(StyleRole.WOOD_LIGHT, "minecraft:crimson_planks", "crimson")
            .role(StyleRole.WOOD_DARK, "minecraft:warped_planks", "warped")
            .role(StyleRole.GLASS, "minecraft:gray_stained_glass")
            .role(StyleRole.GLASS_PANE, "minecraft:gray_stained_glass_pane")
            .colours("white", "light_gray", "gray", "black", "cyan")

            .variant("white", "White lab")
            .role(StyleRole.STONE_PLAIN, "minecraft:white_concrete", "smooth_quartz", "quartz")
            .role(StyleRole.STONE_ROUGH, "minecraft:smooth_quartz", "smooth_quartz", "quartz")
            .role(StyleRole.STONE_REFINED, "minecraft:quartz_bricks", "quartz", "smooth_quartz")
            .role(StyleRole.STONE_DARK, "minecraft:gray_concrete", "polished_andesite", "andesite")
            .role(StyleRole.GLASS, "minecraft:white_stained_glass")
            .role(StyleRole.GLASS_PANE, "minecraft:white_stained_glass_pane")
            .colours("white", "light_gray", "gray", "light_blue")
            .build();

    /** Pale plaster walls, dark tiled roofs, bamboo and cherry. */
    public static final BuildTheme ASIAN = BuildTheme
            .named("asian", "Asian", "Pale plaster, dark tiled roofs, bamboo")
            .role(StyleRole.STONE_PLAIN, "minecraft:quartz_block", "quartz", "smooth_quartz")
            .role(StyleRole.STONE_ROUGH, "minecraft:stone_bricks", "stone_brick", "cobblestone")
            .role(StyleRole.STONE_REFINED, "minecraft:smooth_quartz", "smooth_quartz", "quartz")
            .role(StyleRole.STONE_DARK, "minecraft:dark_prismarine",
                    "dark_prismarine", "prismarine_brick")
            // Bamboo and cherry are 1.20 blocks; birch and jungle carry the look before that.
            .role(StyleRole.WOOD_LIGHT, "minecraft:bamboo_planks", "bamboo", "bamboo_mosaic")
            .fallback(StyleRole.WOOD_LIGHT, "minecraft:birch_planks", "birch")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_ACCENT, "minecraft:cherry_planks", "cherry")
            .fallback(StyleRole.WOOD_ACCENT, "minecraft:jungle_planks", "jungle")
            .role(StyleRole.METAL, "minecraft:oxidized_copper",
                    "oxidized_cut_copper", "cut_copper")
            .role(StyleRole.LAMP, "minecraft:glowstone")
            .role(StyleRole.GLASS, "minecraft:white_stained_glass")
            .role(StyleRole.GLASS_PANE, "minecraft:white_stained_glass_pane")
            .colours("white", "light_gray", "red", "black", "brown", "pink")

            .variant("timber", "Dark timber")
            .role(StyleRole.STONE_PLAIN, "minecraft:smooth_quartz", "smooth_quartz", "quartz")
            .role(StyleRole.STONE_ROUGH, "minecraft:cobblestone", "cobblestone")
            .role(StyleRole.STONE_REFINED, "minecraft:stone_bricks", "stone_brick")
            .role(StyleRole.STONE_DARK, "minecraft:deepslate_tiles",
                    "deepslate_tile", "deepslate_brick")
            .role(StyleRole.WOOD_LIGHT, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_DARK, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.WOOD_ACCENT, "minecraft:dark_oak_planks", "dark_oak")

            .variant("pagoda", "Red pagoda")
            .role(StyleRole.STONE_PLAIN, "minecraft:white_terracotta",
                    "quartz", "smooth_quartz")
            .role(StyleRole.STONE_DARK, "minecraft:red_nether_bricks",
                    "red_nether_brick", "nether_brick")
            .role(StyleRole.STONE_REFINED, "minecraft:quartz_bricks", "quartz", "smooth_quartz")
            .role(StyleRole.WOOD_DARK, "minecraft:crimson_planks", "crimson")
            .role(StyleRole.WOOD_ACCENT, "minecraft:crimson_planks", "crimson")
            .colours("white", "red", "black", "brown")
            .build();

    /** Marble and moss: a temple that has been standing a while. */
    public static final BuildTheme ANCIENT = BuildTheme
            .named("ancient", "Ancient", "Marble, mossy cobble and jungle wood")
            .role(StyleRole.STONE_PLAIN, "minecraft:smooth_quartz", "smooth_quartz", "quartz")
            .role(StyleRole.STONE_ROUGH, "minecraft:mossy_cobblestone",
                    "mossy_cobblestone", "cobblestone")
            .role(StyleRole.STONE_REFINED, "minecraft:chiseled_quartz_block",
                    "quartz", "smooth_quartz")
            .role(StyleRole.STONE_DARK, "minecraft:mossy_stone_bricks",
                    "mossy_stone_brick", "stone_brick")
            .role(StyleRole.WOOD_LIGHT, "minecraft:jungle_planks", "jungle")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_ACCENT, "minecraft:acacia_planks", "acacia")
            .role(StyleRole.METAL, "minecraft:weathered_copper",
                    "weathered_cut_copper", "cut_copper")
            .role(StyleRole.LAMP, "minecraft:glowstone")
            .colours("white", "light_gray", "black", "brown", "red", "cyan")

            .variant("temple", "Sun temple")
            .role(StyleRole.STONE_PLAIN, "minecraft:smooth_sandstone",
                    "smooth_sandstone", "sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:sandstone", "sandstone")
            .role(StyleRole.STONE_REFINED, "minecraft:chiseled_sandstone",
                    "cut_sandstone", "sandstone")
            .role(StyleRole.STONE_DARK, "minecraft:smooth_red_sandstone",
                    "smooth_red_sandstone", "red_sandstone")
            .role(StyleRole.WOOD_LIGHT, "minecraft:birch_planks", "birch")
            .role(StyleRole.WOOD_DARK, "minecraft:acacia_planks", "acacia")
            .role(StyleRole.METAL, "minecraft:copper_block", "cut_copper")

            .variant("overgrown", "Overgrown")
            .role(StyleRole.STONE_PLAIN, "minecraft:mossy_stone_bricks", "mossy_stone_brick")
            .role(StyleRole.STONE_ROUGH, "minecraft:mossy_cobblestone", "mossy_cobblestone")
            .role(StyleRole.STONE_REFINED, "minecraft:cracked_stone_bricks", "stone_brick")
            .role(StyleRole.STONE_DARK, "minecraft:deepslate_bricks",
                    "deepslate_brick", "deepslate_tile")
            .role(StyleRole.WOOD_LIGHT, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.METAL, "minecraft:oxidized_copper", "oxidized_cut_copper")
            .build();

    /** White and grey concrete with quartz detailing and birch. */
    public static final BuildTheme MODERN = BuildTheme
            .named("modern", "Modern", "White and grey concrete, quartz, birch")
            .role(StyleRole.STONE_PLAIN, "minecraft:white_concrete",
                    "smooth_quartz", "quartz", "diorite")
            .role(StyleRole.STONE_ROUGH, "minecraft:light_gray_concrete",
                    "polished_andesite", "smooth_stone", "andesite")
            .role(StyleRole.STONE_REFINED, "minecraft:smooth_quartz",
                    "smooth_quartz", "quartz", "diorite")
            .role(StyleRole.STONE_DARK, "minecraft:gray_concrete",
                    "polished_deepslate", "deepslate_tile")
            .role(StyleRole.WOOD_LIGHT, "minecraft:birch_planks", "birch")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_ACCENT, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.METAL, "minecraft:copper_block", "cut_copper")
            .role(StyleRole.LAMP, "minecraft:sea_lantern")
            .role(StyleRole.GLASS, "minecraft:gray_stained_glass")
            .role(StyleRole.GLASS_PANE, "minecraft:gray_stained_glass_pane")
            .colours("white", "light_gray", "gray", "black", "blue")

            .variant("dark", "Dark modern")
            .role(StyleRole.STONE_PLAIN, "minecraft:gray_concrete",
                    "polished_deepslate", "deepslate_tile")
            .role(StyleRole.STONE_ROUGH, "minecraft:black_concrete",
                    "polished_deepslate", "polished_blackstone")
            .role(StyleRole.STONE_DARK, "minecraft:black_concrete",
                    "polished_blackstone_brick", "polished_blackstone")
            .role(StyleRole.WOOD_LIGHT, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_DARK, "minecraft:spruce_planks", "spruce")

            .variant("warm", "Warm modern")
            .role(StyleRole.STONE_PLAIN, "minecraft:smooth_sandstone",
                    "smooth_sandstone", "sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:white_concrete",
                    "smooth_quartz", "quartz", "diorite")
            .role(StyleRole.STONE_REFINED, "minecraft:cut_sandstone",
                    "cut_sandstone", "sandstone")
            .role(StyleRole.WOOD_LIGHT, "minecraft:oak_planks", "oak")
            .role(StyleRole.WOOD_DARK, "minecraft:spruce_planks", "spruce")
            .role(StyleRole.WOOD_ACCENT, "minecraft:acacia_planks", "acacia")
            .role(StyleRole.GLASS, "minecraft:brown_stained_glass")
            .role(StyleRole.GLASS_PANE, "minecraft:brown_stained_glass_pane")
            .colours("white", "light_gray", "brown", "black")
            .build();

    /** Sandstone in all its forms, acacia beams, sand underfoot. */
    public static final BuildTheme DESERT = BuildTheme
            .named("desert", "Desert", "Sandstone, smooth and cut, with acacia")
            .role(StyleRole.STONE_PLAIN, "minecraft:sandstone", "sandstone", "cut_sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:smooth_sandstone",
                    "smooth_sandstone", "sandstone")
            .role(StyleRole.STONE_REFINED, "minecraft:chiseled_sandstone",
                    "cut_sandstone", "sandstone")
            .role(StyleRole.STONE_DARK, "minecraft:smooth_red_sandstone",
                    "smooth_red_sandstone", "red_sandstone")
            .role(StyleRole.WOOD_LIGHT, "minecraft:acacia_planks", "acacia")
            .role(StyleRole.WOOD_DARK, "minecraft:jungle_planks", "jungle")
            .role(StyleRole.WOOD_ACCENT, "minecraft:birch_planks", "birch")
            .role(StyleRole.SAND, "minecraft:sand", "sand")
            // Sandstone rather than sand: dirt does not fall, and a floor that starts to would be a
            // restyle rearranging the build.
            .role(StyleRole.GROUND, "minecraft:sandstone", "sandstone")
            .role(StyleRole.METAL, "minecraft:copper_block", "cut_copper")
            .role(StyleRole.LAMP, "minecraft:glowstone")
            .colours("white", "light_gray", "black", "orange", "yellow", "brown", "cyan")

            .variant("red", "Red desert")
            .role(StyleRole.STONE_PLAIN, "minecraft:red_sandstone",
                    "red_sandstone", "cut_red_sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:smooth_red_sandstone",
                    "smooth_red_sandstone", "red_sandstone")
            .role(StyleRole.STONE_REFINED, "minecraft:chiseled_red_sandstone",
                    "cut_red_sandstone", "red_sandstone")
            .role(StyleRole.STONE_DARK, "minecraft:smooth_sandstone",
                    "smooth_sandstone", "sandstone")
            .role(StyleRole.SAND, "minecraft:red_sand", "red_sand")
            .role(StyleRole.GROUND, "minecraft:red_sandstone", "red_sandstone")

            .variant("adobe", "Adobe")
            .role(StyleRole.STONE_PLAIN, "minecraft:terracotta", "sandstone", "cut_sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:brown_terracotta",
                    "smooth_sandstone", "sandstone")
            .role(StyleRole.STONE_REFINED, "minecraft:cut_sandstone",
                    "cut_sandstone", "sandstone")
            .role(StyleRole.STONE_DARK, "minecraft:red_sandstone",
                    "red_sandstone", "smooth_red_sandstone")
            .role(StyleRole.WOOD_LIGHT, "minecraft:jungle_planks", "jungle")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.GROUND, "minecraft:terracotta", "sandstone")
            .build();

    /** Badlands: red sandstone, granite and terracotta. */
    public static final BuildTheme MESA = BuildTheme
            .named("mesa", "Mesa", "Red sandstone, granite, terracotta")
            .role(StyleRole.STONE_PLAIN, "minecraft:red_sandstone",
                    "red_sandstone", "cut_red_sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:granite", "granite", "polished_granite")
            .role(StyleRole.STONE_REFINED, "minecraft:cut_red_sandstone",
                    "cut_red_sandstone", "red_sandstone")
            .role(StyleRole.STONE_DARK, "minecraft:brown_terracotta",
                    "polished_granite", "granite")
            .role(StyleRole.WOOD_LIGHT, "minecraft:acacia_planks", "acacia")
            .role(StyleRole.WOOD_DARK, "minecraft:dark_oak_planks", "dark_oak")
            .role(StyleRole.WOOD_ACCENT, "minecraft:jungle_planks", "jungle")
            .role(StyleRole.SAND, "minecraft:red_sand", "red_sand")
            .role(StyleRole.GROUND, "minecraft:terracotta", "red_sandstone")
            .role(StyleRole.METAL, "minecraft:exposed_copper",
                    "exposed_cut_copper", "cut_copper")
            .role(StyleRole.LAMP, "minecraft:glowstone")
            .colours("white", "light_gray", "black", "orange", "yellow", "brown", "red")

            .variant("orange", "Orange bluffs")
            .role(StyleRole.STONE_PLAIN, "minecraft:orange_terracotta",
                    "red_sandstone", "cut_red_sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:smooth_red_sandstone",
                    "smooth_red_sandstone", "red_sandstone")
            .role(StyleRole.STONE_REFINED, "minecraft:chiseled_red_sandstone",
                    "cut_red_sandstone", "red_sandstone")
            .role(StyleRole.STONE_DARK, "minecraft:red_nether_bricks",
                    "red_nether_brick", "nether_brick")
            .role(StyleRole.WOOD_LIGHT, "minecraft:jungle_planks", "jungle")
            .role(StyleRole.GROUND, "minecraft:orange_terracotta", "red_sandstone")

            .variant("white", "White cliffs")
            .role(StyleRole.STONE_PLAIN, "minecraft:white_terracotta",
                    "smooth_sandstone", "sandstone")
            .role(StyleRole.STONE_ROUGH, "minecraft:smooth_sandstone",
                    "smooth_sandstone", "sandstone")
            .role(StyleRole.STONE_REFINED, "minecraft:chiseled_sandstone",
                    "cut_sandstone", "sandstone")
            .role(StyleRole.STONE_DARK, "minecraft:brown_terracotta",
                    "polished_granite", "granite")
            .role(StyleRole.WOOD_LIGHT, "minecraft:birch_planks", "birch")
            .role(StyleRole.GROUND, "minecraft:white_terracotta", "sandstone")
            .build();

    private static final List<BuildTheme> ALL = List.of(
            MEDIEVAL, ANCIENT, ASIAN, DESERT, MESA, MODERN, FUTURISTIC);

    private BuildThemes() {}

    public static List<BuildTheme> all() { return ALL; }

    public static BuildTheme byId(String id) {
        for (BuildTheme theme : ALL) {
            if (theme.id().equals(id)) return theme;
        }
        return null;
    }
}
