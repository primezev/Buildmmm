package dev.buildmatic.core.theme;

import java.util.List;
import java.util.Locale;

/**
 * What one {@link StyleRole} looks like in one theme.
 *
 * <p>Two fields rather than one because Minecraft's naming is not symmetrical. The full cube is
 * {@code stone_bricks}, but its stair is {@code stone_brick_stairs}: there is no single string that
 * composes into both. {@code block} is used when the source block is a cube in its own right, and
 * {@code stems} are fed to {@link dev.buildmatic.core.variant.VariantIndex#resolve} for everything
 * that has a shape - stairs, slabs, walls, fences, doors.
 *
 * <p>Several stems can be given, tried in order. That is what lets a theme name a full cube with no
 * shaped family at all: futuristic light-grey concrete has no stairs, so its stems fall back to
 * polished andesite and the staircases of a build stay staircases.
 *
 * @param block the full-cube form, a complete block id
 * @param stems material stems for shaped blocks, best first
 */
public record StyleMaterial(String block, List<String> stems) {

    public StyleMaterial {
        block = normalise(block);
        stems = List.copyOf(stems);
    }

    public static StyleMaterial of(String block, String... stems) {
        return new StyleMaterial(block, List.of(stems));
    }

    /**
     * True when the running game has this material in some usable form.
     *
     * <p>Used to hide combinations built on blocks the version does not have rather than offering
     * one that would silently do nothing - cherry and bamboo on 1.19.2, tuff bricks before 1.21.
     */
    public boolean existsIn(dev.buildmatic.core.variant.VariantIndex variants) {
        if (variants.isKnown(block)) return true;
        for (String stem : stems) {
            if (variants.resolve(stem, dev.buildmatic.core.variant.BlockShape.SLAB) != null
                    || variants.resolve(stem, dev.buildmatic.core.variant.BlockShape.SOLID) != null) {
                return true;
            }
        }
        return false;
    }

    private static String normalise(String id) {
        String lower = id.trim().toLowerCase(Locale.ROOT);
        return lower.indexOf(':') < 0 ? "minecraft:" + lower : lower;
    }
}
