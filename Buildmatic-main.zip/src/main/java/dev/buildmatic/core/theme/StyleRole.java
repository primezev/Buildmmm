package dev.buildmatic.core.theme;

/**
 * The job a block does in a build, independent of what it is made of.
 *
 * <p>A theme cannot be a plain "this block becomes that block" table: the same build uses stone for
 * its walls, stone bricks for its detailing and deepslate for its roof, and a restyle that collapses
 * all three into one material flattens the build instead of re-dressing it. Roles are the middle
 * layer - the source block is classified into one, and the theme says what that role looks like.
 *
 * <p>Roles are deliberately few. Every extra one is another entry every theme has to fill in
 * convincingly, and a build only really distinguishes a handful of tones anyway.
 */
public enum StyleRole {

    /** The bulk masonry: stone, granite, sandstone, the flat surfaces of a wall. */
    STONE_PLAIN("Plain stone"),
    /** Coarse masonry: cobblestone, andesite, tuff - foundations and rubble. */
    STONE_ROUGH("Rough stone"),
    /** Worked masonry: bricks, tiles, polished and chiselled stone - the detailing. */
    STONE_REFINED("Refined stone"),
    /** Dark masonry: deepslate, blackstone, basalt, nether brick - roofs and shadow lines. */
    STONE_DARK("Dark stone"),

    /** The main timber: oak, birch, bamboo. */
    WOOD_LIGHT("Light wood"),
    /** Beams and trim: spruce, dark oak, mangrove. */
    WOOD_DARK("Dark wood"),
    /** The odd colour out: acacia, cherry, warped. */
    WOOD_ACCENT("Accent wood"),

    /** Loose ground that does not fall: dirt, grass, mud, clay. */
    GROUND("Ground"),
    /** Loose ground that does fall: sand, red sand, gravel. Only ever swapped for each other. */
    SAND("Sand"),

    /** Windows, as blocks. Plain glass only; stained glass follows the colour palette instead. */
    GLASS("Glass"),
    /** Windows, as panes. A separate role because a pane can only ever become another pane. */
    GLASS_PANE("Glass pane"),

    /**
     * Copper in its various weatherings.
     *
     * <p>Copper only. Iron, gold, diamond, emerald and netherite blocks are what a beacon pyramid
     * is built from, and a restyle that quietly stops a beacon working is exactly the kind of
     * damage these roles exist to avoid. Waxed copper is left alone too: waxing is a decision to
     * stop it weathering, and unwaxing it would let the build change colour by itself.
     */
    METAL("Copper"),

    /**
     * Full-brightness light blocks: glowstone, sea lanterns, shroomlight, froglights.
     *
     * <p>All of them emit light level 15, so trading one for another is the rare lighting change
     * that cannot alter what spawns where.
     */
    LAMP("Light source");

    private final String displayName;

    StyleRole(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() { return displayName; }
}
