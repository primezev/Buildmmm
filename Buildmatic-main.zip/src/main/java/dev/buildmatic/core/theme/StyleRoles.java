package dev.buildmatic.core.theme;

import dev.buildmatic.core.variant.BlockShape;

import java.util.HashMap;
import java.util.Map;

/**
 * Sorts a block's material into the {@link StyleRole} it plays in a build.
 *
 * <p>The table is deliberately a whitelist: a material that is not listed has no role, and a block
 * with no role is never touched by a theme. That is the safety property the whole feature rests on -
 * a restyle can only ever produce blocks from a curated set of building materials, so an unknown or
 * modded block, a mechanism, a plant or a fluid comes out of a theme exactly as it went in.
 *
 * <p>Materials appear twice where Minecraft names the cube and its stairs differently:
 * {@code stone_bricks} is the material {@code stone} in the {@code BRICKS} shape, while
 * {@code stone_brick_stairs} is the material {@code stone_brick}. Both spellings are listed.
 */
public final class StyleRoles {

    private static final Map<String, StyleRole> BY_MATERIAL = new HashMap<>();

    private StyleRoles() {}

    private static void role(StyleRole role, String... materials) {
        for (String material : materials) BY_MATERIAL.putIfAbsent(material, role);
    }

    static {
        role(StyleRole.STONE_PLAIN,
                "stone", "smooth_stone", "granite", "diorite", "calcite", "dripstone",
                "end_stone", "prismarine", "sandstone", "smooth_sandstone",
                "red_sandstone", "smooth_red_sandstone", "terracotta", "bone");

        role(StyleRole.STONE_ROUGH,
                "cobblestone", "mossy_cobblestone", "andesite", "tuff", "infested_stone",
                "infested_cobblestone");

        role(StyleRole.STONE_REFINED,
                "stone_brick", "mossy_stone_brick", "cracked_stone_brick", "chiseled_stone_brick",
                // A cube's material is what is left once the shape suffix comes off, so
                // mossy_stone_bricks is the material "mossy_stone" - not "mossy_stone_brick",
                // which is what its stairs are made of. Both spellings have to be listed or the
                // brick cubes of a build come through a restyle untouched.
                "mossy_stone", "cracked_stone", "chiseled_stone",
                "bricks", "brick", "mud_brick", "amethyst",
                "polished_granite", "polished_diorite", "polished_andesite",
                "polished_tuff", "chiseled_tuff", "tuff_brick", "chiseled_tuff_brick",
                "cut_sandstone", "chiseled_sandstone", "cut_red_sandstone", "chiseled_red_sandstone",
                "quartz", "smooth_quartz", "quartz_brick", "chiseled_quartz", "quartz_pillar",
                "prismarine_brick", "end_stone_brick", "purpur", "purpur_pillar",
                "resin", "resin_brick", "chiseled_resin_brick");

        role(StyleRole.STONE_DARK,
                "deepslate", "cobbled_deepslate", "polished_deepslate", "chiseled_deepslate",
                "deepslate_brick", "cracked_deepslate_brick", "deepslate_tile",
                "cracked_deepslate_tile", "cracked_deepslate",
                "blackstone", "polished_blackstone", "polished_blackstone_brick",
                "cracked_polished_blackstone_brick", "cracked_polished_blackstone",
                "chiseled_polished_blackstone", "gilded_blackstone",
                "basalt", "polished_basalt", "smooth_basalt",
                "netherrack", "nether", "nether_brick", "red_nether", "red_nether_brick",
                "cracked_nether_brick", "chiseled_nether_brick", "cracked_nether",
                "chiseled_nether", "dark_prismarine");

        // Woods are grouped by how they read on a wall, not by biome.
        role(StyleRole.WOOD_LIGHT, "oak", "birch", "jungle", "bamboo", "bamboo_mosaic", "pale_oak");
        role(StyleRole.WOOD_DARK, "spruce", "dark_oak", "mangrove", "crimson");
        role(StyleRole.WOOD_ACCENT, "acacia", "cherry", "warped");

        role(StyleRole.GROUND,
                "dirt", "coarse_dirt", "rooted_dirt", "podzol", "grass", "mycelium",
                "mud", "packed_mud", "clay", "moss");

        // Kept apart from GROUND because these fall: a theme may only trade them for each other.
        role(StyleRole.SAND, "sand", "red_sand", "gravel");

        role(StyleRole.GLASS, "glass");
        role(StyleRole.GLASS_PANE, "glass_pane");

        // Copper only, and never the waxed forms - see StyleRole.METAL for why.
        role(StyleRole.METAL,
                "copper", "exposed_copper", "weathered_copper", "oxidized_copper",
                "cut_copper", "exposed_cut_copper", "weathered_cut_copper", "oxidized_cut_copper",
                "chiseled_copper", "exposed_chiseled_copper", "weathered_chiseled_copper",
                "oxidized_chiseled_copper");

        role(StyleRole.LAMP,
                "glowstone", "shroomlight",
                "ochre_froglight", "verdant_froglight", "pearlescent_froglight",
                // sea_lantern's id ends in _lantern, so the shape table reads it as a lantern and
                // its material as "sea". It is a full cube like the rest of this row.
                "sea");
    }

    /**
     * The role this material plays, or null when the material is not one a theme should touch.
     *
     * <p>The shape is consulted for one thing only: a brick or tile form is detailing rather than
     * bulk, so {@code stone_bricks} styles as refined masonry while plain {@code stone} does not.
     */
    public static StyleRole of(String material, BlockShape shape) {
        StyleRole role = BY_MATERIAL.get(material);
        if (role == null) return null;

        if (shape == BlockShape.BRICKS || shape == BlockShape.TILES) {
            if (role == StyleRole.STONE_PLAIN || role == StyleRole.STONE_ROUGH
                    || role == StyleRole.GROUND) {
                return StyleRole.STONE_REFINED;
            }
        }
        return role;
    }

    /** True when a theme has any opinion about this material at all. */
    public static boolean isThemable(String material) {
        return BY_MATERIAL.containsKey(material);
    }
}
