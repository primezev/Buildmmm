package dev.buildmatic.core.theme;

import dev.buildmatic.core.variant.BlockShape;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Pulls Minecraft's sixteen dye colours down onto the handful a theme actually uses.
 *
 * <p>Wool, carpet, concrete, terracotta and stained glass are the other half of a build's palette,
 * and they cannot be handled by {@link StyleRole} at all: their material <em>is</em> the colour, so
 * "light blue" is not a tone of anything, it is one of sixteen siblings. Listing a replacement for
 * each of the sixteen in each of seven themes would be a hundred and twelve entries to get wrong.
 *
 * <p>Instead a theme names the few colours it permits and every other colour is mapped to whichever
 * of them it is closest to. A medieval theme allowing brown, red and grey turns magenta into red
 * and cyan into grey without anyone writing those two rules down, and adding a colour to a palette
 * re-sorts the whole mapping automatically.
 *
 * <p>Closeness is judged on hue first, not on RGB distance. RGB distance sounds right and is not:
 * with a palette of five or six colours it pulls everything towards the greys, because a bright
 * magenta really is nearer to light grey than to a dark red by that measure. The result was a
 * medieval build where the yellow banners came back light grey. Matching hue first sends yellow to
 * brown and magenta to red, which is what a builder means by "the closest colour I have" - while
 * greys still match greys, since a colour with no hue has none to compare.
 */
public final class ThemeColours {

    /** The sixteen dyes, in vanilla's own order, with the RGB the game renders them at. */
    private static final Map<String, int[]> DYES = new LinkedHashMap<>();

    /** The same sixteen as hue/saturation/value, which is what the matching actually compares. */
    private static final Map<String, float[]> HSV = new LinkedHashMap<>();

    static {
        dye("white", 0xF9FFFE);
        dye("orange", 0xF9801D);
        dye("magenta", 0xC74EBD);
        dye("light_blue", 0x3AB3DA);
        dye("yellow", 0xFED83D);
        dye("lime", 0x80C71F);
        dye("pink", 0xF38BAA);
        dye("gray", 0x474F52);
        dye("light_gray", 0x9D9D97);
        dye("cyan", 0x169C9C);
        dye("purple", 0x8932B8);
        dye("blue", 0x3C44AA);
        dye("brown", 0x835432);
        dye("green", 0x5E7C16);
        dye("red", 0xB02E26);
        dye("black", 0x1D1D21);
    }

    /** The block families whose material is a colour rather than a stone or a timber. */
    private static final Set<BlockShape> COLOUR_SHAPES = Set.of(
            BlockShape.WOOL, BlockShape.CARPET, BlockShape.CONCRETE, BlockShape.CONCRETE_POWDER,
            BlockShape.TERRACOTTA, BlockShape.GLAZED_TERRACOTTA,
            BlockShape.STAINED_GLASS, BlockShape.STAINED_GLASS_PANE);

    private ThemeColours() {}

    private static void dye(String name, int rgb) {
        int[] channels = {(rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF};
        DYES.put(name, channels);
        HSV.put(name, hsv(channels));
    }

    public static boolean isColourShape(BlockShape shape) {
        return COLOUR_SHAPES.contains(shape);
    }

    public static boolean isDye(String material) {
        return DYES.containsKey(material);
    }

    public static List<String> all() { return List.copyOf(DYES.keySet()); }

    /**
     * The entry of {@code palette} closest to {@code colour}, or null when neither is usable.
     *
     * <p>A colour already in the palette always maps to itself: the distance to itself is zero.
     */
    public static String nearest(String colour, List<String> palette) {
        float[] source = HSV.get(colour);
        if (source == null || palette.isEmpty()) return null;

        String best = null;
        double bestDistance = Double.MAX_VALUE;
        for (String candidate : palette) {
            float[] hsv = HSV.get(candidate);
            if (hsv == null) continue;
            double distance = distance(source, hsv);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }

    /** Below this much saturation a dye reads as a grey, and its hue is meaningless. */
    private static final float GREY = 0.2f;

    private static double distance(float[] a, float[] b) {
        boolean greyA = a[1] < GREY;
        boolean greyB = b[1] < GREY;

        double score = Math.abs(a[2] - b[2]) + 0.5 * Math.abs(a[1] - b[1]);
        if (greyA != greyB) {
            // Colour for grey is a last resort: it is what happens when the palette has no hue
            // anywhere near, and it should lose to any hue that is even roughly right.
            return score + 1.5;
        }
        if (greyA) return score;

        double hue = Math.abs(a[0] - b[0]);
        if (hue > 180) hue = 360 - hue;
        return score + 3.0 * (hue / 180.0);
    }

    private static float[] hsv(int[] rgb) {
        float r = rgb[0] / 255f;
        float g = rgb[1] / 255f;
        float b = rgb[2] / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float span = max - min;

        float hue;
        if (span == 0) hue = 0;
        else if (max == r) hue = 60 * (((g - b) / span) % 6);
        else if (max == g) hue = 60 * ((b - r) / span + 2);
        else hue = 60 * ((r - g) / span + 4);
        if (hue < 0) hue += 360;

        return new float[] {hue, max == 0 ? 0 : span / max, max};
    }
}
