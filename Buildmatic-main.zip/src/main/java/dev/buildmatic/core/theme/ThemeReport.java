package dev.buildmatic.core.theme;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.variant.VariantIndex;

import java.util.HashSet;
import java.util.Set;

/**
 * What a theme would do to a particular schematic, worked out before anything is applied.
 *
 * <p>Reading it off the palette rather than the block data makes it cheap enough to recompute every
 * time the selection moves in the picker: a build has a few hundred distinct states however many
 * blocks it contains.
 *
 * <p>The number worth showing is {@link #guardedTypes}. "Six mechanisms left untouched" is the
 * answer to the only question a builder actually has about a one-click restyle, which is whether it
 * is about to break their redstone.
 *
 * @param restyledTypes  distinct block states the theme replaces
 * @param guardedTypes   distinct block states held back because they are functional
 * @param keptTypes      distinct block states the theme simply has no opinion about
 * @param restyledBlocks how many placed blocks that adds up to
 * @param totalBlocks    every non-empty block in the schematic
 */
public record ThemeReport(int restyledTypes, int guardedTypes, int keptTypes,
                          long restyledBlocks, long totalBlocks) {

    public int totalTypes() { return restyledTypes + guardedTypes + keptTypes; }

    public static ThemeReport of(BuildTheme theme, Schematic schematic, VariantIndex variants) {
        return of(theme.defaultVariant(), schematic, variants);
    }

    public static ThemeReport of(ThemeVariant theme, Schematic schematic, VariantIndex variants) {
        Set<BlockStateRef> restyled = new HashSet<>();
        Set<BlockStateRef> guarded = new HashSet<>();
        Set<BlockStateRef> kept = new HashSet<>();
        long restyledBlocks = 0;
        long totalBlocks = 0;

        for (SchematicRegion region : schematic.regions()) {
            int[] histogram = region.paletteHistogram();
            for (int i = 0; i < histogram.length && i < region.palette().size(); i++) {
                if (histogram[i] == 0) continue;
                BlockStateRef state = region.palette().get(i);
                if (state.isEmpty()) continue;

                totalBlocks += histogram[i];
                if (theme.retargetId(state.blockId(), variants) != null) {
                    restyled.add(state);
                    restyledBlocks += histogram[i];
                } else if (ThemeSafety.isProtected(state.blockId())) {
                    guarded.add(state);
                } else {
                    kept.add(state);
                }
            }
        }

        // A state that is restyled in one region and guarded in another cannot happen - the test is
        // per state, not per position - so the three sets are disjoint by construction.
        return new ThemeReport(restyled.size(), guarded.size(), kept.size(),
                restyledBlocks, totalBlocks);
    }
}
