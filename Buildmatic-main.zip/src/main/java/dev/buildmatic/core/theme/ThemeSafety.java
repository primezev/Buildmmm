package dev.buildmatic.core.theme;

import dev.buildmatic.core.variant.BlockShape;

import java.util.Locale;
import java.util.Set;

/**
 * The blocks a theme must keep its hands off, and the replacements it must never produce.
 *
 * <p>Restyling a build is a cosmetic operation, and the moment it stops being one it has broken
 * something the builder cannot see. A wooden pressure plate that becomes a stone one no longer
 * detects dropped items; a wooden button that becomes a stone one shortens its pulse from 30 ticks
 * to 20; a solid wall that becomes glass stops conducting a redstone signal; a floor that becomes
 * sand falls out of the sky. None of that shows up in a screenshot, so the rules live here instead
 * of being left to whoever writes the next palette.
 *
 * <p>Three separate guards, because they fail differently:
 *
 * <ul>
 *   <li>{@link #isProtected} - the source block is a mechanism, a container or a block entity, so
 *       it is left exactly as it is.</li>
 *   <li>{@link #isSafeReplacement} - the replacement would change something structural rather than
 *       something visual: solidity, gravity, or the block's own function.</li>
 *   <li>{@link StyleRoles} - the material is not a known building material, so no theme has an
 *       opinion about it in the first place. That whitelist does most of the work; this class is
 *       what catches the cases where a functional block is <em>made of</em> a themed material, like
 *       {@code stone_button} or {@code oak_pressure_plate}.</li>
 * </ul>
 */
public final class ThemeSafety {

    /**
     * Shapes no theme touches: mechanisms, block entities, and decoration whose identity is the
     * point of it. Anything not listed here is fair game as long as its material has a role.
     */
    private static final Set<BlockShape> PROTECTED_SHAPES = Set.of(
            // Redstone components whose timing or trigger depends on the material.
            BlockShape.BUTTON, BlockShape.PRESSURE_PLATE, BlockShape.RAIL,
            // Block entities: swapping the block would leave its stored data behind.
            BlockShape.SIGN, BlockShape.WALL_SIGN, BlockShape.HANGING_SIGN,
            BlockShape.WALL_HANGING_SIGN, BlockShape.BED, BlockShape.BANNER,
            BlockShape.WALL_BANNER, BlockShape.SHULKER_BOX, BlockShape.HEAD, BlockShape.SKULL,
            // Light and decoration that a material swap would silently relocate or extinguish.
            // Not LANTERN: that bucket is where sea_lantern lands by accident of its name, and the
            // hanging lanterns it is meant to cover are held back by id below.
            BlockShape.TORCH, BlockShape.WALL_TORCH, BlockShape.CANDLE,
            BlockShape.ORE, BlockShape.AMETHYST_BUD,
            BlockShape.CORAL, BlockShape.CORAL_FAN, BlockShape.CORAL_WALL_FAN,
            BlockShape.CORAL_BLOCK, BlockShape.MUSHROOM_BLOCK,
            BlockShape.SAPLING, BlockShape.VINES, BlockShape.ROOTS, BlockShape.FUNGUS,
            BlockShape.SPROUTS, BlockShape.OTHER);

    /** Mechanisms, containers, workstations and the rest of the "do not touch" catalogue. */
    private static final Set<String> PROTECTED_BLOCKS = Set.of(
            // Redstone logic and transport.
            "observer", "comparator", "repeater", "lever", "tripwire", "tripwire_hook",
            "daylight_detector", "lightning_rod", "target", "note_block", "jukebox", "bell",
            "dispenser", "dropper", "hopper", "crafter", "tnt", "lodestone",
            // Containers and villager workstations: their contents and their jobs both matter.
            "chest", "trapped_chest", "ender_chest", "barrel", "furnace", "blast_furnace",
            "smoker", "brewing_stand", "composter", "lectern", "cartography_table",
            "fletching_table", "grindstone", "smithing_table", "stonecutter", "loom",
            "enchanting_table", "bookshelf", "chiseled_bookshelf", "decorated_pot", "flower_pot",
            "cake", "beacon", "conduit", "respawn_anchor",
            // World mechanics and admin blocks.
            "spawner", "trial_spawner", "vault", "end_portal_frame", "end_gateway",
            "structure_block", "structure_void", "jigsaw", "barrier", "light", "bedrock",
            // Blocks whose physics a build is relying on.
            "obsidian", "crying_obsidian", "slime_block", "honey_block", "scaffolding",
            "ladder", "chain", "lantern", "soul_lantern",
            "iron_door", "iron_trapdoor", "iron_bars", "dragon_egg",
            "soul_sand", "soul_soil", "magma_block", "powder_snow", "sponge", "wet_sponge",
            "farmland", "dirt_path", "big_dripleaf", "small_dripleaf", "sea_pickle",
            "budding_amethyst", "tinted_glass",
            "ice", "packed_ice", "blue_ice", "frosted_ice");

    /**
     * Blocks whose id misleads the shape table about how much space they take up.
     *
     * <p>{@code glass_pane} carries no recognised suffix - the table's entry is {@code _glass_pane},
     * which needs something in front of it - so it is filed as a plain cube and would be barred
     * from becoming a stained pane. {@code sea_lantern} has the opposite problem: it reads as a
     * lantern because of its name and is in fact a solid block.
     */
    private static final Set<String> NOT_REALLY_CUBES = Set.of(
            "glass_pane", "iron_bars", "chain", "ladder", "lantern", "soul_lantern");

    private static final Set<String> REALLY_CUBES = Set.of("sea_lantern");

    /** Blocks that fall when unsupported. Only ever exchanged for one another. */
    private static final Set<String> FALLING_BLOCKS = Set.of(
            "sand", "red_sand", "gravel", "suspicious_sand", "suspicious_gravel",
            "dragon_egg", "pointed_dripstone");

    private ThemeSafety() {}

    /** True when a theme must leave this block exactly as it found it. */
    public static boolean isProtected(String blockId) {
        String path = path(blockId);
        return isProtected(blockId, BlockShape.of(path).shape());
    }

    public static boolean isProtected(String blockId, BlockShape shape) {
        if (PROTECTED_SHAPES.contains(shape)) return true;

        String path = path(blockId);
        if (PROTECTED_BLOCKS.contains(path)) return true;

        // Families rather than individual ids, so blocks added by a later version are covered too:
        // every redstone block, every piston, every rail, every sculk sensor.
        if (path.contains("redstone")) return true;
        if (path.contains("piston")) return true;
        if (path.contains("command_block")) return true;
        if (path.contains("sculk")) return true;
        if (path.contains("spawner")) return true;
        if (path.contains("portal")) return true;
        if (path.contains("cauldron")) return true;
        if (path.contains("anvil")) return true;
        if (path.contains("campfire")) return true;
        if (path.contains("beehive") || path.contains("bee_nest")) return true;
        if (path.contains("copper_bulb")) return true;
        if (path.equals("rail") || path.endsWith("_rail")) return true;
        return false;
    }

    /**
     * True when {@code target} can stand in for {@code source} without changing how the build
     * behaves.
     *
     * <p>The palettes are hand-written, so in practice this never fires. It exists because the
     * palettes are also the part most likely to be edited by someone adding a theme, and the cost
     * of a wrong entry is a redstone contraption that fails in a way nobody traces back to a swap.
     */
    public static boolean isSafeReplacement(String sourceId, BlockShape sourceShape,
                                            String targetId) {
        BlockShape.Match target = BlockShape.of(path(targetId));

        // A replacement that is itself a mechanism is never cosmetic.
        if (isProtected(targetId, target.shape())) return false;

        // Solid stays solid: a wall that stops filling its cube stops holding up, sealing and
        // conducting, all of which a build may be relying on.
        if (fillsItsCube(sourceId, sourceShape) && !fillsItsCube(targetId, target.shape())) {
            return false;
        }

        // Gravity is one way only. Turning a floor into sand drops it; the reverse is harmless.
        return !isFalling(targetId) || isFalling(sourceId);
    }

    /** True when the block really occupies its whole cube, name notwithstanding. */
    public static boolean fillsItsCube(String blockId, BlockShape shape) {
        String path = path(blockId);
        if (NOT_REALLY_CUBES.contains(path)) return false;
        if (REALLY_CUBES.contains(path)) return true;
        return shape.isFullCube();
    }

    public static boolean isFalling(String blockId) {
        String path = path(blockId);
        return FALLING_BLOCKS.contains(path) || path.endsWith("_concrete_powder");
    }

    private static String path(String blockId) {
        String lower = blockId.trim().toLowerCase(Locale.ROOT);
        int colon = lower.indexOf(':');
        return colon < 0 ? lower : lower.substring(colon + 1);
    }
}
