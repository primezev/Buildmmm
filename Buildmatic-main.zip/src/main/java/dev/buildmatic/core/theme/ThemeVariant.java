package dev.buildmatic.core.theme;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.block.PropertyTranslator;
import dev.buildmatic.core.variant.BlockShape;
import dev.buildmatic.core.variant.VariantIndex;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * One combination of materials within a {@link BuildTheme}.
 *
 * <p>"Medieval" is not a single palette. A cobblestone keep, an oak-framed village house and a
 * mossy ruin are all medieval and share none of their blocks, so a theme offers several
 * combinations and the picker walks between them. The theme is the intent; the variant is the
 * answer.
 *
 * <h2>Why each role holds a list</h2>
 * A material may not exist in the version being played: cherry and bamboo arrived in 1.20, tuff
 * bricks in 1.21, and Buildmatic targets 1.19.2 upwards from one source tree. Each role therefore
 * carries its alternatives in preference order, and the first that the running game actually has
 * wins. That is also what makes a theme safe on a modded or future version: the index is built from
 * whatever blocks the game reports, so an absent material is skipped rather than guessed at.
 *
 * @param id          stable identifier, persisted in save files
 * @param displayName what the picker shows, e.g. "Mossy ruin"
 * @param palette     materials per role, best first
 * @param colours     the dye colours this combination keeps
 */
public record ThemeVariant(String id, String displayName,
                           Map<StyleRole, List<StyleMaterial>> palette, List<String> colours) {

    /**
     * Shapes that are a cube in their own right, so the theme's full-block form is the right answer
     * before any stem is tried: plain stone, brick cubes, planks.
     */
    private static final Set<BlockShape> WHOLE_BLOCK_SHAPES = Set.of(
            BlockShape.SOLID, BlockShape.BRICKS, BlockShape.TILES, BlockShape.PLANKS,
            BlockShape.BLOCK, BlockShape.CONCRETE, BlockShape.TERRACOTTA);

    /**
     * Shapes that may fall back to the full-block form when the theme has no counterpart: a log
     * under a stone theme becomes a stone cube, which keeps the silhouette. Everything else -
     * fences, doors, leaves - stays as it is instead.
     */
    private static final Set<BlockShape> CUBE_FALLBACK_SHAPES = Set.of(
            BlockShape.SOLID, BlockShape.BRICKS, BlockShape.TILES, BlockShape.PLANKS,
            BlockShape.BLOCK, BlockShape.CONCRETE, BlockShape.TERRACOTTA,
            BlockShape.LOG, BlockShape.WOOD, BlockShape.STRIPPED_LOG, BlockShape.STRIPPED_WOOD,
            BlockShape.PILLAR,
            // For sea_lantern alone, which the shape table reads as a lantern; it is a cube, and
            // the only lantern-shaped material any theme classifies.
            BlockShape.LANTERN);

    public ThemeVariant {
        palette = Map.copyOf(palette);
        colours = List.copyOf(colours);
    }

    /** The first material listed for a role, for swatches and labels; null when unset. */
    public StyleMaterial materialFor(StyleRole role) {
        List<StyleMaterial> alternatives = palette.get(role);
        return alternatives == null || alternatives.isEmpty() ? null : alternatives.get(0);
    }

    /**
     * The roles a combination is judged on: the masonry and the timber a build is made of.
     *
     * <p>Glass, copper, lighting, sand and ground are trimmings. A version or a modpack missing one
     * of them should cost the theme that trimming, not the whole combination - hiding a perfectly
     * good cobblestone palette because the game has no copper would be absurd.
     */
    private static final Set<StyleRole> STRUCTURAL = Set.of(
            StyleRole.STONE_PLAIN, StyleRole.STONE_ROUGH, StyleRole.STONE_REFINED,
            StyleRole.STONE_DARK, StyleRole.WOOD_LIGHT, StyleRole.WOOD_DARK,
            StyleRole.WOOD_ACCENT);

    /**
     * True when the running game has enough blocks for this combination to mean anything.
     *
     * <p>A combination built on cherry wood is simply not offered on 1.19.2. Showing it and having
     * it do nothing would be worse than not showing it: the player would be left wondering which of
     * the two of you was broken.
     */
    public boolean isAvailableIn(VariantIndex variants) {
        for (Map.Entry<StyleRole, List<StyleMaterial>> entry : palette.entrySet()) {
            if (!STRUCTURAL.contains(entry.getKey())) continue;

            boolean any = false;
            for (StyleMaterial material : entry.getValue()) {
                if (material.existsIn(variants)) {
                    any = true;
                    break;
                }
            }
            if (!any) return false;
        }
        return true;
    }

    /**
     * The block id this combination wants in place of {@code blockId}, or null to leave it alone.
     *
     * <p>Null is returned far more often than not, and that is the intended behaviour: a theme only
     * speaks for the materials it recognises.
     */
    public String retargetId(String blockId, VariantIndex variants) {
        VariantIndex.BlockKind kind = variants.kindOf(blockId);
        if (kind == null) return null;                       // not in this game's registry
        if (ThemeSafety.isProtected(blockId, kind.shape())) return null;

        // Wool and its relatives are named by colour, not by material, so they take their own path.
        if (ThemeColours.isColourShape(kind.shape())) return recolour(kind, variants);

        StyleRole role = StyleRoles.of(kind.material(), kind.shape());
        if (role == null) return null;

        List<StyleMaterial> alternatives = palette.get(role);
        if (alternatives == null) return null;

        String target = null;
        for (StyleMaterial style : alternatives) {
            target = resolve(style, kind, variants);
            if (target != null) break;
        }

        if (target == null || target.equals(kind.blockId())) return null;
        if (!ThemeSafety.isSafeReplacement(blockId, kind.shape(), target)) return null;
        return target;
    }

    /** One material's answer for one block, or null when this version has no form of it. */
    private static String resolve(StyleMaterial style, VariantIndex.BlockKind kind,
                                  VariantIndex variants) {
        if (WHOLE_BLOCK_SHAPES.contains(kind.shape()) && variants.isKnown(style.block())) {
            return style.block();
        }
        for (String stem : style.stems()) {
            String target = variants.resolve(stem, kind.shape());
            if (target != null) return target;
        }
        if (CUBE_FALLBACK_SHAPES.contains(kind.shape()) && variants.isKnown(style.block())) {
            return style.block();
        }
        return null;
    }

    /**
     * Pulls one coloured block onto the theme's own colours, keeping its family.
     *
     * <p>Wool stays wool and a pane stays a pane; only the dye moves. A theme with no colours of
     * its own leaves the build's colour scheme entirely alone, which is the right default for a
     * restyle that is only meant to touch the masonry.
     */
    private String recolour(VariantIndex.BlockKind kind, VariantIndex variants) {
        if (colours.isEmpty() || !ThemeColours.isDye(kind.material())) return null;

        String colour = ThemeColours.nearest(kind.material(), colours);
        if (colour == null || colour.equals(kind.material())) return null;

        String target = variants.resolve(colour, kind.shape());
        if (target == null || target.equals(kind.blockId())) return null;
        if (!ThemeSafety.isSafeReplacement(kind.blockId(), kind.shape(), target)) return null;
        return target;
    }

    /** The restyled state, properties carried across, or null when nothing should change. */
    public BlockStateRef retarget(BlockStateRef state, VariantIndex variants,
                                  BlockStateSchema schema) {
        if (state.isEmpty()) return null;
        String target = retargetId(state.blockId(), variants);
        if (target == null) return null;

        BlockStateRef result = PropertyTranslator.translate(state, target, schema);
        return result.equals(state) ? null : result;
    }
}
