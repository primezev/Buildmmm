package dev.buildmatic.core.tool;

import dev.buildmatic.core.area.AreaSelection;
import dev.buildmatic.core.area.SelectionBox;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The state machine behind the schematic tool.
 *
 * <p>Holds the current mode, the area selections, and interprets clicks and scrolls. Free of
 * Minecraft types so the whole interaction can be driven from a test rather than only by clicking
 * in a running game, which is the only practical way to keep behaviour this fiddly correct.
 *
 * <p>The client layer is responsible for deciding <em>what</em> was clicked (a world block, a ghost
 * block, a placement) and calling the matching method here.
 */
public final class SchematicTool {

    /** What a click did, so the client can show feedback without duplicating the logic. */
    public record Feedback(boolean handled, String message) {
        public static final Feedback IGNORED = new Feedback(false, "");

        public static Feedback of(String message) { return new Feedback(true, message); }
    }

    private ToolMode mode = ToolMode.AREA_SELECTION;
    private ToolMode.SelectionSubMode selectionSubMode = ToolMode.SelectionSubMode.CORNERS;

    private final List<AreaSelection> selections = new ArrayList<>();
    private int activeSelection = -1;

    /** Blocks picked up by middle click, used by Fill and Replace. */
    private String primaryBlock;
    private String secondaryBlock;

    // --- mode ----------------------------------------------------------------------------------

    public ToolMode mode() { return mode; }

    public void setMode(ToolMode mode) { this.mode = mode; }

    public void cycleMode(boolean forward, boolean creative) {
        mode = forward ? mode.next(creative) : mode.previous(creative);
    }

    public ToolMode.SelectionSubMode selectionSubMode() { return selectionSubMode; }

    public void toggleSelectionSubMode() {
        selectionSubMode = selectionSubMode.toggled();
    }

    public String primaryBlock() { return primaryBlock; }

    public void setPrimaryBlock(String blockId) { this.primaryBlock = blockId; }

    public String secondaryBlock() { return secondaryBlock; }

    public void setSecondaryBlock(String blockId) { this.secondaryBlock = blockId; }

    // --- selections ----------------------------------------------------------------------------

    public List<AreaSelection> selections() { return Collections.unmodifiableList(selections); }

    public AreaSelection activeSelection() {
        if (selections.isEmpty()) {
            return createSelection("Selection 1");
        }
        if (activeSelection < 0 || activeSelection >= selections.size()) activeSelection = 0;
        return selections.get(activeSelection);
    }

    /** The active selection, without creating one; null when there is none. */
    public AreaSelection currentSelectionOrNull() {
        return activeSelection >= 0 && activeSelection < selections.size()
                ? selections.get(activeSelection) : null;
    }

    public AreaSelection createSelection(String name) {
        AreaSelection selection = new AreaSelection(uniqueSelectionName(name));
        selections.add(selection);
        activeSelection = selections.size() - 1;
        return selection;
    }

    public boolean removeSelection(AreaSelection selection) {
        int index = selections.indexOf(selection);
        if (index < 0) return false;
        selections.remove(index);
        if (activeSelection >= selections.size()) activeSelection = selections.size() - 1;
        return true;
    }

    public void setActiveSelection(AreaSelection selection) {
        int index = selections.indexOf(selection);
        if (index >= 0) activeSelection = index;
    }

    private String uniqueSelectionName(String candidate) {
        String base = candidate == null || candidate.isBlank() ? "Selection" : candidate.trim();
        String name = base;
        int suffix = 2;
        while (hasSelectionNamed(name)) name = base + " " + suffix++;
        return name;
    }

    private boolean hasSelectionNamed(String name) {
        for (AreaSelection selection : selections) {
            if (selection.name().equals(name)) return true;
        }
        return false;
    }

    // --- clicks --------------------------------------------------------------------------------

    /**
     * Left click on a world block.
     *
     * <p>In Corners mode this sets corner 1; in Expand mode it grows the box to reach the clicked
     * position, which is how an irregular build gets wrapped without hunting for its extremes.
     */
    public Feedback onLeftClick(Vec3i pos) {
        if (!mode.usesAreaSelection()) return Feedback.IGNORED;

        AreaSelection selection = activeSelection();
        SelectionBox box = selection.activeBox();

        if (selectionSubMode == ToolMode.SelectionSubMode.EXPAND) {
            box.expandToInclude(pos);
            return Feedback.of("Expanded " + box.name() + " to " + describe(box));
        }
        box.setCorner1(pos);
        return Feedback.of("Corner 1 at " + pos + "   " + describe(box));
    }

    /**
     * Right click on a world block.
     *
     * <p>Corners mode sets corner 2; Expand mode collapses the box onto this block to start a fresh
     * expansion from a known point.
     */
    public Feedback onRightClick(Vec3i pos) {
        if (!mode.usesAreaSelection()) return Feedback.IGNORED;

        AreaSelection selection = activeSelection();
        SelectionBox box = selection.activeBox();

        if (selectionSubMode == ToolMode.SelectionSubMode.EXPAND) {
            box.collapseTo(pos);
            return Feedback.of("Reset " + box.name() + " to " + pos);
        }
        box.setCorner2(pos);
        return Feedback.of("Corner 2 at " + pos + "   " + describe(box));
    }

    /** Middle click cycles what the tool holds: box, corner 1, corner 2, then the next box. */
    public Feedback onMiddleClick() {
        if (!mode.usesAreaSelection()) return Feedback.IGNORED;

        AreaSelection selection = currentSelectionOrNull();
        if (selection == null || selection.isEmpty()) return Feedback.of("Nothing selected yet");

        selection.cycleGrabbed();
        SelectionBox box = selection.selectedBox();
        String held = switch (selection.selectedCorner()) {
            case NONE -> "whole box";
            case CORNER_1 -> "corner 1";
            case CORNER_2 -> "corner 2";
        };
        return Feedback.of("Holding " + held + " of " + (box == null ? "?" : box.name()));
    }

    /**
     * Scroll with the nudge modifier held: moves whatever the tool holds one block along the
     * player's facing.
     */
    public Feedback onNudge(Direction facing, int amount) {
        AreaSelection selection = currentSelectionOrNull();
        if (selection == null || selection.isEmpty()) return Feedback.IGNORED;

        selection.nudge(facing, amount);
        SelectionBox box = selection.selectedBox();
        return Feedback.of(selection.isOriginGrabbed()
                ? "Origin at " + selection.origin()
                : describe(box));
    }

    /** Grabs the origin so the next nudge moves it instead of a box. */
    public Feedback grabOrigin() {
        AreaSelection selection = currentSelectionOrNull();
        if (selection == null) return Feedback.IGNORED;
        selection.grabOrigin();
        return Feedback.of("Holding the origin at " + selection.origin());
    }

    /** Adds a sub-region to the active selection. */
    public Feedback addSubRegion() {
        AreaSelection selection = activeSelection();
        if (selection.mode() == AreaSelection.Mode.SIMPLE) {
            return Feedback.of("Simple selections hold one box; switch to multi-region first");
        }
        SelectionBox box = selection.addBox();
        return Feedback.of("Added " + box.name());
    }

    private static String describe(SelectionBox box) {
        if (box == null) return "";
        if (!box.isComplete()) return box.name() + ": waiting for the other corner";
        Vec3i size = box.size();
        return box.name() + ": " + size.x() + "x" + size.y() + "x" + size.z()
                + " (" + box.volume() + " blocks)";
    }
}
