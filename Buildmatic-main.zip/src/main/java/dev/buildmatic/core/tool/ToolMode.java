package dev.buildmatic.core.tool;

/**
 * What the schematic tool does when you click.
 *
 * <p>The order is the cycle order for the {@code [} and {@code ]} keys and for the mode ring. The
 * three modes a builder reaches for
 * constantly - selecting an area, moving a placement, swapping a block's variant - come first, so
 * the common loop never scrolls past the destructive creative-only operations.
 *
 * <p>Litematica buries variant work inside its Schematic Edit mode behind six separate unbound
 * hotkeys. Here it is a mode of its own, third in the cycle.
 */
public enum ToolMode {

    // Hints are kept to a line or two: they are shown inside the tool ring, where anything longer
    // wraps into the labels around it and stops being readable.
    AREA_SELECTION("Area selection", "Left click: corner 1. Right: corner 2.", false),

    PLACEMENT("Placement", "Click to move the build here. Enter places it.", false),

    ROTATE("Rotate", "Right click turns the build, left click turns it back.", false),

    VARIANT_SWAP("Variant swap", "Right click a ghost block for its variants.", false),

    SCHEMATIC_EDIT("Schematic edit", "Left click deletes, right click places.", false),

    FILL("Fill", "Fills the selection with the held block.", true),

    REPLACE("Replace", "Swaps one block for another in the selection.", true),

    PASTE("Paste", "Writes the build into the world.", true),

    MOVE("Move", "Enter picks the selection up so you can carry it.", true),

    DELETE("Delete", "Clears the selection.", true);

    private final String displayName;
    private final String hint;
    private final boolean creativeOnly;

    ToolMode(String displayName, String hint, boolean creativeOnly) {
        this.displayName = displayName;
        this.hint = hint;
        this.creativeOnly = creativeOnly;
    }

    public String displayName() { return displayName; }

    /** One line shown in the tool HUD, so the mode does not have to be memorised. */
    public String hint() { return hint; }

    /** True when the mode writes to the world and therefore needs creative or operator rights. */
    public boolean isCreativeOnly() { return creativeOnly; }

    /** True when the mode edits the schematic in memory rather than the world. */
    public boolean editsSchematic() {
        return this == SCHEMATIC_EDIT || this == VARIANT_SWAP;
    }

    /** True when the mode draws and manipulates the area selection boxes. */
    public boolean usesAreaSelection() {
        return this == AREA_SELECTION || this == FILL || this == REPLACE
                || this == MOVE || this == DELETE;
    }

    /** True when the mode acts on the loaded schematic's placement rather than on a selection. */
    public boolean usesPlacement() {
        return this == PLACEMENT || this == ROTATE || this == PASTE;
    }

    public ToolMode next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public ToolMode previous() {
        return values()[Math.floorMod(ordinal() - 1, values().length)];
    }

    /** The next mode the player is allowed to use, skipping creative-only ones in survival. */
    public ToolMode next(boolean creative) {
        ToolMode mode = this;
        for (int i = 0; i < values().length; i++) {
            mode = mode.next();
            if (creative || !mode.isCreativeOnly()) return mode;
        }
        return this;
    }

    public ToolMode previous(boolean creative) {
        ToolMode mode = this;
        for (int i = 0; i < values().length; i++) {
            mode = mode.previous();
            if (creative || !mode.isCreativeOnly()) return mode;
        }
        return this;
    }

    /** Sub-mode of {@link #AREA_SELECTION}. */
    public enum SelectionSubMode {
        /** Left click sets one corner, right click the other. */
        CORNERS("Corners"),
        /** Right click collapses onto a block, left clicks grow the box to swallow more. */
        EXPAND("Expand");

        private final String displayName;

        SelectionSubMode(String displayName) {
            this.displayName = displayName;
        }

        public String displayName() { return displayName; }

        public SelectionSubMode toggled() {
            return this == CORNERS ? EXPAND : CORNERS;
        }
    }
}
