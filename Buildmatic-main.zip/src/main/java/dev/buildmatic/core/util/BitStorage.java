package dev.buildmatic.core.util;

/**
 * A packed array of fixed-width unsigned integers backed by {@code long[]}.
 *
 * <p>Two layouts exist in the wild and Buildmatic reads and writes both:
 * <ul>
 *   <li>{@link Layout#PACKED} - entries run continuously and may straddle a long boundary. Used by
 *       Litematica's block arrays and by pre-1.16 vanilla chunk storage.</li>
 *   <li>{@link Layout#ALIGNED} - each long holds {@code 64 / bits} entries with the leftover high
 *       bits wasted, so no entry ever straddles. Used by 1.16+ vanilla chunk sections.</li>
 * </ul>
 */
public final class BitStorage {

    public enum Layout { PACKED, ALIGNED }

    private final long[] data;
    private final int bits;
    private final long mask;
    private final int size;
    private final Layout layout;
    private final int entriesPerLong;

    public BitStorage(int bits, int size, Layout layout) {
        this(bits, size, layout, new long[longCount(bits, size, layout)]);
    }

    public BitStorage(int bits, int size, Layout layout, long[] data) {
        if (bits < 1 || bits > 32) {
            throw new IllegalArgumentException("bit width out of range: " + bits);
        }
        int required = longCount(bits, size, layout);
        if (data.length < required) {
            throw new IllegalArgumentException(
                    "backing array holds " + data.length + " longs, need " + required
                            + " for " + size + " entries of " + bits + " bits (" + layout + ")");
        }
        this.data = data;
        this.bits = bits;
        this.mask = bits == 32 ? 0xFFFFFFFFL : (1L << bits) - 1L;
        this.size = size;
        this.layout = layout;
        this.entriesPerLong = 64 / bits;
    }

    public static int longCount(int bits, int size, Layout layout) {
        if (size <= 0) return 0;
        return layout == Layout.PACKED
                ? (int) (((long) size * bits + 63L) / 64L)
                : (size + (64 / bits) - 1) / (64 / bits);
    }

    /** The smallest width that can represent indices {@code 0..maxValue}, floored at 1 bit. */
    public static int bitsFor(int maxValue) {
        if (maxValue <= 1) return 1;
        return 32 - Integer.numberOfLeadingZeros(maxValue);
    }

    public int bits() { return bits; }

    public int size() { return size; }

    public Layout layout() { return layout; }

    public long[] data() { return data; }

    public int get(int index) {
        checkIndex(index);
        if (layout == Layout.ALIGNED) {
            int cell = index / entriesPerLong;
            int offset = (index - cell * entriesPerLong) * bits;
            return (int) ((data[cell] >>> offset) & mask);
        }
        long bitIndex = (long) index * bits;
        int startCell = (int) (bitIndex >> 6);
        int endCell = (int) ((bitIndex + bits - 1) >> 6);
        int offset = (int) (bitIndex & 63L);
        if (startCell == endCell) {
            return (int) ((data[startCell] >>> offset) & mask);
        }
        int spill = 64 - offset;
        return (int) (((data[startCell] >>> offset) | (data[endCell] << spill)) & mask);
    }

    public void set(int index, int value) {
        checkIndex(index);
        long v = value & mask;
        if (layout == Layout.ALIGNED) {
            int cell = index / entriesPerLong;
            int offset = (index - cell * entriesPerLong) * bits;
            data[cell] = (data[cell] & ~(mask << offset)) | (v << offset);
            return;
        }
        long bitIndex = (long) index * bits;
        int startCell = (int) (bitIndex >> 6);
        int endCell = (int) ((bitIndex + bits - 1) >> 6);
        int offset = (int) (bitIndex & 63L);
        data[startCell] = (data[startCell] & ~(mask << offset)) | (v << offset);
        if (startCell != endCell) {
            int spill = 64 - offset;
            int remaining = bits - spill;
            data[endCell] = ((data[endCell] >>> remaining) << remaining) | (v >>> spill);
        }
    }

    /** Re-encodes into a wider or narrower storage, preserving every entry. */
    public BitStorage resize(int newBits) {
        if (newBits == bits) return this;
        BitStorage out = new BitStorage(newBits, size, layout);
        for (int i = 0; i < size; i++) {
            out.set(i, get(i));
        }
        return out;
    }

    /** Re-encodes into the other layout, preserving every entry. */
    public BitStorage convert(Layout target) {
        if (target == layout) return this;
        BitStorage out = new BitStorage(bits, size, target);
        for (int i = 0; i < size; i++) {
            out.set(i, get(i));
        }
        return out;
    }

    public BitStorage copy() {
        return new BitStorage(bits, size, layout, data.clone());
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("index " + index + " of " + size);
        }
    }
}
