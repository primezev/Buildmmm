package dev.buildmatic.core.util;

import java.util.Iterator;

/** An axis-aligned, inclusive block region. Always stored normalised, with {@code min <= max}. */
public record BlockBox(Vec3i min, Vec3i max) implements Iterable<Vec3i> {

    public BlockBox {
        Vec3i lo = min.min(max);
        Vec3i hi = min.max(max);
        min = lo;
        max = hi;
    }

    public static BlockBox of(Vec3i a, Vec3i b) {
        return new BlockBox(a, b);
    }

    /** Builds a box from an origin and a signed size, the way Litematica stores sub-regions. */
    public static BlockBox fromOriginAndSize(Vec3i origin, Vec3i size) {
        Vec3i far = new Vec3i(
                origin.x() + size.x() - Integer.signum(size.x() == 0 ? 1 : size.x()),
                origin.y() + size.y() - Integer.signum(size.y() == 0 ? 1 : size.y()),
                origin.z() + size.z() - Integer.signum(size.z() == 0 ? 1 : size.z()));
        return new BlockBox(origin, far);
    }

    public int sizeX() { return max.x() - min.x() + 1; }

    public int sizeY() { return max.y() - min.y() + 1; }

    public int sizeZ() { return max.z() - min.z() + 1; }

    public Vec3i size() { return new Vec3i(sizeX(), sizeY(), sizeZ()); }

    public long volume() { return (long) sizeX() * sizeY() * sizeZ(); }

    public boolean contains(int x, int y, int z) {
        return x >= min.x() && x <= max.x()
                && y >= min.y() && y <= max.y()
                && z >= min.z() && z <= max.z();
    }

    public boolean contains(Vec3i pos) {
        return contains(pos.x(), pos.y(), pos.z());
    }

    public boolean intersects(BlockBox o) {
        return min.x() <= o.max.x() && max.x() >= o.min.x()
                && min.y() <= o.max.y() && max.y() >= o.min.y()
                && min.z() <= o.max.z() && max.z() >= o.min.z();
    }

    public BlockBox union(BlockBox o) {
        return new BlockBox(min.min(o.min), max.max(o.max));
    }

    public BlockBox offset(Vec3i delta) {
        return new BlockBox(min.add(delta), max.add(delta));
    }

    public BlockBox expand(int amount) {
        return new BlockBox(min.add(-amount, -amount, -amount), max.add(amount, amount, amount));
    }

    /** Restricts the box to a Y slice, or returns null when the slice misses it entirely. */
    public BlockBox clampY(int minY, int maxY) {
        int lo = Math.max(min.y(), Math.min(minY, maxY));
        int hi = Math.min(max.y(), Math.max(minY, maxY));
        if (lo > hi) return null;
        return new BlockBox(new Vec3i(min.x(), lo, min.z()), new Vec3i(max.x(), hi, max.z()));
    }

    public Vec3i center() {
        return new Vec3i(
                min.x() + sizeX() / 2,
                min.y() + sizeY() / 2,
                min.z() + sizeZ() / 2);
    }

    /** Iterates in Y, then Z, then X order, matching the layout of every schematic format. */
    @Override
    public Iterator<Vec3i> iterator() {
        return new Iterator<>() {
            private int x = min.x();
            private int y = min.y();
            private int z = min.z();
            private boolean done = volume() == 0;

            @Override
            public boolean hasNext() { return !done; }

            @Override
            public Vec3i next() {
                Vec3i result = new Vec3i(x, y, z);
                if (++x > max.x()) {
                    x = min.x();
                    if (++z > max.z()) {
                        z = min.z();
                        if (++y > max.y()) done = true;
                    }
                }
                return result;
            }
        };
    }

    @Override
    public String toString() {
        return "[" + min + "] -> [" + max + "] (" + sizeX() + "x" + sizeY() + "x" + sizeZ() + ")";
    }
}
