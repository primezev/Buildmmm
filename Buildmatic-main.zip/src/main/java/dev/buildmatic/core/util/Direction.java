package dev.buildmatic.core.util;

import java.util.Locale;

/**
 * The six block faces.
 *
 * <p>{@link #index()} follows vanilla's ordinal order (down, up, north, south, west, east) and
 * {@link #horizontalIndex()} follows vanilla's compass order (south, west, north, east), so indices
 * read straight out of schematic files and block-state properties line up without translation.
 */
public enum Direction {
    DOWN(Axis.Y, 0, -1, 0, -1, 0),
    UP(Axis.Y, 1, -1, 0, 1, 0),
    NORTH(Axis.Z, 2, 2, 0, 0, -1),
    SOUTH(Axis.Z, 3, 0, 0, 0, 1),
    WEST(Axis.X, 4, 1, -1, 0, 0),
    EAST(Axis.X, 5, 3, 1, 0, 0);

    public enum Axis { X, Y, Z }

    private final Axis axis;
    private final int index;
    private final int horizontalIndex;
    private final int stepX;
    private final int stepY;
    private final int stepZ;

    Direction(Axis axis, int index, int horizontalIndex, int stepX, int stepY, int stepZ) {
        this.axis = axis;
        this.index = index;
        this.horizontalIndex = horizontalIndex;
        this.stepX = stepX;
        this.stepY = stepY;
        this.stepZ = stepZ;
    }

    private static final Direction[] BY_INDEX = new Direction[6];
    private static final Direction[] BY_HORIZONTAL = new Direction[4];

    static {
        for (Direction d : values()) {
            BY_INDEX[d.index] = d;
            if (d.horizontalIndex >= 0) BY_HORIZONTAL[d.horizontalIndex] = d;
        }
    }

    public Axis axis() { return axis; }

    public int index() { return index; }

    /** Compass position (south=0, west=1, north=2, east=3), or -1 for the vertical faces. */
    public int horizontalIndex() { return horizontalIndex; }

    public boolean isHorizontal() { return axis != Axis.Y; }

    public int stepX() { return stepX; }

    public int stepY() { return stepY; }

    public int stepZ() { return stepZ; }

    public Direction opposite() {
        return switch (this) {
            case DOWN -> UP;
            case UP -> DOWN;
            case NORTH -> SOUTH;
            case SOUTH -> NORTH;
            case WEST -> EAST;
            case EAST -> WEST;
        };
    }

    /** The next face clockwise when seen from above; vertical faces are returned unchanged. */
    public Direction clockwise() {
        return isHorizontal() ? BY_HORIZONTAL[(horizontalIndex + 1) & 3] : this;
    }

    public Direction counterClockwise() {
        return isHorizontal() ? BY_HORIZONTAL[(horizontalIndex + 3) & 3] : this;
    }

    /** Rotates around the Y axis; vertical faces are unaffected. */
    public Direction rotate(Rotation rotation) {
        if (!isHorizontal() || rotation == Rotation.NONE) return this;
        return BY_HORIZONTAL[(horizontalIndex + rotation.quarterTurns()) & 3];
    }

    public Direction mirror(Mirror mirror) {
        return switch (mirror) {
            case NONE -> this;
            case FRONT_BACK -> axis == Axis.X ? opposite() : this;
            case LEFT_RIGHT -> axis == Axis.Z ? opposite() : this;
        };
    }

    public static Direction byIndex(int index) {
        return BY_INDEX[Math.floorMod(index, 6)];
    }

    public static Direction byHorizontalIndex(int index) {
        return BY_HORIZONTAL[Math.floorMod(index, 4)];
    }

    /** Parses the lowercase name used in block-state properties; returns null when unknown. */
    public static Direction byName(String name) {
        for (Direction d : values()) {
            if (d.name().equalsIgnoreCase(name)) return d;
        }
        return null;
    }

    public String lowerName() {
        return name().toLowerCase(Locale.ROOT);
    }
}
