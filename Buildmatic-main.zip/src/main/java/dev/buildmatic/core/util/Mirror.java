package dev.buildmatic.core.util;

/** Reflection across a vertical plane, matching vanilla's naming. */
public enum Mirror {
    /** No reflection. */
    NONE,
    /** Mirrors across the X=0 plane, flipping west and east. */
    FRONT_BACK,
    /** Mirrors across the Z=0 plane, flipping north and south. */
    LEFT_RIGHT;

    public Vec3i apply(Vec3i pos) {
        return switch (this) {
            case NONE -> pos;
            case FRONT_BACK -> new Vec3i(-pos.x(), pos.y(), pos.z());
            case LEFT_RIGHT -> new Vec3i(pos.x(), pos.y(), -pos.z());
        };
    }

    /** Mirroring a rotated shape reverses the sense of the rotation. */
    public Rotation compose(Rotation rotation) {
        return this == NONE ? rotation : rotation.inverse();
    }
}
