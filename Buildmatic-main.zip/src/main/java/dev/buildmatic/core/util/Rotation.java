package dev.buildmatic.core.util;

/** Rotation about the Y axis, in quarter turns clockwise when seen from above. */
public enum Rotation {
    NONE(0),
    CLOCKWISE_90(1),
    CLOCKWISE_180(2),
    COUNTERCLOCKWISE_90(3);

    private final int quarterTurns;

    Rotation(int quarterTurns) {
        this.quarterTurns = quarterTurns;
    }

    public int quarterTurns() { return quarterTurns; }

    public int degrees() { return quarterTurns * 90; }

    public Rotation add(Rotation other) {
        return byQuarterTurns(quarterTurns + other.quarterTurns);
    }

    public Rotation inverse() {
        return byQuarterTurns(-quarterTurns);
    }

    /** Swaps X and Z for the odd turns, so callers can size a rotated region correctly. */
    public boolean swapsAxes() {
        return quarterTurns % 2 != 0;
    }

    public static Rotation byQuarterTurns(int turns) {
        return values()[Math.floorMod(turns, 4)];
    }

    /** Rotates a position around the origin. */
    public Vec3i apply(Vec3i pos) {
        return switch (this) {
            case NONE -> pos;
            case CLOCKWISE_90 -> new Vec3i(-pos.z(), pos.y(), pos.x());
            case CLOCKWISE_180 -> new Vec3i(-pos.x(), pos.y(), -pos.z());
            case COUNTERCLOCKWISE_90 -> new Vec3i(pos.z(), pos.y(), -pos.x());
        };
    }
}
