package dev.buildmatic.core.util;

/** An immutable integer block position, independent of any Minecraft type. */
public record Vec3i(int x, int y, int z) implements Comparable<Vec3i> {

    public static final Vec3i ZERO = new Vec3i(0, 0, 0);

    public Vec3i add(int dx, int dy, int dz) {
        return new Vec3i(x + dx, y + dy, z + dz);
    }

    public Vec3i add(Vec3i o) {
        return new Vec3i(x + o.x, y + o.y, z + o.z);
    }

    public Vec3i subtract(Vec3i o) {
        return new Vec3i(x - o.x, y - o.y, z - o.z);
    }

    public Vec3i offset(Direction dir) {
        return add(dir.stepX(), dir.stepY(), dir.stepZ());
    }

    public Vec3i offset(Direction dir, int n) {
        return add(dir.stepX() * n, dir.stepY() * n, dir.stepZ() * n);
    }

    /** Component-wise minimum; useful for normalising a corner pair into a box. */
    public Vec3i min(Vec3i o) {
        return new Vec3i(Math.min(x, o.x), Math.min(y, o.y), Math.min(z, o.z));
    }

    public Vec3i max(Vec3i o) {
        return new Vec3i(Math.max(x, o.x), Math.max(y, o.y), Math.max(z, o.z));
    }

    /** Squared euclidean distance; kept in integers to stay exact for sorting. */
    public long distanceSquared(Vec3i o) {
        long dx = (long) x - o.x;
        long dy = (long) y - o.y;
        long dz = (long) z - o.z;
        return dx * dx + dy * dy + dz * dz;
    }

    public int manhattan(Vec3i o) {
        return Math.abs(x - o.x) + Math.abs(y - o.y) + Math.abs(z - o.z);
    }

    /** Packs into a single long, valid for coordinates within +/-2^20 (Minecraft's world limit). */
    public long pack() {
        return ((long) (x & 0x3FFFFF) << 42) | ((long) (z & 0x3FFFFF) << 20) | (y & 0xFFFFF);
    }

    public static Vec3i unpack(long packed) {
        int x = signExtend((int) (packed >>> 42), 22);
        int z = signExtend((int) (packed >>> 20) & 0x3FFFFF, 22);
        int y = signExtend((int) (packed & 0xFFFFF), 20);
        return new Vec3i(x, y, z);
    }

    private static int signExtend(int value, int bits) {
        int shift = 32 - bits;
        return (value << shift) >> shift;
    }

    @Override
    public int compareTo(Vec3i o) {
        if (y != o.y) return Integer.compare(y, o.y);
        if (z != o.z) return Integer.compare(z, o.z);
        return Integer.compare(x, o.x);
    }

    @Override
    public String toString() {
        return x + ", " + y + ", " + z;
    }
}
