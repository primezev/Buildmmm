package dev.buildmatic.core.variant;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The geometric form of a block, independent of what it is made of.
 *
 * <p>Shapes are recognised from the block id itself rather than from a registry tag, because tags
 * differ between game versions and mods frequently forget to apply them. Every vanilla block
 * follows the {@code <material>_<shape>} convention, and mods overwhelmingly copy it, so a suffix
 * table classifies both without needing a per-version data dump.
 *
 * <p>This is what powers "click a stair, get every other stair": {@link #of} turns
 * {@code minecraft:dark_oak_stairs} into {@code (dark_oak, STAIRS)}, and the variant index then
 * answers every other id that shares one half of that pair.
 */
public enum BlockShape {

    // Order matters only for display; matching uses the longest suffix, see below.
    STAIRS("stairs", "_stairs"),
    SLAB("slab", "_slab"),
    WALL("wall", "_wall"),
    FENCE("fence", "_fence"),
    FENCE_GATE("fence gate", "_fence_gate"),
    DOOR("door", "_door"),
    TRAPDOOR("trapdoor", "_trapdoor"),
    BUTTON("button", "_button"),
    PRESSURE_PLATE("pressure plate", "_pressure_plate"),

    SIGN("sign", "_sign"),
    WALL_SIGN("wall sign", "_wall_sign"),
    HANGING_SIGN("hanging sign", "_hanging_sign"),
    WALL_HANGING_SIGN("wall hanging sign", "_wall_hanging_sign"),

    PLANKS("planks", "_planks"),
    LOG("log", "_log"),
    STRIPPED_LOG("stripped log", "!stripped_", "_log"),
    WOOD("wood", "_wood"),
    STRIPPED_WOOD("stripped wood", "!stripped_", "_wood"),
    LEAVES("leaves", "_leaves"),
    SAPLING("sapling", "_sapling"),

    WOOL("wool", "_wool"),
    CARPET("carpet", "_carpet"),
    BED("bed", "_bed"),
    BANNER("banner", "_banner"),
    WALL_BANNER("wall banner", "_wall_banner"),
    CANDLE("candle", "_candle"),
    SHULKER_BOX("shulker box", "_shulker_box"),

    CONCRETE("concrete", "_concrete"),
    CONCRETE_POWDER("concrete powder", "_concrete_powder"),
    TERRACOTTA("terracotta", "_terracotta"),
    GLAZED_TERRACOTTA("glazed terracotta", "_glazed_terracotta"),
    STAINED_GLASS("stained glass", "_stained_glass"),
    STAINED_GLASS_PANE("stained glass pane", "_stained_glass_pane"),
    GLASS_PANE("glass pane", "_glass_pane"),

    BRICKS("bricks", "_bricks"),
    TILES("tiles", "_tiles"),
    PILLAR("pillar", "_pillar"),
    ORE("ore", "_ore"),
    BLOCK("block", "_block"),

    // Decoration and vegetation. These exist mainly to keep the SOLID bucket clean: without them
    // every coral fan and flower pot is a candidate replacement for a brick.
    CORAL("coral", "_coral"),
    CORAL_FAN("coral fan", "_coral_fan"),
    CORAL_WALL_FAN("coral wall fan", "_coral_wall_fan"),
    CORAL_BLOCK("coral block", "_coral_block"),
    MUSHROOM_BLOCK("mushroom block", "_mushroom_block"),
    AMETHYST_BUD("bud", "_bud"),
    TORCH("torch", "_torch"),
    WALL_TORCH("wall torch", "_wall_torch"),
    LANTERN("lantern", "_lantern"),
    HEAD("head", "_head"),
    SKULL("skull", "_skull"),
    VINES("vines", "_vines"),
    RAIL("rail", "_rail"),
    ROOTS("roots", "_roots"),
    FUNGUS("fungus", "_fungus"),
    SPROUTS("sprouts", "_sprouts"),

    /** A plain cube with no suffix at all: stone, dirt, netherrack, oak_planks' cousins. */
    SOLID("solid", ""),

    /** Anything the suffix table does not recognise. */
    OTHER("other", "");

    /** Ordered longest-first so that {@code _wall_sign} wins over {@code _sign}. */
    private static final List<BlockShape> MATCH_ORDER = buildMatchOrder();

    private final String displayName;
    private final String requiredPrefix;
    private final String suffix;

    BlockShape(String displayName, String suffix) {
        this(displayName, null, suffix);
    }

    BlockShape(String displayName, String prefixMarker, String suffix) {
        this.displayName = displayName;
        // A leading '!' marks a prefix that must also be present and is stripped from the material.
        this.requiredPrefix = prefixMarker == null ? null : prefixMarker.substring(1);
        this.suffix = suffix;
    }

    public String displayName() { return displayName; }

    public String suffix() { return suffix; }

    public String requiredPrefix() { return requiredPrefix; }

    public boolean isStructural() {
        return switch (this) {
            case STAIRS, SLAB, WALL, FENCE, FENCE_GATE, PLANKS, LOG, STRIPPED_LOG, WOOD,
                 STRIPPED_WOOD, BRICKS, TILES, PILLAR, BLOCK, SOLID, CONCRETE, TERRACOTTA,
                 WOOL, STAINED_GLASS -> true;
            default -> false;
        };
    }

    /** True when swapping in this shape preserves the block's collision box. */
    public boolean isFullCube() {
        return switch (this) {
            case PLANKS, LOG, STRIPPED_LOG, WOOD, STRIPPED_WOOD, LEAVES, WOOL, CONCRETE,
                 CONCRETE_POWDER, TERRACOTTA, GLAZED_TERRACOTTA, STAINED_GLASS, BRICKS, TILES,
                 PILLAR, ORE, BLOCK, SOLID -> true;
            default -> false;
        };
    }

    private static List<BlockShape> buildMatchOrder() {
        List<BlockShape> order = new ArrayList<>();
        for (BlockShape shape : values()) {
            if (!shape.suffix.isEmpty()) order.add(shape);
        }
        // Longest suffix first, then longest required prefix, so the most specific rule wins.
        order.sort((a, b) -> {
            int bySuffix = Integer.compare(b.suffix.length(), a.suffix.length());
            if (bySuffix != 0) return bySuffix;
            int aPrefix = a.requiredPrefix == null ? 0 : a.requiredPrefix.length();
            int bPrefix = b.requiredPrefix == null ? 0 : b.requiredPrefix.length();
            return Integer.compare(bPrefix, aPrefix);
        });
        return List.copyOf(order);
    }

    /** The result of classifying a block id. */
    public record Match(String material, BlockShape shape) {}

    /**
     * Splits a block id path into its material and shape.
     *
     * <p>{@code dark_oak_stairs} yields {@code (dark_oak, STAIRS)}, {@code stripped_birch_log}
     * yields {@code (birch, STRIPPED_LOG)}, and a bare {@code stone} yields {@code (stone, SOLID)}.
     */
    public static Match of(String blockPath) {
        String path = blockPath.toLowerCase(Locale.ROOT);
        for (BlockShape shape : MATCH_ORDER) {
            if (!path.endsWith(shape.suffix)) continue;

            String withoutSuffix = path.substring(0, path.length() - shape.suffix.length());
            if (withoutSuffix.isEmpty()) continue;

            if (shape.requiredPrefix != null) {
                if (!withoutSuffix.startsWith(shape.requiredPrefix)) continue;
                withoutSuffix = withoutSuffix.substring(shape.requiredPrefix.length());
                if (withoutSuffix.isEmpty()) continue;
            } else if (hasMoreSpecificPrefixRule(shape, withoutSuffix)) {
                // `stripped_oak_log` must not fall through to plain LOG.
                continue;
            }
            return new Match(withoutSuffix, shape);
        }
        return new Match(path, SOLID);
    }

    private static boolean hasMoreSpecificPrefixRule(BlockShape shape, String material) {
        for (BlockShape other : MATCH_ORDER) {
            if (other.requiredPrefix == null) continue;
            if (!other.suffix.equals(shape.suffix)) continue;
            if (material.startsWith(other.requiredPrefix)) return true;
        }
        return false;
    }

    /** Rebuilds a block id path from a material and a shape, or null when the pair is nonsensical. */
    public static String compose(String material, BlockShape shape) {
        if (shape == OTHER) return null;
        if (shape == SOLID) return material;
        String prefix = shape.requiredPrefix == null ? "" : shape.requiredPrefix;
        return prefix + material + shape.suffix;
    }
}
