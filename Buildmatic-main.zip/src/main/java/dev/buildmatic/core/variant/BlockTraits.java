package dev.buildmatic.core.variant;

/**
 * The few physical facts about a block that decide whether it is a sensible swap for another.
 *
 * <p>Without this, the shapeless {@code SOLID} bucket is a dumping ground: asking for alternatives
 * to {@code bricks} returns every block in the game that has no recognised suffix, which in vanilla
 * means dead coral fans and flower pots outrank actual masonry. Filtering by whether a candidate is
 * even a building block cuts that list from thousands to dozens.
 */
public interface BlockTraits {

    /** True for anything you can stand on or inside: full cubes, glass, stairs, slabs, fences. */
    boolean isBuildingBlock(String blockId);

    /** True only for full opaque cubes: stone, bricks, planks, wool. */
    boolean isFullCube(String blockId);

    /** Accepts everything; used by the headless tests. */
    BlockTraits PERMISSIVE = new BlockTraits() {
        @Override public boolean isBuildingBlock(String blockId) { return true; }
        @Override public boolean isFullCube(String blockId) { return true; }
    };
}
