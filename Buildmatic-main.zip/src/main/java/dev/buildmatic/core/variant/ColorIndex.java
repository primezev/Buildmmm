package dev.buildmatic.core.variant;

/**
 * Average surface colour per block, used to order swap suggestions by how close they look.
 *
 * <p>The core cannot compute this - it needs the texture atlas - so the client supplies an
 * implementation that samples each block's particle or top-face texture once at resource reload.
 */
@FunctionalInterface
public interface ColorIndex {

    int UNKNOWN = -1;

    /** Packed 0xRRGGBB for the block, or {@link #UNKNOWN} when it has not been sampled. */
    int averageColor(String blockId);

    ColorIndex EMPTY = blockId -> UNKNOWN;

    /**
     * Perceptual distance between two packed colours, using the "redmean" approximation.
     *
     * <p>Cheap enough to run across a few hundred candidates every time the swap wheel opens, and
     * markedly better than plain RGB distance at keeping wood tones next to wood tones.
     */
    static double distance(int a, int b) {
        if (a == UNKNOWN || b == UNKNOWN) return Double.MAX_VALUE;
        int r1 = (a >> 16) & 0xFF;
        int g1 = (a >> 8) & 0xFF;
        int b1 = a & 0xFF;
        int r2 = (b >> 16) & 0xFF;
        int g2 = (b >> 8) & 0xFF;
        int b2 = b & 0xFF;

        double rmean = (r1 + r2) / 2.0;
        double dr = r1 - r2;
        double dg = g1 - g2;
        double db = b1 - b2;
        return Math.sqrt(
                (2 + rmean / 256.0) * dr * dr
                        + 4 * dg * dg
                        + (2 + (255 - rmean) / 256.0) * db * db);
    }

    /** Relative luminance in 0..1, for sorting a family light-to-dark. */
    static double luminance(int color) {
        if (color == UNKNOWN) return 0;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0;
    }
}
