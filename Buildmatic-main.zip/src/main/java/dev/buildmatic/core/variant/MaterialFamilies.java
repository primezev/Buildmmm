package dev.buildmatic.core.variant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Curated groupings of block materials.
 *
 * <p>The variant index can already tell you every block that shares a shape, but "every stair in
 * the game" is a wall of two hundred entries. Families let the swap UI lead with the handful a
 * builder actually wants - click an oak stair and the wood set comes first, click a deepslate stair
 * and the stone set does.
 *
 * <p>Unlisted materials still work; they simply have no family and sort after the grouped ones.
 * Modded materials fall into this bucket, which is the right default: a mod's blocks stay together
 * by namespace rather than being force-fitted into a vanilla family.
 */
public final class MaterialFamilies {

    public record Family(String id, String displayName, List<String> materials) {}

    private static final List<Family> FAMILIES = new ArrayList<>();
    private static final Map<String, Family> BY_MATERIAL = new HashMap<>();
    private static final Map<String, Integer> ORDER_WITHIN_FAMILY = new HashMap<>();

    private MaterialFamilies() {}

    private static void family(String id, String displayName, String... materials) {
        Family family = new Family(id, displayName, List.of(materials));
        FAMILIES.add(family);
        for (int i = 0; i < materials.length; i++) {
            BY_MATERIAL.putIfAbsent(materials[i], family);
            ORDER_WITHIN_FAMILY.putIfAbsent(materials[i], i);
        }
    }

    static {
        family("wood", "Wood",
                "oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry",
                "pale_oak", "bamboo", "bamboo_mosaic", "crimson", "warped");

        family("stone", "Stone",
                "stone", "smooth_stone", "cobblestone", "mossy_cobblestone",
                "stone_brick", "mossy_stone_brick", "cracked_stone_brick", "chiseled_stone_brick",
                "granite", "polished_granite", "diorite", "polished_diorite",
                "andesite", "polished_andesite");

        family("deepslate", "Deepslate",
                "deepslate", "cobbled_deepslate", "polished_deepslate", "chiseled_deepslate",
                "deepslate_brick", "cracked_deepslate_brick",
                "deepslate_tile", "cracked_deepslate_tile");

        family("tuff", "Tuff",
                "tuff", "polished_tuff", "chiseled_tuff", "tuff_brick", "chiseled_tuff_brick");

        family("nether", "Nether",
                "netherrack", "nether_brick", "red_nether_brick", "cracked_nether_brick",
                "chiseled_nether_brick", "blackstone", "polished_blackstone",
                "polished_blackstone_brick", "cracked_polished_blackstone_brick",
                "chiseled_polished_blackstone", "gilded_blackstone",
                "basalt", "polished_basalt", "smooth_basalt");

        family("end", "End",
                "end_stone", "end_stone_brick", "purpur", "purpur_pillar");

        family("sandstone", "Sandstone",
                "sandstone", "smooth_sandstone", "cut_sandstone", "chiseled_sandstone",
                "red_sandstone", "smooth_red_sandstone", "cut_red_sandstone",
                "chiseled_red_sandstone");

        family("prismarine", "Prismarine",
                "prismarine", "prismarine_brick", "dark_prismarine");

        family("quartz", "Quartz",
                "quartz", "smooth_quartz", "quartz_brick", "chiseled_quartz",
                "quartz_pillar");

        family("copper", "Copper",
                "copper", "exposed_copper", "weathered_copper", "oxidized_copper",
                "cut_copper", "exposed_cut_copper", "weathered_cut_copper", "oxidized_cut_copper",
                "chiseled_copper", "exposed_chiseled_copper", "weathered_chiseled_copper",
                "oxidized_chiseled_copper",
                "copper_grate", "exposed_copper_grate", "weathered_copper_grate",
                "oxidized_copper_grate");

        family("waxed_copper", "Waxed copper",
                "waxed_copper", "waxed_exposed_copper", "waxed_weathered_copper",
                "waxed_oxidized_copper", "waxed_cut_copper", "waxed_exposed_cut_copper",
                "waxed_weathered_cut_copper", "waxed_oxidized_cut_copper",
                "waxed_chiseled_copper", "waxed_exposed_chiseled_copper",
                "waxed_weathered_chiseled_copper", "waxed_oxidized_chiseled_copper");

        family("earth", "Earth",
                "dirt", "coarse_dirt", "rooted_dirt", "podzol", "mycelium", "grass_block",
                "mud", "packed_mud", "mud_brick", "clay", "gravel", "sand", "red_sand");

        family("resin", "Resin", "resin", "resin_brick", "chiseled_resin_brick");

        family("amethyst", "Amethyst", "amethyst", "amethyst_block", "budding_amethyst");

        family("metal", "Metal",
                "iron", "gold", "copper", "netherite", "emerald", "diamond", "lapis",
                "redstone", "coal", "raw_iron", "raw_gold", "raw_copper");

        // The 16 dye colours, in the vanilla inventory order builders are used to.
        family("colour", "Colour",
                "white", "light_gray", "gray", "black", "brown", "red", "orange", "yellow",
                "lime", "green", "cyan", "light_blue", "blue", "purple", "magenta", "pink");
    }

    public static Family familyOf(String material) {
        return BY_MATERIAL.get(material);
    }

    public static String familyIdOf(String material) {
        Family family = BY_MATERIAL.get(material);
        return family == null ? "" : family.id();
    }

    public static boolean sameFamily(String a, String b) {
        Family fa = BY_MATERIAL.get(a);
        return fa != null && fa == BY_MATERIAL.get(b);
    }

    /** Other materials in the same family, in curated order; empty when the material is unknown. */
    public static List<String> siblings(String material) {
        Family family = BY_MATERIAL.get(material);
        return family == null ? List.of() : family.materials();
    }

    /**
     * Position within the curated family order, used as a tiebreak so that a swap list reads
     * oak, spruce, birch rather than acacia, bamboo, birch.
     */
    public static int orderOf(String material) {
        return ORDER_WITHIN_FAMILY.getOrDefault(material, Integer.MAX_VALUE);
    }

    public static List<Family> all() { return List.copyOf(FAMILIES); }

    /** Families keyed by id, for the settings screen. */
    public static Map<String, Family> byId() {
        Map<String, Family> map = new LinkedHashMap<>();
        for (Family family : FAMILIES) map.put(family.id(), family);
        return map;
    }
}
