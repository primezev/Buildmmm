package dev.buildmatic.core.variant;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * The block-family index behind Buildmatic's variant swapping.
 *
 * <p>It is built once from whatever block ids the running game reports, so it automatically covers
 * blocks added by newer Minecraft versions and by mods, without a hardcoded table to maintain.
 * Given any block it can answer the two questions the swap UI asks:
 *
 * <ul>
 *   <li><b>Same shape, other materials</b> - click a stair, get every other stair.</li>
 *   <li><b>Same material, other shapes</b> - click oak planks, get oak stairs, slabs, fences.</li>
 * </ul>
 *
 * <p>Results are ranked so the plausible choices come first: same material family, then closest
 * average colour, then the curated family order.
 */
public final class VariantIndex {

    /** A block id decomposed into the two axes the swap UI navigates. */
    public record BlockKind(String blockId, String namespace, String material, BlockShape shape) {

        public String familyId() { return MaterialFamilies.familyIdOf(material); }

        /** Human-readable material, e.g. {@code dark_oak} becomes {@code Dark oak}. */
        public String materialDisplayName() { return prettify(material); }
    }

    /** One swap suggestion, already scored. */
    public record Candidate(BlockKind kind, double score, boolean sameFamily, double colorDistance)
            implements Comparable<Candidate> {

        @Override
        public int compareTo(Candidate o) {
            int byScore = Double.compare(o.score, score);
            if (byScore != 0) return byScore;
            return kind.blockId().compareTo(o.kind.blockId());
        }
    }

    /** How the swap UI wants candidates filtered. */
    public enum Axis {
        /** Keep the shape, change the material: all stairs, all slabs. */
        MATERIAL,
        /** Keep the material, change the shape: oak planks, stairs, slab, fence. */
        SHAPE,
        /** Both axes at once. */
        BOTH
    }

    public record Query(Axis axis, String search, String preferredNamespace, boolean familiesOnly,
                        int limit) {

        public static Query materials() {
            return new Query(Axis.MATERIAL, "", "", false, 512);
        }

        public static Query shapes() {
            return new Query(Axis.SHAPE, "", "", false, 512);
        }

        public Query withSearch(String search) {
            return new Query(axis, search == null ? "" : search, preferredNamespace, familiesOnly, limit);
        }

        public Query withAxis(Axis axis) {
            return new Query(axis, search, preferredNamespace, familiesOnly, limit);
        }

        public Query withFamiliesOnly(boolean familiesOnly) {
            return new Query(axis, search, preferredNamespace, familiesOnly, limit);
        }

        public Query withLimit(int limit) {
            return new Query(axis, search, preferredNamespace, familiesOnly, limit);
        }
    }

    private final Map<String, BlockKind> kinds;
    private final Map<BlockShape, List<BlockKind>> byShape;
    private final Map<String, List<BlockKind>> byMaterial;
    private final ColorIndex colors;
    private final BlockTraits traits;

    private VariantIndex(Map<String, BlockKind> kinds,
                         Map<BlockShape, List<BlockKind>> byShape,
                         Map<String, List<BlockKind>> byMaterial,
                         ColorIndex colors,
                         BlockTraits traits) {
        this.kinds = kinds;
        this.byShape = byShape;
        this.byMaterial = byMaterial;
        this.colors = colors;
        this.traits = traits;
    }

    public static VariantIndex build(Collection<String> blockIds, ColorIndex colors) {
        return build(blockIds, colors, BlockTraits.PERMISSIVE);
    }

    /** Builds an index over every block id the game knows about. */
    public static VariantIndex build(Collection<String> blockIds, ColorIndex colors,
                                     BlockTraits traits) {
        Map<String, BlockKind> kinds = new HashMap<>(blockIds.size() * 2);
        Map<BlockShape, List<BlockKind>> byShape = new HashMap<>();
        Map<String, List<BlockKind>> byMaterial = new TreeMap<>();

        for (String rawId : blockIds) {
            String id = normalise(rawId);
            int colon = id.indexOf(':');
            String namespace = id.substring(0, colon);
            String path = id.substring(colon + 1);

            BlockShape.Match match = BlockShape.of(path);
            BlockKind kind = new BlockKind(id, namespace, match.material(), match.shape());
            kinds.put(id, kind);
            byShape.computeIfAbsent(match.shape(), k -> new ArrayList<>()).add(kind);
            byMaterial.computeIfAbsent(match.material(), k -> new ArrayList<>()).add(kind);
        }

        for (List<BlockKind> list : byShape.values()) list.sort(VariantIndex::byCuratedOrder);
        for (List<BlockKind> list : byMaterial.values()) list.sort(VariantIndex::byCuratedOrder);

        return new VariantIndex(
                Collections.unmodifiableMap(kinds),
                Collections.unmodifiableMap(byShape),
                Collections.unmodifiableMap(byMaterial),
                colors == null ? ColorIndex.EMPTY : colors,
                traits == null ? BlockTraits.PERMISSIVE : traits);
    }

    private static int byCuratedOrder(BlockKind a, BlockKind b) {
        int byFamilyOrder = Integer.compare(
                MaterialFamilies.orderOf(a.material()), MaterialFamilies.orderOf(b.material()));
        if (byFamilyOrder != 0) return byFamilyOrder;
        return a.blockId().compareTo(b.blockId());
    }

    private static String normalise(String id) {
        String lower = id.trim().toLowerCase(Locale.ROOT);
        return lower.indexOf(':') < 0 ? "minecraft:" + lower : lower;
    }

    // --- lookups -------------------------------------------------------------------------------

    public int size() { return kinds.size(); }

    public ColorIndex colors() { return colors; }

    public BlockKind kindOf(String blockId) {
        return kinds.get(normalise(blockId));
    }

    /** True when the block exists in the running game. */
    public boolean isKnown(String blockId) {
        return kinds.containsKey(normalise(blockId));
    }

    public List<BlockKind> withShape(BlockShape shape) {
        return byShape.getOrDefault(shape, List.of());
    }

    public List<BlockKind> withMaterial(String material) {
        return byMaterial.getOrDefault(material, List.of());
    }

    /** Every shape available for a material, e.g. what forms oak comes in. */
    public List<BlockShape> shapesFor(String material) {
        List<BlockShape> shapes = new ArrayList<>();
        for (BlockKind kind : withMaterial(material)) {
            if (!shapes.contains(kind.shape())) shapes.add(kind.shape());
        }
        return shapes;
    }

    /**
     * The ranked swap suggestions for a block.
     *
     * <p>This is the call the variant wheel makes every time the player targets a ghost block.
     */
    public List<Candidate> candidates(String blockId, Query query) {
        BlockKind source = kindOf(blockId);
        if (source == null) return List.of();

        List<BlockKind> pool = new ArrayList<>();
        if (query.axis() == Axis.MATERIAL || query.axis() == Axis.BOTH) {
            pool.addAll(withShape(source.shape()));
        }
        if (query.axis() == Axis.SHAPE || query.axis() == Axis.BOTH) {
            pool.addAll(withMaterial(source.material()));
        }

        String search = query.search() == null ? "" : query.search().trim().toLowerCase(Locale.ROOT);
        int sourceColor = colors.averageColor(source.blockId());

        boolean sourceBuilds = traits.isBuildingBlock(source.blockId());
        boolean sourceCube = traits.isFullCube(source.blockId());

        Map<String, Candidate> scored = new HashMap<>();
        for (BlockKind kind : pool) {
            if (kind.blockId().equals(source.blockId())) continue;
            if (scored.containsKey(kind.blockId())) continue;
            if (!isPlausible(source, kind, sourceBuilds, sourceCube)) continue;

            boolean sameFamily = MaterialFamilies.sameFamily(source.material(), kind.material());
            if (query.familiesOnly() && !sameFamily) continue;
            if (!search.isEmpty() && !matches(kind, search)) continue;

            double colorDistance = ColorIndex.distance(sourceColor, colors.averageColor(kind.blockId()));
            scored.put(kind.blockId(),
                    new Candidate(kind, score(source, kind, sameFamily, colorDistance, query),
                            sameFamily, colorDistance));
        }

        List<Candidate> results = new ArrayList<>(scored.values());
        Collections.sort(results);
        if (results.size() > query.limit()) {
            return List.copyOf(results.subList(0, query.limit()));
        }
        return List.copyOf(results);
    }

    /**
     * Rejects candidates that share a bucket with the source but nothing else.
     *
     * <p>{@link BlockShape#SOLID} catches every block whose id carries no recognised suffix, which
     * lumps bricks in with coral fans and flower pots. Being a building block at all is the hard
     * line: a coral fan is never what a builder meant by "another block like this brick".
     *
     * <p>Filling the cube is deliberately <em>not</em> a hard line, only a scoring bonus - swapping
     * a brick wall for glass is a real choice, and rejecting it would be worse than ranking it low.
     */
    private boolean isPlausible(BlockKind source, BlockKind candidate,
                                boolean sourceBuilds, boolean sourceCube) {
        // Named shapes are already specific enough; a stair is a stair.
        if (source.shape() != BlockShape.SOLID || candidate.shape() != BlockShape.SOLID) {
            return true;
        }
        return sourceBuilds == traits.isBuildingBlock(candidate.blockId());
    }

    private double score(BlockKind source, BlockKind candidate, boolean sameFamily,
                         double colorDistance, Query query) {
        double score = 0;

        // Family membership dominates: a builder swapping oak wants the other woods first.
        if (sameFamily) score += 10_000;

        // Then namespace: vanilla before mods, unless the source is itself modded.
        if (candidate.namespace().equals(source.namespace())) score += 2_000;
        if (!query.preferredNamespace().isEmpty()
                && candidate.namespace().equals(query.preferredNamespace())) {
            score += 3_000;
        }

        // Keeping the shape is safer than changing it, so rank those above cross-shape hits.
        if (candidate.shape() == source.shape()) score += 1_000;
        else if (candidate.shape().isFullCube() && source.shape().isFullCube()) score += 400;

        // Same solidity: a full cube swapped for another full cube leaves the build watertight.
        if (traits.isFullCube(source.blockId()) == traits.isFullCube(candidate.blockId())) {
            score += 800;
        }

        // Closer colours score higher; the constant keeps this below the family term. In the
        // shapeless SOLID bucket there is no shape to go on, so colour carries the ordering.
        if (colorDistance != Double.MAX_VALUE) {
            double weight = source.shape() == BlockShape.SOLID ? 3.0 : 1.0;
            score += Math.max(0, (500 - colorDistance) * weight);
        }

        // Curated order as a final nudge so lists read in the familiar oak-spruce-birch sequence.
        int order = MaterialFamilies.orderOf(candidate.material());
        if (order != Integer.MAX_VALUE) score += Math.max(0, 64 - order);

        return score;
    }

    private static boolean matches(BlockKind kind, String search) {
        return kind.blockId().contains(search)
                || kind.material().contains(search)
                || kind.shape().displayName().contains(search)
                || prettify(kind.material()).toLowerCase(Locale.ROOT).contains(search);
    }

    /**
     * Composes the id a material/shape pair would have, but only returns it when that block really
     * exists. Used by the batch swap dialog to build "convert every wood block to spruce" rules
     * without offering combinations the game has no block for.
     */
    public String resolve(String material, BlockShape shape) {
        String path = BlockShape.compose(material, shape);
        if (path == null) return null;
        String id = "minecraft:" + path;
        if (kinds.containsKey(id)) return id;
        // Try the material's own namespace before giving up, for modded sets.
        for (BlockKind kind : withMaterial(material)) {
            String candidate = kind.namespace() + ":" + path;
            if (kinds.containsKey(candidate)) return candidate;
        }
        return null;
    }

    /**
     * Maps a whole material onto another one, keeping each block's shape.
     *
     * <p>This is what powers "convert this entire build from oak to dark oak": every
     * {@code oak_*} block resolves to its {@code dark_oak_*} counterpart where one exists.
     */
    public Map<String, String> materialMapping(String fromMaterial, String toMaterial) {
        Map<String, String> mapping = new TreeMap<>();
        for (BlockKind kind : withMaterial(fromMaterial)) {
            String target = resolve(toMaterial, kind.shape());
            if (target != null) mapping.put(kind.blockId(), target);
        }
        return mapping;
    }

    /** {@code dark_oak} becomes {@code Dark oak}, for labels and layer names. */
    public static String prettify(String material) {
        if (material.isEmpty()) return material;
        String spaced = material.replace('_', ' ');
        return Character.toUpperCase(spaced.charAt(0)) + spaced.substring(1);
    }
}
