package dev.buildmatic.core.verify;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Compares what a placement wants against what is actually in the world.
 *
 * <p>Splitting "wrong block" from "wrong state" matters in practice: a stair facing the wrong way
 * is a two-second fix, a wrong material is a trip to the chest. Litematica lumps both into one
 * bucket.
 */
public final class SchematicVerifier {

    public enum Status {
        /** The world matches the schematic. */
        CORRECT,
        /** Nothing is placed where the schematic wants a block. */
        MISSING,
        /** Something is placed where the schematic wants nothing. */
        EXTRA,
        /** A different block entirely. */
        WRONG_BLOCK,
        /** The right block, facing or configured differently. */
        WRONG_STATE
    }

    public record Mismatch(Vec3i worldPos, Status status, BlockStateRef expected,
                           BlockStateRef found) {}

    public record Result(Map<Status, Integer> counts, List<Mismatch> mismatches,
                         int checked, int skippedUnloaded) {

        public int count(Status status) { return counts.getOrDefault(status, 0); }

        public int wrong() {
            return count(Status.MISSING) + count(Status.EXTRA)
                    + count(Status.WRONG_BLOCK) + count(Status.WRONG_STATE);
        }

        public boolean isComplete() { return wrong() == 0 && skippedUnloaded == 0; }

        /** 0..1 completion, counting only the blocks the schematic actually asks for. */
        public double progress() {
            int wanted = count(Status.CORRECT) + count(Status.MISSING)
                    + count(Status.WRONG_BLOCK) + count(Status.WRONG_STATE);
            return wanted == 0 ? 1.0 : (double) count(Status.CORRECT) / wanted;
        }
    }

    /** How many mismatches to record before only counting; keeps a bad placement from OOMing. */
    public static final int DEFAULT_MISMATCH_LIMIT = 20_000;

    private SchematicVerifier() {}

    public static Result verify(SchematicPlacement placement, WorldView world) {
        return verify(placement, world, placement.worldBounds(), DEFAULT_MISMATCH_LIMIT);
    }

    /**
     * Walks {@code area} and classifies every position.
     *
     * @param area the world-space region to check, normally the placement's own bounds clipped to
     *             what is loaded around the player
     */
    public static Result verify(SchematicPlacement placement, WorldView world, BlockBox area,
                                int mismatchLimit) {
        Map<Status, Integer> counts = new EnumMap<>(Status.class);
        List<Mismatch> mismatches = new ArrayList<>();
        int checked = 0;
        int skipped = 0;

        for (Vec3i pos : area) {
            BlockStateRef expected = placement.expectedAt(pos);
            if (expected == null) continue;

            if (!world.isLoaded(pos.x(), pos.y(), pos.z())) {
                skipped++;
                continue;
            }
            checked++;

            BlockStateRef found = world.blockAt(pos.x(), pos.y(), pos.z());
            Status status = classify(expected, found);
            counts.merge(status, 1, Integer::sum);

            if (status != Status.CORRECT && mismatches.size() < mismatchLimit) {
                mismatches.add(new Mismatch(pos, status, expected, found));
            }
        }
        return new Result(Collections.unmodifiableMap(counts),
                Collections.unmodifiableList(mismatches), checked, skipped);
    }

    static Status classify(BlockStateRef expected, BlockStateRef found) {
        boolean wantsNothing = expected == null || expected.isEmpty();
        boolean hasNothing = found == null || found.isEmpty();

        if (wantsNothing) return hasNothing ? Status.CORRECT : Status.EXTRA;
        if (hasNothing) return Status.MISSING;
        if (expected.equals(found)) return Status.CORRECT;
        if (expected.blockId().equals(found.blockId())) return Status.WRONG_STATE;
        return Status.WRONG_BLOCK;
    }
}
