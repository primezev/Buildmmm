package dev.buildmatic.core.verify;

import dev.buildmatic.core.block.BlockStateRef;

/**
 * Read-only access to the world, in the core's own vocabulary.
 *
 * <p>Keeping the verifier behind this interface means the whole comparison is testable against a
 * hand-built fake world, with no client, no server and no Minecraft on the classpath.
 */
public interface WorldView {

    BlockStateRef blockAt(int x, int y, int z);

    /**
     * True when the chunk holding this position is loaded.
     *
     * <p>Unloaded positions are reported separately rather than counted as missing, so the progress
     * bar does not lie while the player is walking towards the far end of a build.
     */
    boolean isLoaded(int x, int y, int z);
}
