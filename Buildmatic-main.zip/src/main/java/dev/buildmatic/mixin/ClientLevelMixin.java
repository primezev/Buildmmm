package dev.buildmatic.mixin;

import dev.buildmatic.client.BuildmaticClient;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tells the preview exactly which block changed.
 *
 * <p>Without this the only way to keep "hide blocks already built" and the red tint honest was to
 * throw the whole mesh cache away on a timer, which meant re-meshing an entire build once a second
 * whether anything had happened or not. One position is enough to rebuild one 16-cube.
 */
@Mixin(ClientLevel.class)
public class ClientLevelMixin {

    @Inject(method = "setBlocksDirty", at = @At("HEAD"))
    private void buildmatic$blockChanged(BlockPos pos, BlockState before, BlockState after,
                                         CallbackInfo callback) {
        if (before != after) {
            BuildmaticClient.onWorldBlockChanged(pos.getX(), pos.getY(), pos.getZ());
        }
    }
}
