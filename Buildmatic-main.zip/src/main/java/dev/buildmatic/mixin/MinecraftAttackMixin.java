package dev.buildmatic.mixin;

import dev.buildmatic.client.BuildmaticClient;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Gives the left click to the tool instead of to the pickaxe.
 *
 * <p>The click has to be handled here rather than through {@code AttackBlockCallback}: that event
 * is fired from inside {@code startAttack}, so cancelling the method to stop the block breaking
 * also stops the callback from ever running. Doing the work first and cancelling afterwards gets
 * both - the corner is set, and nothing is mined.
 *
 * <p>Holding the button goes through {@code continueAttack}, which never consults the callback at
 * all; without cancelling that too, dragging across a wall in creative deletes it.
 */
@Mixin(Minecraft.class)
public class MinecraftAttackMixin {

    @Inject(method = "startAttack", at = @At("HEAD"), cancellable = true)
    private void buildmatic$startAttack(CallbackInfoReturnable<Boolean> callback) {
        if (BuildmaticClient.handleAttack()) {
            callback.setReturnValue(false);
        }
    }

    @Inject(method = "continueAttack", at = @At("HEAD"), cancellable = true)
    private void buildmatic$continueAttack(boolean held, CallbackInfo callback) {
        // Only the initial click does anything; repeating it would drag corner 1 along the wall.
        if (BuildmaticClient.toolActive(Minecraft.getInstance())) {
            callback.cancel();
        }
    }
}
