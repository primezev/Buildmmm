package dev.buildmatic.mixin;

import dev.buildmatic.client.BuildmaticClient;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Catches the use action before the game decides there is nothing to use it on.
 *
 * <p>Fabric's {@code UseBlockCallback} only fires when the crosshair is on a real block. Schematic
 * work is mostly aimed at empty space - that is what a ghost block is - so both easy place and the
 * tool's right click were never reached. {@code startUseItem} runs regardless of what is being
 * looked at, which is why the hook belongs here.
 */
@Mixin(Minecraft.class)
public class MinecraftMixin {

    @Inject(method = "startUseItem", at = @At("HEAD"), cancellable = true)
    private void buildmatic$startUseItem(CallbackInfo callback) {
        if (BuildmaticClient.handleUseItem()) {
            callback.cancel();
        }
    }
}
