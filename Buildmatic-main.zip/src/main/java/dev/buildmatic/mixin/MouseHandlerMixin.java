package dev.buildmatic.mixin;

import dev.buildmatic.client.BuildmaticClient;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lets the schematic tool use the mouse wheel.
 *
 * <p>Fabric exposes no scroll event, and {@code onScroll} is private, so this is the only way in.
 * The injection cancels only when Buildmatic actually consumed the scroll - the tool has to be in
 * hand and no screen open - so the hotbar keeps working the rest of the time.
 */
@Mixin(MouseHandler.class)
public class MouseHandlerMixin {

    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void buildmatic$onScroll(long window, double horizontal, double vertical,
                                     CallbackInfo callback) {
        if (BuildmaticClient.handleScroll(vertical)) {
            callback.cancel();
        }
    }
}
