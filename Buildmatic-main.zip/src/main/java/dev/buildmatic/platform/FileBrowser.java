package dev.buildmatic.platform;

import java.nio.file.Path;

//? if >=1.21.9 {
import net.minecraft.util.Util;
//?} else {
/*import net.minecraft.Util;
*///?}

/**
 * Hands a directory to the operating system's file browser.
 *
 * <p>One call, one version branch: the {@code Util} class moved from {@code net.minecraft} to
 * {@code net.minecraft.util} in the 1.21.9 package reshuffle. The OS enum behind it has not changed
 * since 1.19, so {@code openUri} means the same thing on every target - Explorer on Windows, Finder
 * on macOS, {@code xdg-open} on Linux - and the game shells out itself rather than touching AWT,
 * which is what makes this safe to call from the render thread.
 */
public final class FileBrowser {

    private FileBrowser() {}

    /** Opens the directory in a file manager window. Silent if the platform refuses. */
    public static void open(Path directory) {
        Util.getPlatform().openUri(directory.toUri());
    }
}
