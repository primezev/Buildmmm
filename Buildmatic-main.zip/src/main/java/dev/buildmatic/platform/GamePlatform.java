package dev.buildmatic.platform;

import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;

import java.nio.file.Path;
import java.util.Collection;

/**
 * Everything Buildmatic's core needs from the running game.
 *
 * <p>This is the only seam where version-specific code lives. The core is compiled once and works
 * identically from 1.19.2 to 26.2; the implementation behind this interface is what Stonecutter's
 * preprocessor varies per target, and it is deliberately tiny so that a new Minecraft release
 * breaks a handful of methods rather than the whole mod.
 */
public interface GamePlatform {

    /** Every block id in the registry, including modded ones. */
    Collection<String> blockIds();

    /** Property definitions for the running game's blocks. */
    BlockStateSchema stateSchema();

    /** Average block colours sampled from the texture atlas; may be {@link ColorIndex#EMPTY}. */
    ColorIndex colorIndex();

    /** Physical facts used to keep nonsense out of the variant suggestions. */
    default dev.buildmatic.core.variant.BlockTraits blockTraits() {
        return dev.buildmatic.core.variant.BlockTraits.PERMISSIVE;
    }

    /** The data version to stamp into files written now. */
    int dataVersion();

    /** The Minecraft release string, e.g. {@code 1.21.8} or {@code 26.2}. */
    String gameVersion();

    /** Where schematics live; {@code .minecraft/schematics} by default. */
    Path schematicsDirectory();

    /** Where Buildmatic's own configuration lives. */
    Path configDirectory();

    /**
     * Builds the variant index from this platform's registry and colours.
     *
     * <p>Called once after a resource reload, since both the block list and the atlas can change
     * when a resource pack or a datapack is swapped.
     */
    default VariantIndex buildVariantIndex() {
        return VariantIndex.build(blockIds(), colorIndex(), blockTraits());
    }
}
