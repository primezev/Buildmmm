package dev.buildmatic.platform;

import dev.buildmatic.core.area.WorldCaptureSource;
import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.util.BlockBox;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Reads the client's world for schematic capture.
 *
 * <p>On a multiplayer server the client only ever receives what it can see, so container contents
 * and most entity data arrive empty. That is a limitation of the protocol rather than of this
 * class, and {@link dev.buildmatic.core.area.WorldCapture} reports what it could not read.
 */
public final class LevelCaptureSource implements WorldCaptureSource {

    private final Level level;
    private final MinecraftStateSchema schema;
    private final BlockPos.MutableBlockPos scratch = new BlockPos.MutableBlockPos();

    public LevelCaptureSource(Level level, MinecraftStateSchema schema) {
        this.level = level;
        this.schema = schema;
    }

    @Override
    public BlockStateRef blockAt(int x, int y, int z) {
        return schema.toRef(level.getBlockState(scratch.set(x, y, z)));
    }

    @Override
    public boolean isLoaded(int x, int y, int z) {
        //? if >=1.21.2 {
        if (y < level.getMinY() || y > level.getMaxY()) return false;
        //?} else {
        /*if (y < level.getMinBuildHeight() || y > level.getMaxBuildHeight()) return false;
        *///?}
        return level.hasChunkAt(scratch.set(x, y, z));
    }

    @Override
    public NbtCompound blockEntityAt(int x, int y, int z) {
        BlockEntity entity = level.getBlockEntity(scratch.set(x, y, z));
        if (entity == null) return null;
        try {
            // Saving a block entity started needing the registries in 1.20.5, for the components.
            //? if >=1.20.5 {
            return VanillaNbt.toBuildmatic(entity.saveWithFullMetadata(level.registryAccess()));
            //?} else {
            /*return VanillaNbt.toBuildmatic(entity.saveWithFullMetadata());
            *///?}
        } catch (RuntimeException e) {
            // One unreadable block entity must not abort a capture of ten thousand blocks.
            dev.buildmatic.Buildmatic.LOGGER.debug("could not read block entity at {} {} {}", x, y, z, e);
            return null;
        }
    }

    /**
     * Entities are not captured yet.
     *
     * <p>26.x writes entity NBT through a {@code ValueOutput} sink rather than returning a compound,
     * so this needs its own adapter. Returning nothing loses item frames and armour stands, which is
     * visible but harmless; guessing at the API and writing corrupt entity data would not be.
     */
    @Override
    public List<SchematicEntity> entitiesIn(BlockBox box) {
        return List.of();
    }
}
