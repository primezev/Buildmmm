package dev.buildmatic.platform;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.verify.WorldView;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/**
 * Exposes the client's level to the verifier and the render filters.
 *
 * <p>Positions in unloaded chunks report as not loaded rather than as air, so a half-loaded build
 * does not show up as thousands of missing blocks.
 */
public final class LevelWorldView implements WorldView {

    private final Level level;
    private final MinecraftStateSchema schema;
    private final BlockPos.MutableBlockPos scratch = new BlockPos.MutableBlockPos();

    public LevelWorldView(Level level, MinecraftStateSchema schema) {
        this.level = level;
        this.schema = schema;
    }

    @Override
    public BlockStateRef blockAt(int x, int y, int z) {
        scratch.set(x, y, z);
        return schema.toRef(level.getBlockState(scratch));
    }

    @Override
    public boolean isLoaded(int x, int y, int z) {
        //? if >=1.21.2 {
        if (y < level.getMinY() || y > level.getMaxY()) return false;
        //?} else {
        /*if (y < level.getMinBuildHeight() || y > level.getMaxBuildHeight()) return false;
        *///?}
        return level.hasChunkAt(scratch.set(x, y, z));
    }
}
