package dev.buildmatic.platform;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.variant.ColorIndex;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
//? if >=1.20 {
import net.minecraft.world.level.material.MapColor;
//?} else {
/*import net.minecraft.world.level.material.MaterialColor;
*///?}

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/** The live {@link GamePlatform}, backed by the running client's registries. */
public final class MinecraftPlatform implements GamePlatform {

    private final MinecraftStateSchema schema = new MinecraftStateSchema();
    private final MapColorIndex colors = new MapColorIndex();

    private Collection<String> blockIds;

    @Override
    public Collection<String> blockIds() {
        if (blockIds == null) blockIds = schema.allBlockIds();
        return blockIds;
    }

    @Override
    public BlockStateSchema stateSchema() { return schema; }

    @Override
    public ColorIndex colorIndex() { return colors; }

    /**
     * Reads solidity straight off the block's default state.
     *
     * <p>{@code blocksMotion} is the line between something you build with and scenery: bricks,
     * glass and stairs all block motion, coral fans, flowers and torches do not.
     */
    @Override
    public dev.buildmatic.core.variant.BlockTraits blockTraits() {
        return new dev.buildmatic.core.variant.BlockTraits() {
            @Override
            public boolean isBuildingBlock(String blockId) {
                BlockState state = schema.toBlockState(BlockStateRef.of(blockId));
                // Blocking motion moved from the material onto the state itself in 1.20.
                //? if >=1.20 {
                return !state.isAir() && state.blocksMotion();
                //?} else {
                /*return !state.isAir() && state.getMaterial().blocksMotion();
                *///?}
            }

            @Override
            public boolean isFullCube(String blockId) {
                //? if >=1.21.2 {
                return schema.toBlockState(BlockStateRef.of(blockId)).isSolidRender();
                //?} else {
                /*return schema.toBlockState(BlockStateRef.of(blockId))
                        .isSolidRender(net.minecraft.world.level.EmptyBlockGetter.INSTANCE,
                                net.minecraft.core.BlockPos.ZERO);
                *///?}
            }
        };
    }

    @Override
    public int dataVersion() {
        //? if >=1.21.5 {
        return SharedConstants.getCurrentVersion().dataVersion().version();
        //?} else {
        /*return SharedConstants.getCurrentVersion().getDataVersion().getVersion();
        *///?}
    }

    @Override
    public String gameVersion() {
        //? if >=1.21.5 {
        return SharedConstants.getCurrentVersion().name();
        //?} else {
        /*return SharedConstants.getCurrentVersion().getName();
        *///?}
    }

    @Override
    public Path schematicsDirectory() {
        Path dir = Minecraft.getInstance().gameDirectory.toPath().resolve("schematics");
        return ensureExists(dir);
    }

    @Override
    public Path configDirectory() {
        return ensureExists(FabricLoader.getInstance().getConfigDir().resolve("buildmatic"));
    }

    /** Access to the descriptor/state bridge, for the renderer and the world capture. */
    public MinecraftStateSchema schema() { return schema; }

    /** Drops every cache. Call on a resource or datapack reload. */
    public void invalidate() {
        schema.invalidate();
        colors.invalidate();
        blockIds = null;
    }

    private static Path ensureExists(Path dir) {
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            dev.buildmatic.Buildmatic.LOGGER.warn("could not create {}", dir, e);
        }
        return dir;
    }

    /**
     * Block colours taken from the map palette.
     *
     * <p>Only about sixty distinct colours exist, so this is coarser than sampling the texture
     * atlas, but it needs no render thread, no resource reload ordering and no atlas API - which
     * is the part that changes most between Minecraft versions. It is also good enough for what it
     * is used for: ordering swap suggestions so wood tones sit next to wood tones.
     *
     * <p>Blocks that tint themselves from the biome want a level and a position to answer; passing
     * neither can throw for those, and a failure here only costs a slightly worse sort order, so it
     * degrades to {@link ColorIndex#UNKNOWN} instead of propagating.
     */
    private final class MapColorIndex implements ColorIndex {

        private final Map<String, Integer> cache = new HashMap<>();

        @Override
        public int averageColor(String blockId) {
            Integer cached = cache.get(blockId);
            if (cached != null) return cached;

            int color = UNKNOWN;
            try {
                BlockState state = schema.toBlockState(BlockStateRef.of(blockId));
                // The map palette was called MaterialColor until 1.20.
                //? if >=1.20 {
                MapColor mapColor = state.getMapColor(null, BlockPos.ZERO);
                if (mapColor != null && mapColor != MapColor.NONE) color = mapColor.col;
                //?} else {
                /*MaterialColor mapColor = state.getMapColor(null, BlockPos.ZERO);
                if (mapColor != null && mapColor != MaterialColor.NONE) color = mapColor.col;
                *///?}
            } catch (RuntimeException ignored) {
                // Biome-tinted blocks need a real level; they simply sort last.
            }
            cache.put(blockId, color);
            return color;
        }

        void invalidate() { cache.clear(); }
    }
}
