package dev.buildmatic.platform;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * The registry-backed {@link BlockStateSchema}, and the bridge between {@link BlockStateRef} and
 * the game's own {@link BlockState}.
 *
 * <p>Property names and values are cached on first use rather than walked every time: the swap
 * engine asks "can this block hold {@code facing=north}?" once per palette entry per rule, and the
 * variant wheel asks a few hundred times the instant it opens.
 *
 * <p>The identifier type is never named here - only inferred with {@code var} - and block lookup
 * goes through a prebuilt id map rather than a static parse. Minecraft renamed
 * {@code ResourceLocation} to {@code Identifier} in 1.21.11, so naming it would force a preprocessor
 * branch through the whole file; this way one source compiles unchanged on every target.
 */
public final class MinecraftStateSchema implements BlockStateSchema {

    private record BlockInfo(Map<String, Property<?>> properties,
                             Map<String, List<String>> values,
                             BlockStateRef defaultState,
                             BlockState defaultBlockState) {}

    /** Namespaced id to block, built once from the registry. */
    private Map<String, Block> blocksById;

    private final Map<String, BlockInfo> cache = new HashMap<>();
    /** Descriptor to game state, populated as the schematic pipeline resolves blocks. */
    private final Map<BlockStateRef, BlockState> toGame = new HashMap<>();
    /** Game state to descriptor, keyed by the registry's own state id so lookups stay cheap. */
    private final Map<Integer, BlockStateRef> fromGame = new HashMap<>();

    // --- BlockStateSchema ------------------------------------------------------------------------

    @Override
    public Set<String> propertiesOf(String blockId) {
        BlockInfo info = info(blockId);
        return info == null ? Set.of() : info.properties().keySet();
    }

    @Override
    public List<String> valuesOf(String blockId, String property) {
        BlockInfo info = info(blockId);
        if (info == null) return List.of();
        return info.values().getOrDefault(property, List.of());
    }

    @Override
    public BlockStateRef defaultState(String blockId) {
        BlockInfo info = info(blockId);
        return info == null ? BlockStateRef.of(blockId) : info.defaultState();
    }

    @Override
    public boolean isKnownBlock(String blockId) {
        return info(blockId) != null;
    }

    @Override
    public boolean accepts(String blockId, String property, String value) {
        BlockInfo info = info(blockId);
        if (info == null) return false;
        List<String> values = info.values().get(property);
        return values != null && values.contains(value);
    }

    // --- conversion ----------------------------------------------------------------------------

    /**
     * Resolves a descriptor into a real block state.
     *
     * <p>Unknown blocks and unknown property values degrade to the closest valid state rather than
     * throwing: a schematic built on a newer version should still render everything the running
     * game does understand, with the rest showing as air.
     */
    public BlockState toBlockState(BlockStateRef ref) {
        BlockState cached = toGame.get(ref);
        if (cached != null) return cached;

        BlockInfo info = info(ref.blockId());
        if (info == null) {
            BlockState air = Blocks.AIR.defaultBlockState();
            toGame.put(ref, air);
            return air;
        }

        BlockState state = info.defaultBlockState();
        for (Map.Entry<String, String> entry : ref.properties().entrySet()) {
            Property<?> property = info.properties().get(entry.getKey());
            if (property == null) continue;
            state = applyProperty(state, property, entry.getValue());
        }
        toGame.put(ref, state);
        fromGame.putIfAbsent(Block.getId(state), ref);
        return state;
    }

    /** Applies one property by name, ignoring values the property cannot hold. */
    private static <T extends Comparable<T>> BlockState applyProperty(
            BlockState state, Property<T> property, String value) {
        for (T candidate : property.getPossibleValues()) {
            if (property.getName(candidate).equals(value)) {
                return state.setValue(property, candidate);
            }
        }
        return state;
    }

    /** Describes a game state as a version-independent descriptor. */
    public BlockStateRef toRef(BlockState state) {
        int id = Block.getId(state);
        BlockStateRef cached = fromGame.get(id);
        if (cached != null) return cached;

        var key = Registries.BLOCK.getKey(state.getBlock());
        String blockId = key == null ? "minecraft:air" : key.getNamespace() + ":" + key.getPath();

        Map<String, String> properties = new TreeMap<>();
        for (Property<?> property : state.getProperties()) {
            properties.put(property.getName(), nameOf(state, property));
        }

        BlockStateRef ref = BlockStateRef.of(blockId, properties);
        fromGame.put(id, ref);
        toGame.putIfAbsent(ref, state);
        return ref;
    }

    private static <T extends Comparable<T>> String nameOf(BlockState state, Property<T> property) {
        return property.getName(state.getValue(property));
    }

    // --- registry access -------------------------------------------------------------------------

    /** Every block id in the registry, sorted. */
    public List<String> allBlockIds() {
        List<String> ids = new ArrayList<>(blocksById().keySet());
        Collections.sort(ids);
        return ids;
    }

    /**
     * The item that represents a block in a list, ready to draw.
     *
     * <p>An icon and a readable name say far more at a glance than {@code minecraft:polished_andesite}
     * ever will, and the game already knows both.
     */
    public net.minecraft.world.item.ItemStack icon(String blockId) {
        net.minecraft.world.item.ItemStack cached = icons.get(blockId);
        if (cached != null) return cached;

        Block block = blocksById().get(normalise(blockId));
        net.minecraft.world.item.ItemStack stack = block == null
                ? net.minecraft.world.item.ItemStack.EMPTY
                : new net.minecraft.world.item.ItemStack(block.asItem());
        icons.put(blockId, stack);
        return stack;
    }

    /** The block's translated name, falling back to the id when the block is unknown. */
    public net.minecraft.network.chat.Component displayName(String blockId) {
        Block block = blocksById().get(normalise(blockId));
        return block == null
                ? net.minecraft.network.chat.Component.literal(blockId)
                : block.getName();
    }

    private final Map<String, net.minecraft.world.item.ItemStack> icons = new HashMap<>();

    /** Clears every cache; call on a resource or datapack reload. */
    public void invalidate() {
        blocksById = null;
        cache.clear();
        toGame.clear();
        fromGame.clear();
        icons.clear();
    }

    private Map<String, Block> blocksById() {
        if (blocksById != null) return blocksById;
        Map<String, Block> map = new HashMap<>();
        for (var key : Registries.BLOCK.keySet()) {
            //? if >=1.21.2 {
            Block block = Registries.BLOCK.getValue(key);
            //?} else {
            /*Block block = Registries.BLOCK.get(key);
            *///?}
            if (block != null) map.put(key.getNamespace() + ":" + key.getPath(), block);
        }
        blocksById = map;
        return map;
    }

    private BlockInfo info(String blockId) {
        BlockInfo cached = cache.get(blockId);
        if (cached != null) return cached;
        if (cache.containsKey(blockId)) return null;

        Block block = blocksById().get(normalise(blockId));
        if (block == null) {
            cache.put(blockId, null);
            return null;
        }

        BlockInfo info = describe(blockId, block);
        cache.put(blockId, info);
        return info;
    }

    private static String normalise(String blockId) {
        String lower = blockId.trim().toLowerCase(java.util.Locale.ROOT);
        return lower.indexOf(':') < 0 ? "minecraft:" + lower : lower;
    }

    private BlockInfo describe(String blockId, Block block) {
        var definition = block.getStateDefinition();

        Map<String, Property<?>> properties = new LinkedHashMap<>();
        Map<String, List<String>> values = new HashMap<>();
        for (Property<?> property : definition.getProperties()) {
            properties.put(property.getName(), property);
            values.put(property.getName(), possibleValues(property));
        }

        BlockState defaultState = block.defaultBlockState();
        Map<String, String> defaults = new TreeMap<>();
        for (Property<?> property : defaultState.getProperties()) {
            defaults.put(property.getName(), nameOf(defaultState, property));
        }

        return new BlockInfo(
                Collections.unmodifiableMap(properties),
                Collections.unmodifiableMap(values),
                BlockStateRef.of(normalise(blockId), defaults),
                defaultState);
    }

    private static <T extends Comparable<T>> List<String> possibleValues(Property<T> property) {
        List<String> names = new ArrayList<>();
        for (T value : property.getPossibleValues()) {
            names.add(property.getName(value));
        }
        return Collections.unmodifiableList(names);
    }
}
