package dev.buildmatic.platform;

import net.minecraft.core.Registry;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

/**
 * The two vanilla registries Buildmatic reads, under one name.
 *
 * <p>1.19.3 gathered the registry statics into {@code BuiltInRegistries}; before that they hung off
 * {@code Registry} itself. Eight call sites care, so they go through here and the difference is
 * stated once - the same arrangement as {@link dev.buildmatic.client.gui.Canvas} for drawing and
 * {@link dev.buildmatic.client.gui.Buttons} for widgets.
 */
public final class Registries {

    //? if >=1.19.3 {
    public static final Registry<Block> BLOCK = net.minecraft.core.registries.BuiltInRegistries.BLOCK;
    public static final Registry<Item> ITEM = net.minecraft.core.registries.BuiltInRegistries.ITEM;
    //?} else {
    /*public static final Registry<Block> BLOCK = Registry.BLOCK;
    public static final Registry<Item> ITEM = Registry.ITEM;
    *///?}

    private Registries() {}
}
