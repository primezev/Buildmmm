package dev.buildmatic.platform;

import dev.buildmatic.core.area.AreaSelection;
import dev.buildmatic.core.area.SelectionBox;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * Fill, replace, delete and move, applied to an area selection.
 *
 * <p>These write to the world, so they run only in creative singleplayer where the integrated
 * server's level is reachable. Doing it through commands on a server would need operator rights and
 * a rate limit; refusing outright is honest and leaves the schematic side of the mod usable
 * everywhere.
 */
public final class SelectionOperations {

    /** What an operation did. */
    public record Result(boolean success, int blocksChanged, String message) {
        static Result refused(String why) { return new Result(false, 0, why); }
    }

    /** Enough rope to reshape a build, not enough to freeze the client. */
    private static final int MAX_BLOCKS = 500_000;

    private SelectionOperations() {}

    public static Result fill(AreaSelection selection, BlockState block) {
        return apply(selection, "Filled", (level, pos) -> level.setBlock(pos, block, 2));
    }

    public static Result delete(AreaSelection selection) {
        BlockState air = Blocks.AIR.defaultBlockState();
        return apply(selection, "Cleared", (level, pos) -> level.setBlock(pos, air, 2));
    }

    /** Swaps one block type for another, leaving everything else alone. */
    public static Result replace(AreaSelection selection, BlockState from, BlockState to) {
        return apply(selection, "Replaced", (level, pos) -> {
            if (level.getBlockState(pos).getBlock() == from.getBlock()) {
                level.setBlock(pos, to, 2);
            }
        });
    }

    // Moving a region lives in the client instead: it cuts the selection into a schematic and hands
    // it to the placement tools, so it can be carried and aimed before anything is written.

    // --- plumbing ------------------------------------------------------------------------------

    private interface BlockAction {
        void apply(Level level, BlockPos pos);
    }

    private static Result apply(AreaSelection selection, String verb, BlockAction action) {
        Minecraft client = Minecraft.getInstance();
        Level level = serverLevel(client);
        Result refusal = check(client, level, selection);
        if (refusal != null) return refusal;

        int changed = 0;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (SelectionBox box : selection.boxes()) {
            if (!box.isEnabled() || !box.isComplete()) continue;
            for (Vec3i pos : box.box()) {
                action.apply(level, cursor.set(pos.x(), pos.y(), pos.z()).immutable());
                changed++;
            }
        }
        return new Result(true, changed, verb + " " + changed + " block(s)");
    }

    /** The shared refusals, so every operation says the same thing for the same reason. */
    private static Result check(Minecraft client, Level level, AreaSelection selection) {
        if (client.player == null) return Result.refused("No world");
        if (!client.player.isCreative()) return Result.refused("Creative mode only");
        if (level == null) {
            return Result.refused("Singleplayer only - a server would need operator commands");
        }
        if (selection == null || !selection.hasCompleteBox()) {
            return Result.refused("Draw a selection first: click two corners with the tool");
        }
        long volume = selection.volume();
        if (volume > MAX_BLOCKS) {
            return Result.refused(volume + " blocks is over the " + MAX_BLOCKS + " limit");
        }
        return null;
    }

    private static Level serverLevel(Minecraft client) {
        var server = client.getSingleplayerServer();
        if (server == null || client.level == null) return null;
        return server.getLevel(client.level.dimension());
    }

    /** The box every enabled sub-region spans, for a preview outline. */
    public static BlockBox bounds(AreaSelection selection) {
        return selection == null ? null : selection.bounds();
    }
}
