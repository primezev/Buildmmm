package dev.buildmatic.platform;

import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtIo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Converts between Minecraft's NBT classes and Buildmatic's own.
 *
 * <p>Done by round-tripping through the binary format rather than by walking the tag tree
 * type-by-type. Both sides implement the same on-disk layout, so this stays correct across every
 * game version even as the tag classes themselves change - and they have: 26.x turned the getters
 * into {@code Optional}-returning methods and several tags into records.
 *
 * <p>The cost is a few kilobytes of copying per block entity, which is nothing against the tens of
 * thousands of blocks being read around it.
 */
public final class VanillaNbt {

    private VanillaNbt() {}

    /** Minecraft's compound to Buildmatic's, or null when it cannot be read. */
    public static NbtCompound toBuildmatic(net.minecraft.nbt.CompoundTag tag) {
        if (tag == null) return null;
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(512);
            try (DataOutputStream out = new DataOutputStream(buffer)) {
                net.minecraft.nbt.NbtIo.write(tag, out);
            }
            try (DataInputStream in = new DataInputStream(
                    new ByteArrayInputStream(buffer.toByteArray()))) {
                return NbtIo.readRoot(in).tag();
            }
        } catch (IOException | RuntimeException e) {
            dev.buildmatic.Buildmatic.LOGGER.debug("could not convert NBT from Minecraft", e);
            return null;
        }
    }

    /** Buildmatic's compound to Minecraft's, or null when it cannot be written. */
    public static net.minecraft.nbt.CompoundTag toMinecraft(NbtCompound tag) {
        if (tag == null) return null;
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(512);
            try (DataOutputStream out = new DataOutputStream(buffer)) {
                NbtIo.writeNamed("", tag, out);
            }
            try (DataInputStream in = new DataInputStream(
                    new ByteArrayInputStream(buffer.toByteArray()))) {
                return net.minecraft.nbt.NbtIo.read(in);
            }
        } catch (IOException | RuntimeException e) {
            dev.buildmatic.Buildmatic.LOGGER.debug("could not convert NBT to Minecraft", e);
            return null;
        }
    }
}
