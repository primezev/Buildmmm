package dev.buildmatic.platform;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.Vec3i;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Writes a placement into the world.
 *
 * <p>In singleplayer the blocks go straight onto the integrated server's level, which keeps block
 * entities and is instant. On a server there is no such access, so nothing is written and the
 * caller is told why rather than half-pasting a build.
 */
public final class WorldWriter {

    /** What a write did. */
    public record Result(boolean success, int blocksChanged, String message) {}

    /** Guard against a stray click on a huge schematic locking the client up. */
    private static final int MAX_BLOCKS = 500_000;

    private WorldWriter() {}

    public static Result paste(SchematicPlacement placement, MinecraftStateSchema schema) {
        return write(placement, schema, false);
    }

    public static Result delete(SchematicPlacement placement, MinecraftStateSchema schema) {
        return write(placement, schema, true);
    }

    private static Result write(SchematicPlacement placement, MinecraftStateSchema schema,
                                boolean clear) {
        Minecraft client = Minecraft.getInstance();
        if (placement == null) return new Result(false, 0, "Nothing loaded");
        if (client.player == null || client.level == null) {
            return new Result(false, 0, "No world");
        }
        if (!client.player.isCreative()) {
            return new Result(false, 0, "Creative mode only");
        }

        Level level = serverLevel(client);
        if (level == null) {
            return new Result(false, 0,
                    "Only works in singleplayer - a server would need operator commands");
        }

        long volume = placement.schematic().totalVolume();
        if (volume > MAX_BLOCKS) {
            return new Result(false, 0,
                    "Too large (" + volume + " blocks); the limit is " + MAX_BLOCKS);
        }

        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos target = new BlockPos.MutableBlockPos();
        int changed = 0;

        for (SchematicRegion region : placement.schematic().regions()) {
            if (!placement.isRegionVisible(region)) continue;

            for (int y = 0; y < region.sizeY(); y++) {
                for (int z = 0; z < region.sizeZ(); z++) {
                    for (int x = 0; x < region.sizeX(); x++) {
                        Vec3i schematicPos = region.origin().add(x, y, z);
                        if (!placement.layerRange().contains(schematicPos)) continue;

                        BlockStateRef expected = placement.expectedAt(placement.toWorld(schematicPos));
                        if (expected == null) continue;

                        Vec3i world = placement.toWorld(schematicPos);
                        target.set(world.x(), world.y(), world.z());

                        BlockState state = clear ? air : schema.toBlockState(expected);
                        if (level.getBlockState(target).equals(state)) continue;

                        // Flag 2 updates clients without triggering neighbour updates, so a pasted
                        // redstone build does not fire itself apart as it appears.
                        level.setBlock(target, state, 2);
                        changed++;
                    }
                }
            }
        }

        return new Result(true, changed,
                (clear ? "Cleared " : "Pasted ") + changed + " block(s)");
    }

    /**
     * The integrated server's copy of the level the player is in.
     *
     * <p>Writing to the client's own level would only produce ghost blocks that vanish on the next
     * chunk update; the server copy is the one that counts.
     */
    private static Level serverLevel(Minecraft client) {
        var server = client.getSingleplayerServer();
        if (server == null || client.level == null) return null;
        return server.getLevel(client.level.dimension());
    }
}
