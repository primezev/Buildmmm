package dev.buildmatic.client.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapRule;
import dev.buildmatic.core.swap.SwapScopes;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class VariantWheelTest {

    private static final BlockStateRef STAIRS =
            BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]");

    private SchematicRegion region;
    private VariantIndex variants;
    private VariantWheel wheel;

    @BeforeEach
    void setUp() {
        Schematic schematic = Schematic.single("Test", new Vec3i(8, 4, 8));
        region = schematic.region(0);
        for (int x = 0; x < 8; x++) {
            region.setBlock(x, 0, 0, STAIRS);
        }

        List<String> registry = new ArrayList<>();
        for (String wood : List.of("oak", "spruce", "birch", "jungle", "acacia", "dark_oak",
                "mangrove", "cherry")) {
            registry.add("minecraft:" + wood + "_planks");
            registry.add("minecraft:" + wood + "_stairs");
            registry.add("minecraft:" + wood + "_slab");
            registry.add("minecraft:" + wood + "_fence");
        }
        // Enough stone types that the candidate list overflows one ring and paging is exercised.
        for (String stone : List.of("stone", "cobblestone", "granite", "andesite", "diorite",
                "deepslate", "blackstone", "sandstone")) {
            registry.add("minecraft:" + stone + "_stairs");
            registry.add("minecraft:" + stone + "_slab");
        }
        variants = VariantIndex.build(registry, ColorIndex.EMPTY);

        wheel = new VariantWheel(variants, BlockStateSchema.PERMISSIVE);
        wheel.open(region, new Vec3i(0, 0, 0), STAIRS);
    }

    @Test
    void opensOnTheTargetedBlock() {
        assertTrue(wheel.isOpen());
        assertEquals(STAIRS, wheel.target());
        assertEquals(new Vec3i(0, 0, 0), wheel.localPos());
        assertFalse(wheel.allCandidates().isEmpty());
    }

    @Test
    void theMaterialAxisOffersOtherStairs() {
        assertTrue(wheel.allCandidates().stream()
                .allMatch(c -> c.kind().shape() == dev.buildmatic.core.variant.BlockShape.STAIRS));
        assertEquals("minecraft:spruce_stairs", wheel.allCandidates().get(0).kind().blockId(),
                "the wood family should lead for an oak block");
    }

    @Test
    void theShapeAxisOffersOtherOakForms() {
        wheel.setAxis(VariantIndex.Axis.SHAPE);
        assertTrue(wheel.allCandidates().stream()
                .allMatch(c -> c.kind().material().equals("oak")));
        assertTrue(wheel.allCandidates().stream()
                .anyMatch(c -> c.kind().blockId().equals("minecraft:oak_slab")));
    }

    @Test
    void togglingTheAxisFlipsBackAndForth() {
        assertEquals(VariantIndex.Axis.MATERIAL, wheel.axis());
        wheel.toggleAxis();
        assertEquals(VariantIndex.Axis.SHAPE, wheel.axis());
        wheel.toggleAxis();
        assertEquals(VariantIndex.Axis.MATERIAL, wheel.axis());
    }

    @Test
    void searchNarrowsTheRing() {
        wheel.setSearch("granite");
        assertEquals(1, wheel.allCandidates().size());
        assertEquals("minecraft:granite_stairs", wheel.allCandidates().get(0).kind().blockId());

        wheel.setSearch("");
        assertTrue(wheel.allCandidates().size() > 1);
    }

    @Test
    void familiesOnlyDropsTheStoneStairs() {
        wheel.setFamiliesOnly(true);
        assertTrue(wheel.allCandidates().stream().allMatch(VariantIndex.Candidate::sameFamily));
        assertTrue(wheel.allCandidates().stream()
                .noneMatch(c -> c.kind().blockId().equals("minecraft:granite_stairs")));
    }

    @Test
    void theRingPagesRatherThanOverflowing() {
        assertTrue(wheel.allCandidates().size() > VariantWheel.RING_CAPACITY,
                "fixture must have more candidates than one ring holds");
        assertEquals(VariantWheel.RING_CAPACITY, wheel.ring().size());
        assertTrue(wheel.maxPage() > 0);

        List<VariantIndex.Candidate> firstPage = List.copyOf(wheel.ring());
        wheel.nextPage();
        assertEquals(1, wheel.page());
        assertFalse(wheel.ring().equals(firstPage));

        wheel.previousPage();
        assertEquals(0, wheel.page());
        assertEquals(firstPage, wheel.ring());
    }

    @Test
    void theCentreIsADeadZoneSoReleasingWithoutMovingCancels() {
        wheel.hoverAt(0, 0, 20);
        assertEquals(-1, wheel.hovered());
        assertNull(wheel.hoveredCandidate());
        assertNull(wheel.buildRule(false));
    }

    @Test
    void slotZeroSitsAtTheTopAndSlotsRunClockwise() {
        int slots = wheel.ring().size();
        assertEquals(12, slots, "fixture assumes a full ring");

        // Screen coordinates: y grows downward, so "up" is a negative dy.
        wheel.hoverAt(0, -100, 20);
        assertEquals(0, wheel.hovered());

        // A quarter turn clockwise from the top is to the right.
        wheel.hoverAt(100, 0, 20);
        assertEquals(slots / 4, wheel.hovered());

        wheel.hoverAt(0, 100, 20);
        assertEquals(slots / 2, wheel.hovered());

        wheel.hoverAt(-100, 0, 20);
        assertEquals(slots * 3 / 4, wheel.hovered());
    }

    @Test
    void previewShowsTheSwapBeforeItIsCommitted() {
        wheel.hoverAt(0, -100, 20);
        BlockStateRef preview = wheel.preview();
        assertNotNull(preview);
        assertEquals("minecraft:spruce_stairs", preview.blockId());
        assertEquals("north", preview.property("facing"),
                "the preview must keep the original facing");
    }

    @Test
    void exactStrictnessProducesASingleBlockRule() {
        wheel.hoverAt(0, -100, 20);
        wheel.setStrictness(SwapScopes.Strictness.EXACT_STATE);

        SwapRule rule = wheel.buildRule(false);
        assertNotNull(rule);
        assertTrue(rule.scope() instanceof SwapRule.Scope.Positions);
        assertEquals(1, ((SwapRule.Scope.Positions) rule.scope()).positions().size());
        assertFalse(rule.isPaletteResolvable());
    }

    @Test
    void sameBlockStrictnessProducesAWholeSchematicRule() {
        wheel.hoverAt(0, -100, 20);
        wheel.setStrictness(SwapScopes.Strictness.SAME_BLOCK);

        SwapRule rule = wheel.buildRule(false);
        assertTrue(rule.scope() instanceof SwapRule.Scope.Everywhere);
        assertTrue(rule.matcher() instanceof SwapRule.Matcher.Block);
        assertTrue(rule.isPaletteResolvable(), "a build-wide swap must take the palette fast path");
    }

    @Test
    void sameMaterialStrictnessConvertsMaterialToMaterial() {
        wheel.hoverAt(0, -100, 20);
        wheel.setStrictness(SwapScopes.Strictness.SAME_MATERIAL);

        SwapRule rule = wheel.buildRule(false);
        assertTrue(rule.matcher() instanceof SwapRule.Matcher.Material);
        assertEquals("oak", ((SwapRule.Matcher.Material) rule.matcher()).material());
        assertTrue(rule.target() instanceof SwapRule.Target.Material);
        assertEquals("spruce", ((SwapRule.Target.Material) rule.target()).material(),
                "picking a spruce stair should convert every oak shape, not just the stairs");
    }

    @Test
    void floodFillProducesAnExplicitPositionSet() {
        wheel.hoverAt(0, -100, 20);
        wheel.setStrictness(SwapScopes.Strictness.SAME_BLOCK);

        SwapRule rule = wheel.buildRule(true);
        assertTrue(rule.scope() instanceof SwapRule.Scope.Positions);
        assertEquals(8, ((SwapRule.Scope.Positions) rule.scope()).positions().size(),
                "the whole connected run of stairs");
    }

    @Test
    void closingClearsEverything() {
        wheel.close();
        assertFalse(wheel.isOpen());
        assertTrue(wheel.allCandidates().isEmpty());
        assertNull(wheel.hoveredCandidate());
    }
}
