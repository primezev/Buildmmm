package dev.buildmatic.core.area;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicEntity;
import dev.buildmatic.core.tool.SchematicTool;
import dev.buildmatic.core.tool.ToolMode;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AreaSelectionTest {

    private static final BlockStateRef STONE = BlockStateRef.of("minecraft:stone");
    private static final BlockStateRef CHEST = BlockStateRef.of("minecraft:chest");

    // --- boxes ---------------------------------------------------------------------------------

    @Test
    void aBoxNeedsBothCornersBeforeItHasASize() {
        SelectionBox box = new SelectionBox("a");
        assertFalse(box.isComplete());
        assertNull(box.box());

        box.setCorner1(new Vec3i(0, 0, 0));
        assertFalse(box.isComplete());

        box.setCorner2(new Vec3i(2, 3, 4));
        assertTrue(box.isComplete());
        assertEquals(new Vec3i(3, 4, 5), box.size());
        assertEquals(60, box.volume());
    }

    @Test
    void cornersAreKeptAsClickedSoTheGrabbedOneDoesNotJump() {
        SelectionBox box = new SelectionBox("a", new Vec3i(10, 0, 0), new Vec3i(0, 0, 0));
        // The box normalises, but the corners themselves stay where the player put them.
        assertEquals(new Vec3i(10, 0, 0), box.corner1());
        assertEquals(new Vec3i(0, 0, 0), box.corner2());
        assertEquals(new Vec3i(0, 0, 0), box.box().min());
    }

    @Test
    void expandGrowsToSwallowEachClick() {
        SelectionBox box = new SelectionBox("a");
        box.collapseTo(new Vec3i(5, 5, 5));
        assertEquals(1, box.volume());

        box.expandToInclude(new Vec3i(7, 5, 5));
        box.expandToInclude(new Vec3i(5, 9, 5));
        box.expandToInclude(new Vec3i(3, 5, 5));

        assertEquals(BlockBox.of(new Vec3i(3, 5, 5), new Vec3i(7, 9, 5)), box.box());
    }

    @Test
    void nudgingACornerResizesAndMovingKeepsTheSize() {
        SelectionBox box = new SelectionBox("a", new Vec3i(0, 0, 0), new Vec3i(4, 4, 4));

        box.nudgeCorner(SelectionBox.Corner.CORNER_2, Direction.EAST, 2);
        assertEquals(new Vec3i(7, 5, 5), box.size());

        Vec3i before = box.size();
        box.move(Direction.UP, 3);
        assertEquals(before, box.size());
        assertEquals(3, box.box().min().y());
    }

    // --- selections ----------------------------------------------------------------------------

    @Test
    void subRegionNamesStayUniqueBecauseTheyBecomeRegionNames() {
        AreaSelection selection = new AreaSelection("test");
        selection.addBox("Wall");
        selection.addBox("Wall");
        selection.addBox("Wall");

        Set<String> names = new HashSet<>();
        for (SelectionBox box : selection.boxes()) names.add(box.name());
        assertEquals(3, names.size(), "duplicate names would collide when saved");
    }

    @Test
    void simpleModeCollapsesToASingleBox() {
        AreaSelection selection = new AreaSelection("test");
        selection.addBox("a");
        selection.addBox("b");
        assertEquals(2, selection.boxCount());

        selection.setMode(AreaSelection.Mode.SIMPLE);
        assertEquals(1, selection.boxCount());
        assertEquals("a", selection.boxes().get(0).name());
    }

    @Test
    void boundsSpanEveryEnabledBox() {
        AreaSelection selection = new AreaSelection("test");
        selection.addBox("a").setCorner1(new Vec3i(0, 0, 0));
        selection.boxes().get(0).setCorner2(new Vec3i(1, 1, 1));

        SelectionBox far = selection.addBox("b");
        far.setCorner1(new Vec3i(20, 0, 0));
        far.setCorner2(new Vec3i(21, 1, 1));

        assertEquals(BlockBox.of(new Vec3i(0, 0, 0), new Vec3i(21, 1, 1)), selection.bounds());
        assertEquals(8 + 8, selection.volume());

        far.setEnabled(false);
        assertEquals(BlockBox.of(new Vec3i(0, 0, 0), new Vec3i(1, 1, 1)), selection.bounds());
    }

    @Test
    void theOriginTracksTheSelectionUntilItIsPinned() {
        AreaSelection selection = new AreaSelection("test");
        SelectionBox box = selection.addBox("a");
        box.setCorner1(new Vec3i(5, 6, 7));
        box.setCorner2(new Vec3i(9, 9, 9));

        assertFalse(selection.hasExplicitOrigin());
        assertEquals(new Vec3i(5, 6, 7), selection.origin());

        box.move(Direction.EAST, 10);
        assertEquals(new Vec3i(15, 6, 7), selection.origin(), "an unpinned origin follows");

        selection.setOrigin(new Vec3i(0, 0, 0));
        box.move(Direction.EAST, 10);
        assertEquals(new Vec3i(0, 0, 0), selection.origin(), "a pinned origin stays put");

        selection.clearExplicitOrigin();
        assertEquals(new Vec3i(25, 6, 7), selection.origin());
    }

    @Test
    void middleClickCyclesBoxThenCornersThenTheNextBox() {
        AreaSelection selection = new AreaSelection("test");
        selection.addBox("a");
        selection.addBox("b");
        selection.selectBox(0);

        assertEquals(SelectionBox.Corner.NONE, selection.selectedCorner());
        selection.cycleGrabbed();
        assertEquals(SelectionBox.Corner.CORNER_1, selection.selectedCorner());
        selection.cycleGrabbed();
        assertEquals(SelectionBox.Corner.CORNER_2, selection.selectedCorner());
        selection.cycleGrabbed();
        assertEquals(SelectionBox.Corner.NONE, selection.selectedCorner());
        assertEquals(1, selection.selectedBoxIndex(), "it moves on to the next box");
    }

    // --- the tool ------------------------------------------------------------------------------

    @Test
    void cornersModeSetsOneCornerPerButton() {
        SchematicTool tool = new SchematicTool();
        tool.onLeftClick(new Vec3i(0, 0, 0));
        tool.onRightClick(new Vec3i(4, 4, 4));

        SelectionBox box = tool.activeSelection().activeBox();
        assertEquals(new Vec3i(0, 0, 0), box.corner1());
        assertEquals(new Vec3i(4, 4, 4), box.corner2());
        assertEquals(125, box.volume());
    }

    @Test
    void expandModeCollapsesOnRightClickAndGrowsOnLeft() {
        SchematicTool tool = new SchematicTool();
        tool.toggleSelectionSubMode();
        assertEquals(ToolMode.SelectionSubMode.EXPAND, tool.selectionSubMode());

        tool.onRightClick(new Vec3i(5, 5, 5));
        tool.onLeftClick(new Vec3i(8, 5, 5));
        tool.onLeftClick(new Vec3i(5, 5, 2));

        assertEquals(BlockBox.of(new Vec3i(5, 5, 2), new Vec3i(8, 5, 5)),
                tool.activeSelection().activeBox().box());
    }

    @Test
    void modesThatDoNotDrawBoxesIgnoreClicks() {
        SchematicTool tool = new SchematicTool();
        tool.setMode(ToolMode.VARIANT_SWAP);
        assertFalse(tool.onLeftClick(new Vec3i(0, 0, 0)).handled());
        assertFalse(tool.onRightClick(new Vec3i(0, 0, 0)).handled());
    }

    @Test
    void survivalSkipsTheCreativeOnlyModes() {
        ToolMode mode = ToolMode.AREA_SELECTION;
        for (int i = 0; i < 20; i++) {
            mode = mode.next(false);
            assertFalse(mode.isCreativeOnly(), mode + " should not be reachable in survival");
        }
    }

    @Test
    void nudgingMovesWhicheverElementTheToolHolds() {
        SchematicTool tool = new SchematicTool();
        tool.onLeftClick(new Vec3i(0, 0, 0));
        tool.onRightClick(new Vec3i(4, 4, 4));

        AreaSelection selection = tool.activeSelection();
        // Holding the whole box: the size stays and the box slides.
        tool.onNudge(Direction.EAST, 2);
        assertEquals(new Vec3i(2, 0, 0), selection.activeBox().box().min());
        assertEquals(125, selection.activeBox().volume());

        // Holding a corner: the box resizes.
        selection.setSelectedCorner(SelectionBox.Corner.CORNER_2);
        tool.onNudge(Direction.UP, 3);
        assertEquals(new Vec3i(5, 8, 5), selection.activeBox().size());
    }

    // --- capture -------------------------------------------------------------------------------

    /** A tiny hand-built world: a 3x1x3 stone floor with one chest, everything else air. */
    private static WorldCaptureSource fakeWorld(Set<Vec3i> unloaded) {
        return new WorldCaptureSource() {
            @Override public BlockStateRef blockAt(int x, int y, int z) {
                if (y != 0 || x < 0 || x > 2 || z < 0 || z > 2) return BlockStateRef.AIR;
                return x == 1 && z == 1 ? CHEST : STONE;
            }
            @Override public boolean isLoaded(int x, int y, int z) {
                return !unloaded.contains(new Vec3i(x, y, z));
            }
            @Override public NbtCompound blockEntityAt(int x, int y, int z) {
                if (y == 0 && x == 1 && z == 1) {
                    NbtCompound tag = new NbtCompound();
                    tag.putString("id", "minecraft:chest");
                    return tag;
                }
                return null;
            }
            @Override public List<SchematicEntity> entitiesIn(BlockBox box) { return List.of(); }
        };
    }

    @Test
    void captureReadsTheSelectionIntoASchematic() {
        AreaSelection selection = new AreaSelection("floor");
        SelectionBox box = selection.addBox("main");
        box.setCorner1(new Vec3i(0, 0, 0));
        box.setCorner2(new Vec3i(2, 0, 2));

        WorldCapture.Result result =
                WorldCapture.capture(selection, fakeWorld(Set.of()), "floor", "tester");

        Schematic schematic = result.schematic();
        assertEquals(1, schematic.regionCount());
        assertEquals(new Vec3i(3, 1, 3), schematic.enclosingSize());
        assertEquals(9, result.capturedBlocks());
        assertEquals(1, result.blockEntities());
        assertTrue(result.isComplete());

        assertEquals(STONE, schematic.getBlock(0, 0, 0));
        assertEquals(CHEST, schematic.getBlock(1, 0, 1));
        assertEquals("tester", schematic.metadata().author());

        NbtCompound chest = schematic.region(0).blockEntity(new Vec3i(1, 0, 1));
        assertNotNull(chest);
        assertEquals("minecraft:chest", chest.getString("id", ""));
    }

    @Test
    void eachSubRegionBecomesItsOwnRegionRelativeToTheOrigin() {
        AreaSelection selection = new AreaSelection("two");
        SelectionBox first = selection.addBox("left");
        first.setCorner1(new Vec3i(0, 0, 0));
        first.setCorner2(new Vec3i(0, 0, 0));
        SelectionBox second = selection.addBox("right");
        second.setCorner1(new Vec3i(2, 0, 2));
        second.setCorner2(new Vec3i(2, 0, 2));

        WorldCapture.Result result =
                WorldCapture.capture(selection, fakeWorld(Set.of()), "two", "");

        assertEquals(2, result.schematic().regionCount());
        assertEquals("left", result.schematic().region(0).name());
        assertEquals(Vec3i.ZERO, result.schematic().region(0).origin());
        assertEquals(new Vec3i(2, 0, 2), result.schematic().region(1).origin());
        assertEquals(2, result.capturedBlocks(), "only the two selected blocks, not the gap");
    }

    @Test
    void unloadedPositionsAreReportedRatherThanSavedAsAir() {
        AreaSelection selection = new AreaSelection("floor");
        SelectionBox box = selection.addBox("main");
        box.setCorner1(new Vec3i(0, 0, 0));
        box.setCorner2(new Vec3i(2, 0, 2));

        Set<Vec3i> unloaded = Set.of(new Vec3i(0, 0, 0), new Vec3i(1, 0, 1));
        WorldCapture.Result result =
                WorldCapture.capture(selection, fakeWorld(unloaded), "floor", "");

        assertEquals(2, result.unloadedPositions());
        assertFalse(result.isComplete());
        assertEquals(7, result.capturedBlocks());
        assertTrue(result.schematic().getBlock(0, 0, 0).isAir(),
                "the unread position stays empty rather than being guessed");
    }

    @Test
    void capturedSchematicSurvivesARoundTripThroughTheCounts() {
        AreaSelection selection = new AreaSelection("floor");
        SelectionBox box = selection.addBox("main");
        box.setCorner1(new Vec3i(0, 0, 0));
        box.setCorner2(new Vec3i(2, 0, 2));

        Schematic schematic =
                WorldCapture.capture(selection, fakeWorld(Set.of()), "floor", "").schematic();

        Map<BlockStateRef, Integer> counts = new HashMap<>(schematic.countBlocks());
        assertEquals(8, counts.get(STONE));
        assertEquals(1, counts.get(CHEST));
    }
}
