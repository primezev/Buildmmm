package dev.buildmatic.core.block;

import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BlockStateRefTest {

    @Test
    void parsingIsOrderIndependentAndInterned() {
        BlockStateRef a = BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]");
        BlockStateRef b = BlockStateRef.parse("oak_stairs[shape=straight,half=bottom,facing=north]");
        assertSame(a, b, "identical states must intern to one instance");
        assertEquals("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]", a.descriptor());
    }

    @Test
    void exposesIdParts() {
        BlockStateRef state = BlockStateRef.parse("othermod:ruby_stairs[facing=east]");
        assertEquals("othermod", state.namespace());
        assertEquals("ruby_stairs", state.path());
        assertEquals("othermod:ruby_stairs", state.blockId());
        assertFalse(state.isVanilla());
    }

    @Test
    void distinguishesAirFromStructureVoid() {
        assertTrue(BlockStateRef.AIR.isAir());
        assertTrue(BlockStateRef.AIR.isEmpty());
        assertFalse(BlockStateRef.STRUCTURE_VOID.isAir());
        assertTrue(BlockStateRef.STRUCTURE_VOID.isEmpty());
    }

    @Test
    void derivationReusesInstancesWhenNothingChanges() {
        BlockStateRef state = BlockStateRef.parse("minecraft:oak_stairs[facing=north]");
        assertSame(state, state.with("facing", "north"));
        assertEquals("south", state.with("facing", "south").property("facing"));
        assertEquals("minecraft:spruce_stairs[facing=north]",
                state.withBlock("spruce_stairs").descriptor());
        assertEquals("minecraft:oak_stairs", state.bare().descriptor());
    }

    @Test
    void rejectsMalformedDescriptors() {
        assertThrows(IllegalArgumentException.class, () -> BlockStateRef.parse("minecraft:stone[broken"));
        assertThrows(IllegalArgumentException.class, () -> BlockStateRef.parse("minecraft:stone[novalue]"));
        assertThrows(IllegalArgumentException.class, () -> BlockStateRef.parse(""));
        assertSame(BlockStateRef.AIR,
                BlockStateRef.parseOrDefault("minecraft:stone[broken", BlockStateRef.AIR));
    }

    // --- rotation and mirroring ------------------------------------------------------------------

    @Test
    void rotatesFacing() {
        BlockStateRef stair = BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]");
        assertEquals("east", stair.rotate(Rotation.CLOCKWISE_90).property("facing"));
        assertEquals("south", stair.rotate(Rotation.CLOCKWISE_180).property("facing"));
        assertEquals("west", stair.rotate(Rotation.COUNTERCLOCKWISE_90).property("facing"));
        assertSame(stair, stair
                .rotate(Rotation.CLOCKWISE_90)
                .rotate(Rotation.CLOCKWISE_90)
                .rotate(Rotation.CLOCKWISE_90)
                .rotate(Rotation.CLOCKWISE_90));
    }

    @Test
    void mirrorFlipsStairHandednessOnlyOnTheMirroredAxis() {
        BlockStateRef stair = BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=inner_left]");
        BlockStateRef flipped = stair.mirror(Mirror.LEFT_RIGHT);
        assertEquals("south", flipped.property("facing"));
        assertEquals("inner_right", flipped.property("shape"));
        // A north-facing stair is unaffected by a west/east flip.
        assertSame(stair, stair.mirror(Mirror.FRONT_BACK));
    }

    @Test
    void rotatesPillarAxis() {
        BlockStateRef log = BlockStateRef.parse("minecraft:oak_log[axis=x]");
        assertEquals("z", log.rotate(Rotation.CLOCKWISE_90).property("axis"));
        assertEquals("x", log.rotate(Rotation.CLOCKWISE_180).property("axis"));
        assertEquals("y", BlockStateRef.parse("minecraft:oak_log[axis=y]")
                .rotate(Rotation.CLOCKWISE_90).property("axis"));
    }

    @Test
    void permutesFenceConnections() {
        BlockStateRef fence = BlockStateRef.parse(
                "minecraft:oak_fence[north=true,south=false,east=false,west=false]");
        BlockStateRef rotated = fence.rotate(Rotation.CLOCKWISE_90);
        assertEquals("true", rotated.property("east"));
        assertEquals("false", rotated.property("north"));

        BlockStateRef wall = BlockStateRef.parse(
                "minecraft:cobblestone_wall[north=tall,south=none,east=low,west=none]");
        BlockStateRef rotatedWall = wall.rotate(Rotation.CLOCKWISE_90);
        assertEquals("tall", rotatedWall.property("east"));
        assertEquals("low", rotatedWall.property("south"));
    }

    @Test
    void rotatesTheSixteenStepSignIndex() {
        BlockStateRef sign = BlockStateRef.parse("minecraft:oak_sign[rotation=0]");
        assertEquals("4", sign.rotate(Rotation.CLOCKWISE_90).property("rotation"));
        assertEquals("8", sign.rotate(Rotation.CLOCKWISE_180).property("rotation"));
        assertEquals("12", sign.rotate(Rotation.COUNTERCLOCKWISE_90).property("rotation"));
    }

    @Test
    void transformsRailShapes() {
        assertEquals("east_west", BlockStateRef.parse("minecraft:rail[shape=north_south]")
                .rotate(Rotation.CLOCKWISE_90).property("shape"));
        assertEquals("south_east", BlockStateRef.parse("minecraft:rail[shape=north_east]")
                .rotate(Rotation.CLOCKWISE_90).property("shape"));
        assertEquals("ascending_east", BlockStateRef.parse("minecraft:rail[shape=ascending_north]")
                .rotate(Rotation.CLOCKWISE_90).property("shape"));
        assertEquals("ascending_south", BlockStateRef.parse("minecraft:rail[shape=ascending_north]")
                .mirror(Mirror.LEFT_RIGHT).property("shape"));
    }

    @Test
    void flipsDoorHingesAndDoubleChestHalves() {
        BlockStateRef door = BlockStateRef.parse("minecraft:oak_door[facing=north,hinge=left,half=lower]");
        BlockStateRef mirrored = door.mirror(Mirror.LEFT_RIGHT);
        assertEquals("right", mirrored.property("hinge"));
        assertEquals("lower", mirrored.property("half"), "door half must not be treated as top/bottom");

        BlockStateRef chest = BlockStateRef.parse("minecraft:chest[facing=north,type=left]");
        assertEquals("right", chest.mirror(Mirror.LEFT_RIGHT).property("type"));

        // Slabs use `type` too, with a different domain, and must be left alone.
        BlockStateRef slab = BlockStateRef.parse("minecraft:oak_slab[type=top]");
        assertEquals("top", slab.mirror(Mirror.LEFT_RIGHT).property("type"));
    }
}
