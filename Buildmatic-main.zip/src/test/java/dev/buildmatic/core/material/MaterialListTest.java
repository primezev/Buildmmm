package dev.buildmatic.core.material;

import dev.buildmatic.core.block.BlockStateRef;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MaterialListTest {

    private static final ItemMapper MAPPER = ItemMapper.VANILLA;

    private static void costs(String descriptor, String itemId, int count) {
        assertEquals(new ItemMapper.Cost(itemId, count),
                MAPPER.costOf(BlockStateRef.parse(descriptor)), descriptor);
    }

    private static void isFree(String descriptor) {
        assertTrue(MAPPER.costOf(BlockStateRef.parse(descriptor)).isFree(), descriptor);
    }

    @Test
    void plainBlocksCostThemselves() {
        costs("minecraft:oak_planks", "minecraft:oak_planks", 1);
        costs("minecraft:stone", "minecraft:stone", 1);
    }

    @Test
    void aDoubleSlabCostsTwoSlabs() {
        costs("minecraft:oak_slab[type=double]", "minecraft:oak_slab", 2);
        costs("minecraft:oak_slab[type=top]", "minecraft:oak_slab", 1);
    }

    @Test
    void theSecondHalfOfATwoBlockStructureIsFree() {
        isFree("minecraft:oak_door[half=upper,facing=north,hinge=left]");
        isFree("minecraft:red_bed[part=head,facing=north]");
        isFree("minecraft:piston_head[facing=up]");
    }

    @Test
    void stackedBlocksChargePerUnit() {
        costs("minecraft:candle[candles=4,lit=false]", "minecraft:candle", 4);
        costs("minecraft:snow[layers=5]", "minecraft:snow", 5);
        costs("minecraft:sea_pickle[pickles=3]", "minecraft:sea_pickle", 3);
        costs("minecraft:turtle_egg[eggs=2]", "minecraft:turtle_egg", 2);
    }

    @Test
    void wallMountedVariantsCostTheirFreeStandingItem() {
        costs("minecraft:wall_torch[facing=north]", "minecraft:torch", 1);
        costs("minecraft:oak_wall_sign[facing=north]", "minecraft:oak_sign", 1);
        costs("minecraft:oak_wall_hanging_sign[facing=north]", "minecraft:oak_hanging_sign", 1);
        costs("minecraft:white_wall_banner[facing=north]", "minecraft:white_banner", 1);
    }

    @Test
    void blocksWhoseItemIsNamedDifferently() {
        costs("minecraft:redstone_wire[power=0]", "minecraft:redstone", 1);
        costs("minecraft:wheat[age=7]", "minecraft:wheat_seeds", 1);
        costs("minecraft:carrots[age=7]", "minecraft:carrot", 1);
        costs("minecraft:cocoa[age=2,facing=north]", "minecraft:cocoa_beans", 1);
    }

    @Test
    void fluidsCostBucketsAndOnlyAtTheSource() {
        costs("minecraft:water[level=0]", "minecraft:water_bucket", 1);
        costs("minecraft:lava[level=0]", "minecraft:lava_bucket", 1);
        isFree("minecraft:water[level=3]");
    }

    @Test
    void unobtainableBlocksAreFree() {
        isFree("minecraft:fire");
        isFree("minecraft:nether_portal[axis=x]");
        isFree("minecraft:cave_air");
        isFree("minecraft:air");
    }

    @Test
    void listAggregatesAndDiffsAgainstTheInventory() {
        Map<BlockStateRef, Integer> counts = new HashMap<>();
        counts.put(BlockStateRef.of("minecraft:oak_planks"), 100);
        counts.put(BlockStateRef.parse("minecraft:oak_slab[type=double]"), 10);
        counts.put(BlockStateRef.parse("minecraft:oak_door[half=upper,facing=north,hinge=left]"), 5);

        Map<String, Integer> inventory = new HashMap<>();
        inventory.put("minecraft:oak_planks", 64);

        MaterialList list = MaterialList.from(counts, MAPPER, inventory);
        assertEquals(2, list.distinctItems(), "the free door halves must not appear");
        assertEquals(120, list.totalItems());

        MaterialList.Entry planks = list.entries().stream()
                .filter(e -> e.itemId().equals("minecraft:oak_planks")).findFirst().orElseThrow();
        assertEquals(100, planks.required());
        assertEquals(64, planks.available());
        assertEquals(36, planks.missing());
        assertFalse(planks.isSatisfied());

        MaterialList.Entry slabs = list.entries().stream()
                .filter(e -> e.itemId().equals("minecraft:oak_slab")).findFirst().orElseThrow();
        assertEquals(20, slabs.required());

        assertFalse(list.isComplete());
        assertEquals(36 + 20, list.totalMissing(), "36 planks short plus all 20 slabs");
    }

    @Test
    void entriesSortMostMissingFirst() {
        Map<BlockStateRef, Integer> counts = new HashMap<>();
        counts.put(BlockStateRef.of("minecraft:stone"), 10);
        counts.put(BlockStateRef.of("minecraft:oak_planks"), 500);

        MaterialList list = MaterialList.from(counts, MAPPER, Map.of());
        assertEquals("minecraft:oak_planks", list.entries().get(0).itemId());
    }
}
