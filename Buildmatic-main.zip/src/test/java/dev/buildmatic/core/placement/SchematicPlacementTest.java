package dev.buildmatic.core.placement;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Mirror;
import dev.buildmatic.core.util.Rotation;
import dev.buildmatic.core.util.Vec3i;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SchematicPlacementTest {

    private static final BlockStateRef STAIR_NORTH =
            BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]");
    private static final BlockStateRef PLANKS = BlockStateRef.of("minecraft:oak_planks");
    private static final Vec3i ORIGIN = new Vec3i(100, 64, 200);

    private Schematic schematic;
    private SchematicPlacement placement;

    @BeforeEach
    void setUp() {
        // Deliberately non-cubic, so rotation anchoring is observable.
        schematic = Schematic.single("L", new Vec3i(4, 1, 2));
        SchematicRegion region = schematic.region(0);
        for (int x = 0; x < 4; x++) {
            for (int z = 0; z < 2; z++) {
                region.setBlock(x, 0, z, PLANKS);
            }
        }
        region.setBlock(0, 0, 0, STAIR_NORTH);
        schematic.refreshStatistics();

        placement = new SchematicPlacement(schematic, null, ORIGIN);
    }

    @Test
    void untransformedPlacementMapsOneToOne() {
        assertEquals(ORIGIN, placement.toWorld(Vec3i.ZERO));
        assertEquals(new Vec3i(103, 64, 201), placement.toWorld(new Vec3i(3, 0, 1)));
        assertEquals(BlockBox.of(ORIGIN, new Vec3i(103, 64, 201)), placement.worldBounds());
    }

    @Test
    void worldAndSchematicSpacesRoundTripUnderEveryTransform() {
        for (Rotation rotation : Rotation.values()) {
            for (Mirror mirror : Mirror.values()) {
                placement.setRotation(rotation);
                placement.setMirror(mirror);
                for (int x = 0; x < 4; x++) {
                    for (int z = 0; z < 2; z++) {
                        Vec3i local = new Vec3i(x, 0, z);
                        assertEquals(local, placement.toSchematic(placement.toWorld(local)),
                                rotation + " + " + mirror);
                    }
                }
            }
        }
    }

    @Test
    void rotatingSpinsTheBuildInPlaceRatherThanOrbitingIt() {
        for (Rotation rotation : Rotation.values()) {
            for (Mirror mirror : Mirror.values()) {
                placement.setRotation(rotation);
                placement.setMirror(mirror);
                assertEquals(ORIGIN, placement.worldBounds().min(),
                        "the build must stay anchored at the placement origin: "
                                + rotation + " + " + mirror);
            }
        }
    }

    @Test
    void aQuarterTurnSwapsTheFootprint() {
        placement.setRotation(Rotation.CLOCKWISE_90);
        assertEquals(new Vec3i(2, 1, 4), placement.worldBounds().size());
    }

    @Test
    void rotatingThePlacementAlsoRotatesTheBlockStates() {
        placement.setRotation(Rotation.CLOCKWISE_90);
        BlockStateRef stair = placement.expectedAt(placement.toWorld(Vec3i.ZERO));
        assertEquals("east", stair.property("facing"),
                "a rotated build whose stairs still face north would be wrong");
    }

    @Test
    void expectedAtIsNullOutsideTheBuild() {
        assertEquals(PLANKS, placement.expectedAt(new Vec3i(102, 64, 201)));
        assertNull(placement.expectedAt(new Vec3i(120, 64, 201)));
    }

    @Test
    void layerSliceHidesEverythingOutsideIt() {
        placement.setLayerRange(LayerRange.single(Direction.Axis.Y, 1));
        assertNull(placement.expectedAt(new Vec3i(102, 64, 201)));

        placement.setLayerRange(LayerRange.single(Direction.Axis.Y, 0));
        assertEquals(PLANKS, placement.expectedAt(new Vec3i(102, 64, 201)));
    }

    @Test
    void hidingARegionRemovesItFromThePlacement() {
        placement.setRegionVisible("main", false);
        assertNull(placement.expectedAt(new Vec3i(102, 64, 201)));

        placement.setRegionVisible("main", true);
        assertEquals(PLANKS, placement.expectedAt(new Vec3i(102, 64, 201)));
    }

    @Test
    void layerRangesNormaliseAndShift() {
        assertTrue(LayerRange.ALL_LAYERS.contains(new Vec3i(0, 999, 0)));

        LayerRange single = LayerRange.single(Direction.Axis.Y, 5);
        assertTrue(single.contains(new Vec3i(0, 5, 0)));
        assertEquals(6, single.shift(1).min());

        LayerRange reversed = LayerRange.range(Direction.Axis.X, 10, 2);
        assertEquals(2, reversed.min());
        assertEquals(10, reversed.max());
        assertTrue(reversed.contains(new Vec3i(5, 0, 0)));
    }
}
