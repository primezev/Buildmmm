package dev.buildmatic.core.render;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.placement.LayerRange;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Rotation;
import dev.buildmatic.core.util.Vec3i;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GhostRaycastTest {

    private static final BlockStateRef STONE = BlockStateRef.of("minecraft:stone");
    private static final BlockStateRef GLASS = BlockStateRef.of("minecraft:glass");

    private SchematicRegion region;
    private SchematicPlacement placement;

    @BeforeEach
    void setUp() {
        Schematic schematic = Schematic.single("Test", new Vec3i(8, 8, 8));
        region = schematic.region(0);
        placement = new SchematicPlacement(schematic, null, new Vec3i(0, 0, 0));
    }

    @Test
    void hitsTheFirstBlockAlongTheRay() {
        region.setBlock(4, 0, 0, STONE);

        GhostRaycast.Hit hit = GhostRaycast.trace(placement, null,
                0.5, 0.5, 0.5, 1, 0, 0, 20);

        assertNotNull(hit);
        assertEquals(new Vec3i(4, 0, 0), hit.localPos());
        assertEquals(STONE, hit.state());
        assertEquals(Direction.WEST, hit.face(), "the ray entered through the west face");
        assertTrue(hit.distance() > 3 && hit.distance() < 4.5);
    }

    @Test
    void stopsAtTheNearestBlockNotTheFarthest() {
        region.setBlock(2, 0, 0, GLASS);
        region.setBlock(5, 0, 0, STONE);

        GhostRaycast.Hit hit = GhostRaycast.trace(placement, null,
                0.5, 0.5, 0.5, 1, 0, 0, 20);

        assertEquals(GLASS, hit.state());
        assertEquals(new Vec3i(2, 0, 0), hit.localPos());
    }

    @Test
    void aRayStartingInsideABlockHitsIt() {
        region.setBlock(0, 0, 0, STONE);

        GhostRaycast.Hit hit = GhostRaycast.trace(placement, null,
                0.5, 0.5, 0.5, 1, 0, 0, 20);

        assertEquals(new Vec3i(0, 0, 0), hit.localPos());
        assertNull(hit.face(), "no face was crossed to get there");
    }

    @Test
    void missesWhenNothingIsInTheWay() {
        region.setBlock(4, 4, 4, STONE);

        assertNull(GhostRaycast.trace(placement, null, 0.5, 0.5, 0.5, 1, 0, 0, 20));
    }

    @Test
    void respectsTheMaximumDistance() {
        region.setBlock(7, 0, 0, STONE);

        assertNull(GhostRaycast.trace(placement, null, 0.5, 0.5, 0.5, 1, 0, 0, 3));
        assertNotNull(GhostRaycast.trace(placement, null, 0.5, 0.5, 0.5, 1, 0, 0, 20));
    }

    @Test
    void tracesDiagonallyWithoutSkippingCells() {
        // A wall the diagonal ray must not slip between.
        for (int y = 0; y < 8; y++) {
            for (int z = 0; z < 8; z++) {
                region.setBlock(5, y, z, STONE);
            }
        }
        GhostRaycast.Hit hit = GhostRaycast.trace(placement, null,
                0.5, 0.5, 0.5, 1, 0.4, 0.35, 30);

        assertNotNull(hit, "a grazing ray must still hit a solid wall");
        assertEquals(5, hit.localPos().x());
    }

    @Test
    void tracesDownwards() {
        region.setBlock(0, 0, 0, STONE);

        GhostRaycast.Hit hit = GhostRaycast.trace(placement, null,
                0.5, 6.5, 0.5, 0, -1, 0, 20);

        assertEquals(new Vec3i(0, 0, 0), hit.localPos());
        assertEquals(Direction.UP, hit.face());
    }

    @Test
    void ignoresBlocksOutsideTheLayerSlice() {
        region.setBlock(4, 0, 0, STONE);
        region.setBlock(4, 2, 0, STONE);

        placement.setLayerRange(LayerRange.single(Direction.Axis.Y, 2));
        assertNull(GhostRaycast.trace(placement, null, 0.5, 0.5, 0.5, 1, 0, 0, 20),
                "the sliced-away row must not be targetable");

        GhostRaycast.Hit hit = GhostRaycast.trace(placement, null, 0.5, 2.5, 0.5, 1, 0, 0, 20);
        assertEquals(new Vec3i(4, 2, 0), hit.localPos());
    }

    @Test
    void ignoresHiddenRegions() {
        region.setBlock(4, 0, 0, STONE);
        placement.setRegionVisible("main", false);

        assertNull(GhostRaycast.trace(placement, null, 0.5, 0.5, 0.5, 1, 0, 0, 20));
    }

    @Test
    void followsTheRotatedPlacement() {
        region.setBlock(4, 0, 0, STONE);
        placement.setRotation(Rotation.CLOCKWISE_90);

        // After a quarter turn the block sits along +Z instead of +X.
        Vec3i expectedWorld = placement.toWorld(new Vec3i(4, 0, 0));
        GhostRaycast.Hit hit = GhostRaycast.trace(placement, null,
                expectedWorld.x() + 0.5, expectedWorld.y() + 0.5, expectedWorld.z() - 3.5,
                0, 0, 1, 20);

        assertNotNull(hit);
        assertEquals(new Vec3i(4, 0, 0), hit.localPos());
        assertEquals(expectedWorld, hit.worldPos());
    }

    @Test
    void aZeroLengthDirectionIsRejected() {
        region.setBlock(0, 0, 0, STONE);
        assertNull(GhostRaycast.trace(placement, null, 0.5, 0.5, 0.5, 0, 0, 0, 20));
    }
}
