package dev.buildmatic.core.render;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.placement.LayerRange;
import dev.buildmatic.core.placement.SchematicPlacement;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.swap.SwapLayer;
import dev.buildmatic.core.swap.SwapRule;
import dev.buildmatic.core.util.Direction;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;
import dev.buildmatic.core.verify.WorldView;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GhostSliceBuilderTest {

    private static final BlockStateRef STONE = BlockStateRef.of("minecraft:stone");
    private static final BlockStateRef GLASS = BlockStateRef.of("minecraft:glass");
    private static final SwapEngine.ChunkKey SLICE = new SwapEngine.ChunkKey("main", 0, 0, 0);

    private Schematic schematic;
    private SchematicRegion region;
    private SchematicPlacement placement;
    private SwapEngine swaps;

    @BeforeEach
    void setUp() {
        schematic = Schematic.single("Test", new Vec3i(16, 16, 16));
        region = schematic.region(0);
        VariantIndex variants = VariantIndex.build(
                List.of("minecraft:stone", "minecraft:glass", "minecraft:oak_planks",
                        "minecraft:spruce_planks"),
                ColorIndex.EMPTY);
        swaps = new SwapEngine(schematic, variants, BlockStateSchema.PERMISSIVE);
        placement = new SchematicPlacement(schematic, swaps, new Vec3i(0, 0, 0));
    }

    private GhostSlice build(GhostSliceBuilder.Context context) {
        return GhostSliceBuilder.build(region, SLICE, context);
    }

    private GhostSliceBuilder.Context context() {
        return GhostSliceBuilder.Context.of(placement, swaps);
    }

    @Test
    void anEmptyRegionDrawsNothing() {
        assertTrue(build(context()).isEmpty());
    }

    /**
     * The renderer only translates each block to its world position, so the entry has to carry the
     * state already turned. Storing the schematic's own orientation drew a rotated build with every
     * door, trapdoor and stair still facing the way it did before the turn, and made the preview
     * disagree with what pasting produced.
     */
    @Test
    void rotatingThePlacementTurnsTheBlocksAsWellAsTheirPositions() {
        BlockStateRef northDoor = BlockStateRef.parse(
                "minecraft:oak_door[facing=north,half=lower,hinge=left,open=false]");
        region.setBlock(5, 5, 5, northDoor);

        assertEquals(northDoor, build(context()).entries().get(0).state());

        placement.setRotation(dev.buildmatic.core.util.Rotation.CLOCKWISE_90);
        GhostSlice.Entry turned = build(context()).entries().get(0);

        assertEquals("east", turned.state().properties().get("facing"));
        // Everything else about a door is untouched by a turn.
        assertEquals("lower", turned.state().properties().get("half"));
        assertEquals("left", turned.state().properties().get("hinge"));
        assertEquals("false", turned.state().properties().get("open"));
        // The entry is still addressed in schematic-local space; only the state is in world space.
        assertEquals(new Vec3i(5, 5, 5), turned.localPos());
    }

    @Test
    void aLoneBlockDrawsAllSixFaces() {
        region.setBlock(5, 5, 5, STONE);

        GhostSlice slice = build(context());
        assertEquals(1, slice.size());
        assertEquals(6, slice.drawnFaces());

        GhostSlice.Entry entry = slice.entries().get(0);
        assertEquals(new Vec3i(5, 5, 5), entry.localPos());
        assertEquals(STONE, entry.state());
        for (Direction direction : Direction.values()) {
            assertTrue(entry.isFaceVisible(direction), direction.toString());
        }
    }

    @Test
    void touchingCubesHideTheFaceBetweenThem() {
        region.setBlock(5, 5, 5, STONE);
        region.setBlock(6, 5, 5, STONE);

        GhostSlice slice = build(context());
        assertEquals(2, slice.size());
        assertEquals(10, slice.drawnFaces(), "the shared face is drawn from neither side");

        GhostSlice.Entry west = slice.entries().stream()
                .filter(e -> e.localPos().x() == 5).findFirst().orElseThrow();
        assertFalse(west.isFaceVisible(Direction.EAST));
        assertTrue(west.isFaceVisible(Direction.WEST));
    }

    @Test
    void aBlockFullyEnclosedInStoneIsDroppedEntirely() {
        region.setBlock(5, 5, 5, STONE);
        for (Direction direction : Direction.values()) {
            Vec3i n = new Vec3i(5, 5, 5).offset(direction);
            region.setBlock(n, STONE);
        }
        GhostSlice slice = build(context());
        assertFalse(slice.entries().stream().anyMatch(e -> e.localPos().equals(new Vec3i(5, 5, 5))),
                "a completely buried block contributes no geometry");
    }

    @Test
    void transparentNeighboursDoNotOcclude() {
        region.setBlock(5, 5, 5, STONE);
        region.setBlock(6, 5, 5, GLASS);

        GhostSlice slice = build(context());
        GhostSlice.Entry stone = slice.entries().stream()
                .filter(e -> e.state().equals(STONE)).findFirst().orElseThrow();
        assertTrue(stone.isFaceVisible(Direction.EAST), "glass must not hide what is behind it");
    }

    @Test
    void theRegionEdgeIsAlwaysDrawn() {
        region.setBlock(0, 0, 0, STONE);
        GhostSlice.Entry entry = build(context()).entries().get(0);
        assertTrue(entry.isFaceVisible(Direction.WEST));
        assertTrue(entry.isFaceVisible(Direction.DOWN));
        assertTrue(entry.isFaceVisible(Direction.NORTH));
    }

    @Test
    void theLayerSliceRemovesRowsAndExposesTheCut() {
        for (int y = 0; y < 4; y++) region.setBlock(5, y, 5, STONE);
        placement.setLayerRange(LayerRange.single(Direction.Axis.Y, 1));

        GhostSlice slice = build(context());
        assertEquals(1, slice.size());

        GhostSlice.Entry entry = slice.entries().get(0);
        assertEquals(1, entry.localPos().y());
        assertTrue(entry.isFaceVisible(Direction.UP),
                "the sliced-away neighbour must not keep the cut face hidden");
        assertTrue(entry.isFaceVisible(Direction.DOWN));
    }

    @Test
    void theSliceOnlyCoversItsOwnSixteenCube() {
        region.setBlock(1, 1, 1, STONE);
        region.setBlock(1, 1, 1 + 16 >= 16 ? 15 : 1, STONE);

        Schematic big = Schematic.single("Big", new Vec3i(32, 16, 16));
        SchematicRegion bigRegion = big.region(0);
        bigRegion.setBlock(1, 1, 1, STONE);
        bigRegion.setBlock(17, 1, 1, STONE);

        SwapEngine bigSwaps = new SwapEngine(big,
                VariantIndex.build(List.of("minecraft:stone"), ColorIndex.EMPTY),
                BlockStateSchema.PERMISSIVE);
        SchematicPlacement bigPlacement = new SchematicPlacement(big, bigSwaps, Vec3i.ZERO);
        GhostSliceBuilder.Context bigContext = GhostSliceBuilder.Context.of(bigPlacement, bigSwaps);

        GhostSlice first = GhostSliceBuilder.build(bigRegion,
                new SwapEngine.ChunkKey("main", 0, 0, 0), bigContext);
        GhostSlice second = GhostSliceBuilder.build(bigRegion,
                new SwapEngine.ChunkKey("main", 1, 0, 0), bigContext);

        assertEquals(1, first.size());
        assertEquals(new Vec3i(1, 1, 1), first.entries().get(0).localPos());
        assertEquals(1, second.size());
        assertEquals(new Vec3i(17, 1, 1), second.entries().get(0).localPos());
    }

    @Test
    void slicesOfCoversTheWholeRegion() {
        Schematic big = Schematic.single("Big", new Vec3i(33, 17, 16));
        assertEquals(3 * 2 * 1, GhostSliceBuilder.slicesOf(big.region(0)).size());
    }

    @Test
    void theSliceShowsTheSwappedStateNotTheOriginal() {
        region.setBlock(5, 5, 5, BlockStateRef.of("minecraft:oak_planks"));
        swaps.addLayer(SwapLayer.of("oak -> spruce", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce"))));

        assertEquals(BlockStateRef.of("minecraft:spruce_planks"),
                build(context()).entries().get(0).state());
    }

    @Test
    void theSwappedFilterShowsOnlyEditedBlocks() {
        region.setBlock(5, 5, 5, BlockStateRef.of("minecraft:oak_planks"));
        region.setBlock(8, 5, 5, STONE);
        swaps.addLayer(SwapLayer.of("oak -> spruce", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce"))));

        GhostSlice slice = build(context().withFilter(GhostSliceBuilder.Filter.SWAPPED));
        assertEquals(1, slice.size());
        assertEquals(new Vec3i(5, 5, 5), slice.entries().get(0).localPos());
    }

    // --- world-aware filtering -------------------------------------------------------------------

    private WorldView worldOf(Map<Vec3i, BlockStateRef> blocks) {
        return new WorldView() {
            @Override public BlockStateRef blockAt(int x, int y, int z) {
                return blocks.getOrDefault(new Vec3i(x, y, z), BlockStateRef.AIR);
            }
            @Override public boolean isLoaded(int x, int y, int z) { return true; }
        };
    }

    @Test
    void statusReflectsWhatIsAlreadyBuilt() {
        region.setBlock(1, 1, 1, STONE);
        region.setBlock(3, 1, 1, STONE);
        region.setBlock(5, 1, 1, STONE);

        Map<Vec3i, BlockStateRef> world = new HashMap<>();
        world.put(new Vec3i(1, 1, 1), STONE);
        world.put(new Vec3i(3, 1, 1), GLASS);

        GhostSlice slice = build(context().withWorld(worldOf(world)));
        Map<Vec3i, GhostSlice.Status> byPos = new HashMap<>();
        for (GhostSlice.Entry entry : slice.entries()) byPos.put(entry.localPos(), entry.status());

        assertEquals(GhostSlice.Status.PLACED, byPos.get(new Vec3i(1, 1, 1)));
        assertEquals(GhostSlice.Status.WRONG, byPos.get(new Vec3i(3, 1, 1)));
        assertEquals(GhostSlice.Status.MISSING, byPos.get(new Vec3i(5, 1, 1)));
    }

    @Test
    void theMissingFilterHidesWhatIsAlreadyDone() {
        region.setBlock(1, 1, 1, STONE);
        region.setBlock(5, 1, 1, STONE);

        Map<Vec3i, BlockStateRef> world = new HashMap<>();
        world.put(new Vec3i(1, 1, 1), STONE);

        GhostSlice slice = build(context()
                .withWorld(worldOf(world))
                .withFilter(GhostSliceBuilder.Filter.MISSING));

        assertEquals(1, slice.size());
        assertEquals(new Vec3i(5, 1, 1), slice.entries().get(0).localPos());
    }

    @Test
    void unloadedChunksLeaveTheStatusUnknownRatherThanMissing() {
        region.setBlock(1, 1, 1, STONE);
        WorldView unloaded = new WorldView() {
            @Override public BlockStateRef blockAt(int x, int y, int z) { return BlockStateRef.AIR; }
            @Override public boolean isLoaded(int x, int y, int z) { return false; }
        };
        assertEquals(GhostSlice.Status.UNKNOWN,
                build(context().withWorld(unloaded)).entries().get(0).status());
    }

    @Test
    void occlusionHeuristicKnowsItsSpecialCases() {
        assertTrue(OcclusionOracle.HEURISTIC.occludesNeighbourFace(STONE));
        assertTrue(OcclusionOracle.HEURISTIC.occludesNeighbourFace(
                BlockStateRef.of("minecraft:oak_planks")));
        assertTrue(OcclusionOracle.HEURISTIC.occludesNeighbourFace(
                BlockStateRef.parse("minecraft:oak_slab[type=double]")));

        assertFalse(OcclusionOracle.HEURISTIC.occludesNeighbourFace(GLASS));
        assertFalse(OcclusionOracle.HEURISTIC.occludesNeighbourFace(
                BlockStateRef.of("minecraft:oak_leaves")));
        assertFalse(OcclusionOracle.HEURISTIC.occludesNeighbourFace(
                BlockStateRef.parse("minecraft:oak_slab[type=top]")));
        assertFalse(OcclusionOracle.HEURISTIC.occludesNeighbourFace(
                BlockStateRef.parse("minecraft:oak_stairs[facing=north]")));
        assertFalse(OcclusionOracle.HEURISTIC.occludesNeighbourFace(BlockStateRef.AIR));
        assertFalse(OcclusionOracle.HEURISTIC.occludesNeighbourFace(
                BlockStateRef.parse("minecraft:stone[waterlogged=true]")));
    }
}
