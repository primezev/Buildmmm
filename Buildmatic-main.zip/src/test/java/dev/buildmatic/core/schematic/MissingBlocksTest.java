package dev.buildmatic.core.schematic;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.util.Vec3i;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MissingBlocksTest {

    /** A game that only has vanilla, which is what an unmodded client looks like. */
    private static final BlockStateSchema VANILLA_ONLY = new BlockStateSchema() {
        @Override public Set<String> propertiesOf(String blockId) { return Set.of(); }
        @Override public List<String> valuesOf(String blockId, String property) { return List.of(); }
        @Override public BlockStateRef defaultState(String blockId) { return BlockStateRef.of(blockId); }
        @Override public boolean isKnownBlock(String blockId) {
            return blockId.startsWith("minecraft:");
        }
    };

    private Schematic schematic;
    private SchematicRegion region;

    @BeforeEach
    void setUp() {
        schematic = Schematic.single("Test", new Vec3i(16, 16, 16));
        region = schematic.region(0);
    }

    private void fill(BlockStateRef state, int count) {
        for (int i = 0; i < count; i++) region.setBlock(i % 16, i / 16, 0, state);
    }

    @Test
    void aVanillaBuildIsMissingNothing() {
        fill(BlockStateRef.of("minecraft:stone"), 10);
        schematic.refreshStatistics();

        MissingBlocks missing = MissingBlocks.scan(schematic, VANILLA_ONLY);
        assertTrue(missing.isEmpty());
        assertEquals(0, missing.total());
        assertEquals("", missing.describe());
    }

    @Test
    void countsWhatTheGameDoesNotHaveAndGroupsItByMod() {
        region.setBlock(0, 0, 0, BlockStateRef.of("minecraft:stone"));
        region.setBlock(1, 0, 0, BlockStateRef.of("mcwwindows:dark_oak_four_window"));
        region.setBlock(2, 0, 0, BlockStateRef.of("mcwwindows:oak_four_window"));
        region.setBlock(3, 0, 0, BlockStateRef.of("mcwwindows:oak_four_window"));
        region.setBlock(4, 0, 0, BlockStateRef.of("amendments:wall_lantern"));
        schematic.refreshStatistics();

        MissingBlocks missing = MissingBlocks.scan(schematic, VANILLA_ONLY);

        assertFalse(missing.isEmpty());
        assertEquals(4, missing.total());
        assertEquals(2, missing.modCount());
        assertEquals(3, missing.byNamespace().get("mcwwindows"));
        assertEquals(1, missing.byNamespace().get("amendments"));
        // The mod that costs the most blocks is named first, since it is the one worth installing.
        assertEquals("mcwwindows", missing.byNamespace().keySet().iterator().next());
        assertTrue(missing.describe().startsWith("4 blocks from 2 missing mods: mcwwindows (3)"),
                missing.describe());
    }

    @Test
    void airIsNeverReportedEvenWhenTheSchemaRejectsIt() {
        region.setBlock(0, 0, 0, BlockStateRef.of("minecraft:stone"));
        schematic.refreshStatistics();

        MissingBlocks missing = MissingBlocks.scan(schematic, new BlockStateSchema() {
            @Override public Set<String> propertiesOf(String id) { return Set.of(); }
            @Override public List<String> valuesOf(String id, String p) { return List.of(); }
            @Override public BlockStateRef defaultState(String id) { return BlockStateRef.of(id); }
            @Override public boolean isKnownBlock(String id) { return false; }
        });

        assertEquals(1, missing.total());
        assertFalse(missing.byBlock().containsKey("minecraft:air"));
    }

    @Test
    void theShortFormDropsTheNamesForLinesThatAlreadyCarryCounts() {
        region.setBlock(0, 0, 0, BlockStateRef.of("mcwwindows:oak_four_window"));
        region.setBlock(1, 0, 0, BlockStateRef.of("amendments:wall_lantern"));
        schematic.refreshStatistics();

        MissingBlocks missing = MissingBlocks.scan(schematic, VANILLA_ONLY);
        assertEquals("2 blocks from 2 missing mods", missing.describeShort());
    }

    @Test
    void bothFormsReadCorrectlyForASingleBlockFromASingleMod() {
        region.setBlock(0, 0, 0, BlockStateRef.of("chipped:oak_planks_1"));
        schematic.refreshStatistics();

        MissingBlocks missing = MissingBlocks.scan(schematic, VANILLA_ONLY);
        assertEquals("1 block from 1 missing mod", missing.describeShort());
        assertEquals("1 block from 1 missing mod: chipped (1)", missing.describe());
    }

    @Test
    void longListsAreTruncatedRatherThanRunningOffTheStatusBar() {
        for (int i = 0; i < 6; i++) {
            region.setBlock(i, 0, 0, BlockStateRef.of("mod" + i + ":block"));
        }
        schematic.refreshStatistics();

        MissingBlocks missing = MissingBlocks.scan(schematic, VANILLA_ONLY);
        assertEquals(6, missing.modCount());
        assertTrue(missing.describe().endsWith(", and 3 more"), missing.describe());
    }
}
