package dev.buildmatic.core.schematic;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtIo;
import dev.buildmatic.core.schematic.format.LitematicaFormat;
import dev.buildmatic.core.schematic.format.SpongeSchematicFormat;
import dev.buildmatic.core.schematic.format.VanillaStructureFormat;
import dev.buildmatic.core.util.Vec3i;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SchematicFormatsTest {

    private static final BlockStateRef STAIRS =
            BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]");
    private static final BlockStateRef PLANKS = BlockStateRef.of("minecraft:oak_planks");
    private static final BlockStateRef STONE = BlockStateRef.of("minecraft:stone");

    private Schematic schematic;

    @BeforeEach
    void buildSample() {
        schematic = Schematic.single("Test Build", new Vec3i(16, 8, 16));
        schematic.metadata().setAuthor("Buildmatic").setDescription("fixture");
        SchematicRegion region = schematic.region(0);

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                region.setBlock(x, 0, z, STONE);
                region.setBlock(x, 1, z, PLANKS);
            }
        }
        for (int x = 0; x < 16; x++) {
            region.setBlock(x, 2, 0, STAIRS);
        }

        NbtCompound chest = new NbtCompound();
        chest.putString("id", "minecraft:chest");
        region.blockEntities().put(new Vec3i(3, 2, 3), chest);

        schematic.refreshStatistics();
    }

    @Test
    void countsBlocksCorrectly() {
        assertEquals(256, schematic.countBlocks().get(STONE));
        assertEquals(256, schematic.countBlocks().get(PLANKS));
        assertEquals(16, schematic.countBlocks().get(STAIRS));
        assertEquals(528L, schematic.totalBlocks());
        assertEquals(16 * 8 * 16L, schematic.totalVolume());
    }

    @Test
    void litematicaSurvivesAFileRoundTrip(@TempDir Path dir) throws IOException {
        Path file = dir.resolve("build.litematic");
        NbtIo.write("", LitematicaFormat.write(schematic, 4189), file, true);
        assertTrue(Files.size(file) > 0);

        Schematic reloaded = LitematicaFormat.read(NbtIo.read(file));
        assertEquals("Test Build", reloaded.metadata().name());
        assertEquals("Buildmatic", reloaded.metadata().author());
        assertEquals(4189, reloaded.metadata().dataVersion());
        assertEquals(new Vec3i(16, 8, 16), reloaded.enclosingSize());
        assertEquals(schematic.countBlocks(), reloaded.countBlocks());
        assertEquals(STAIRS, reloaded.getBlock(5, 2, 0));

        NbtCompound chest = reloaded.region(0).blockEntity(new Vec3i(3, 2, 3));
        assertNotNull(chest);
        assertEquals("minecraft:chest", chest.getString("id", ""));

        assertAllBlocksMatch(schematic, reloaded);
    }

    @Test
    void litematicaNormalisesNegativeRegionSizes() throws IOException {
        NbtCompound root = LitematicaFormat.write(schematic, 4189);
        NbtCompound region = root.getCompound("Regions").getCompound("main");

        // Re-express the same box from the opposite corner, the way an in-game selection can.
        region.getCompound("Position").putInt("x", 15);
        region.getCompound("Size").putInt("x", -16);

        Schematic reloaded = LitematicaFormat.read(root);
        assertEquals(Vec3i.ZERO, reloaded.region(0).origin());
        assertEquals(new Vec3i(16, 8, 16), reloaded.region(0).size());
    }

    @Test
    void spongeVersion3SurvivesARoundTrip() throws IOException {
        Schematic reloaded = SpongeSchematicFormat.read(SpongeSchematicFormat.write(schematic, 4189, 3));
        assertEquals(schematic.enclosingSize(), reloaded.enclosingSize());
        assertEquals(schematic.countBlocks(), reloaded.countBlocks());
        assertAllBlocksMatch(schematic, reloaded);
    }

    @Test
    void spongeVersion2SurvivesARoundTrip() throws IOException {
        Schematic reloaded = SpongeSchematicFormat.read(SpongeSchematicFormat.write(schematic, 4189, 2));
        assertEquals(schematic.countBlocks(), reloaded.countBlocks());
        assertAllBlocksMatch(schematic, reloaded);
    }

    @Test
    void vanillaStructureSurvivesARoundTrip() throws IOException {
        Schematic reloaded = VanillaStructureFormat.read(VanillaStructureFormat.write(schematic, 4189));
        assertEquals(schematic.countBlocks(), reloaded.countBlocks());
        assertAllBlocksMatch(schematic, reloaded);
    }

    /**
     * A structure file written by Minecraft rather than by Buildmatic.
     *
     * <p>The round trip above cannot catch this: Buildmatic's own writer always emits air at palette
     * slot 0, so reading its own output hides the assumption. Vanilla orders the palette by first
     * appearance, and a solid build has no air in it at all - which used to leave every position
     * absent from {@code blocks} pointing at slot 0 and come back as a solid cube of whatever that
     * was.
     */
    @Test
    void vanillaStructureWithoutAirAtPaletteSlotZeroReadsAsAir() throws IOException {
        NbtCompound root = new NbtCompound();
        root.putInt("DataVersion", 4189);
        root.put("size", dev.buildmatic.core.nbt.NbtList.ofInts(3, 1, 3));

        var palette = new dev.buildmatic.core.nbt.NbtList(
                dev.buildmatic.core.nbt.NbtTag.TAG_COMPOUND);
        palette.add(namedBlock("minecraft:dirt"));
        palette.add(namedBlock("minecraft:oak_planks"));
        root.put("palette", palette);

        var blocks = new dev.buildmatic.core.nbt.NbtList(
                dev.buildmatic.core.nbt.NbtTag.TAG_COMPOUND);
        blocks.add(positioned(0, 0, 0, 0));
        blocks.add(positioned(2, 0, 2, 1));
        root.put("blocks", blocks);

        Schematic loaded = VanillaStructureFormat.read(root);
        SchematicRegion region = loaded.regions().get(0);

        assertEquals("minecraft:dirt", region.getBlock(new Vec3i(0, 0, 0)).blockId());
        assertEquals("minecraft:oak_planks", region.getBlock(new Vec3i(2, 0, 2)).blockId());
        // The seven positions the file never mentions are air, not seven more blocks of dirt.
        assertEquals(1, loaded.countBlocks().get(BlockStateRef.of("minecraft:dirt")));
        for (Vec3i pos : new Vec3i[]{new Vec3i(1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(1, 0, 1),
                new Vec3i(2, 0, 0), new Vec3i(0, 0, 2), new Vec3i(1, 0, 2), new Vec3i(2, 0, 1)}) {
            assertTrue(region.getBlock(pos).isEmpty(), pos + " should be air");
        }
    }

    private static NbtCompound namedBlock(String id) {
        NbtCompound entry = new NbtCompound();
        entry.putString("Name", id);
        return entry;
    }

    private static NbtCompound positioned(int x, int y, int z, int state) {
        NbtCompound entry = new NbtCompound();
        entry.put("pos", dev.buildmatic.core.nbt.NbtList.ofInts(x, y, z));
        entry.putInt("state", state);
        return entry;
    }

    @Test
    void detectsFormatsFromContentAndFileName() throws IOException {
        assertEquals(SchematicFormat.LITEMATICA,
                SchematicFormat.byContent(LitematicaFormat.write(schematic, 0)));
        assertEquals(SchematicFormat.SPONGE,
                SchematicFormat.byContent(SpongeSchematicFormat.write(schematic, 0, 3)));
        assertEquals(SchematicFormat.VANILLA_STRUCTURE,
                SchematicFormat.byContent(VanillaStructureFormat.write(schematic, 0)));

        assertEquals(SchematicFormat.LITEMATICA, SchematicFormat.byFileName("house.litematic"));
        assertEquals(SchematicFormat.SPONGE, SchematicFormat.byFileName("HOUSE.SCHEM"));
        assertEquals(SchematicFormat.VANILLA_STRUCTURE, SchematicFormat.byFileName("a/b/house.nbt"));
    }

    @Test
    void nbtReadsBothCompressedAndPlainFiles(@TempDir Path dir) throws IOException {
        NbtCompound root = LitematicaFormat.write(schematic, 4189);

        Path gzipped = dir.resolve("gz.litematic");
        NbtIo.write("", root, gzipped, true);
        Path plain = dir.resolve("plain.litematic");
        NbtIo.write("", root, plain, false);

        assertEquals(schematic.countBlocks(), LitematicaFormat.read(NbtIo.read(gzipped)).countBlocks());
        assertEquals(schematic.countBlocks(), LitematicaFormat.read(NbtIo.read(plain)).countBlocks());
        assertTrue(Files.size(gzipped) < Files.size(plain), "gzip should shrink a uniform build");
    }

    @Test
    void flattensMultipleRegionsOnExport() throws IOException {
        Schematic multi = new Schematic();
        multi.metadata().setName("Two towers");
        SchematicRegion a = new SchematicRegion("a", Vec3i.ZERO, new Vec3i(2, 2, 2));
        SchematicRegion b = new SchematicRegion("b", new Vec3i(10, 0, 0), new Vec3i(2, 2, 2));
        a.setBlock(0, 0, 0, STONE);
        b.setBlock(0, 0, 0, PLANKS);
        multi.addRegion(a);
        multi.addRegion(b);
        multi.refreshStatistics();

        Schematic flattened = SpongeSchematicFormat.read(SpongeSchematicFormat.write(multi, 0, 3));
        assertEquals(1, flattened.regionCount());
        assertEquals(new Vec3i(12, 2, 2), flattened.enclosingSize());
        assertEquals(STONE, flattened.getBlock(0, 0, 0));
        assertEquals(PLANKS, flattened.getBlock(10, 0, 0));
    }

    private static void assertAllBlocksMatch(Schematic expected, Schematic actual) {
        Vec3i size = expected.enclosingSize();
        for (int y = 0; y < size.y(); y++) {
            for (int z = 0; z < size.z(); z++) {
                for (int x = 0; x < size.x(); x++) {
                    assertEquals(expected.getBlock(x, y, z), actual.getBlock(x, y, z),
                            "block at " + x + "," + y + "," + z);
                }
            }
        }
    }
}
