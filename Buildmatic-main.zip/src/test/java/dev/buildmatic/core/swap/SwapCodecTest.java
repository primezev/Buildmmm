package dev.buildmatic.core.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.nbt.NbtCompound;
import dev.buildmatic.core.nbt.NbtList;
import dev.buildmatic.core.nbt.NbtTag;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.theme.BuildThemes;
import dev.buildmatic.core.theme.ThemeVariant;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.BlockShape;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SwapCodecTest {

    private static SwapRule roundTrip(SwapRule rule) {
        SwapLayer layer = SwapLayer.of("test", rule);
        NbtCompound tag = SwapCodec.write(layer);
        assertNotNull(tag, "the rule could not be written: " + rule.describe());
        SwapLayer read = SwapCodec.read(tag);
        assertNotNull(read, "the rule could not be read back: " + rule.describe());
        assertEquals(1, read.rules().size());
        return read.rules().get(0);
    }

    @Test
    void everyMatcherSurvives() {
        SwapRule.Target target = new SwapRule.Target.Block("minecraft:spruce_planks");
        for (SwapRule.Matcher matcher : List.of(
                new SwapRule.Matcher.Exact(
                        BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom]")),
                new SwapRule.Matcher.Block("minecraft:oak_planks"),
                new SwapRule.Matcher.Material("oak"),
                new SwapRule.Matcher.Shape(BlockShape.STAIRS),
                new SwapRule.Matcher.Any())) {
            SwapRule rule = SwapRule.of(matcher, target);
            assertEquals(rule, roundTrip(rule));
        }
    }

    @Test
    void everyTargetSurvives() {
        SwapRule.Matcher matcher = new SwapRule.Matcher.Block("minecraft:oak_planks");
        for (SwapRule.Target target : List.of(
                new SwapRule.Target.State(BlockStateRef.parse("minecraft:spruce_slab[type=top]")),
                new SwapRule.Target.Block("minecraft:spruce_planks"),
                new SwapRule.Target.Material("spruce"),
                new SwapRule.Target.Shape(BlockShape.SLAB),
                new SwapRule.Target.Themed(BuildThemes.MEDIEVAL),
                new SwapRule.Target.Remove(),
                new SwapRule.Target.Weighted(List.of(
                        new SwapRule.Target.WeightedEntry("minecraft:stone", 70),
                        new SwapRule.Target.WeightedEntry("minecraft:cobblestone", 30)), 1234L))) {
            SwapRule rule = SwapRule.of(matcher, target);
            assertEquals(rule, roundTrip(rule));
        }
    }

    @Test
    void everyScopeSurvives() {
        SwapRule.Matcher matcher = new SwapRule.Matcher.Any();
        SwapRule.Target target = new SwapRule.Target.Block("minecraft:glass");
        for (SwapRule.Scope scope : List.of(
                new SwapRule.Scope.Everywhere(),
                new SwapRule.Scope.Region("main"),
                new SwapRule.Scope.Box("main",
                        new BlockBox(new Vec3i(1, 2, 3), new Vec3i(9, 8, 7))),
                new SwapRule.Scope.Positions("main", Set.of(
                        new Vec3i(1, 2, 3), new Vec3i(-4, 5, -6), new Vec3i(0, 0, 0))))) {
            SwapRule rule = new SwapRule(matcher, target, scope);
            assertEquals(rule, roundTrip(rule));
        }
    }

    @Test
    void layerIdentityAndStateSurvive() {
        SwapLayer layer = SwapLayer.of("oak -> spruce", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce")));
        layer.setEnabled(false);

        SwapLayer read = SwapCodec.read(SwapCodec.write(layer));
        assertNotNull(read);
        assertEquals(layer.id(), read.id(), "a layer must come back as the same layer");
        assertEquals("oak -> spruce", read.name());
        assertFalse(read.isEnabled(), "a layer switched off must not come back switched on");
    }

    @Test
    void aThemeSurvivesAWholeRoundTripThroughTheEngine() {
        VariantIndex variants = VariantIndex.build(List.of(
                "minecraft:stone", "minecraft:stone_bricks", "minecraft:cobblestone",
                "minecraft:oak_planks", "minecraft:spruce_planks", "minecraft:redstone_wire"),
                ColorIndex.EMPTY);

        Schematic schematic = Schematic.single("Test", new Vec3i(4, 3, 4));
        SchematicRegion region = schematic.region(0);
        region.setBlock(0, 0, 0, BlockStateRef.of("minecraft:stone"));
        region.setBlock(1, 0, 0, BlockStateRef.of("minecraft:oak_planks"));
        region.setBlock(2, 0, 0, BlockStateRef.of("minecraft:redstone_wire"));
        schematic.refreshStatistics();

        SwapEngine engine = new SwapEngine(schematic, variants, BlockStateSchema.PERMISSIVE);
        engine.addLayer(SwapLayer.of("Medieval theme", SwapRule.of(
                new SwapRule.Matcher.Any(), new SwapRule.Target.Themed(BuildThemes.MEDIEVAL))));

        NbtList saved = SwapCodec.writeAll(engine.layers());

        SwapEngine reopened = new SwapEngine(schematic, variants, BlockStateSchema.PERMISSIVE);
        assertEquals(0, SwapCodec.readInto(reopened, saved));

        assertEquals(BlockStateRef.of("minecraft:stone_bricks"), reopened.stateAt(region, 0, 0, 0));
        assertEquals(BlockStateRef.of("minecraft:spruce_planks"), reopened.stateAt(region, 1, 0, 0));
        assertEquals(BlockStateRef.of("minecraft:redstone_wire"), reopened.stateAt(region, 2, 0, 0));
    }

    // --- what a corrupt or outdated file must do --------------------------------------------------

    @Test
    void theCombinationSurvivesNotJustTheTheme() {
        ThemeVariant mossy = BuildThemes.MEDIEVAL.variantById("mossy");
        assertNotNull(mossy);

        SwapRule rule = SwapRule.of(new SwapRule.Matcher.Any(),
                new SwapRule.Target.Themed(BuildThemes.MEDIEVAL, mossy));
        SwapRule read = roundTrip(rule);

        assertEquals(rule, read);
        assertEquals(mossy, ((SwapRule.Target.Themed) read.target()).variant(),
                "coming back as the default combination would be a different build");
    }

    @Test
    void aFileWrittenBeforeCombinationsExistedMeansTheDefault() {
        // Layers saved by the first version of this feature carry a theme and no combination.
        NbtCompound target = new NbtCompound()
                .putString("Type", "themed").putString("Theme", "medieval");

        SwapLayer read = SwapCodec.read(layerWith(target));
        assertNotNull(read, "an older save file must still open");
        assertEquals(BuildThemes.MEDIEVAL.defaultVariant(),
                ((SwapRule.Target.Themed) read.rules().get(0).target()).variant());
    }

    @Test
    void aCombinationThatNoLongerExistsTakesItsLayerWithIt() {
        NbtCompound target = new NbtCompound().putString("Type", "themed")
                .putString("Theme", "medieval").putString("Variant", "art_deco");
        assertNull(SwapCodec.read(layerWith(target)),
                "falling back to the default would restyle the build into something else");
    }

    @Test
    void aThemeThatNoLongerExistsTakesItsLayerWithIt() {
        NbtCompound target = new NbtCompound()
                .putString("Type", "themed").putString("Theme", "steampunk");
        assertNull(SwapCodec.read(layerWith(target)),
                "guessing a replacement theme would restyle the build behind the player's back");
    }

    @Test
    void anUnknownRuleTypeDropsTheWholeLayer() {
        NbtCompound target = new NbtCompound().putString("Type", "teleport");
        assertNull(SwapCodec.read(layerWith(target)));
    }

    @Test
    void unreadableLayersAreCountedRatherThanSwallowed() {
        NbtList list = new NbtList(NbtTag.TAG_COMPOUND);
        list.add(layerWith(new NbtCompound().putString("Type", "block")
                .putString("Block", "minecraft:glass")));
        list.add(layerWith(new NbtCompound().putString("Type", "themed")
                .putString("Theme", "steampunk")));

        VariantIndex variants = VariantIndex.build(List.of("minecraft:glass"), ColorIndex.EMPTY);
        Schematic schematic = Schematic.single("Test", new Vec3i(2, 2, 2));
        SwapEngine engine = new SwapEngine(schematic, variants, BlockStateSchema.PERMISSIVE);

        assertEquals(1, SwapCodec.readInto(engine, list));
        assertEquals(1, engine.layers().size(), "the readable layer must still arrive");
    }

    @Test
    void aLayerIsDroppedWholeRatherThanHalfApplied() {
        NbtList rules = new NbtList(NbtTag.TAG_COMPOUND);
        rules.add(rule(new NbtCompound().putString("Type", "block")
                .putString("Block", "minecraft:glass")));
        rules.add(rule(new NbtCompound().putString("Type", "nonsense")));

        NbtCompound layer = new NbtCompound();
        layer.putString("Id", "x");
        layer.putString("Name", "half broken");
        layer.put("Rules", rules);

        assertNull(SwapCodec.read(layer));
    }

    @Test
    void writingSkipsNothingItCanExpress() {
        SwapLayer layer = new SwapLayer("many rules");
        layer.addRule(SwapRule.of(new SwapRule.Matcher.Any(),
                new SwapRule.Target.Themed(BuildThemes.DESERT)));
        layer.addRule(SwapRule.of(new SwapRule.Matcher.Material("oak"),
                new SwapRule.Target.Material("acacia")));

        NbtCompound tag = SwapCodec.write(layer);
        assertNotNull(tag);
        SwapLayer read = SwapCodec.read(tag);
        assertNotNull(read);
        assertEquals(layer.rules(), read.rules());
        assertTrue(read.isPaletteResolvable());
    }

    private static NbtCompound layerWith(NbtCompound target) {
        NbtList rules = new NbtList(NbtTag.TAG_COMPOUND);
        rules.add(rule(target));

        NbtCompound layer = new NbtCompound();
        layer.putString("Id", "test");
        layer.putString("Name", "test");
        layer.put("Rules", rules);
        return layer;
    }

    private static NbtCompound rule(NbtCompound target) {
        NbtCompound rule = new NbtCompound();
        rule.put("Matcher", new NbtCompound().putString("Type", "any"));
        rule.put("Target", target);
        rule.put("Scope", new NbtCompound().putString("Type", "everywhere"));
        return rule;
    }
}
