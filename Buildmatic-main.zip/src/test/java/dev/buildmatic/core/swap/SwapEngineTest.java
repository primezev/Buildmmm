package dev.buildmatic.core.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.BlockBox;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.BlockShape;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SwapEngineTest {

    private static final BlockStateRef STAIRS =
            BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]");
    private static final BlockStateRef PLANKS = BlockStateRef.of("minecraft:oak_planks");
    private static final BlockStateRef STONE = BlockStateRef.of("minecraft:stone");

    private Schematic schematic;
    private SchematicRegion region;
    private VariantIndex variants;
    private SwapEngine engine;

    @BeforeEach
    void setUp() {
        schematic = Schematic.single("Test", new Vec3i(16, 8, 16));
        region = schematic.region(0);
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                region.setBlock(x, 0, z, STONE);
                region.setBlock(x, 1, z, PLANKS);
            }
        }
        for (int x = 0; x < 16; x++) {
            region.setBlock(x, 2, 0, STAIRS);
        }
        schematic.refreshStatistics();

        variants = VariantIndex.build(sampleRegistry(), ColorIndex.EMPTY);
        engine = new SwapEngine(schematic, variants, BlockStateSchema.PERMISSIVE);
    }

    private static List<String> sampleRegistry() {
        List<String> ids = new ArrayList<>();
        for (String wood : List.of("oak", "spruce", "birch", "jungle", "acacia", "dark_oak")) {
            ids.add("minecraft:" + wood + "_planks");
            ids.add("minecraft:" + wood + "_stairs");
            ids.add("minecraft:" + wood + "_slab");
            ids.add("minecraft:" + wood + "_fence");
            ids.add("minecraft:stripped_" + wood + "_log");
        }
        for (String stone : List.of("stone", "cobblestone", "stone_brick", "granite", "andesite")) {
            ids.add("minecraft:" + stone + "_stairs");
            ids.add("minecraft:" + stone + "_slab");
        }
        ids.add("minecraft:stone");
        ids.add("minecraft:cobblestone");
        ids.add("minecraft:andesite");
        ids.add("minecraft:glass");
        return ids;
    }

    @Test
    void withoutLayersNothingChanges() {
        assertEquals(PLANKS, engine.stateAt(region, 5, 1, 5));
        assertEquals(STAIRS, engine.stateAt(region, 5, 2, 0));
        assertFalse(engine.isSwapped(region, 5, 1, 5));
    }

    @Test
    void materialSwapConvertsEveryShapeAndKeepsProperties() {
        engine.addLayer(SwapLayer.of("oak -> spruce", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce"))));

        assertEquals(BlockStateRef.of("minecraft:spruce_planks"), engine.stateAt(region, 5, 1, 5));
        assertEquals(
                BlockStateRef.parse("minecraft:spruce_stairs[facing=north,half=bottom,shape=straight]"),
                engine.stateAt(region, 5, 2, 0),
                "a variant swap must preserve facing, half and shape");
        assertEquals(STONE, engine.stateAt(region, 5, 0, 5), "unrelated blocks stay put");
    }

    @Test
    void wholeSchematicRulesUseThePaletteFastPath() {
        SwapLayer layer = SwapLayer.of("oak -> spruce", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce")));
        assertTrue(layer.isPaletteResolvable());
        engine.addLayer(layer);
        assertTrue(engine.hasDirtyChunks());
    }

    @Test
    void layersChainInOrder() {
        engine.addLayer(SwapLayer.of("a", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce"))));
        engine.addLayer(SwapLayer.of("b", SwapRule.of(
                new SwapRule.Matcher.Material("spruce"), new SwapRule.Target.Material("birch"))));

        assertEquals(BlockStateRef.of("minecraft:birch_planks"), engine.stateAt(region, 5, 1, 5));
    }

    @Test
    void disablingALayerRevertsOnlyThatStep() {
        SwapLayer first = SwapLayer.of("a", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce")));
        engine.addLayer(first);
        engine.addLayer(SwapLayer.of("b", SwapRule.of(
                new SwapRule.Matcher.Material("spruce"), new SwapRule.Target.Material("birch"))));

        engine.setLayerEnabled(first, false);
        assertEquals(PLANKS, engine.stateAt(region, 5, 1, 5));

        engine.setLayerEnabled(first, true);
        assertEquals(BlockStateRef.of("minecraft:birch_planks"), engine.stateAt(region, 5, 1, 5));
    }

    @Test
    void removingALayerUndoesIt() {
        SwapLayer layer = SwapLayer.of("a", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce")));
        engine.addLayer(layer);
        assertTrue(engine.isSwapped(region, 5, 1, 5));

        engine.removeLayer(layer);
        assertEquals(PLANKS, engine.stateAt(region, 5, 1, 5));
        assertFalse(engine.isSwapped(region, 5, 1, 5));
    }

    @Test
    void singleBlockScopeTouchesOnlyThatBlockAndOneChunk() {
        SwapLayer layer = SwapLayer.of("one block", new SwapRule(
                new SwapRule.Matcher.Any(),
                new SwapRule.Target.Block("minecraft:glass"),
                new SwapRule.Scope.Positions("main", Set.of(new Vec3i(5, 1, 5)))));
        engine.addLayer(layer);

        assertFalse(layer.isPaletteResolvable());
        assertEquals(BlockStateRef.of("minecraft:glass"), engine.stateAt(region, 5, 1, 5));
        assertEquals(PLANKS, engine.stateAt(region, 6, 1, 5));
        assertEquals(1, engine.consumeDirtyChunks().size(),
                "a one-block swap must not invalidate the whole build");
    }

    @Test
    void boxScopeAppliesOnlyInsideTheBox() {
        engine.addLayer(SwapLayer.of("box", new SwapRule(
                new SwapRule.Matcher.Block("minecraft:oak_planks"),
                new SwapRule.Target.Block("minecraft:glass"),
                new SwapRule.Scope.Box("main", BlockBox.of(new Vec3i(0, 1, 0), new Vec3i(3, 1, 3))))));

        assertEquals(BlockStateRef.of("minecraft:glass"), engine.stateAt(region, 2, 1, 2));
        assertEquals(PLANKS, engine.stateAt(region, 8, 1, 8));
    }

    @Test
    void shapeMatcherCatchesEveryMaterial() {
        engine.addLayer(SwapLayer.of("all stairs", SwapRule.of(
                new SwapRule.Matcher.Shape(BlockShape.STAIRS),
                new SwapRule.Target.Material("granite"))));

        assertEquals(BlockStateRef.parse(
                        "minecraft:granite_stairs[facing=north,half=bottom,shape=straight]"),
                engine.stateAt(region, 5, 2, 0));
        assertEquals(PLANKS, engine.stateAt(region, 5, 1, 5), "planks are not stairs");
    }

    @Test
    void shapeTargetChangesFormWhileKeepingMaterial() {
        engine.addLayer(SwapLayer.of("planks -> slabs", SwapRule.of(
                new SwapRule.Matcher.Block("minecraft:oak_planks"),
                new SwapRule.Target.Shape(BlockShape.SLAB))));

        assertEquals("minecraft:oak_slab", engine.stateAt(region, 5, 1, 5).blockId());
    }

    @Test
    void weightedNoiseIsDeterministicAcrossEngines() {
        SwapRule.Target.Weighted target = new SwapRule.Target.Weighted(List.of(
                new SwapRule.Target.WeightedEntry("minecraft:stone", 70),
                new SwapRule.Target.WeightedEntry("minecraft:cobblestone", 20),
                new SwapRule.Target.WeightedEntry("minecraft:andesite", 10)), 1234L);

        List<BlockStateRef> first = sample(target);
        List<BlockStateRef> second = sample(target);

        assertEquals(first, second, "the same seed and position must always give the same block");
        assertTrue(first.stream().distinct().count() > 1, "weights should actually mix blocks");
    }

    private List<BlockStateRef> sample(SwapRule.Target target) {
        SwapEngine noise = new SwapEngine(schematic, variants, BlockStateSchema.PERMISSIVE);
        noise.addLayer(SwapLayer.of("noise", SwapRule.of(
                new SwapRule.Matcher.Block("minecraft:stone"), target)));
        List<BlockStateRef> result = new ArrayList<>();
        for (int x = 0; x < 16; x++) result.add(noise.stateAt(region, x, 0, 0));
        return result;
    }

    @Test
    void effectiveCountsDriveTheMaterialList() {
        engine.addLayer(SwapLayer.of("oak -> spruce", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce"))));
        engine.addLayer(SwapLayer.of("one block", new SwapRule(
                new SwapRule.Matcher.Any(),
                new SwapRule.Target.Block("minecraft:glass"),
                new SwapRule.Scope.Positions("main", Set.of(new Vec3i(5, 1, 5))))));

        Map<BlockStateRef, Integer> counts = engine.countEffectiveBlocks();
        assertEquals(255, counts.get(BlockStateRef.of("minecraft:spruce_planks")));
        assertEquals(1, counts.get(BlockStateRef.of("minecraft:glass")));
        assertEquals(256, counts.get(STONE));
        assertNull(counts.get(PLANKS), "swapped-away blocks must not appear in the material list");
    }

    @Test
    void bakingIsPermanentButLeavesTheOriginalAlone() {
        engine.addLayer(SwapLayer.of("oak -> spruce", SwapRule.of(
                new SwapRule.Matcher.Material("oak"), new SwapRule.Target.Material("spruce"))));
        engine.addLayer(SwapLayer.of("one block", new SwapRule(
                new SwapRule.Matcher.Any(),
                new SwapRule.Target.Block("minecraft:glass"),
                new SwapRule.Scope.Positions("main", Set.of(new Vec3i(5, 1, 5))))));

        Schematic baked = engine.bake();
        assertEquals(BlockStateRef.of("minecraft:spruce_planks"), baked.getBlock(6, 1, 5));
        assertEquals(BlockStateRef.of("minecraft:glass"), baked.getBlock(5, 1, 5));
        assertEquals(PLANKS, schematic.getBlock(6, 1, 5), "the source schematic must be untouched");
    }

    @Test
    void removeTargetDeletesBlocks() {
        engine.addLayer(SwapLayer.of("strip stairs", SwapRule.of(
                new SwapRule.Matcher.Shape(BlockShape.STAIRS), new SwapRule.Target.Remove())));

        assertTrue(engine.stateAt(region, 5, 2, 0).isAir());
        assertNull(engine.countEffectiveBlocks().get(STAIRS));
    }
}
