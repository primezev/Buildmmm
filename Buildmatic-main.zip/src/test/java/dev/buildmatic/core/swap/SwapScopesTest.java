package dev.buildmatic.core.swap;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import dev.buildmatic.core.variant.BlockTraits;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SwapScopesTest {

    private static final BlockStateRef PLANKS = BlockStateRef.of("minecraft:oak_planks");
    private static final BlockStateRef STAIR_N =
            BlockStateRef.parse("minecraft:oak_stairs[facing=north]");
    private static final BlockStateRef STAIR_S =
            BlockStateRef.parse("minecraft:oak_stairs[facing=south]");
    private static final BlockStateRef STONE = BlockStateRef.of("minecraft:stone");

    private SchematicRegion region;
    private VariantIndex variants;

    @BeforeEach
    void setUp() {
        Schematic schematic = Schematic.single("Test", new Vec3i(8, 4, 8));
        region = schematic.region(0);
        variants = VariantIndex.build(List.of(
                "minecraft:oak_planks", "minecraft:oak_stairs", "minecraft:oak_slab",
                "minecraft:spruce_planks", "minecraft:stone"), ColorIndex.EMPTY);
    }

    @Test
    void floodFillSpreadsThroughConnectedBlocksOnly() {
        // Two 3-block planks bars on the same row, separated by one air gap.
        for (int x = 0; x < 3; x++) region.setBlock(x, 0, 0, PLANKS);
        for (int x = 4; x < 7; x++) region.setBlock(x, 0, 0, PLANKS);

        SwapScopes.FloodResult result = SwapScopes.flood(
                region, new Vec3i(0, 0, 0), SwapScopes.Strictness.SAME_BLOCK, variants);

        assertEquals(3, result.size(), "the fill must stop at the gap");
        assertFalse(result.hitLimit());
        assertTrue(result.positions().contains(new Vec3i(2, 0, 0)));
        assertFalse(result.positions().contains(new Vec3i(4, 0, 0)));
    }

    @Test
    void floodFillDoesNotLeakDiagonally() {
        // A checkerboard: touching only at the corners.
        region.setBlock(0, 0, 0, PLANKS);
        region.setBlock(1, 0, 1, PLANKS);
        region.setBlock(2, 0, 2, PLANKS);

        SwapScopes.FloodResult result = SwapScopes.flood(
                region, new Vec3i(0, 0, 0), SwapScopes.Strictness.SAME_BLOCK, variants);

        assertEquals(1, result.size(), "corner contact is not connectivity");
    }

    @Test
    void floodFillRespectsStrictness() {
        region.setBlock(0, 0, 0, STAIR_N);
        region.setBlock(1, 0, 0, STAIR_S);
        region.setBlock(2, 0, 0, PLANKS);
        region.setBlock(3, 0, 0, STONE);

        assertEquals(1, SwapScopes.flood(region, new Vec3i(0, 0, 0),
                SwapScopes.Strictness.EXACT_STATE, variants).size(),
                "a differently facing stair is a different state");

        assertEquals(2, SwapScopes.flood(region, new Vec3i(0, 0, 0),
                SwapScopes.Strictness.SAME_BLOCK, variants).size(),
                "both stairs are the same block");

        assertEquals(3, SwapScopes.flood(region, new Vec3i(0, 0, 0),
                SwapScopes.Strictness.SAME_MATERIAL, variants).size(),
                "stairs and planks are both oak, stone is not");
    }

    @Test
    void floodFillStopsAtItsLimitAndSaysSo() {
        for (int x = 0; x < 8; x++) {
            for (int z = 0; z < 8; z++) {
                region.setBlock(x, 0, z, PLANKS);
            }
        }
        SwapScopes.FloodResult result = SwapScopes.flood(
                region, Vec3i.ZERO, SwapScopes.Strictness.SAME_BLOCK, variants, 10);

        assertEquals(10, result.size());
        assertTrue(result.hitLimit(), "hitting the cap must be reported, not hidden");
    }

    @Test
    void floodFillFromEmptySpaceFindsNothing() {
        assertEquals(0, SwapScopes.flood(region, new Vec3i(4, 2, 4),
                SwapScopes.Strictness.SAME_BLOCK, variants).size());
    }

    @Test
    void matchersPairWithTheIntendedBreadth() {
        assertTrue(SwapScopes.matcherFor(STAIR_N, SwapScopes.Strictness.EXACT_STATE, variants)
                instanceof SwapRule.Matcher.Exact);
        assertTrue(SwapScopes.matcherFor(STAIR_N, SwapScopes.Strictness.SAME_BLOCK, variants)
                instanceof SwapRule.Matcher.Block);

        SwapRule.Matcher material =
                SwapScopes.matcherFor(STAIR_N, SwapScopes.Strictness.SAME_MATERIAL, variants);
        assertTrue(material instanceof SwapRule.Matcher.Material);
        assertEquals("oak", ((SwapRule.Matcher.Material) material).material());
    }

    @Test
    void anUnknownBlockFallsBackToMatchingItself() {
        BlockStateRef modded = BlockStateRef.of("othermod:mystery_block");
        SwapRule.Matcher matcher =
                SwapScopes.matcherFor(modded, SwapScopes.Strictness.SAME_MATERIAL, variants);
        assertTrue(matcher instanceof SwapRule.Matcher.Block);
    }
}
