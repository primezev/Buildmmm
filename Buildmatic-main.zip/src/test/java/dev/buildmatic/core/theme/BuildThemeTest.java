package dev.buildmatic.core.theme;

import dev.buildmatic.core.block.BlockStateRef;
import dev.buildmatic.core.block.BlockStateSchema;
import dev.buildmatic.core.schematic.Schematic;
import dev.buildmatic.core.schematic.SchematicRegion;
import dev.buildmatic.core.swap.SwapEngine;
import dev.buildmatic.core.swap.SwapLayer;
import dev.buildmatic.core.swap.SwapRule;
import dev.buildmatic.core.util.Vec3i;
import dev.buildmatic.core.variant.BlockShape;
import dev.buildmatic.core.variant.ColorIndex;
import dev.buildmatic.core.variant.VariantIndex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The theme tests are mostly about what must <em>not</em> happen. A restyle that looks right and
 * quietly stops a piston is worse than one that leaves a few blocks alone.
 */
class BuildThemeTest {

    private VariantIndex variants;

    @BeforeEach
    void setUp() {
        variants = VariantIndex.build(sampleRegistry(), ColorIndex.EMPTY);
    }

    /** Enough of the vanilla registry for the palettes to resolve against. */
    private static List<String> sampleRegistry() {
        List<String> ids = new ArrayList<>();

        for (String wood : List.of("oak", "spruce", "birch", "jungle", "acacia", "dark_oak",
                "cherry", "bamboo", "bamboo_mosaic", "warped", "crimson")) {
            ids.add("minecraft:" + wood + "_planks");
            ids.add("minecraft:" + wood + "_stairs");
            ids.add("minecraft:" + wood + "_slab");
        }
        for (String wood : List.of("oak", "spruce", "birch", "jungle", "acacia", "dark_oak",
                "cherry", "bamboo", "warped", "crimson")) {
            ids.add("minecraft:" + wood + "_fence");
            ids.add("minecraft:" + wood + "_fence_gate");
            ids.add("minecraft:" + wood + "_door");
            ids.add("minecraft:" + wood + "_trapdoor");
            ids.add("minecraft:" + wood + "_button");
            ids.add("minecraft:" + wood + "_pressure_plate");
        }
        // Only the woods that really have leaves and logs, so the fixture cannot make a swap look
        // possible that the game would refuse.
        for (String wood : List.of("oak", "spruce", "birch", "jungle", "acacia", "dark_oak",
                "cherry")) {
            ids.add("minecraft:" + wood + "_leaves");
            ids.add("minecraft:" + wood + "_log");
        }

        for (String stone : List.of("stone_brick", "mossy_stone_brick", "cobblestone",
                "mossy_cobblestone", "deepslate_brick", "deepslate_tile", "polished_deepslate",
                "cobbled_deepslate", "granite", "polished_granite", "andesite", "polished_andesite",
                "diorite", "polished_diorite", "quartz",
                "smooth_quartz", "sandstone", "smooth_sandstone",
                "red_sandstone", "smooth_red_sandstone", "dark_prismarine",
                "prismarine_brick", "purpur", "nether_brick", "red_nether_brick",
                "blackstone", "polished_blackstone", "polished_blackstone_brick",
                "tuff", "polished_tuff", "tuff_brick")) {
            ids.add("minecraft:" + stone + "_stairs");
            ids.add("minecraft:" + stone + "_slab");
        }
        // Copper, in every weathering the game exposes as a building material. Only the fresh one
        // is called a block; the weathered three are bare ids.
        ids.add("minecraft:copper_block");
        ids.add("minecraft:exposed_copper");
        ids.add("minecraft:weathered_copper");
        ids.add("minecraft:oxidized_copper");
        for (String copper : List.of("cut_copper", "exposed_cut_copper", "weathered_cut_copper",
                "oxidized_cut_copper")) {
            ids.add("minecraft:" + copper);
            ids.add("minecraft:" + copper + "_stairs");
            ids.add("minecraft:" + copper + "_slab");
            ids.add("minecraft:waxed_" + copper);
        }
        ids.add("minecraft:waxed_copper_block");

        // Slabs without a matching stair, exactly as vanilla has them.
        ids.add("minecraft:smooth_stone_slab");
        ids.add("minecraft:cut_sandstone_slab");
        ids.add("minecraft:cut_red_sandstone_slab");
        for (String walled : List.of("cobblestone", "mossy_cobblestone", "stone_brick",
                "mossy_stone_brick", "deepslate_brick", "granite", "andesite", "diorite",
                "sandstone", "red_sandstone", "nether_brick", "red_nether_brick",
                "blackstone", "polished_blackstone", "polished_blackstone_brick",
                "tuff", "polished_tuff", "tuff_brick")) {
            ids.add("minecraft:" + walled + "_wall");
        }

        ids.addAll(List.of(
                "minecraft:stone", "minecraft:smooth_stone", "minecraft:stone_bricks",
                "minecraft:mossy_stone_bricks", "minecraft:cracked_stone_bricks",
                "minecraft:chiseled_stone_bricks", "minecraft:cobblestone",
                "minecraft:mossy_cobblestone", "minecraft:granite", "minecraft:polished_granite",
                "minecraft:andesite", "minecraft:polished_andesite", "minecraft:diorite",
                "minecraft:deepslate", "minecraft:cobbled_deepslate", "minecraft:polished_deepslate",
                "minecraft:deepslate_bricks", "minecraft:deepslate_tiles", "minecraft:blackstone",
                "minecraft:quartz_block", "minecraft:smooth_quartz", "minecraft:quartz_bricks",
                "minecraft:chiseled_quartz_block", "minecraft:quartz_pillar",
                "minecraft:sandstone", "minecraft:smooth_sandstone", "minecraft:cut_sandstone",
                "minecraft:chiseled_sandstone", "minecraft:red_sandstone",
                "minecraft:smooth_red_sandstone", "minecraft:cut_red_sandstone",
                "minecraft:dark_prismarine", "minecraft:prismarine_bricks",
                "minecraft:white_concrete", "minecraft:light_gray_concrete",
                "minecraft:gray_concrete", "minecraft:black_concrete",
                "minecraft:brown_terracotta", "minecraft:orange_terracotta",
                "minecraft:white_terracotta", "minecraft:terracotta",
                "minecraft:polished_blackstone", "minecraft:polished_blackstone_bricks",
                "minecraft:nether_bricks", "minecraft:red_nether_bricks",
                "minecraft:tuff", "minecraft:polished_tuff", "minecraft:tuff_bricks",
                "minecraft:chiseled_tuff", "minecraft:chiseled_red_sandstone",
                "minecraft:bricks", "minecraft:mud_bricks",
                "minecraft:dirt", "minecraft:coarse_dirt", "minecraft:grass_block",
                "minecraft:sand", "minecraft:red_sand", "minecraft:gravel",
                "minecraft:glowstone", "minecraft:sea_lantern", "minecraft:shroomlight",
                "minecraft:glass", "minecraft:glass_pane", "minecraft:water", "minecraft:air"));

        // The dyed families, including the ones that carry a block entity and must stay put.
        for (String colour : ThemeColours.all()) {
            ids.add("minecraft:" + colour + "_wool");
            ids.add("minecraft:" + colour + "_carpet");
            ids.add("minecraft:" + colour + "_concrete");
            ids.add("minecraft:" + colour + "_concrete_powder");
            ids.add("minecraft:" + colour + "_terracotta");
            ids.add("minecraft:" + colour + "_glazed_terracotta");
            ids.add("minecraft:" + colour + "_stained_glass");
            ids.add("minecraft:" + colour + "_stained_glass_pane");
            ids.add("minecraft:" + colour + "_bed");
            ids.add("minecraft:" + colour + "_banner");
            ids.add("minecraft:" + colour + "_shulker_box");
            ids.add("minecraft:" + colour + "_candle");
        }

        // The things a restyle must not touch.
        ids.addAll(List.of(
                "minecraft:redstone_wire", "minecraft:redstone_torch", "minecraft:redstone_lamp",
                "minecraft:redstone_block", "minecraft:repeater", "minecraft:comparator",
                "minecraft:observer", "minecraft:piston", "minecraft:sticky_piston",
                "minecraft:piston_head", "minecraft:tnt", "minecraft:hopper",
                "minecraft:dispenser", "minecraft:dropper", "minecraft:lever", "minecraft:target",
                "minecraft:note_block", "minecraft:chest", "minecraft:trapped_chest",
                "minecraft:furnace", "minecraft:rail", "minecraft:powered_rail",
                "minecraft:detector_rail", "minecraft:activator_rail", "minecraft:slime_block",
                "minecraft:honey_block", "minecraft:obsidian", "minecraft:iron_door",
                "minecraft:iron_trapdoor", "minecraft:stone_button", "minecraft:stone_pressure_plate",
                "minecraft:polished_blackstone_pressure_plate", "minecraft:daylight_detector",
                "minecraft:sculk_sensor", "minecraft:oak_sign", "minecraft:spawner",
                "minecraft:command_block"));
        return ids;
    }

    private String retarget(BuildTheme theme, String blockId) {
        return theme.retargetId(blockId, variants);
    }

    // --- the look ---------------------------------------------------------------------------------

    @Test
    void medievalRedressesStoneAndWood() {
        BuildTheme medieval = BuildThemes.MEDIEVAL;

        assertEquals("minecraft:stone_bricks", retarget(medieval, "minecraft:stone"));
        assertEquals("minecraft:cobblestone", retarget(medieval, "minecraft:andesite"));
        assertEquals("minecraft:spruce_planks", retarget(medieval, "minecraft:oak_planks"));
        assertEquals("minecraft:spruce_stairs", retarget(medieval, "minecraft:oak_stairs"));
        assertEquals("minecraft:dark_oak_fence", retarget(medieval, "minecraft:spruce_fence"),
                "spruce reads as the dark wood, so it moves to dark oak rather than standing still");
    }

    @Test
    void propertiesSurviveARestyle() {
        BlockStateRef stair =
                BlockStateRef.parse("minecraft:oak_stairs[facing=north,half=bottom,shape=straight]");
        BlockStateRef result =
                BuildThemes.MEDIEVAL.retarget(stair, variants, BlockStateSchema.PERMISSIVE);

        assertEquals(BlockStateRef.parse(
                        "minecraft:spruce_stairs[facing=north,half=bottom,shape=straight]"),
                result);
    }

    @Test
    void brickFormsAreTreatedAsDetailingRatherThanBulk() {
        // stone and stone bricks must not collapse onto the same block, or the build flattens.
        assertEquals("minecraft:mossy_stone_bricks",
                retarget(BuildThemes.MEDIEVAL, "minecraft:stone_bricks"));
        assertEquals("minecraft:stone_bricks", retarget(BuildThemes.MEDIEVAL, "minecraft:stone"));
    }

    @Test
    void everyThemeChangesSomething() {
        for (BuildTheme theme : BuildThemes.all()) {
            boolean any = retarget(theme, "minecraft:stone") != null
                    || retarget(theme, "minecraft:oak_planks") != null
                    || retarget(theme, "minecraft:cobblestone") != null;
            assertTrue(any, theme.id() + " restyles nothing at all");
        }
    }

    // --- what must not happen ---------------------------------------------------------------------

    @Test
    void mechanismsAreNeverRestyled() {
        List<String> untouchable = List.of(
                "minecraft:redstone_wire", "minecraft:redstone_torch", "minecraft:redstone_lamp",
                "minecraft:redstone_block", "minecraft:repeater", "minecraft:comparator",
                "minecraft:observer", "minecraft:piston", "minecraft:sticky_piston",
                "minecraft:piston_head", "minecraft:tnt", "minecraft:hopper",
                "minecraft:dispenser", "minecraft:dropper", "minecraft:lever", "minecraft:target",
                "minecraft:note_block", "minecraft:chest", "minecraft:trapped_chest",
                "minecraft:furnace", "minecraft:rail", "minecraft:powered_rail",
                "minecraft:detector_rail", "minecraft:activator_rail", "minecraft:slime_block",
                "minecraft:honey_block", "minecraft:obsidian", "minecraft:iron_door",
                "minecraft:iron_trapdoor", "minecraft:daylight_detector", "minecraft:sculk_sensor",
                "minecraft:oak_sign", "minecraft:spawner", "minecraft:command_block");

        for (BuildTheme theme : BuildThemes.all()) {
            for (String blockId : untouchable) {
                assertNull(retarget(theme, blockId),
                        theme.id() + " would have restyled " + blockId);
            }
        }
    }

    /**
     * Wooden and stone plates and buttons are not interchangeable - the wooden ones detect items and
     * hold their pulse half as long again - so a wood-to-stone theme must not convert them.
     */
    @Test
    void buttonsAndPressurePlatesKeepTheirWiring() {
        for (BuildTheme theme : BuildThemes.all()) {
            assertNull(retarget(theme, "minecraft:oak_button"), theme.id());
            assertNull(retarget(theme, "minecraft:oak_pressure_plate"), theme.id());
            assertNull(retarget(theme, "minecraft:stone_button"), theme.id());
            assertNull(retarget(theme, "minecraft:stone_pressure_plate"), theme.id());
        }
    }

    @Test
    void shapeIsAlwaysPreserved() {
        List<String> shaped = List.of(
                "minecraft:oak_stairs", "minecraft:oak_slab", "minecraft:oak_fence",
                "minecraft:oak_fence_gate", "minecraft:oak_door", "minecraft:oak_trapdoor",
                "minecraft:cobblestone_wall", "minecraft:stone_brick_slab",
                "minecraft:stone_brick_stairs", "minecraft:oak_log", "minecraft:oak_leaves");

        for (BuildTheme theme : BuildThemes.all()) {
            for (String blockId : shaped) {
                String target = retarget(theme, blockId);
                if (target == null) continue;                 // leaving it alone is always allowed

                BlockShape sourceShape = BlockShape.of(path(blockId)).shape();
                BlockShape targetShape = BlockShape.of(path(target)).shape();
                if (sourceShape == BlockShape.LOG) continue;  // a log may fall back to a cube

                assertEquals(sourceShape, targetShape,
                        theme.id() + ": " + blockId + " -> " + target + " changed shape");
            }
        }
    }

    @Test
    void nothingGainsGravity() {
        for (BuildTheme theme : BuildThemes.all()) {
            for (String blockId : List.of("minecraft:stone", "minecraft:dirt",
                    "minecraft:grass_block", "minecraft:oak_planks", "minecraft:cobblestone")) {
                String target = retarget(theme, blockId);
                if (target == null) continue;
                assertFalse(ThemeSafety.isFalling(target),
                        theme.id() + " turned " + blockId + " into a falling block");
            }
        }
    }

    @Test
    void sandStaysSandLike() {
        assertEquals("minecraft:sand", retarget(BuildThemes.DESERT, "minecraft:gravel"),
                "gravel already falls, so trading it for sand changes nothing structural");
        assertEquals("minecraft:red_sand", retarget(BuildThemes.MESA, "minecraft:sand"));
        assertNull(retarget(BuildThemes.MEDIEVAL, "minecraft:sand"),
                "a theme with no sand of its own leaves it alone");
    }

    // --- colours ----------------------------------------------------------------------------------

    @Test
    void colouredBlocksArePulledOntoTheThemesOwnColours() {
        // Medieval keeps white, light grey, grey, black, brown, red and green.
        assertEquals("minecraft:red_wool", retarget(BuildThemes.MEDIEVAL, "minecraft:magenta_wool"));
        assertEquals("minecraft:green_wool", retarget(BuildThemes.MEDIEVAL, "minecraft:lime_wool"));
        assertEquals("minecraft:brown_wool", retarget(BuildThemes.MEDIEVAL, "minecraft:yellow_wool"),
                "hue before brightness: yellow belongs with the earths, not with light grey");
        assertNull(retarget(BuildThemes.MEDIEVAL, "minecraft:brown_wool"),
                "a colour the theme already allows must stay exactly as it is");
        assertNull(retarget(BuildThemes.MEDIEVAL, "minecraft:white_wool"));
        assertEquals("minecraft:white_wool", retarget(BuildThemes.MODERN, "minecraft:pink_wool"),
                "with no warm hue in the palette a colour falls back to the grey of its brightness");
    }

    @Test
    void aColourSwapKeepsTheBlockFamily() {
        assertEquals("minecraft:red_carpet",
                retarget(BuildThemes.MEDIEVAL, "minecraft:magenta_carpet"));
        assertEquals("minecraft:red_stained_glass",
                retarget(BuildThemes.MEDIEVAL, "minecraft:magenta_stained_glass"));
        assertEquals("minecraft:red_stained_glass_pane",
                retarget(BuildThemes.MEDIEVAL, "minecraft:magenta_stained_glass_pane"));
        assertEquals("minecraft:red_terracotta",
                retarget(BuildThemes.MEDIEVAL, "minecraft:magenta_terracotta"));
        assertEquals("minecraft:red_concrete_powder",
                retarget(BuildThemes.MEDIEVAL, "minecraft:magenta_concrete_powder"),
                "powder for powder: both fall, so the build behaves the same");
    }

    @Test
    void colouredBlockEntitiesAreStillOffLimits() {
        for (BuildTheme theme : BuildThemes.all()) {
            assertNull(retarget(theme, "minecraft:magenta_bed"), theme.id());
            assertNull(retarget(theme, "minecraft:magenta_banner"), theme.id());
            assertNull(retarget(theme, "minecraft:magenta_shulker_box"), theme.id());
            assertNull(retarget(theme, "minecraft:magenta_candle"), theme.id());
        }
    }

    @Test
    void uncolouredBlocksAreNotDraggedIntoTheColourPath() {
        // Plain terracotta and plain glass carry no dye, so they are restyled as materials - by
        // the stone and glass roles - rather than being pulled onto a colour.
        assertEquals("minecraft:stone_bricks", retarget(BuildThemes.MEDIEVAL, "minecraft:terracotta"));
        assertEquals("minecraft:light_gray_stained_glass",
                retarget(BuildThemes.MEDIEVAL, "minecraft:glass"));
        assertNull(retarget(BuildThemes.MEDIEVAL, "minecraft:white_wool"),
                "white is in the medieval palette, so white wool has nowhere to go");
    }

    @Test
    void everyThemeColourIsARealDye() {
        for (BuildTheme theme : BuildThemes.all()) {
            assertFalse(theme.colours().isEmpty(), theme.id() + " has no colours at all");
            for (String colour : theme.colours()) {
                assertTrue(ThemeColours.isDye(colour), theme.id() + ": " + colour + " is not a dye");
            }
            // Every one of the sixteen has to land somewhere, or a build would come back part
            // recoloured and part not.
            for (String dye : ThemeColours.all()) {
                assertNotNull(ThemeColours.nearest(dye, theme.colours()), theme.id() + ": " + dye);
            }
        }
    }

    // --- ground -----------------------------------------------------------------------------------

    @Test
    void onlyTheDryThemesTouchTheGround() {
        assertEquals("minecraft:sandstone", retarget(BuildThemes.DESERT, "minecraft:dirt"));
        assertEquals("minecraft:sandstone", retarget(BuildThemes.DESERT, "minecraft:grass_block"));
        assertEquals("minecraft:terracotta", retarget(BuildThemes.MESA, "minecraft:coarse_dirt"));

        for (BuildTheme theme : List.of(BuildThemes.MEDIEVAL, BuildThemes.ANCIENT,
                BuildThemes.ASIAN, BuildThemes.MODERN, BuildThemes.FUTURISTIC)) {
            assertNull(retarget(theme, "minecraft:grass_block"),
                    theme.id() + " should leave the terrain a build sits on alone");
        }
    }

    @Test
    void unknownBlocksSurviveUntouched() {
        for (BuildTheme theme : BuildThemes.all()) {
            assertNull(retarget(theme, "somemod:arcane_pillar"));
            assertNull(retarget(theme, "minecraft:water"));
            assertNull(retarget(theme, "minecraft:oak_leaves_that_do_not_exist"));
        }
    }

    @Test
    void waxedCopperIsLeftToStayTheColourItWasWaxedAt() {
        for (BuildTheme theme : BuildThemes.all()) {
            assertNull(retarget(theme, "minecraft:waxed_copper_block"), theme.id());
            assertNull(retarget(theme, "minecraft:waxed_cut_copper"), theme.id());
        }
        assertNotNull(retarget(BuildThemes.MEDIEVAL, "minecraft:copper_block"),
                "unwaxed copper is weathering anyway, so restyling it changes nothing about it");
    }

    @Test
    void everyPaletteEntryIsAnOrdinaryBuildingBlock() {
        for (BuildTheme theme : BuildThemes.all()) {
            for (ThemeVariant variant : theme.variants()) {
                String where = theme.id() + "/" + variant.id();
                for (StyleRole role : StyleRole.values()) {
                    List<StyleMaterial> alternatives = variant.palette().get(role);
                    if (alternatives == null) continue;

                    for (StyleMaterial material : alternatives) {
                        BlockShape shape = BlockShape.of(path(material.block())).shape();
                        assertFalse(ThemeSafety.isProtected(material.block()),
                                where + " builds with " + material.block());
                        if (role == StyleRole.GLASS_PANE) {
                            // The one role whose target is deliberately not a cube: a pane can
                            // only ever stand in for another pane.
                            assertEquals(BlockShape.STAINED_GLASS_PANE, shape,
                                    where + ": " + material.block() + " is not a pane");
                        } else {
                            assertTrue(ThemeSafety.fillsItsCube(material.block(), shape),
                                    where + ": " + material.block() + " is not a full cube");
                        }
                        assertTrue(variants.isKnown(material.block()),
                                where + ": " + material.block() + " is not a real block");

                        // Ground has no shaped family; every masonry and timber stem must have
                        // one, or a build's stairs would be left behind by the restyle.
                        if (role == StyleRole.SAND || role == StyleRole.GROUND) continue;
                        for (String stem : material.stems()) {
                            assertNotNull(variants.resolve(stem, BlockShape.SLAB),
                                    where + ": no slab for the stem " + stem);
                        }
                    }
                }
            }
        }
    }

    // --- coverage ---------------------------------------------------------------------------------

    /**
     * The material of a cube is what is left when the shape suffix comes off, which is not the
     * material its stairs are made of: {@code mossy_stone_bricks} is {@code mossy_stone} while
     * {@code mossy_stone_brick_stairs} is {@code mossy_stone_brick}. Missing the first spelling
     * left brick cubes - most of a stone build - untouched by every theme.
     */
    @Test
    void brickCubesAreRestyledAndNotOnlyTheirStairs() {
        for (String brick : List.of("minecraft:mossy_stone_bricks",
                "minecraft:cracked_stone_bricks", "minecraft:chiseled_stone_bricks")) {
            assertNotNull(retarget(BuildThemes.FUTURISTIC, brick), brick);
            assertNotNull(retarget(BuildThemes.DESERT, brick), brick);
        }
        // The cube and its stairs must also land in the same family, or a brick wall would come
        // out of the restyle in two different materials.
        String cube = retarget(BuildThemes.DESERT, "minecraft:mossy_stone_bricks");
        String stairs = retarget(BuildThemes.DESERT, "minecraft:mossy_stone_brick_stairs");
        assertTrue(cube != null && cube.contains("sandstone"), "cube went to " + cube);
        assertTrue(stairs != null && stairs.contains("sandstone"), "stairs went to " + stairs);
    }

    @Test
    void windowsCopperAndLightsAreRestyledToo() {
        // The three families a build is full of that used to come through a theme untouched.
        assertEquals("minecraft:light_gray_stained_glass",
                retarget(BuildThemes.MEDIEVAL, "minecraft:glass"));
        assertEquals("minecraft:light_gray_stained_glass_pane",
                retarget(BuildThemes.MEDIEVAL, "minecraft:glass_pane"),
                "a pane may only ever become another pane");
        assertEquals("minecraft:oxidized_copper",
                retarget(BuildThemes.MEDIEVAL, "minecraft:copper_block"));
        assertEquals("minecraft:oxidized_cut_copper_stairs",
                retarget(BuildThemes.MEDIEVAL, "minecraft:cut_copper_stairs"));
        assertEquals("minecraft:sea_lantern",
                retarget(BuildThemes.MODERN, "minecraft:glowstone"));
        assertEquals("minecraft:glowstone",
                retarget(BuildThemes.MEDIEVAL, "minecraft:sea_lantern"),
                "sea_lantern reads as a lantern by its name but is a cube like the rest");
    }

    @Test
    void aThemeChangesMostOfAnOrdinaryBuild() {
        // What a house is actually made of, mechanisms aside. A theme that leaves most of this
        // alone is not doing its job, whatever its palette says.
        List<String> build = List.of(
                "minecraft:stone", "minecraft:cobblestone", "minecraft:stone_bricks",
                "minecraft:mossy_stone_bricks", "minecraft:chiseled_stone_bricks",
                "minecraft:andesite", "minecraft:granite", "minecraft:bricks",
                "minecraft:deepslate_bricks", "minecraft:quartz_block", "minecraft:terracotta",
                "minecraft:oak_planks", "minecraft:oak_stairs", "minecraft:oak_slab",
                "minecraft:oak_fence", "minecraft:oak_log", "minecraft:oak_leaves",
                "minecraft:spruce_planks", "minecraft:cobblestone_wall",
                "minecraft:stone_brick_stairs", "minecraft:glass", "minecraft:glass_pane",
                "minecraft:copper_block", "minecraft:glowstone", "minecraft:magenta_wool");

        for (BuildTheme theme : BuildThemes.all()) {
            int changed = 0;
            for (String blockId : build) {
                if (retarget(theme, blockId) != null) changed++;
            }
            assertTrue(changed * 100 / build.size() >= 60,
                    theme.id() + " restyles only " + changed + " of " + build.size()
                            + " ordinary building blocks");
        }
    }

    // --- combinations -----------------------------------------------------------------------------

    @Test
    void everyThemeOffersSeveralCombinations() {
        for (BuildTheme theme : BuildThemes.all()) {
            assertTrue(theme.availableVariants(variants).size() > 1,
                    theme.id() + " offers nothing to choose between");
            assertEquals("default", theme.defaultVariant().id(),
                    theme.id() + ": the first combination is what old save files mean");
        }
    }

    @Test
    void combinationsOfOneThemeActuallyDiffer() {
        // Two combinations that dress the same build identically are not worth offering twice.
        for (BuildTheme theme : BuildThemes.all()) {
            List<ThemeVariant> available = theme.availableVariants(variants);
            for (int i = 1; i < available.size(); i++) {
                assertNotEquals(fingerprint(available.get(0)), fingerprint(available.get(i)),
                        theme.id() + ": " + available.get(i).id() + " looks like the default");
            }
        }
    }

    /** What a combination does to a handful of ordinary blocks, as a comparable string. */
    private String fingerprint(ThemeVariant variant) {
        StringBuilder out = new StringBuilder();
        for (String blockId : List.of("minecraft:stone", "minecraft:cobblestone",
                "minecraft:stone_bricks", "minecraft:oak_planks", "minecraft:oak_stairs",
                "minecraft:dirt")) {
            out.append(variant.retargetId(blockId, variants)).append('|');
        }
        return out.toString();
    }

    @Test
    void everyCombinationIsAsSafeAsTheDefault() {
        // The guards sit below the palette, so they hold for every combination rather than only
        // for the one that happened to be written first.
        for (BuildTheme theme : BuildThemes.all()) {
            for (ThemeVariant variant : theme.variants()) {
                String where = theme.id() + "/" + variant.id();
                for (String blockId : List.of("minecraft:redstone_wire", "minecraft:repeater",
                        "minecraft:sticky_piston", "minecraft:tnt", "minecraft:hopper",
                        "minecraft:oak_pressure_plate", "minecraft:stone_button",
                        "minecraft:powered_rail", "minecraft:chest")) {
                    assertNull(variant.retargetId(blockId, variants),
                            where + " would have restyled " + blockId);
                }
                String ground = variant.retargetId("minecraft:dirt", variants);
                assertFalse(ground != null && ThemeSafety.isFalling(ground),
                        where + " turned the ground into a falling block");
            }
        }
    }

    // --- other game versions ----------------------------------------------------------------------

    /**
     * A 1.19.2-era registry: no cherry or bamboo wood, no tuff family, no pale oak.
     *
     * <p>Buildmatic compiles from one source tree for 1.19.2 upwards and builds its index from
     * whatever blocks the running game reports, so the themes have to survive being asked for
     * blocks that do not exist yet.
     */
    private static VariantIndex oldVariants() {
        List<String> ids = new ArrayList<>();
        for (String id : sampleRegistry()) {
            if (id.contains("cherry") || id.contains("bamboo") || id.contains("pale_oak")
                    || id.contains("tuff") || id.contains("resin")) {
                continue;
            }
            ids.add(id);
        }
        return VariantIndex.build(ids, ColorIndex.EMPTY);
    }

    @Test
    void combinationsTheVersionCannotBuildAreNotOffered() {
        VariantIndex old = oldVariants();

        ThemeVariant tuff = BuildThemes.MEDIEVAL.variantById("tuff");
        assertNotNull(tuff);
        assertTrue(tuff.isAvailableIn(variants), "the tuff keep needs 1.21 blocks and they are here");
        assertFalse(tuff.isAvailableIn(old),
                "a combination the version has no blocks for would just sit there doing nothing");
        assertFalse(BuildThemes.MEDIEVAL.availableVariants(old).contains(tuff));
    }

    @Test
    void everyThemeStillWorksOnAnOldVersion() {
        VariantIndex old = oldVariants();
        for (BuildTheme theme : BuildThemes.all()) {
            assertFalse(theme.availableVariants(old).isEmpty(),
                    theme.id() + " has nothing left to offer on 1.19.2");

            for (ThemeVariant variant : theme.availableVariants(old)) {
                String where = theme.id() + "/" + variant.id();
                assertNotNull(variant.retargetId("minecraft:stone", old),
                        where + " leaves plain stone alone on 1.19.2");

                // Not oak specifically: a combination whose own timber is oak leaves oak alone,
                // and rightly so. What matters is that its wood resolves to something at all.
                boolean anyWood = false;
                for (String wood : List.of("oak", "spruce", "birch", "jungle", "acacia",
                        "dark_oak")) {
                    if (variant.retargetId("minecraft:" + wood + "_planks", old) != null) {
                        anyWood = true;
                        break;
                    }
                }
                assertTrue(anyWood, where + " converts no wood at all on 1.19.2");
            }
        }
    }

    @Test
    void aThemeFallsBackWhenItsWoodDoesNotExistYet() {
        assertEquals("minecraft:bamboo_planks",
                BuildThemes.ASIAN.retargetId("minecraft:oak_planks", variants));
        assertEquals("minecraft:birch_planks",
                BuildThemes.ASIAN.retargetId("minecraft:oak_planks", oldVariants()),
                "bamboo is a 1.20 block, so an older world gets the fallback rather than nothing");
    }

    @Test
    void noThemeEverNamesABlockTheVersionDoesNotHave() {
        // The invariant the whole cross-version story rests on: a restyle can only produce blocks
        // the running game actually knows, or the schematic would end up holding a phantom id.
        for (VariantIndex registry : List.of(variants, oldVariants())) {
            for (BuildTheme theme : BuildThemes.all()) {
                for (ThemeVariant variant : theme.availableVariants(registry)) {
                    for (String blockId : sampleRegistry()) {
                        String target = variant.retargetId(blockId, registry);
                        if (target == null) continue;
                        assertTrue(registry.isKnown(target),
                                theme.id() + "/" + variant.id() + ": " + blockId + " -> " + target
                                        + ", which this version does not have");
                    }
                }
            }
        }
    }

    // --- through the engine -----------------------------------------------------------------------

    @Test
    void aThemeIsOneFastLayer() {
        Schematic schematic = Schematic.single("Test", new Vec3i(8, 4, 8));
        SchematicRegion region = schematic.region(0);
        for (int x = 0; x < 8; x++) {
            for (int z = 0; z < 8; z++) {
                region.setBlock(x, 0, z, BlockStateRef.of("minecraft:stone"));
                region.setBlock(x, 1, z, BlockStateRef.of("minecraft:oak_planks"));
            }
        }
        region.setBlock(0, 2, 0, BlockStateRef.of("minecraft:redstone_wire"));
        region.setBlock(1, 2, 0, BlockStateRef.of("minecraft:repeater"));
        region.setBlock(2, 2, 0, BlockStateRef.of("minecraft:sticky_piston"));
        schematic.refreshStatistics();

        SwapEngine engine = new SwapEngine(schematic, variants, BlockStateSchema.PERMISSIVE);
        SwapLayer layer = SwapLayer.of("Medieval theme", SwapRule.of(
                new SwapRule.Matcher.Any(),
                new SwapRule.Target.Themed(BuildThemes.MEDIEVAL)));

        assertTrue(layer.isPaletteResolvable(),
                "a theme must fold into the palette or a big build would restyle block by block");
        engine.addLayer(layer);

        assertEquals(BlockStateRef.of("minecraft:stone_bricks"), engine.stateAt(region, 3, 0, 3));
        assertEquals(BlockStateRef.of("minecraft:spruce_planks"), engine.stateAt(region, 3, 1, 3));
        assertEquals(BlockStateRef.of("minecraft:redstone_wire"), engine.stateAt(region, 0, 2, 0));
        assertEquals(BlockStateRef.of("minecraft:repeater"), engine.stateAt(region, 1, 2, 0));
        assertEquals(BlockStateRef.of("minecraft:sticky_piston"), engine.stateAt(region, 2, 2, 0));

        ThemeReport report = ThemeReport.of(BuildThemes.MEDIEVAL, schematic, variants);
        assertEquals(2, report.restyledTypes());
        assertEquals(3, report.guardedTypes(), "the redstone should be reported, not silently kept");
        assertEquals(128, report.restyledBlocks());
    }

    private static String path(String blockId) {
        return blockId.substring(blockId.indexOf(':') + 1);
    }
}
