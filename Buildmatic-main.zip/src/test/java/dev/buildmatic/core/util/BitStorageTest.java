package dev.buildmatic.core.util;

import dev.buildmatic.core.schematic.SchematicRegion;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class BitStorageTest {

    @ParameterizedTest
    @ValueSource(ints = {2, 3, 4, 5, 7, 11, 17, 31, 32})
    void roundTripsEveryValueInBothLayouts(int bits) {
        for (BitStorage.Layout layout : BitStorage.Layout.values()) {
            Random random = new Random(bits * 31L + layout.ordinal());
            int size = 1000;
            BitStorage storage = new BitStorage(bits, size, layout);
            long mask = bits == 32 ? 0xFFFFFFFFL : (1L << bits) - 1;

            int[] expected = new int[size];
            for (int i = 0; i < size; i++) {
                expected[i] = (int) (random.nextInt() & mask);
                storage.set(i, expected[i]);
            }
            for (int i = 0; i < size; i++) {
                assertEquals(expected[i], storage.get(i),
                        "index " + i + " with " + bits + " bits, " + layout);
            }
        }
    }

    @ParameterizedTest
    @ValueSource(ints = {2, 3, 5, 11, 17})
    void resizePreservesEveryValue(int bits) {
        Random random = new Random(bits);
        int size = 500;
        BitStorage storage = new BitStorage(bits, size, BitStorage.Layout.PACKED);
        long mask = (1L << bits) - 1;
        int[] expected = new int[size];
        for (int i = 0; i < size; i++) {
            expected[i] = (int) (random.nextInt() & mask);
            storage.set(i, expected[i]);
        }

        BitStorage wider = storage.resize(bits + 3);
        assertEquals(bits + 3, wider.bits());
        for (int i = 0; i < size; i++) {
            assertEquals(expected[i], wider.get(i));
        }
    }

    @Test
    void convertingBetweenLayoutsPreservesEveryValue() {
        BitStorage packed = new BitStorage(5, 300, BitStorage.Layout.PACKED);
        for (int i = 0; i < 300; i++) packed.set(i, i % 32);

        BitStorage aligned = packed.convert(BitStorage.Layout.ALIGNED);
        assertEquals(BitStorage.Layout.ALIGNED, aligned.layout());
        for (int i = 0; i < 300; i++) {
            assertEquals(i % 32, aligned.get(i));
        }
    }

    @Test
    void bitsForCoversTheExactBoundaries() {
        assertEquals(1, BitStorage.bitsFor(0));
        assertEquals(1, BitStorage.bitsFor(1));
        assertEquals(2, BitStorage.bitsFor(2));
        assertEquals(2, BitStorage.bitsFor(3));
        assertEquals(3, BitStorage.bitsFor(4));
        assertEquals(3, BitStorage.bitsFor(7));
        assertEquals(4, BitStorage.bitsFor(8));
    }

    @Test
    void paletteWidthMatchesTheLitematicaRule() {
        // Litematica clamps to two bits and otherwise uses ceil(log2(paletteSize)).
        assertEquals(2, SchematicRegion.bitsForPalette(1));
        assertEquals(2, SchematicRegion.bitsForPalette(2));
        assertEquals(2, SchematicRegion.bitsForPalette(4));
        assertEquals(3, SchematicRegion.bitsForPalette(5));
        assertEquals(3, SchematicRegion.bitsForPalette(8));
        assertEquals(4, SchematicRegion.bitsForPalette(9));
    }

    @Test
    void rejectsAnUndersizedBackingArray() {
        assertThrows(IllegalArgumentException.class,
                () -> new BitStorage(8, 1000, BitStorage.Layout.PACKED, new long[2]));
    }

    @Test
    void rejectsOutOfRangeIndices() {
        BitStorage storage = new BitStorage(4, 10, BitStorage.Layout.PACKED);
        assertThrows(IndexOutOfBoundsException.class, () -> storage.get(10));
        assertThrows(IndexOutOfBoundsException.class, () -> storage.set(-1, 0));
    }
}
