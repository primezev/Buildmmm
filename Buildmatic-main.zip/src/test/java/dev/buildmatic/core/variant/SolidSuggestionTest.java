package dev.buildmatic.core.variant;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Regression cover for the shapeless {@code SOLID} bucket.
 *
 * <p>Asking for alternatives to {@code minecraft:bricks} once returned a page of dead coral fans:
 * none of them carry a recognised suffix, so they all landed in the same bucket as the bricks.
 */
class SolidSuggestionTest {

    /** Scenery: no recognised suffix, and nothing you can build with. */
    private static final Set<String> SCENERY = Set.of(
            "minecraft:dead_brain_coral_wall_fan",
            "minecraft:dead_bubble_coral",
            "minecraft:dead_fire_coral_fan",
            "minecraft:dead_horn_coral",
            "minecraft:poppy",
            "minecraft:torch");

    /** Panes and glass block motion but do not fill their cube. */
    private static final Set<String> NOT_FULL_CUBES = Set.of("minecraft:glass");

    private static final List<String> REGISTRY = List.of(
            "minecraft:bricks", "minecraft:stone", "minecraft:deepslate", "minecraft:sandstone",
            "minecraft:netherrack", "minecraft:glass",
            "minecraft:dead_brain_coral_wall_fan", "minecraft:dead_bubble_coral",
            "minecraft:dead_fire_coral_fan", "minecraft:dead_horn_coral",
            "minecraft:poppy", "minecraft:torch");

    private static final BlockTraits TRAITS = new BlockTraits() {
        @Override public boolean isBuildingBlock(String blockId) { return !SCENERY.contains(blockId); }
        @Override public boolean isFullCube(String blockId) {
            return !SCENERY.contains(blockId) && !NOT_FULL_CUBES.contains(blockId);
        }
    };

    private static VariantIndex index() {
        return VariantIndex.build(REGISTRY, ColorIndex.EMPTY, TRAITS);
    }

    @Test
    void coralsAndFlowersAreNotAlternativesToBricks() {
        List<VariantIndex.Candidate> candidates =
                index().candidates("minecraft:bricks", VariantIndex.Query.materials());

        for (VariantIndex.Candidate candidate : candidates) {
            assertFalse(SCENERY.contains(candidate.kind().blockId()),
                    candidate.kind().blockId() + " is not something you build a wall out of");
        }
        assertFalse(candidates.isEmpty(), "real masonry should still be offered");
    }

    @Test
    void realBuildingBlocksSurvive() {
        List<String> ids = index().candidates("minecraft:bricks", VariantIndex.Query.materials())
                .stream().map(c -> c.kind().blockId()).toList();

        assertTrue(ids.contains("minecraft:stone"));
        assertTrue(ids.contains("minecraft:deepslate"));
        assertTrue(ids.contains("minecraft:sandstone"));
    }

    @Test
    void glassStaysAvailableButRanksBelowFullCubes() {
        List<VariantIndex.Candidate> candidates =
                index().candidates("minecraft:bricks", VariantIndex.Query.materials());
        List<String> ids = candidates.stream().map(c -> c.kind().blockId()).toList();

        assertTrue(ids.contains("minecraft:glass"),
                "swapping a wall to glass is a real choice, not nonsense");
        assertEquals(ids.size() - 1, ids.indexOf("minecraft:glass"),
                "but a block that does not fill its cube ranks last among the solids");
    }

    @Test
    void aCoralFindsOtherCoralsAndNoMasonry() {
        // The suffix rules put corals in their own shape, so they never see the masonry bucket.
        List<String> ids = index()
                .candidates("minecraft:dead_bubble_coral", VariantIndex.Query.materials())
                .stream().map(c -> c.kind().blockId()).toList();

        assertEquals(List.of("minecraft:dead_horn_coral"), ids);
    }

    @Test
    void sceneryLeftInTheSolidBucketStillAvoidsMasonry() {
        // A poppy carries no suffix at all, so it lands in SOLID with the bricks; only the
        // building-block check keeps the two apart.
        List<String> ids = index()
                .candidates("minecraft:poppy", VariantIndex.Query.materials())
                .stream().map(c -> c.kind().blockId()).toList();

        assertFalse(ids.contains("minecraft:bricks"));
        assertFalse(ids.contains("minecraft:stone"));
    }

    @Test
    void namedShapesAreUnaffectedByTheFilter() {
        VariantIndex index = VariantIndex.build(
                List.of("minecraft:oak_stairs", "minecraft:stone_stairs", "minecraft:glass"),
                ColorIndex.EMPTY, TRAITS);

        List<String> ids = index.candidates("minecraft:oak_stairs", VariantIndex.Query.materials())
                .stream().map(c -> c.kind().blockId()).toList();
        assertEquals(List.of("minecraft:stone_stairs"), ids, "a stair is a stair");
    }

    @Test
    void decorationSuffixesKeepScenerySeparateEvenWithoutTraits() {
        // Even with no physical information, the id itself should classify these away from SOLID.
        assertEquals(BlockShape.CORAL_WALL_FAN, BlockShape.of("dead_brain_coral_wall_fan").shape());
        assertEquals(BlockShape.CORAL_FAN, BlockShape.of("dead_fire_coral_fan").shape());
        assertEquals(BlockShape.CORAL, BlockShape.of("dead_bubble_coral").shape());
        assertEquals(BlockShape.TORCH, BlockShape.of("redstone_torch").shape());
        assertEquals(BlockShape.WALL_TORCH, BlockShape.of("soul_wall_torch").shape());
        assertEquals(BlockShape.LANTERN, BlockShape.of("soul_lantern").shape());
        assertEquals(BlockShape.SOLID, BlockShape.of("bricks").shape());
    }
}
