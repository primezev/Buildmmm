plugins {
    id("dev.kikugie.stonecutter")
}

stonecutter active "26.2.x"

stonecutter parameters {
    swaps["mod_version"] = "\"${property("mod.version")}\";"
    swaps["minecraft"] = "\"${node.metadata.version}\";"

    dependencies["fapi"] = node.project.property("deps.fabric_api") as String

    replacements {
        // Mojang renamed ResourceLocation -> Identifier in the official mappings from 1.21.11 on.
        // Source is written against `ResourceLocation`; older targets keep it, newer ones get swapped.
        string(current.parsed >= "1.21.11") {
            replace("ResourceLocation", "Identifier")
        }

        // Access wideners became class tweakers with the 26.1 unobfuscation.
        string(current.parsed >= "26.1") {
            replace("classTweaker v2 named", "classTweaker v2 official")
        }
    }
}
