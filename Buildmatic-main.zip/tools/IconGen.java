import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Draws Buildmatic's icon: a B built out of blocks, with one of them swapped to the accent colour
 * and a ghost block waiting in the notch above it - the mod in one letter.
 *
 * <p>Drawn flat rather than isometric on purpose. Modrinth and the mod list show this at 32-64px,
 * and an isometric letter turns to mush at that size; a face-on voxel grid still reads as a B.
 *
 * <p>Usage: {@code java IconGen.java <size> <out.png>}
 */
public final class IconGen {

    static final Color BG_TOP = new Color(0x1B2029);
    static final Color BG_BOTTOM = new Color(0x0B0D11);
    static final Color EDGE = new Color(0x0A0C0F);

    static final Color SLATE_TOP = new Color(0x8A97A9);
    static final Color SLATE_BOTTOM = new Color(0x414B59);

    static final Color CYAN_TOP = new Color(0x8ADCFB);
    static final Color CYAN_BOTTOM = new Color(0x2C7CA1);

    static final Color ACCENT = new Color(0x4FC3F7);

    /** How many block seams run across the letter. Sets how coarse the masonry looks. */
    static final int GRID = 5;

    public static void main(String[] args) throws Exception {
        int size = args.length > 0 ? Integer.parseInt(args[0]) : 512;
        String out = args.length > 1 ? args[1] : "icon.png";

        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        // Background: rounded panel in the same dark the mod's own panels use.
        g.setPaint(new GradientPaint(0, 0, BG_TOP, 0, size, BG_BOTTOM));
        g.fill(new RoundRectangle2D.Float(0, 0, size, size, size * 0.18f, size * 0.18f));

        // A soft accent glow behind the letter, so the cyan block reads as lit rather than painted.
        g.setPaint(new RadialGradientPaint(
                new Point2D.Float(size * 0.5f, size * 0.5f), size * 0.46f,
                new float[]{0f, 1f},
                new Color[]{new Color(0x4F, 0xC3, 0xF7, 42), new Color(0x4F, 0xC3, 0xF7, 0)}));
        g.fillRect(0, 0, size, size);

        // The letter is drawn as a real letterform, not assembled from grid cells. Built from cells
        // the bowls never close: the end of each bar meets the side of its bowl at a corner, and
        // whether they are spaced or merged the eye reads a C or an E with debris beside it. A
        // solid B with the masonry laid over it keeps both the letter and the blocks.
        float w = size * 0.50f;
        float h = size * 0.66f;
        float x0 = (size - w) / 2f;
        float y0 = (size - h) / 2f;
        float t = w * 0.30f;
        float stroke = Math.max(1f, size / 110f);

        java.awt.geom.Area letter = letterB(x0, y0, w, h, t);

        g.setPaint(new GradientPaint(0, y0, SLATE_TOP, 0, y0 + h, SLATE_BOTTOM));
        g.fill(letter);

        // One course of the masonry swapped to the accent: the mod's whole idea, in one block.
        float pitch = h / GRID;
        var accent = new java.awt.geom.Area(new java.awt.geom.Rectangle2D.Float(
                x0 + t, y0 + 2 * pitch, pitch, pitch));
        accent.intersect(letter);
        if (!accent.isEmpty()) {
            var bounds = accent.getBounds2D();
            g.setPaint(new GradientPaint(0, (float) bounds.getMinY(), CYAN_TOP,
                    0, (float) bounds.getMaxY(), CYAN_BOTTOM));
            g.fill(accent);
        }

        seams(g, letter, x0, y0, w, h, pitch, stroke);

        g.setColor(EDGE);
        g.setStroke(new BasicStroke(stroke * 2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(letter);

        g.dispose();
        File file = new File(out);
        ImageIO.write(image, "png", file);
        System.out.println("wrote " + file.getAbsolutePath() + " (" + size + "x" + size + ")");
    }

    /**
     * The B as a letterform: a stem with two bowls hung off it.
     *
     * <p>Each bowl is a rounded rectangle with a smaller one cut out of it. Rounding all four
     * corners is fine because the stem is laid over the left pair, so only the right ones show.
     */
    static java.awt.geom.Area letterB(float x, float y, float w, float h, float t) {
        float bowlH = h / 2f + t / 2f;
        float outerR = bowlH * 0.52f;
        float innerR = Math.max(0f, outerR - t);

        java.awt.geom.Area letter = new java.awt.geom.Area(
                new java.awt.geom.Rectangle2D.Float(x, y, t, h));
        letter.add(bowl(x, y, w, bowlH, t, outerR, innerR));
        // The lower bowl is the wider of the two, the way most typefaces cut a B.
        letter.add(bowl(x, y + h - bowlH, w * 1.06f, bowlH, t, outerR, innerR));
        return letter;
    }

    static java.awt.geom.Area bowl(float x, float y, float w, float h, float t,
                                   float outerR, float innerR) {
        java.awt.geom.Area area = new java.awt.geom.Area(
                new RoundRectangle2D.Float(x, y, w, h, outerR, outerR));
        area.subtract(new java.awt.geom.Area(new RoundRectangle2D.Float(
                x + t, y + t, w - 2 * t, h - 2 * t, innerR, innerR)));
        return area;
    }

    /**
     * The masonry inside the letter, so it reads as stacked blocks rather than a flat glyph.
     *
     * <p>Clipped to the letter, so only the interior seams land; the outline is drawn afterwards.
     * Each seam gets a light line beside a dark one, which is the whole bevel: at 64px both fade
     * out and leave a clean letter, at 512 they read as blocks.
     */
    static void seams(Graphics2D g, java.awt.geom.Area letter, float x0, float y0,
                      float w, float h, float pitch, float stroke) {
        java.awt.Shape clip = g.getClip();
        g.clip(letter);
        g.setStroke(new BasicStroke(stroke, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER));

        for (float x = x0 + pitch; x < x0 + w * 1.1f; x += pitch) {
            line(g, x, y0, x, y0 + h, stroke, true);
        }
        for (float y = y0 + pitch; y < y0 + h; y += pitch) {
            line(g, x0, y, x0 + w * 1.1f, y, stroke, false);
        }
        g.setClip(clip);
    }

    /** One seam: a dark line with a lighter one just past it, for the bevel. */
    static void line(Graphics2D g, float x1, float y1, float x2, float y2, float stroke,
                     boolean vertical) {
        g.setColor(new Color(0, 0, 0, 48));
        g.draw(new java.awt.geom.Line2D.Float(x1, y1, x2, y2));

        g.setColor(new Color(255, 255, 255, 22));
        float dx = vertical ? stroke : 0;
        float dy = vertical ? 0 : stroke;
        g.draw(new java.awt.geom.Line2D.Float(x1 + dx, y1 + dy, x2 + dx, y2 + dy));
    }
}
